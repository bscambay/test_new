﻿using INSIGHT_Request.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace INSIGHT_RequestTests
{
    [TestClass]
    public class WebApiTests
    {
        private string _hostName = "localhost";
        private string _url = string.Empty;

        #region Constructors
        public WebApiTests()
        {

        }

        public WebApiTests(string url)
        {
            UnitTestHelper.SetHttpContextWithSimulatedRequest(_hostName, url);

            InitCache a = new InitCache();
            a.addCacheObjects();
        }

        #endregion

        [TestMethod]
        public void casepinsearch()
        {
            //            
            //Test controller action method casepinsearch            
            //
            string searchResultJSON = string.Empty;
            string url = "http://localhost:56294/insight-request/insightuser/casepinsearch";

            string resultContains = "\"CLMT_NM25\"";

            // Arrange            
            WebApiTests w = new WebApiTests(url);
            var controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("casepin", "897960");
            controller.Configuration = new HttpConfiguration();

            // Act
            var response = controller.casepinsearch();
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains(resultContains));

            //Test for failure
            //due to bad data
            controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("userid", "897960");
            controller.Configuration = new HttpConfiguration();

            // Act
            response = controller.casepinsearch();
            response.TryGetContentValue<string>(out searchResultJSON);

            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains("Missing PIN/Some error occurred"));
            Assert.AreEqual(HttpStatusCode.InternalServerError, response.StatusCode);

            //Test for failure
            //due to bad data
            controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("casepin", "123456");
            controller.Configuration = new HttpConfiguration();

            // Act
            response = controller.casepinsearch();
            response.TryGetContentValue<string>(out searchResultJSON);

            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains("{\"Error\":\"User or Office not Authorized\"}"));
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
        }


        [TestMethod]

        public void casessnsearch()
        {
            //            
            //Test controller action method casessnsearch            
            //
            string searchResultJSON = string.Empty;
            string url = "http://localhost:56294/insight-request/insightuser/casessnsearch";
            string resultContains = "\"HOFC_WRK_UNIT_UID\"";

            // Arrange            
            WebApiTests w = new WebApiTests(url);
            var controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();

            ////Add pin as header parameter
            controller.Request.Headers.Add("casepin", "897960");

            ////Add ssn as body parameter
            INSIGHT_Request.Models.OAORouteParameters rparm = new INSIGHT_Request.Models.OAORouteParameters();
            rparm.searchssn = "250459808";            
            controller.Configuration = new HttpConfiguration();

            // Act
            var response = controller.casessnsearch(rparm);
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            try
            {
                Assert.IsTrue(searchResultJSON.Contains(resultContains));
            }
            catch (System.Exception x)
            {
                Assert.IsTrue(searchResultJSON.Contains("No claims associated with this user"));
            }
            
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

        }

        [TestMethod]
        public void admincases()
        {
            //            
            //Test controller action method admincases            
            //            

            // Arrange            
            string searchResultJSON = string.Empty;
            string url = "http://localhost:56294/insight-request/insightuser/admincases";
            string resultContains = "Administrator";
            WebApiTests w = new WebApiTests(url);
            var controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();

            string adminpin = "000005";
            int checkforAdminOnly = 1;
            url = string.Format("{0}/{1}", url, checkforAdminOnly);            
                        
            controller.Configuration = new HttpConfiguration();
            //Add pin as header parameter
            controller.Request.Headers.Add("adminpin", adminpin);

            // Act
            var response = controller.admincases(checkforAdminOnly);
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Equals(resultContains));
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

            // Arrange                        
            url = "http://localhost:56294/insight-request/insightuser/admincases";
            resultContains = "Not Administrator";            
            controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();

            adminpin = "000000";            
            url = string.Format("{0}/{1}", url, checkforAdminOnly);            
            controller.Configuration = new HttpConfiguration();
            //Add pin as header parameter
            controller.Request.Headers.Add("adminpin", adminpin);

            // Act
            response = controller.admincases(checkforAdminOnly);
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Equals(resultContains));
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

            // Arrange                        
            url = "http://localhost:56294/insight-request/insightuser/admincases";
            resultContains = "\"HOFC_DSPN_DT\"";           
            controller = new InsightUserController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            adminpin = "000005";
            checkforAdminOnly = 0;

            //Add pin as header parameter
            controller.Request.Headers.Add("adminpin", adminpin);
            controller.Request.Headers.Add("casepin", "897960");            

            // Act
            response = controller.admincases(checkforAdminOnly);
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains(resultContains));
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

        }

        [TestMethod]
        public void medexpertdata()
        {
            //            
            //Test controller action method            
            //
            string searchResultJSON = string.Empty;
            string url = "http://localhost:56294/insight-request/insightsqlapi/structdata/medexpertdata";

            string resultContains = "\"HEDULVL_CD\"";

            // Arrange            
            WebApiTests w = new WebApiTests(url);
            var controller = new InsightSqlApiController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            // Act
            var response = controller.casefromfolder();
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains(resultContains));

        }

        [TestMethod]
        public void mergedcasesdata()
        {
            //            
            //Test controller action method             
            //
            string searchResultJSON = string.Empty;
            string url = "http://localhost:56294/insight-request/insightsqlapi/structdata/merged-case-data";

            string resultContains = "\"DOCU_CTL_ID\"";

            // Arrange            
            WebApiTests w = new WebApiTests(url);
            var controller = new InsightSqlApiController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            // Act
            var response = controller.GetMergedCaseData();
            response.TryGetContentValue<string>(out searchResultJSON);

            // Assert                        
            Assert.IsNotNull(searchResultJSON);
            Assert.IsTrue(searchResultJSON.Contains(resultContains));

        }
    }
}
