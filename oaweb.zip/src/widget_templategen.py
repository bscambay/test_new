# INSIGHT QUALITY ANALYSIS TEMPLATE GENERATION WIDGET
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 04.14.2017
#
# SUMMARY:
# This script is designed to act as a 'widget' for the OAO version of
# INSIGHT.  It generates, with varying levels of customization, a pre-filled
# analysis template Microsoft Word document (.docx) file for use by the OAO
# analyst as they complete their analysis of the hearing disposition to which
# the INSIGHT web app page they generate from pertains.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os
import os.path
import re
import math
from shutil import copyfile

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.shared import Inches, Pt
from docx.shared import RGBColor

import database_actions as ifsda
import date_helper as dh
import iqrgenerator.iqrgenerator_common_calcs as ifsiqrcc
import nlp_helper

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
tempdir = os.path.join(insightdir, "temp")
templatedir = os.path.join(insightdir, "Templates")
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Template generator for default template with NO custom settings:
def template_generator(requestid):
    '''TIP: Should ALWAYS create a file
    and return a file name string formatted ideally
    as [requestid].docx.'''
    try:
        if not os.path.exists(tempdir):
            os.mkdir(tempdir)
        # (1) Attempt to retrieve INSIGHT observation data associated with REQID:
        insight_obs_dict = 'U'
        insight_obs_dict_raw = ifsda.retrieve_case_entity_schema2(requestid)

        # (2)(A) If unable to retrieve the INSIGHT observation data,
        # return the error template:
        if insight_obs_dict_raw in ['U', 'E']:
            template_fn = str(requestid) + '.docx'
            template_fp = os.path.join(tempdir, template_fn)
            template_err_fp = os.path.join(templatedir, "template_err_database.docx")
            copyfile(template_err_fp, template_fp)
            return template_fn

        # (2)(B) Else use INSIGHT observation data to create custom
        # analysis template document:
        else:

            # Add 'normalization' akin to what happens in iqrgenerator.py:
            # Normalize input dict values:
            insight_obs_dict = {}
            for k, v in insight_obs_dict_raw.iteritems():
                if not isinstance(v, dict):
                    if v is None or (isinstance(v, float) and math.isnan(v)) or (isinstance(v, str) and v == ''):
                        insight_obs_dict[k] = 'U'
                    else:
                        insight_obs_dict[k] = v
                else:
                    chd_dictlist = v.values()
                    chd_dictlist_nml = []
                    for chd_d in chd_dictlist:
                        chd_d_nml = {}
                        for subk, subv in chd_d.iteritems():
                            if subv is None or (isinstance(subv, float) and math.isnan(subv)) or (
                                    (isinstance(subv), str) and subv == ''):
                                chd_d_nml[k] = 'U'
                            else:
                                chd_d_nml[k] = subv
                        chd_dictlist_nml.append(chd_d_nml)
                    insight_obs_dict[k] = chd_dictlist_nml

            # Add 'CLAIMDISP_STRUCT' and subvalues:
            insight_obs_dict['CLAIMDISP_STRUCT'] = ifsiqrcc.convert_struct_claimdisp(insight_obs_dict['struct_hodisp'])
            claimtypelist = [subd['CLM_TYP'] for subd in insight_obs_dict['CLAIMDISP_STRUCT']]
            disptypestr = ifsiqrcc.parse_disp_type_struct(insight_obs_dict['CLAIMDISP_STRUCT'])

            # (2)(B)(1) Create Document object using custom
            # 'template.docx' and define custom styles:
            document = Document(os.path.join(templatedir, "template.docx"))

            # Define document font/paragraph/margin styles:
            stylepar = document.styles.add_style('Zoom', WD_STYLE_TYPE.PARAGRAPH)
            paragraph_format = stylepar.paragraph_format
            paragraph_format.space_before = Pt(0)
            paragraph_format.space_after = Pt(0)
            paragraph_format.widow_control = False
            font = stylepar.font
            font.name = 'Calibri'
            font.size = Pt(11)

            redpar = document.styles.add_style('Zoom3', WD_STYLE_TYPE.PARAGRAPH)
            paragraph_format = redpar.paragraph_format
            paragraph_format.space_before = Pt(0)
            paragraph_format.space_after = Pt(0)
            paragraph_format.widow_control = False
            font = redpar.font
            font.name = 'Calibri'
            font.size = Pt(11)
            font.color.rgb = RGBColor(255, 000, 000)

            hangingindent_s2 = document.styles.add_style('Zoom2', WD_STYLE_TYPE.PARAGRAPH)
            paragraph_format = hangingindent_s2.paragraph_format
            paragraph_format.space_before = Pt(0)
            paragraph_format.space_after = Pt(0)
            paragraph_format.widow_control = False
            paragraph_format.left_indent = Inches(0.24)
            paragraph_format.first_line_indent = Inches(-0.24)
            font = hangingindent_s2.font
            font.name = 'Calibri'
            font.size = Pt(11)

            styleparbold = document.styles.add_style('Indent', WD_STYLE_TYPE.PARAGRAPH)
            paragraph_format = styleparbold.paragraph_format
            paragraph_format.space_before = Pt(0)
            paragraph_format.space_after = Pt(0)
            paragraph_format.widow_control = True
            font = styleparbold.font
            font.name = 'Calibri'
            font.size = Pt(11)
            font.bold = True

            styletbl = document.styles.add_style('Table', WD_STYLE_TYPE.TABLE)
            paragraph_format = styletbl.paragraph_format
            paragraph_format.space_before = Pt(0)
            paragraph_format.space_after = Pt(0)
            paragraph_format.widow_control = True
            font = styletbl.font
            font.name = 'Calibri'
            font.size = Pt(11)

            sections = document.sections
            section = sections[0]
            section.left_margin = Inches(0.75)
            section.right_margin = Inches(0.75)
            section.top_margin = Inches(0.75)
            section.bottom_margin = Inches(0.75)

            # (2)(B)(3) Write document paragraphs:
            p = document.add_paragraph("", style=stylepar)

            # Claimant name:
            p.add_run("CLAIMANT:  ").bold = True
            try:
                clnm_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp', 'CLMT_NM25',
                                                                     'U', 'U', 'U')
                if not clnm_struct_val_list:
                    clnm = insight_obs_dict['clnm']
                    p.add_run(clnm).bold = True
                else:
                    if len(list(set(clnm_struct_val_list))) == 1:
                        p.add_run(clnm_struct_val_list[0].strip()).bold = True
                    else:
                        clnm = insight_obs_dict['clnm']
                        p.add_run(clnm).bold = True
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run('__').bold = True

            # SSN:
            p.add_run(" (SSN: ").bold = True
            try:
                clmt_ssn_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp', 'CLMT_SSN',
                                                                         'U', 'U', 'U')
                if not clmt_ssn_struct_val_list:
                    clmt_ssn = insight_obs_dict['ssn']
                    p.add_run(clmt_ssn).bold = True
                else:
                    if len(clmt_ssn_struct_val_list) == 1:
                        clmt_ssn_struct_val = clmt_ssn_struct_val_list[0]
                        clmt_ssn_struct_val_lastfour = "###-##-" + clmt_ssn_struct_val[5:]
                        p.add_run(clmt_ssn_struct_val_lastfour.strip()).bold = True
                        p.add_run(")").bold = True
                    else:
                        clmt_ssn = insight_obs_dict['ssn']
                        if clmt_ssn in ['U', 'P', 'E'] or bool(re.search(r"^[0-9]{9}$", clmt_ssn)) is False:
                            p.add_run('Unable to Retrieve SSN').bold = True
                            p.add_run(")").bold = True
                        else:
                            clmt_ssn_lastfour = "###-##-" + clmt_ssn[5:]
                            p.add_run(clmt_ssn_lastfour).bold = True
                            p.add_run(")").bold = True
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run('__)').bold = True

            # Critical status:
            try:
                crit_ver = 'N'
                crit_str = ''
                dn_ver = 0
                phom_ver = 0
                suic_ver = 0
                teri_ver = 0
                for subd in insight_obs_dict['struct_oao']:
                    if subd['DIRE_NEED_SW'] == 'Y':
                        dn_ver = 1
                        crit_ver = 'Y'
                    if subd['PTNTLY_HOMCDL_SW'] == 'Y':
                        phom_ver = 1
                        crit_ver = 'Y'
                    if subd['SUICIDL_SW'] == 'Y':
                        suic_ver = 1
                        crit_ver = 'Y'
                    if subd['TERI_SW'] == 'Y':
                        teri_ver = 1
                        crit_ver = 'Y'
                if crit_ver == 'Y':
                    crit_type_list = []
                    if dn_ver == 1:
                        crit_type_list.append('Dire Need')
                    if phom_ver == 1:
                        crit_type_list.append('Potentially Homicidal')
                    if suic_ver == 1:
                        crit_type_list.append('Suicidal')
                    if teri_ver == 1:
                        crit_type_list.append('Terminal Illness')
                    if crit_type_list:
                        crit_str = 'Critical Case: ' + '; '.join(crit_type_list)
                    else:
                        crit_str = 'Critical Case'
                    p = document.add_paragraph("", style=redpar)
                    p.add_run(crit_str).bold = True
            except Exception:
                logger.exception('EXCEPTION')
                p = document.add_paragraph("", style=redpar)
                p.add_run('Unable to Retrieve Critical Status').bold = True

            # Static Section Headings:
            p = document.add_paragraph("", style=stylepar)
            p.add_run("RECOMMENDATION:  ").bold = True
            p.add_run("\n")
            p.add_run("=== ").bold = True
            p.add_run("\n\n")

            p.add_run("ISSUES: ").bold = True
            p.add_run("\n\n")

            p.add_run("CONTENTIONS: ").bold = True
            p.add_run("\n\n")

            p.add_run("ADDITIONAL EV: ").bold = True
            p.add_run("\n\n")
            p.add_run("---").bold = True
            p.add_run("\n")

            p.add_run("Background: ").bold = True
            p.add_run("\n")

            # Add decision notes 'background' information (non-table):
            bg_tuplist = [("Claim(s)", "claimtype"), ("Disposition Type(s)", "disptype"), ("DOB", "CLMT_DOB"),
                          ("DOF", "dof"), ("AOD", "aod"), ("Disp. Date", "FNL_DSPN_DT"), ("DLI", "dli"),
                          ("Circuit", "circuit"), ("RR Timely", "CRNT_RQSTD_DT"),
                          ("Age at Start of PAI", "STRUCT_AGEREL_PAISTART"),
                          ("Age at End of PAI", "STRUCT_AGEREL_PAIEND")]
            for tup in bg_tuplist:

                # Claim Type(s):
                if tup[1] == 'claimtype':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        if not claimtypelist:
                            p.add_run('__')
                        else:
                            p.add_run('; '.join(claimtypelist))
                    p.add_run("\n")

                # Disposition Type(s):
                elif tup[1] == 'disptype':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        if disptypestr == '':
                            p.add_run('__')
                        else:
                            p.add_run(disptypestr)
                    p.add_run("\n")

                # DOB:
                elif tup[1] == "CLMT_DOB":
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        # Prioritize structured DOB over decision value:
                        struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp', 'CLMT_DOB',
                                                                        'U', 'U', 'U')
                        if len(struct_val_list) == 1 and struct_val_list[0] not in ['U', 'P', 'E']:
                            p.add_run(struct_val_list[0])
                        else:
                            tupres = insight_obs_dict['dob']
                            if tupres not in ['U', 'P', 'E']:
                                p.add_run(tupres)
                            else:
                                p.add_run('__')
                    p.add_run("\n")

                # AOD:
                # TIP: Don't output AOD for solely adult T16 SSI claims - not valuable!
                elif tup[1] == 'aod':
                    if len([ct for ct in claimtypelist if 'T16' in ct]) != len(claimtypelist):
                        p.add_run(tup[0]).underline = True
                        p.add_run(':  ')
                        if tup[1] == '':
                            p.add_run('__')
                        else:
                            # Prioritize decision DLI over structured value:
                            tupres = insight_obs_dict[tup[1]]
                            if tupres not in ['U', 'P', 'E', '']:
                                p.add_run(tupres)
                            else:
                                struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                                'ALLGD_DISB_ONST_DT', 'U', 'U', 'U')
                                if len(struct_val_list) == 1 and struct_val_list[0] not in ['U', 'P', 'E']:
                                    p.add_run(struct_val_list[0])
                                    p.add_run(" (NOTE: Not derived from decision - double check this value's accuracy)")
                                else:
                                    p.add_run('__')
                        p.add_run("\n")

                # DOF:
                elif tup[1] == 'dof':
                    # TIP: Don't output DOF for solely Age 18 Redeterminations - not valuable!
                    if len([ct for ct in claimtypelist if ct == 'T16 SSI Age 18 Redetermination']) != len(
                            claimtypelist):
                        p.add_run(tup[0]).underline = True
                        p.add_run(':  ')
                        appdtlist = []
                        for subd in insight_obs_dict['CLAIMDISP_STRUCT']:
                            if subd['PFLG_DT'] != 'E':
                                appdtstr = "%s (%s) (Protective Filing Date)" % (subd['PFLG_DT'], subd['CLM_TYP'])
                                appdtlist.append(appdtstr)
                            else:
                                if subd['APP_DT'] != 'E':
                                    appdtstr = "%s (%s)" % (subd['APP_DT'], subd['CLM_TYP'])
                                    appdtlist.append(appdtstr)
                                else:
                                    if subd['CLM_TYP'] not in ['U', 'P', 'E', '']:
                                        appdtstr = "Unknown (%s)" % subd['CLM_TYP']
                                        appdtlist.append(appdtstr)
                                    else:
                                        appdtlist.append("Unknown DOF/Claim")
                        if not appdtlist or len(appdtlist) == len(
                                [astr for astr in appdtlist if astr == 'Unknown DOF/Claim']):
                            p.add_run('__')
                        else:
                            p.add_run('; '.join(appdtlist))
                        p.add_run("\n")

                # DID:
                elif tup[1] == 'FNL_DSPN_DT':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        # Prioritize decision value over structured DID:
                        tupres = insight_obs_dict['did']
                        if tupres not in ['U', 'P', 'E']:
                            p.add_run(tupres)
                        else:
                            struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                            'FNL_DSPN_DT', 'U', 'U', 'U')
                            if len(struct_val_list) == 1 and struct_val_list[0] not in ['U', 'P', 'E']:
                                p.add_run(struct_val_list[0])
                                p.add_run(" (NOTE: Not derived from decision - double check this value's accuracy)")
                            else:
                                p.add_run('__')
                    p.add_run("\n")

                # DLI:
                # TIP: Don't output DLI for solely T16 claims - not relevant.
                elif tup[1] == 'dli':
                    if len([ct for ct in claimtypelist if 'T2' in ct]) != 0:
                        p.add_run(tup[0]).underline = True
                        p.add_run(':  ')
                        if tup[1] == '':
                            p.add_run('__')
                        else:
                            # Prioritize decision DLI over structured value:
                            tupres = insight_obs_dict[tup[1]]
                            if tupres not in ['U', 'P', 'E', '']:
                                p.add_run(tupres)
                                # TODO: Add in use of 'did' value if present over 'FNL_DSPN_DT'
                                # for DLI/DID comparisons:
                                did_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                                    'FNL_DSPN_DT', 'U', 'U', 'U')
                                if len(did_struct_val_list) == 1 and did_struct_val_list[0] not in ['U', 'P', 'E']:
                                    dli_dt = dh.parse_date_todatetime_struct(tupres)
                                    did_struct_val_dt = dh.parse_date_todatetime_struct(did_struct_val_list[0])
                                    if dli_dt != 'E' and did_struct_val_dt != 'E':
                                        if dli_dt < did_struct_val_dt:
                                            p.add_run(" (remote)")
                            else:
                                struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                                'DLI', 'U', 'U', 'U')
                                if len(struct_val_list) == 1 and struct_val_list[0] not in ['U', 'P', 'E']:
                                    p.add_run(struct_val_list[0])
                                    did_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict,
                                                                                        'struct_hodisp', 'FNL_DSPN_DT',
                                                                                        'U', 'U', 'U')
                                    if len(did_struct_val_list) == 1 and did_struct_val_list[0] not in ['U', 'P', 'E']:
                                        dli_dt = dh.parse_date_todatetime_struct(struct_val_list[0])
                                        did_struct_val_dt = dh.parse_date_todatetime_struct(did_struct_val_list[0])
                                        if dli_dt != 'E' and did_struct_val_dt != 'E':
                                            if dli_dt < did_struct_val_dt:
                                                p.add_run(" (remote)")
                                    p.add_run(" (NOTE: Not derived from decision - double check this value's accuracy)")
                                else:
                                    p.add_run('__')
                        p.add_run('\n')

                # Circuit:
                elif tup[1] == 'circuit':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        # Prefer decision circuit over structured value:
                        tupres = insight_obs_dict[tup[1]]
                        if tupres not in ['U', 'P', 'E', '']:
                            p.add_run(tupres)
                        else:
                            circuit_struct = insight_obs_dict['CIRCUIT_STRUCT']
                            if circuit_struct and circuit_struct not in ['U', 'P', 'E', '']:
                                p.add_run(circuit_struct)
                                p.add_run(" (NOTE: Not derived from decision - double check this value's accuracy)")
                            else:
                                p.add_run('__')
                    p.add_run("\n")

                # Date RR Filed and RR Deadline:
                elif tup[1] == 'CRNT_RQSTD_DT':

                    # If own motion, do NOT parse RR deadline (not relevant):
                    wkld_typ_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_oao', 'WKLD_TYP', 'U', 'U',
                                                                  'U')
                    if 'URR' not in wkld_typ_list:

                        p.add_run(tup[0]).underline = True
                        p.add_run(':  ')
                        if tup[1] == '':
                            p.add_run('__')
                        else:

                            # Retrieve 'didval', with 'did' prioritized over 'FNL_DSPN_DT':
                            didval = 'U'
                            did = insight_obs_dict['did']
                            if did in ['U', 'P', 'E', ''] or ';' in did:
                                fnldspndt_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict,
                                                                                          'struct_hodisp',
                                                                                          'FNL_DSPN_DT', 'U', 'U', 'U')
                                fnldspndt_struct_val_nonu = [v for v in fnldspndt_struct_val_list if v != 'U']
                                if len(set(fnldspndt_struct_val_nonu)) == 1:
                                    didval = fnldspndt_struct_val_nonu[0]
                            else:
                                didval = did

                            # Calc 'rr_deadline_str' using 'didval':
                            rr_deadline_str = 'U'
                            if didval != 'U':
                                rr_deadline_restup = ifsiqrcc.calc_rr_deadline(didval)
                                if rr_deadline_restup[0] != 'E':
                                    rr_deadline_str = rr_deadline_restup[0]

                            # Retrieve ARPS RR filing date:
                            rrfdval = 'U'
                            rrdt_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_oao',
                                                                                 'CRNT_RQSTD_DT', 'U', 'U', 'U')
                            rrdt_struct_val_nonu = [v for v in rrdt_struct_val_list if v != 'U']
                            if len(set(rrdt_struct_val_nonu)) == 1:
                                rrfdval = rrdt_struct_val_nonu[0]

                            # Calc timeliness:
                            timelinessver = 'U'
                            if rr_deadline_str != 'U' and rrfdval != 'U':
                                rr_deadline_dt = dh.parse_date_todatetime_struct(rr_deadline_str)
                                rrfdval_dt = dh.parse_date_todatetime_struct(rrfdval)
                                if rr_deadline_dt != 'E' and rrfdval_dt != 'E':
                                    if rrfdval_dt > rr_deadline_dt:
                                        timelinessver = 'No'
                                    else:
                                        timelinessver = 'Yes'

                            # Generate output:
                            if timelinessver == 'No':
                                if rr_deadline_restup[1] not in ['U', 'E']:
                                    rr_untimely_msg = 'No (RR Filing Deadline: %s %s; ARPS RR Filing Date: %s)' % (
                                        rr_deadline_restup[0], rr_deadline_restup[1], rrfdval)
                                else:
                                    rr_untimely_msg = 'No (RR Filing Deadline: %s; ARPS RR Filing Date: %s)' % (
                                        rr_deadline_restup[0], rrfdval)
                                p.add_run(rr_untimely_msg)
                            else:
                                if rr_deadline_str != 'U':
                                    if rr_deadline_restup[1] not in ['U', 'E']:
                                        rr_default_msg = '__ (RR Filing Deadline: %s %s)' % (
                                            rr_deadline_restup[0], rr_deadline_restup[1])
                                    else:
                                        rr_default_msg = '__ (RR Filing Deadline: %s)' % (rr_deadline_restup[0])
                                    p.add_run(rr_default_msg)
                                else:
                                    p.add_run('__')
                        p.add_run("\n")

                # Age at Start of PAI & PAI Start Date:
                elif tup[1] == 'STRUCT_AGEREL_PAISTART':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        tupres = insight_obs_dict[tup[1]]
                        tupres_src = insight_obs_dict['STRUCT_AGEREL_PAISTART_SRC']
                        paistart = insight_obs_dict['paistart']
                        clmt_dob = 'U'
                        dob_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                            'CLMT_DOB', 'U', 'U', 'U')
                        if dob_struct_val_list and len(list(set(dob_struct_val_list))) == 1:
                            clmt_dob = dob_struct_val_list[0]
                        if tupres in ['U', 'P', 'E', ''] or paistart in ['U', 'P', 'E', '']:
                            p.add_run('__')
                        else:
                            paistartstr = 'start of PAI: Unknown'
                            if tupres_src == '1':
                                paistartstr = 'start of PAI: %s [NOTE: calculated from structured data]' % paistart
                            else:
                                paistartstr = 'start of PAI: %s' % paistart
                            tupres_str = 'Unknown'
                            tupres_agecat = 'E'
                            if paistart not in ['U', 'P', 'E'] and clmt_dob != 'U':
                                tupres_agecat = ifsiqrcc.calc_agecat(clmt_dob, paistart)
                            if tupres_agecat != 'E':
                                tupres_str = "%s / %s (%s)" % (tupres, tupres_agecat, paistartstr)
                            else:
                                tupres_str = "%s (%s)" % (tupres, paistartstr)
                            p.add_run(tupres_str)
                    p.add_run('\n')

                # Age at End of PAI & PAI End Date:
                elif tup[1] == 'STRUCT_AGEREL_PAIEND':
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        tupres = insight_obs_dict[tup[1]]
                        tupres_src = insight_obs_dict['STRUCT_AGEREL_PAIEND_SRC']
                        paiend = insight_obs_dict['paiend']
                        clmt_dob = 'U'
                        dob_struct_val_list = ifsiqrcc.gather_container_tgt(insight_obs_dict, 'struct_hodisp',
                                                                            'CLMT_DOB', 'U', 'U', 'U')
                        if dob_struct_val_list and len(list(set(dob_struct_val_list))) == 1:
                            clmt_dob = dob_struct_val_list[0]
                        if tupres in ['U', 'P', 'E', ''] or paiend in ['U', 'P', 'E', '']:
                            p.add_run('__')
                        else:
                            paiendstr = 'end of PAI: Unknown'
                            if tupres_src == '1':
                                paiendstr = 'end of PAI: %s [NOTE: calculated from structured data]' % paiend
                            else:
                                paiendstr = 'end of PAI: %s' % paiend
                            tupres_str = 'Unknown'
                            tupres_agecat = 'E'
                            if paiend not in ['U', 'P', 'E'] and clmt_dob != 'U':
                                tupres_agecat = ifsiqrcc.calc_agecat(clmt_dob, paiend)
                            if tupres_agecat != 'E':
                                tupres_str = "%s / %s (%s)" % (tupres, tupres_agecat, paiendstr)
                            else:
                                tupres_str = "%s (%s)" % (tupres, paiendstr)
                            p.add_run(tupres_str)
                    p.add_run('\n')

                # TIP: No restrictions on other outputs:
                else:
                    p.add_run(tup[0]).underline = True
                    p.add_run(':  ')
                    if tup[1] == '':
                        p.add_run('__')
                    else:
                        tupres = insight_obs_dict[tup[1]]
                        if tupres == 'U':
                            p.add_run('__')
                        else:
                            p.add_run(tupres)
                    p.add_run("\n")

            # Add decision notes 'findings' information if those
            # findings are notable:
            p = document.add_paragraph("", style=stylepar)
            p.add_run("Findings: ").bold = True
            p.add_run(" \n")

            # Step 1 SGA Verdict:
            try:
                s1sgaver_dict = {"1":"No period of SGA", "2":"Period of SGA and 12+ month period of non-SGA",
                                 "3":"Period of SGA (whether 12+ month period of non-SGA unknown)",
                                 "4":"Period of SGA (whether 12+ month period of non-SGA unknown)"}
                s1sgaver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's1sga', 's1sgaver', 1,
                                                                 s1sgaver_dict)
                if s1sgaver_txt != 'Unknown':
                    p.add_run("S1").underline = True
                    p.add_run(": ")
                    p.add_run(s1sgaver_txt)
                    p.add_run(" \n")
                else:
                    p.add_run("S1").underline = True
                    p.add_run(": __")
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S1").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Step 2 Verdict:
            try:
                s2ver_dict = {"1":"Severe MDI(s)", "2":"Non-Severe MDI(s)", "3":"No MDI(s)"}
                s2ver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's2', 's2ver', 1, s2ver_dict)
                if s2ver_txt != 'Unknown':
                    p.add_run("S2").underline = True
                    p.add_run(": ")
                    p.add_run(s2ver_txt)
                    s2txt_fitcleaned_list = []
                    for subd in insight_obs_dict['s2']:
                        if subd['s2txtsrc'] == '0':
                            if subd['s2ver'] in ['1', '2']:
                                s2txt = subd['s2txt']
                                if s2txt not in ['U', 'P', 'E', '']:
                                    s2txt_fitcleaned_list.append(nlp_helper.s2txt_cleaner_fit(s2txt))
                    if s2txt_fitcleaned_list:
                        if len(s2txt_fitcleaned_list) != 1:
                            s2txt_fitcleaned_resstr = "; ".join(
                                ["(%s) '%s'" % (str(i), s2txt) for i, s2txt in enumerate(s2txt_fitcleaned_list)])
                            s2txt_fitcleaned_resstr = """ (MDIs: "%s")""" % s2txt_fitcleaned_resstr
                            p.add_run(s2txt_fitcleaned_resstr)
                        else:
                            s2txt_fitcleaned_resstr = """ (MDIs: "%s")""" % s2txt_fitcleaned_list[0]
                            p.add_run(s2txt_fitcleaned_resstr)
                    p.add_run(" \n")
                else:
                    p.add_run("S2").underline = True
                    p.add_run(": __")
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S2").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Step 3 Meets/Equals Verdict:
            try:
                s3mteqver_dict = {"1":"Does Not Meet/Equal Listing(s)", "2":"Yes, Meets Listing(s)",
                                  "3":"Yes, Medically Equals Listing(s)",
                                  "4":"Yes, Meets/Medically Equals Listing(s) (Precise Type Unknown)"}
                s3mteqver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's3mteq', 's3mteqver', 1,
                                                                  s3mteqver_dict)
                if s3mteqver_txt != 'Unknown':
                    p.add_run("S3").underline = True
                    p.add_run(": ")
                    p.add_run(s3mteqver_txt)
                    s3mteqlistnum_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's3mteq', 's3mteqlistnum',
                                                                          1, {})
                    if s3mteqlistnum_txt not in ['U', 'P', 'E', '[]', '']:
                        p.add_run(s3mteqlistnum_txt.strip())
                        p.add_run(" \n")
                    else:
                        p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S3").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Step 3 Functionally Equals Verdict:
            try:
                s3feqver_dict = {"1":"Yes, Functionally Equals", "2":"Does Not Functionally Equal"}
                s3feqver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's3feq', 's3feqver', 1,
                                                                 s3feqver_dict)
                if s3feqver_txt != 'Unknown':
                    p.add_run("S3 FEQ").underline = True
                    p.add_run(": ")
                    p.add_run(s3feqver_txt)
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S3 FEQ").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # RFC Exertional Level:
            try:
                rfcexlvl_dict = {"F":"Full Exertion", "H":"Heavy Exertion", "M":"Medium Exertion", "L":"Light Exertion",
                                 "S":"Sedentary Exertion"}
                rfcexlvl_parsed_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 'rfc', 'rfcexlvl_parsed', 1,
                                                                        rfcexlvl_dict)
                if rfcexlvl_parsed_txt != 'Unknown':
                    p.add_run("RFC").underline = True
                    p.add_run(": ")
                    p.add_run(rfcexlvl_parsed_txt)
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("RFC").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Step 4 Verdict:
            try:
                s4ver_dict = {"1":"Can Perform PRW", "2":"Cannot Perform PRW", "3":"Has No PRW",
                              "4":"Expedited Finding"}
                s4ver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's4', 's4ver', 1, s4ver_dict)
                if s4ver_txt != 'Unknown':
                    p.add_run("S4").underline = True
                    p.add_run(": ")
                    p.add_run(s4ver_txt)
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S4").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Education Level Verdict:
            try:
                edver_dict = {"I":"Illiterate", "M":"Marginal", "L":"Limited", "H":"High School"}
                edver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 'edver', 'U', 0, edver_dict)
                if edver_txt != 'Unknown':
                    p.add_run("ED LVL").underline = True
                    p.add_run(": ")
                    p.add_run(edver_txt)
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("ED LVL").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # Step 5 Verdict & MVR Values:
            try:
                # Calculate the Step 5 string value:
                s5ver_dict = {"1":"Can Perform Other Work", "2":"Can Perform Other Work (Alternative Finding)",
                              "3":"Cannot Perform Other Work"}
                s5ver_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's5', 's5ver', 1, s5ver_dict)
                if s5ver_txt != 'Unknown':
                    p.add_run("S5").underline = True
                    p.add_run(": ")
                    p.add_run(s5ver_txt)
                    mvr_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 'mvr', 's5mvr', 0, {})
                    if mvr_txt != 'Unknown':
                        mvr_txt_fnl = ' (MVR(s) Cited: %s)' % mvr_txt
                        p.add_run(mvr_txt_fnl)
                    s5dot_txt = ifsiqrcc.createbgtxt_findingchild(insight_obs_dict, 's5dot', 's5dotnum', 0, {})
                    if s5dot_txt != 'Unknown':
                        s5dot_txt_fnl = ' (Rep. Job DOT #(s) Cited: %s)' % s5dot_txt
                        p.add_run(s5dot_txt_fnl)
                    p.add_run(" \n")
            except Exception:
                logger.exception('EXCEPTION')
                p.add_run("S5").underline = True
                p.add_run(": __")
                p.add_run(" \n")

            # (2)(B)(4) Save copy of completed template to TEMP directory to
            # enable return as static file to end user:
            template_fn = str(requestid) + '.docx'
            template_fp = os.path.join(tempdir, template_fn)
            try:
                document.save(template_fp)
                return template_fn
            except Exception:
                template_err_fp = os.path.join(templatedir, "template_err.docx")
                copyfile(template_err_fp, template_fp)
                return template_fn

    except Exception, x:
        logger.exception('EXCEPTION')
        template_fn = str(requestid) + '.docx'
        template_fp = os.path.join(tempdir, template_fn)
        template_err_fp = os.path.join(templatedir, "template_err_unknown.docx")
        copyfile(template_err_fp, template_fp)
        return template_fn
