# Brief Introduction:

This utility is for cross checking the performance of classifiers which are in use in script \src\ie_data_loader.py and gives us some sense of how the classifiers work there. It is designed to be easily customized: just instantiating the ML_util class with the training file name located in \src\data\ folder, the classifier and the ngram end number, setting up the log file name that you prefer and calling the run method, then on the command line to execute the python script, it will print out the Accuracy predicted using the testing data splitted from the training data, Classification metrics and the Confusion metrics

There is no need to have unit test for these utilities since they are call for internal review
Log files will show what has been predicted wrong from the classifier

To run:
` python src\ml\{anyname except the ml_util.py}


# Background:

This utilizes scikit-learn's train_test_split helper function to randomly split the data file into training and test sets; uses bags of words to turn text into numerical features vectors; uses the TFIDF vectorizer to tokenize the features before feeding into the classifier and then predicting the unknown and untagged new record.

