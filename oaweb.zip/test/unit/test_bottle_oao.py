# ==============================================================================
# TEST bottle_oao.py
# ==============================================================================

from boddle import boddle
import mock
import pytest

# Set directories:
import setup_config
from bottle_oao import (error404,
                        favicon,
                        server_static_about,
                        server_static_docs,
                        server_static_fonts,
                        server_static_help,
                        server_static_images,
                        server_static_javascript,
                        server_static_stylesheets,
                        log_access,
                        generatetemplate,
                        ssolookup,
                        childbmi,
                        getcldob,
                        getcldid,
                        agecalc,
                        oaofb,
                        getinsighthtml)
#For mock patch testing
import bottle_oao

# Test availability of all fonts used by site
@pytest.mark.parametrize("filename, response", [
    ('OpenSans-Bold.ttf', 200),
    ('OpenSans-ExtraBold.ttf', 200),
    ('OpenSans-ExtraBoldItalic.ttf', 200),
    ('OpenSans-Italic.ttf', 200),
    ('OpenSans-Light.ttf', 200),
    ('OpenSans-LightItalic.ttf', 200),
    ('OpenSans-Regular.ttf', 200),
    ('OpenSans-Semibold.ttf', 200),
    ('OpenSans-SemiboldItalic.ttf', 200),
    ('crazy_fonts.ttf', 404),
])
def test_server_static_fonts(filename, response):
    returned_response = server_static_fonts(filename)
    assert returned_response.status_code == response


# Test availability of site downloadable PDF files
@pytest.mark.parametrize("filename, response", [
    ('INSIGHT for OAO Orientation Slide Deck 082222017.pdf', 200),
    ('INSIGHT for OAO Quick Reference 08222017.pdf', 200),
    ('INSIGHT_OAO_Training_Guide_v1.pdf', 200),
    ('crazy_files.pdf', 404),
])
def test_server_static_docs(filename, response):
    returned_response = server_static_docs(filename)
    assert returned_response.status_code == response


# Test availability of site 404 page
@pytest.mark.parametrize("filename, response", [
    ('404.html', 200),
])
def test_error404(filename, response):
    returned_response = error404(filename)
    assert returned_response.status_code == response


# Test availability of Javascript content
@pytest.mark.parametrize("filename, response", [
    ('jquery-3.3.1.js', 200),
    ('jquery-3.3.1.min.js', 200),
    ('jquery.maskedinput.js', 200),
    ('jquery.maskedinput.min.js', 200),
    ('jquery.tablesorter.min.js', 200),
    ('jquery-ui-1.12.1.min.js', 200),
    ('json2.js', 200),
    ('json2.min.js', 200),
    ('modal-window.js', 200),
    ('case-summary.js', 200),
    ('tools.js', 200),
    ('about.js', 200),
    ('case_search.js', 200),
    ('crazy_javascript.js', 404),
])
def test_server_static_javascript(filename, response):
    returned_response = server_static_javascript(filename)
    assert returned_response.status_code == response

# Test availability of CSS content
@pytest.mark.parametrize("filename, response", [
    ('main.css', 200),
    ('modal-window.css', 200),
    ('print.css', 200),
    ('crazy_css.css', 404),
])
def test_server_static_stylesheets(filename, response):
    returned_response = server_static_stylesheets(filename)
    assert returned_response.status_code == response


# Test availability of all image content
@pytest.mark.parametrize("filename, response", [
    ('about.png', 200),
    ('Insight.png', 200),
    ('searchicon.png', 200),
    ('about.png', 200),
    ('jar-loading.gif', 200),
    ('crazy_images.png', 404),
])
def test_server_static_images(filename, response):
    returned_response = server_static_images(filename)
    assert returned_response.status_code == response


# Test availability of site favicon
def test_favicon():
    returned_response = favicon()
    assert returned_response.status_code == 200


# Test availability of the site about page
def test_server_static_about():
    returned_response = server_static_about()
    assert returned_response.status_code == 200


# Test availability of the site help page
def test_server_static_help():
    returned_response = server_static_help()
    assert returned_response.status_code == 200

# Test SSN search for admins using a test pin functionality
@mock.patch('bottle_oao.generate_search_by_ssn_admin')
def test_generate_search_by_ssn_admin(mock_method):
    insight_content = '''
    <td scope="row" class="ssn_results_column">123-45-6789</td>
    <td>DOE, JANE</td>
    <td>SSDC</td>
    <td>10</td>
    <td>RR </td>
    <td>5/17/2018</td>
    <td>5/11/2018</td>
    <td>'''
    mock_method.return_value = insight_content
    result = bottle_oao.generate_search_by_ssn_admin("027763")
    assert result == insight_content

# Test case search by user pin functionality
@mock.patch('bottle_oao.generate_search_by_ssn')
def test_generate_search_by_ssn(mock_method):
    insight_content = '''
    <div class="api_error_message">
        <h2 class="headingnonbold" tabindex="0">User or Office not Authorized</h2>
    </div>'''
    mock_method.return_value = insight_content
    result = bottle_oao.generate_search_by_ssn()
    assert result == insight_content

# Test log_access route
@mock.patch('bottle_oao.insert_access')
def test_log_access_route(mock_function):
    with boddle(params={'fullpath': '/dumbpath'}, headers={'X-Remote-User': -1234567}, method='POST'):
        log_access()
        mock_function.assert_called_once_with('-1234567', '/dumbpath')

@mock.patch('bottle_oao.log_usage')
def test_generatetemplate_route(mock_func):
    with boddle(path='/oaoapp/generatetemplate/dummyrid'):
        result = generatetemplate('dummyrid')
        # because the dummy rid
        assert result.find('Something Is Amiss') > -1

@mock.patch('bottle_oao.log_usage')
def test_ssolookup_route(mock_func):
    with boddle(params={'reqid': 1234567, 'inputzip':123456789}, method="POST"):
        result = ssolookup()
        assert result.find('Invalid zip code input') > -1

@mock.patch('bottle_oao.log_usage')
def test_childbmi_route(mock_func):
    with boddle(params={'reqid':-123456, 'childhtft': 'nan'}, method='POST'):
        result = childbmi()
        assert result.find('Invalid height (feet) input') > -1

def test_getcldob_route():
    with boddle(body='funnythings', method='POST'):
        result = getcldob()
        assert result == 'Unknown'

def test_getcldid_route():
    with boddle(body='funnythings', method='POST'):
        result = getcldid()
        assert result == 'Unknown'

@mock.patch('bottle_oao.log_usage')
def test_agecalc_route(mock_func):
    with boddle(params={'reqid': -123456, 'agecalcdob': ''}, method='POST'):
        result = agecalc()
        assert result.find('Please enter a date of birth') > -1

def test_oaofb_route():
    with boddle(params={'reqid': -1234567}, method='POSt'):
        result = oaofb()
        assert result.find("No feedback checkboxes checked and no text found in 'Other' field") > -1

@mock.patch('bottle_oao.ifsda.retrieve_case_entity_schema2')
def test_getinsighthtml_route(mock_func):
    with boddle(params={'reqid': -1234567}):
        mock_func.return_value = None
        result = getinsighthtml(-1234567)
        # because the dummy rid
        assert result.find('Something Is Amiss') > -1
