/*****************************************************************************************
                      Add table sorter to case search results on page load
*******************************************************************************************/
$(document).ready(function()
    {
        $("#decision_table").tablesorter({
            sortList: [[0,0]],
           textExtraction: function(node) {
                return node.innerHTML.replace(/-/g,'');
            }
        }).bind("sortEnd", function(event) {
            var table = event.target;
            currentSort = table.config.sortList;
            sortedColumn = currentSort[0][0];
            sortOrder = currentSort[0][1] // 1 - Desc, 0 - Asc
            sortedOrderText = sortOrder ? "descending" : "ascending";
            sortedColumnName = $(table.config.headerList[sortedColumn]).text();
            genericSortText = " ascending or descending"
             $(table.config.headerList).each(function(d) {
                var columnName = $(table.config.headerList[d]).text();
                var table_header = $(table.config.headerList[d]);
                var table_header_button = $(table_header).find('button')
                table_header_button.attr('title', ("Sort "+columnName+genericSortText))
                table_header.css('color', '#4d5b65')
             })
            $(table.config.headerList[sortedColumn]).attr('title', (sortedColumnName+" sorted "+sortedOrderText))
            $(table.config.headerList[sortedColumn]).css('color', 'black')
            //Update caption text
            $("#casesearchtablecaption").text("Decision Review Results sorted by "+(sortedColumnName+" "+sortedOrderText)+".")
         })
        // Set focus on the ssn search input field when the page loads.
        $("#ssn_input").focus();
    }
);

/*****************************************************************************************
                                 Filter case search results by SSN
*******************************************************************************************/
function filterBySSN() {
    var input, filter, i;
    var tablerowswithvalue = 0;
    input = document.getElementById("ssnFilter");
    filter = input.value.toString();
    ssn_class = document.getElementsByClassName("ssn_results_column");
    for(i = 0; i < ssn_class.length; i++) {
        if(ssn_class[i]) {
            //Replace hyphen with empty string to handle pattern match.
            if (ssn_class[i].innerHTML.replace(/-/g,'').indexOf(filter) > -1) {
                ssn_class[i].parentNode.style.display = "";
                tablerowswithvalue++;
            } else {
                ssn_class[i].parentNode.style.display = "none";
            }
        }
    }
    $("#case_result_count").text(tablerowswithvalue);
}

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}


/*****************************************************************************************
                        Validate SSN entry on search input box
*******************************************************************************************/
$("#ssn_input").on("keydown",(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .(period)
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A, Command+A, Ctrl+C, Command+C, Ctrl+V, Command+V, Ctrl+X, Command+X
            ($.inArray([65, 67, 86, 88]) && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }

        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }

        // When user select text in the document, also abort.
        var selection = window.getSelection().toString();
        if (selection !== '') {
            return;
        }

        // When the arrow keys are pressed, abort.
        if ($.inArray(event.keyCode, [38, 40, 37, 39]) !== -1) {
            return;
        }

        var $this = $(this);
        var input = $this.val();

        input = input.replace(/[\W\s\._\-]+/g, '');
        var split = 0;
        var chunk = [];

        for (var i = 0, len = input.length; i < len; i += split) {
            split = (i >= 3 && i <= 5) ? 2 : 3;
            if (i >= 5) {
                split = 4;
            }
            chunk.push(input.substr(i, split));
        }

        $this.val(function () {
            return chunk.join("-");
        });
})).on('paste', function (e) {
    var $this = $(this);
    setTimeout(function () {
         $this.val($this.val().replace(/[^0-9]/g, ''));
         var input = $this.val();
         var split = 0;
         var chunk = [];

         for (var i = 0, len = input.length; i < len; i += split) {
              split = (i >= 3 && i <= 5) ? 2 : 3;
              if (i >= 5) {
                   split = 4;
              }
              chunk.push(input.substr(i, split));
         }

         $this.val(function () {
              return chunk.join("-");
         });
    }, 5);
});;

