# INSIGHT RFC TEXT PARSER
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 09.03.2017

# SUMMARY: 
# Parses RFC finding heading text to output structured data values regarding
# its content, including whether targeted functional area terms are or are not
# referenced and the level of limitation (LOL) value(s) associated with 
# targeted functional area terms (FA).
#
# After a series of cleaning, simplification, and transformation processes, the
# parser breaks down input text into clause-like subsections ('ss') based in reference to
# grammar rules but driven primarily on segmenting '1 LOL, 1+ functional attribute (FA)'
# clusters.  Once input text is broken down as much as possible, a counting method
# centered on LOLs is utilized in determining whether to assign an LOL values to FAs present
# in the SS.  If only 1 LOL present, we assume it is logically associated to the co-present
# FAs.  This assumption is driven by the purpose of RFCs, which are designed as positive
# 'findings' or statements as to the claimant's limitations.
#
# Advantages of this approach are that the code can correctly parse a 
# variety of 'imperfect' sentence structures (at least in some cases), including:
# 
# Nonparallel structures: 
# "he can occasionally stoop, frequently crawl and he should not reach."
# Non-use of semicolons to divide list items containing commas:
# "..must never stoop, kneel, or crouch, occasionally reach, finger, and feel.."
# Non-use of oxford commas in lists:
# "..she can handle, finger and feel occasionally.."
# Confusing negation:
# "...she can never reach beyond frequently.."
# Double negatives:
# "He is not unable to stoop" (will not assign an LOL value to 'stoop')
#
#
# IMPORTANT NOTE:
# Presently, this ignores 'less than' modifiers when assigning LOL values.
# For example, "She can stoop less than occasionally" is not policy compliant
# because it does not articulate a 'maximum capacity' to perform the function
# stooping.  Nonetheless, as 'occasional' here is the only LOL reference that the
# claimant clearly could not *exceed*, as the utility of this RFC information
# is largely for comparsion purposes to DOT job requirements and non-assignment
# here would result in an inability to detect even clear conflicts with such
# job requirements (e.g. 'constant' stooping requirement), and to otherwise
# avoid a path of speculating as to the claimant's 'actual' capacity based on
# this language, I choose to assign here.
# 
# INPUT: 
# A string consisting of the text of a single RFC finding heading.
# 
# OUTPUT: 
# A dictionary. Primarily, the dictionary contains detailed RFC-related data
# values where keys = INSIGHT data point names and values = LOL or 
# presence/absence values (see INSIGHT Extract Data Dictionary for more 
# information). The dictionary also contains certain RFC-related IQ data point
# names and values (see INSIGHT Quality Data Dictionary for more information).
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

# Import modules:
import re
import os.path
import time
import logging
from textblob.en.taggers import PatternTagger
import nlp_helper
from rfcparser_data_loader import *
import rfcparser_presabs as presabs
import common_fx as cfx

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Perform misc. setup actions:
tagger = PatternTagger()

# Define RFC LOL/FA parsing function:
# @profile
def rfcparser(rfc_str):
	'''Parse RFC finding heading string to determine the level(s)
	of limitation associated with targeted functional areas.
	
	Args:
		rfc_str {str}: A string containing the RFC
		text of an RFC finding, cleaned/normalized
		from its original form by by 'rfcparser'.
	Returns:
		Dictionary.
	Raises:
		N/A.
	'''
	# (1) Create RFC presence/absence dictionary and set default values:
	rfcparsingdict = {}
	rfcparsingdict['rfcfitexlvl'] = 'U'
	rfcparsingdict['rfcfitexlvlsrc'] = 'U'
	rfcparsingdict['rfcliftlol'] = 'U'
	rfcparsingdict['rfccarrylol'] = 'U'
	rfcparsingdict['rfcsitlol'] = 'U'
	rfcparsingdict['rfcstandlol'] = 'U'
	rfcparsingdict['rfcwalklol'] = 'U'
	rfcparsingdict['rfcpushlol'] = 'U'
	rfcparsingdict['rfcpulllol'] = 'U'
	rfcparsingdict['rfcclimbrampstairlol'] = 'U'
	rfcparsingdict['rfcclimblrslol'] = 'U'
	rfcparsingdict['rfcbalancelol'] = 'U'
	rfcparsingdict['rfcstooplol'] = 'U'
	rfcparsingdict['rfckneellol'] = 'U'
	rfcparsingdict['rfccrouchlol'] = 'U'
	rfcparsingdict['rfccrawllol'] = 'U'
	rfcparsingdict['rfcreachlol'] = 'U'
	rfcparsingdict['rfchandlelol'] = 'U'
	rfcparsingdict['rfcfingerlol'] = 'U'
	rfcparsingdict['rfcfeellol'] = 'U'
	rfcparsingdict['rfcnearacuitylol'] = 'U'
	rfcparsingdict['rfcfaracuitylol'] = 'U'
	rfcparsingdict['rfcdepthperceptionlol'] = 'U'
	rfcparsingdict['rfcaccomodationlol'] = 'U'
	rfcparsingdict['rfccolorvisionlol'] = 'U'
	rfcparsingdict['rfcfieldofvisionlol'] = 'U'
	rfcparsingdict['rfcfootcontrolslol'] = 'U'
	rfcparsingdict['rfcexposuretoweatherlol'] = 'U'
	rfcparsingdict['rfcextremeheatlol'] = 'U'
	rfcparsingdict['rfcextremecoldlol'] = 'U'
	rfcparsingdict['rfcwetnesslol'] = 'U'
	rfcparsingdict['rfchumiditylol'] = 'U'
	rfcparsingdict['rfcvibrationlol'] = 'U'
	rfcparsingdict['rfcatmosphericconditionslol'] = 'U'
	rfcparsingdict['rfchazardslol'] = 'U'
	rfcparsingdict['rfcmovingmechanicallol'] = 'U'
	rfcparsingdict['rfcexposedheightslol'] = 'U'
	rfcparsingdict['rfctoxiccausticchemicalslol'] = 'U'
	rfcparsingdict['rfctalklol'] = 'U'
	rfcparsingdict['rfchearlol'] = 'U'
	rfcparsingdict['rfctastelol'] = 'U'
	rfcparsingdict['rfcsmelllol'] = 'U'
	# IQ:
	rfcparsingdict['flag_rfc_vague_lol_ver'] = 'U'
	rfcparsingdict['flag_rfc_vague_lol_val'] = 'U'
	rfcparsingdict['flag_rfc_lessthan_lol_ver'] = 'U'
	rfcparsingdict['flag_rfc_lessthan_lol_val'] = 'U'
	rfcparsingdict['flag_rfc_vague_parblol_ver'] = 'U'
	rfcparsingdict['flag_rfc_vague_parblol_val'] = 'U'
	rfcparsingdict['flag_rfc_minlang_ver'] = 'U'
	rfcparsingdict['flag_rfc_minlang_val'] = 'U'
	rfcparsingdict['flag_rfc_nolimlang_ver'] = 'U'
	rfcparsingdict['flag_rfc_nolimlang_val'] = 'U'
	
	try:
		# (2) Check argument types:
		if bool(isinstance(rfc_str, str)) is False:
			rfc_presabs_dict = presabs.rfc_presabs_parser(rfc_str)
			rfcparsingdict = dict(rfcparsingdict.items() + rfc_presabs_dict.items())
			rfcparsingdict = {k:'E' for k,v in rfcparsingdict.iteritems()}
			return rfcparsingdict
		
		# (3) If 'rfc_str' value passed == INSIGHT Extract Data Dictionary value 
		# indicating no RFC text value was extracted (via either 'U' or 'P'
		# value depending on context of why no RFC text value was extracted), 
		# set 'rfcparsingdict' values to appropriate matching value and return:
		if rfc_str in ['U', 'P']:
			rfcparsingdict = {k:rfc_str for k,v in rfcparsingdict.iteritems()}
			rfcparsingdict['flag_rfc_vague_lol_ver'] = rfc_str
			rfcparsingdict['flag_rfc_vague_lol_val'] = rfc_str
			rfcparsingdict['flag_rfc_lessthan_lol_ver'] = rfc_str
			rfcparsingdict['flag_rfc_lessthan_lol_val'] = rfc_str
			rfcparsingdict['flag_rfc_vague_parblol_ver'] = rfc_str
			rfcparsingdict['flag_rfc_vague_parblol_val'] = rfc_str
			rfcparsingdict['flag_rfc_minlang_ver'] = rfc_str
			rfcparsingdict['flag_rfc_minlang_val'] = rfc_str
			rfcparsingdict['flag_rfc_nolimlang_ver'] = rfc_str
			rfcparsingdict['flag_rfc_nolimlang_val'] = rfc_str
			rfc_presabs_dict = presabs.rfc_presabs_parser(rfc_str)
			rfcparsingdict = dict(rfcparsingdict.items() + rfc_presabs_dict.items())
			return rfcparsingdict
		
		# (4) Clean/Normalize RFC Text (Pre-Presence/Absence Parsing):
		
		# Strip RFC string, normalize spacing, lower case:
		rfclolfa = " ".join(rfc_str.split())
		rfclolfa = rfclolfa.lower()
		
		# Determine 'FIT Language/CFR-Based' Exertional Level:
		# TIP: While this does not presently attempt to detect negation/tailor
		# results accordingly, in vast majority of cases (esp. UNFAVs), the ALJ is not
		# negating the claimant's ability to perform these exertional levels.  And
		# even if they do, the ALJ could include negation language to convey a
		# *reduction* in the exertional level (e.g. 'the claimant cannot perform
		# the *full* range of light exertion, as he can only stand for 4 hours total').
		# Finally, even in the 'doomsday scenario' where the ALJ in a FFAV states
		# 'the claimant cannot perform even sedentary exertion', that ALJ *still* is
		# going to end up citing to a sedentary MVR (meaning assigning 'S' value in
		# this instance would still be valuable for IQ purposes).  Yes, it's logical
		# to state this assignment would be wrong because the ALJ is stating the claimant
		# simply cannot perform sedentary exertion, but that's wrong in itself, and the fact
		# that sedentary exertion was cited is still valuable for data scientists.
		# Thus, tabling more complex parsing for now.
		
		# Search for FIT/CFR exertional level terms:
		fullrfcsearch1 = re.search(r"full\s{0,6}range\s{0,6}of\s{0,6}work\s{0,6}at\s{0,6}all\s{0,6}exertional\s{0,6}levels|no\s{0,6}exertional\s{0,6}limitations", rfclolfa)
		heavyrfcsearch1 = re.search("heavy\s{0,6}work|heavy\s{0,6}exertion|heavy\s{0,6}exertional\s{0,6}level", rfclolfa)
		heavyrfcsearch2 = re.search("404.1567\(d\)|416.967\(d\)", rfclolfa)
		medrfcsearch1 = re.search("medium\s{0,6}work|medium\s{0,6}exertion|medium\s{0,6}exertional\s{0,6}level", rfclolfa)
		medrfcsearch2 = re.search("404.1567\(c\)|416.967\(c\)", rfclolfa)
		ltrfcsearch1 = re.search("light\s{0,6}work|light\s{0,6}exertion|light\s{0,6}exertional\s{0,6}level", rfclolfa)
		ltrfcsearch2 = re.search("404.1567\(b\)|416.967\(b\)", rfclolfa)
		sedrfcsearch1 = re.search("sedentary\s{0,6}work|sedentary\s{0,6}exertion|sedentary\s{0,6}exertional\s{0,6}level", rfclolfa)
		sedrfcsearch2 = re.search("404.1567\(a\)|404.1567\(a\)\s{0,6}and\s{0,6}416.967\(a\)|416.967\(a\)", rfclolfa)
		
		# Parse results:
		rfcexlvlunstructured = []
		if bool(fullrfcsearch1):
			rfcexlvlunstructured.append("F")
		if bool(heavyrfcsearch1) is True:
			rfcexlvlunstructured.append("H")
		if bool(heavyrfcsearch2) is True:
			rfcexlvlunstructured.append("H")
		if bool(medrfcsearch1) is True:
			rfcexlvlunstructured.append("M")
		if bool(medrfcsearch2) is True:
			rfcexlvlunstructured.append("M")
		if bool(ltrfcsearch1) is True:
			rfcexlvlunstructured.append("L")
		if bool(ltrfcsearch2) is True:
			rfcexlvlunstructured.append("L")
		if bool(sedrfcsearch1) is True:
			rfcexlvlunstructured.append("S")
		if bool(sedrfcsearch2) is True:
			rfcexlvlunstructured.append("S")
		# If 1 result in 'rfcexlvlunstructured', make that the 'checked' result:
		if len(rfcexlvlunstructured) == 1:
			rfcparsingdict['rfcfitexlvl'] = rfcexlvlunstructured[0]
			rfcparsingdict['rfcfitexlvlsrc'] = '0'
		# If 2+ results, output all as 'checked' value:
		elif len(rfcexlvlunstructured) > 1:
			rfcexlvlunstructured = list(set(rfcexlvlunstructured))
			rfcparsingdict['rfcfitexlvl'] = "; ".join(rfcexlvlunstructured)
			rfcparsingdict['rfcfitexlvlsrc'] = '0'

		# Remove FIT RFC introductory language:
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(after ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that ?the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(after ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}through ?the ?date ?last ?insured[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(after ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}since ?attaining ?age ?18[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(after ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}based ?on ?the ?current ?impairments[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(after ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}(the ?undersigned ?finds ?|i ?find ?)that ?the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", "", rfclolfa)

		# Remove FIT RFC exertional level to CFR language:
		rfclolfa = re.sub(r"(less ?than ?|reduced ?range ?of ?|restricted ?range ?of ?|limited ?range ?of ?|decreased ?range ?of ?|[a-z]+ ?range ?of ?)?(sedentary|light|medium) ?(exertion|work) ?as ?defined ?in ?in ?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\)) ?except", " ", rfclolfa)
		rfclolfa = re.sub(r"(less ?than ?(the|a)? ?)?full ?range ?of ?work ?at ?all ?exertional ?levels ?but ?with ?the ?following ?nonexertional ?limitations:", " ", rfclolfa)
		rfclolfa = re.sub(r"(less ?than ?(the|a)? ?)?full ?range ?of ?(sedentary|light|medium) ?(exertion|work) ?as ?defined ?in ?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\))", " ", rfclolfa)
		rfclolfa = re.sub(r"(less ?than ?(the|a)? ?)?full ?range ?of ?(sedentary|light|medium) ?(exertion|work) ?as ?defined ?in ?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\))", " ", rfclolfa)
		rfclolfa = re.sub(r"(less ?than ?(the|a)? ?|reduced ?range ?of ?|restricted ?range ?of ?|limited ?range ?of ?|decreased ?range ?of ?|[a-z]+ ?range ?of ?)?(sedentary|light|medium) ?(exertion|work)", " ", rfclolfa)
		rfclolfa = re.sub(r"(less ?than ?(the|a)? ?)?the ?full ?range ?of ?(sedentary|light|medium) ?(exertion|work)", " ", rfclolfa)
		rfclolfa = re.sub(r"(sedentary|light|medium) ?(exertion|work)", " ", rfclolfa)

		# Remove lingering FIT RFC language and regulatory 
		# references (in logical order):
		rfclolfa = re.sub(r"(\(|\[)?as ?defined ?in ?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.|416\.)([0-9a-z\(\)]+ ?)(and ?)?(404\.|416\.)?([0-9a-z\(\)]+ ?)?(\(|\[|\.)?", " ", rfclolfa)
		rfclolfa = re.sub(r"(\(|\[)?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.|416\.)([0-9a-z\(\)]+ ?)(and ?)?(404\.|416\.)?([0-9a-z\(\)]+ ?)?(\.)?", " ", rfclolfa)
		rfclolfa = re.sub(r"(\(|\[)?20 ?(c\.f\.\r.|cfr)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\b404\.|\b416\.)([0-9a-z\(\)]+ ?)", " ", rfclolfa)
		rfclolfa = re.sub(r"(\(|\[)?(\bexhibit|\bexh\.?|\bex\.?) [0-9a-e]+(\)|\])?", " ", rfclolfa)
		rfclolfa = re.sub(r"(\(|\[)?(social ?security ?ruling|ssr) [0-9a-z\-]{1,20}(\)|\])?", " ", rfclolfa)
		rfclolfa = re.sub(r"(\(|\[)?(\bpages?|\bpp\.?|\bp\.?) [0-9\-]{1,20}(\)|\])?", " ", rfclolfa)
		rfclolfa = rfclolfa.strip()
		rfclolfa = re.sub(r"^to ?perform ?(the|a|)\b", " ", rfclolfa)
		rfclolfa = rfclolfa.strip()
		rfclolfa = re.sub(r"^except ?(for ?the ?following|the claimant\b|that\b|she\b|he\b)|^except\b|^with ?the ?exception ?o?f?", " ", rfclolfa)
		rfclolfa = rfclolfa.strip()
		rfclolfa = re.sub(r"^(\.|,|:|;|\-)", " ", rfclolfa)
		
		# Remove trailing FIT RFC language:
		rfclolfa = re.sub(r"(in ?making ?this ?finding[, ]{0,4}(the ?undersigned ?has|i ?have) ?considered ?all ?symptoms ?and ?the ?extent)", " ", rfclolfa)
		rfclolfa = re.sub(r"in ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|i ?have|i) ?considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably", " ", rfclolfa)
		rfclolfa = re.sub(r"to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted", " ", rfclolfa)
		rfclolfa = re.sub(r"in ?making ?this ?finding,", "", rfclolfa)
		rfclolfa = rfclolfa.strip()

		# (5) Run RFC Presence/Absence Parser:
		rfclolfa_presabsvsn = rfclolfa
		rfc_presabs_dict = presabs.rfc_presabs_parser(rfclolfa_presabsvsn)
		rfcparsingdict = dict(rfcparsingdict.items() + rfc_presabs_dict.items())
		
		# (6) Clean/Normalize RFC Text (Post-Presence/Absence Parsing):

		# Remove physical body system associational clauses:
		# OPENQ: If you eventually wish to differentiate between 'overhead reaching'
		# and its synonyms versus simple 'reaching' (NOTE: DOT doesn't distinguish), 
		# you'll need to reconsider removing body system references.
		rfclolfa = re.sub(r"(\bwith|\babove|\bregarding|\bwith ?regard\w* ?to|\bfor\b|\bas ?it ?pertains ?to|\bas ?for|\busing|\buse ?of)( ?)(the ?claimant's|the ?claimant.?s|mrs\. ?[a-z\'\-]+|miss ?[a-z\'\-]+|ms. [a-z\'\-]+|the|his|her|)( ?)(bilateral|left|right|)( ?)(upper|lower|)( ?)(\bextremit[a-z]*\b|\bforearm[a-z]*\b|\bshoulder[a-z]*\b|\bwrist[a-z]*\b|\bhip[a-z]*\b|\blegs\b|\btoes\b|\bextremity\b|\bforearm\b|\barm(?! controls)\b|\bshoulder[a-z]*\b|\bwrist[a-z]*\b|\bhip[a-z]*\b|\bleg(?! controls)\b|\btoe[a-z]*\b)", " ", rfclolfa)
		rfclolfa = re.sub(r"(the ?claimant's|the ?claimant.?s|mrs\. ?[a-z\'\-]+|miss ?[a-z\'\-]+|ms. [a-z\'\-]+|the|his|her)( ?)(bilateral|left|right|)( ?)(upper|lower|)( ?)(extremities|forearms|arms|shoulders|wrists|hands|fingers|hips|legs|feet(?! controls)|toes|extremity|forearm|arm(?! controls)|shoulder|wrist|hand(?! controls)|finger|hip|leg(?! controls)|foot(?! controls)|toe)", " ", rfclolfa)
		
		# Correct select quoting-as-letter OCR issues:
		rfclolfa = re.sub(r"(limited|restricted|impeded|constrained|inhibited|limitations|restrictions)([a-z]{1,3})", r"\1", rfclolfa)

		# Perform subject normalization (09.03.2017):
		# TODO: Replace output of 'claimant' with more accurate 'subject' once
		# you have a chance to assign it a custom POS of XX.
		rfclolfa = re.sub(r"\bthe ?claimant\b", " claimant ", rfclolfa)
		rfclolfa = re.sub(r"\b(she|he)\b", " claimant ", rfclolfa)
		# WARNING: This will replace 'subject-like' entities, including non-claimant
		# and limitation articulation entities, e.g. '..per the claimant's psychologist mr. wilson..'
		# TODO: This would obviously be more effective if you still had capitalization data..
		# WARNING: This is a VERY simple REGEX pattern.  It won't capture last names consisting of multiple words/tokens like "de la huerta".
		rfclolfa = re.sub(r"\b(mrs|miss|ms|mr)\. ?[a-z\'\-]+ ", " claimant ", rfclolfa)
		rfclolfa = " ".join(rfclolfa.split())

		# Add spaces around *NON-number* words connected by '-' or '/':
		# TIP: This ensures high value terms directly connected via '-' or '/' 
		# are properly tokenized, e.g. language like "he can stoop/crouch"
		# won't be tokenized as (u'stoop/crouch', u'NN').
		while bool(re.search(r"([a-z]+)(/)([a-z]+)", rfclolfa)):
			rfclolfa = re.sub(r"([a-z]+)(/)([a-z]+)", r"\1 / \3", rfclolfa)
		
		while bool(re.search(r"([a-z]+)(-)([a-z]+)", rfclolfa)):
			rfclolfa = re.sub(r"([a-z]+)(-)([a-z]+)", r"\1 - \3", rfclolfa)
		
		# Add spaces around *numbers* divided by '-' and '/' BUT ONLY where 
		# immediately followed by RFC exertional metric terms (pounds/hours):
		# TIP: This ensures proper tokenization, e.g. "he can sit 2-4 hours" 
		# won't be tokenized as ('2-4', 'NN').
		# TIP: Preemptively converting 1/2 to prevent false space additional
		# via this change.
		rfclolfa = re.sub(r"1/2 hour\b", "one-half hour", rfclolfa)
		while bool(re.search(r"([0-9]+)(/|-)([0-9]+) ?(pounds?|lbs?|hours?|hrs?)\b", rfclolfa)):
			rfclolfa = re.sub(r"([0-9]+)(/|-)([0-9]+) ?(pounds?|lbs?|hours?|hrs?)\b", r"\1 / \3 \4", rfclolfa)


		# Perform 'can' normalization (09.03.2017):
		rfclolfa = re.sub(r"\b(has|had|retain(ed|s)) ?the ?capacity ?to\b|\b(was|is|remain(ed|s)) ?capable ?of\b", " can ", rfclolfa)
		rfclolfa = re.sub(r"\b(has|had|retain(ed|s)) ?the ?capacity ?to\b|\b(was|is|remain(ed|s)) ?capable ?of\b", " can ", rfclolfa)
		rfclolfa = re.sub(r"\b(is|was|remain(ed|s)) ?able ?to\b", " can ", rfclolfa)
		rfclolfa = " ".join(rfclolfa.split())

		# Transform 'can->avoid/avoid-synonym' -> 'can' normalization, e.g.
		# 'can avoid exposure to heights' -> 'can exposure to heights'.
		# TIP: Prevents false interpretation of 'avoid'/avoid synonym as 
		# 'total preclusion' when it is more properly read as 'capable of 
		# avoiding').
		# TIP: This supports eventual 'intelligent' no limitation 
		# IQ parsing b/c it retains the 'can', thereby leaving what 
		# could be a clause like 'can->FA terms' with no other LOL terms
		# present.
		rfclolfa = re.sub(r"\bcan ?(avoid|avert|abstain|circumvent|skip|bypass|evade|steer ?clear|cease|decline|stop|forgo|keep ?away|refuse|give ?up|be ?cautious|be ?wary|heed|look|watch|be ?mindful|refrain|take ?care|shun)", " can ", rfclolfa)

		# Transform all written numbers to integers up to 100 and perform 
		# other numeric cleaning/simplification via 'text2int':
		# TIP: This outputs written fractions (e.g. 'one-fourth') as no space '#/#', 
		# e.g. '1/4'; this is valuable because differentiates normalized written 
		# fractions from already-normalized NON-fractions (e.g. '2 / 4 hours'), as
		# '#/#' will not be divided during tokenization.
		rfclolfa = nlp_helper.text2int(rfclolfa)
		# print "POST-FRACTION RFCLOLFA:"
		# print rfclolfa
		# print "\n"

		# Transform select abbreviated/shortened words to remove their periods: 
		# TIP 08.08.2016: Critical to successful LOL identification b/c current
		# REGEX patterns do not compensate here for periods.
		rfclolfa = re.sub(r"\blbs\.", "lbs", rfclolfa)
		rfclolfa = re.sub(r"\blb\.", "lb", rfclolfa)

		# Transform all contractions to their full words:
		rfclolfa = nlp_helper.contractionexpand(rfclolfa)

		# Normalize spacing again:
		rfclolfa = " ".join(rfclolfa.split())
		
		# Transform many 'such as' variations uniform to 'such as':
		rfclolfa = re.sub(r"e\.g\.|including ?but ?not ?limited ?to|which ?includes ?but ?is ?not ?limited ?to|some ?of ?which ?are|which ?includes", " such as ", rfclolfa)
		rfclolfa = " ".join(rfclolfa.split())

		# Transform select '(legally defined) LOL 1 BUT NOT (legally or not 
		# legally defined) LOL 2' to 'LOL 1':
		# Constant:
		rfclolfa = re.sub(r"(\bconstantly|\bconstant)(,|)( ?)(but|yet|although|albeit)( ?)(never|not)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual)(,|)", r" \1 ", rfclolfa)
		rfclolfa = re.sub(r"(\bconstantly|\bconstant)(,|)( ?)(rather ?than|as ?opposed ?to|instead ?of)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual)(,|)", r" \1 ", rfclolfa)
		# Frequent:
		rfclolfa = re.sub(r"(\bfrequently|\bfrequent)(,|)( ?)(but|yet|although|albeit)( ?)(never|not)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual|constantly|constant)(,|)", r" \1 ", rfclolfa)
		rfclolfa = re.sub(r"(\bfrequently|\bfrequent)(,|)( ?)(but|yet|although|albeit)( ?)(rather ?than|as ?opposed ?to|instead ?of)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual|constantly|constant)(,|)", r" \1 ", rfclolfa)
		# Occasional:
		rfclolfa = re.sub(r"(\boccasionally|\boccasional)(,|)( ?)(but|yet|although|albeit)( ?)(never|not)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual|constantly|constant|frequently|frequent)(,|)", r" \1 ", rfclolfa)
		rfclolfa = re.sub(r"(\boccasionally|\boccasional)(,|)( ?)(but|yet|although|albeit)( ?)(rather ?than|as ?opposed ?to|instead ?of)( ?)(continually|continual|continuous|uninterrupted|endless|continued|perpetually|perpetual|constantly|constant|frequently|frequent)(,|)", r" \1 ", rfclolfa)
		# Non-Legally Defined 'But' Variations (to prevent false but splits):
		rfclolfa = re.sub(r'(decreased|restricted|limited|impeded|compromised|reduced) ?but ?adequate', ' limited ', rfclolfa)
		rfclolfa = re.sub(r'\b(decreased|restricted|limited|impeded|compromised|reduced|adequate|infrequent|continual)( ?)(but|yet|although|albeit) ?not(?! his)(?! her)(?! able)(?! capable) ?((\w+ \w+|\w+))', r' \1 ', rfclolfa)  # TIP: The inclusion of 'not' here is key to preventing false transformations.
		rfclolfa = " ".join(rfclolfa.split())
		
		# Transform highly complex exertional phrases of 
		# '[no/occ/total LOL] [lift FA/carry FA] [# LB] [no/occ/total LOL]' 
		# to '[lift FA/carry FA] [# LB] [no/occ/total LOL]':
		# TIP: Your dataset REGEX patterns handle instances where this 
		# complex language *immediately precedes* the targeted LOL value, 
		# e.g. "he can not perform any more than occasional stooping".
		rfclolfa = re.sub(r'(\bcan\b|\bcould\b|\bmay\b|\bwill\b|\bwould\b|\bmust\b|\bshall\b|\bshould\b|\bought ?to\b|\bought\b|)( ?)(\bnever|\bnot|\bno|\b(inability|unable) ?to|\b(restricted|impeded|restrained|hindered|constrained|inhibited|precluded) ?from|\bavoid|\brefrain ?from|precludes ?(the ?claimant ?from|him ?from|her ?from|Mr\. ?\w+ ?from|Ms\. ?\w+ ?from|Mrs\. ?\w+ ?from|Miss ?\w+ ?from|)|preclude ?(the ?claimant ?from|him ?from|her ?from|Mr\. ?\w+ ?from|Ms\. ?\w+ ?from|Mrs\. ?\w+ ?from|Miss ?\w+ ?from|))( ?)((lifting|carrying|lift|carry) ?(and ?/ ?or|and|and ?or| ?- ?|or| ?/ ?| |) ?(lifting|carrying|lift|carry|)) ?(any\w* ?more ?than|more ?than|beyond|in ?excess of|above|outside|) ?(\d+ ?(pounds|pound|lbs|lb)) ?(on ?any ?more ?than ?an|any ?more ?than|more ?than|beyond|on ?an|above|at most|) ?(occasionally|occasional ?basis|occasional)', r' \9 \14 occasionally ', rfclolfa)
		rfclolfa = re.sub(r'(\bcan\b|\bcould\b|\bmay\b|\bwill\b|\bwould\b|\bmust\b|\bshall\b|\bshould\b|\bought ?to\b|\bought\b|)( ?)(only|perform ?only|)( ?)(occasionally|on ?an ?occasional (but ?not ?frequent|) ?basis|at ?most ?occasionally|no ?more ?than ?occasionally|occasionally ?but ?(not|never) ?[a-z]+|occasional)( ?)(perform|)( ?)((lifting|carrying|lift|carry) ?(and ?/ ?or|and|and ?or| ?- ?|or| ?/ ?| |) ?(lifting|carrying|lift|carry|)) ?(up ?to ?|a ?total ?of ?|at ?most|no ?more ?than|never ?more ?than|any\w* ?more ?than|) ?(\d+ ?(pounds|pound|lbs|lb))', r' \11 \16 occasionally ', rfclolfa)           
		rfclolfa = re.sub(r'(\bcan\b|\bcould\b|\bmay\b|\bwill\b|\bwould\b|\bmust\b|\bshall\b|\bshould\b|\bought ?to\b|\bought\b|)( ?)(only|perform ?only|)( ?)(frequently|on ?an ?frequent (but ?not ?occasional|) ?basis|at ?most ?frequently|no ?more ?than ?frequently|frequently ?but ?(not|never) ?[a-z]+|frequent)( ?)(perform|)( ?)((lifting|carrying|lift|carry) ?(and ?/ ?or|and|and ?or| ?- ?|or| ?/ ?| |) ?(lifting|carrying|lift|carry|)) ?(up ?to ?|a ?total ?of ?|at ?most|no ?more ?than|never ?more ?than|any\w* ?more ?than|) ?(\d+ ?(pounds|pound|lbs|lb))', r' \11 \16 frequently ', rfclolfa)
		
		# Transform highly complex non-exertional phrases of 
		# '[not|no] [FA FA FA FA] [on any more|any more|more than] [TARGETED LOL]' 
		# to '[FA FA FA FA] [TARGETED LOL]', but ONLY IF nearly every word in 
		# [FA FA FA] is a targeted FA *and* [FA FA FA] contains no other LOLs in 
		# whatever few words remain.        
		splitlol_finditer = re.finditer(r"(\bcan|\bcould|\bmay|\bwill|\bwould|\bmust|\bshall|\bshould|\bought ?to|\bought|)( ?)(\bnever|\bnot|\bno|inability ?to|unable ?to|restricted ?from|impeded ?from|restrained ?from|hindered ?from|constrained ?from|inhibited ?from|precluded ?from|\bavoid|refrain ?from|precludes ?the ?claimant ?from|precludes ?him ?from|precludes ?her ?from|precludes|preclude ?the ?claimant ?from|preclude ?him ?from|preclude ?her ?from|preclude)( ?)((\w+[ ,/]{1,3}){1,10}?)( ?)(on ?any ?more ?than|any\w* ?more ?than|more ?than|beyond|above|in ?excess ?of|outside)( ?)(occasionally|frequently|constantly|occasional|frequent|constant|\w+ly)", rfclolfa)
		for res in splitlol_finditer:
			
			# Retrieve pertinent match groups:
			reswhole = res.group()
			reslol = res.group(10)
			resfastr = res.group(5)
			
			# If NO LOL terms in FA substring, proceed:
			resfastr = " ".join(resfastr.split())
			if not any(re.search(item[1], resfastr) for item in alllol):
				
				# If 1+ 'words' present in FA substring, proceed:
				fafindall = re.findall(r"[a-z0-9]+", resfastr)
				if fafindall:
					
					# If 1+ targeted FA term present, proceed:
					fastr = " ".join(fafindall)
					fastr = fastr.lower()
					# TIP: This compensates for FA REGEX patterns below that only look for '/'-split "and or":
					fastr = fastr.replace(" and or ", " and / or ")
					fareslistct = 0
					for listitem in alltargetfa:
						if bool(re.search(listitem[1], fastr)):
							fareslistct = 1
							fastr = re.sub(listitem[1], " ", fastr)
					if fareslistct != 0:
						
						# If, after removing targeted FA terms, 2 or fewer non-stopwords words remain, 
						# proceed with simplification:
						fastr_list = [token for token in fastr.split() if token not in stopword_coordinatingandmisc]
						if len(fastr_list) <= 2:
							rfclolfa_replstr = " " + resfastr + " " + reslol + " "
							rfclolfa = rfclolfa.replace(reswhole, rfclolfa_replstr, 1)
							rfclolfa = " ".join(rfclolfa.split())
		
		# TODO: Transform '[NEGATION] [on any more|any more|more than] [LOL]'
		# Example: "He cannot engage in any more than occasional stooping, crouching, or crawling."
		# Example: "He cannot perform more than frequent NNFA, NNFA, and NNFA"


		# Remove dates:
		# OPENQ: If a date is present in an RFC, it's highly likely there's some surrounding
		# 'low information' words related to that date's presence; can we quickly detect
		# surrounding date prepositional phrases/clauses and remove them?
		rfclolfa = re.sub(r'(january|february|march|april|may|june|july|august|september|october|november|december|\bjan\.?|\bfeb\.?|\bmar\.?|\bapr\.?|\bmay\.?|\bjun\.?|\bjul\.?|\baug\.?|\bsept\.?|\boct\.?|\bnov\.?|\bdec\.?) ?(\d{1,2})(, ?| )(\d {,2}){3}\d', ' ', rfclolfa)
		rfclolfa = re.sub(r'(january|february|march|april|may|june|july|august|september|october|november|december|\bjan\.?|\bfeb\.?|\bmar\.?|\bapr\.?|\bmay\.?|\bjun\.?|\bjul\.?|\baug\.?|\bsept\.?|\boct\.?|\bnov\.?|\bdec\.?) (\d {,2}){3}\d', ' ', rfclolfa)
		
		#print "\nRFC TEXT, ALL CLEANING/NORMALIZATION COMPLETE:"
		#print rfclolfa
		
		# (7) Begin Splitting of RFC With Sentence Tokenization:
		# TIP: You cannot perform other tokenization (such as semicolon or CC 
		# splitting) yet b/c we must preserve colons and semicolons for in-depth
		# parsing/splitting using all POS tag data.
		
		# Define SS 'Catchall' List Container:
		# TIP: Ultimately will hold ALL SS's (even those discarded at later steps):
		ss_catchall = []
		
		# Sentence tokenize:
		rfcsplit1 = nlp_helper.sentence_splitter(rfclolfa)
		
		# Before ideal form substitution, perform whitelist 'long form' EX 
		# sentence splitting where semantically a match means a given LOL/FA pair
		# 'thought' is almost certainly concluded after such language and thus
		# a split is appropriate.  Example:
		# "he can sit a total of 6 hours in an 8 hour day, and ...."
		# here '6 hours in an 8 hour day' would return a match, and would strongly
		# suppport performance of a split after 'day', as whatever follows is highly
		# unlikely to be semantically related to the content before the split.
		# TODO:
		rfcsplit1a = []
		for ss in rfcsplit1:
			ss_endloc_reslist = []
			for listitem in allsplitters:
				lol_ex_lb_finditer = re.finditer(listitem[1], ss)
				for res in lol_ex_lb_finditer:
					ss_endloc_reslist.append(res.end())
			ss_endloc_reslist_sortedunique = sorted(list(set(ss_endloc_reslist)))
			
			reslist = []
			if len(ss_endloc_reslist_sortedunique) == 0:
				rfcsplit1a.append(ss)
			elif len(ss_endloc_reslist_sortedunique) == 1:
				rfcsplit1a.append(ss[:ss_endloc_reslist_sortedunique[0]])
				rfcsplit1a.append(ss[ss_endloc_reslist_sortedunique[0]:])
			elif len(ss_endloc_reslist_sortedunique) == 2:
				rfcsplit1a.append(ss[:ss_endloc_reslist_sortedunique[0]])
				rfcsplit1a.append(ss[ss_endloc_reslist_sortedunique[0]:ss_endloc_reslist_sortedunique[1]])
				rfcsplit1a.append(ss[ss_endloc_reslist_sortedunique[1]:])
			else:
				for i, endloc in enumerate(ss_endloc_reslist_sortedunique):
					if i == 0:
						res = ss[:endloc]
						rfcsplit1a.append(res)
					elif i == len(ss_endloc_reslist_sortedunique)-1:
						res = ss[endloc:]
						rfcsplit1a.append(res)
					elif i == len(ss_endloc_reslist_sortedunique):
						break
					else:
						res1 = ss[ss_endloc_reslist_sortedunique[i-1]:endloc]
						rfcsplit1a.append(res1)
						res2 = ss[endloc:ss_endloc_reslist_sortedunique[i+1]]
						rfcsplit1a.append(res2)
		
		rfcsplit1a = list(set(rfcsplit1a))
		
		# (8) Perform 'Ideal Form' Substitutions:       
		
		# Sub in LOL_EX dataset items first:
		rfcsplit2a = []
		for ss in rfcsplit1a:
			ssdict = {"ss_revised":ss}  
			while True:  # TIP: This loop continues to sub in LOL_EX_LB ideal form language until it's no longer found.
				ss_revised = ssdict["ss_revised"]
				# TIP: Reslog list object contains:
				# sublist[0] = match length, 
				# sublist[1] = match start index position and match end index position, 
				# sublist[2] = the grouped result string, 
				# sublist[3] = the 'listitem' REGEX pattern, 
				# sublist[4] = the 'listitem' replacement string, and 
				# sublist[5] = the 'listitem' capture group #.
				reslog = []  
				for listitem in lol_ex:
					try:
						lol_ex_lb_finditer = re.finditer(listitem[1], ss_revised)
						for res in lol_ex_lb_finditer:
							reslog.append([int(res.end()-res.start()), [res.start(), res.end()], res.group(), listitem[1], listitem[2], listitem[3]])
					except Exception, x:
						logger.exception('EXCEPTION')
						raise
				if reslog:
					# TIP: If the 'longest' reslog item is a tie, this code will select the 'first' in the list (arbitrary):
					reslog.sort(key=lambda x:x[0], reverse=True)

					# Create spans from reslog sublist[1] index values:
					reslog = [[item[0], "_".join([str(i) for i in range(item[1][0],item[1][1])]), item[2], item[3], item[4], item[5]] for item in reslog]
					
					# Filter reslog to retain only longest *non-overlapping* spans:
					reslistoflists = []
					for listitem in reslog:
						if not any(listitem[1] in lol[1] for lol in reslistoflists):
							reslistoflists.append(listitem)
					
					# Replace each matching text entity with its 'ideal form' replacement:
					for lol in reslistoflists:              
						lol_res = re.findall(lol[3], lol[2])[0]
						lol_res_amt = lol_res[lol[5]]
						substr = " " + lol_res_amt + lol[4] + " "
						ss_revised = ss_revised.replace(lol[2], substr, 1)

					# Reassign 'ss_revised', then continue with loop:
					ssdict["ss_revised"] = ss_revised

				# Else if 0 new entries found, append and proceed to the next SS:
				else:
					rfcsplit2a.append(str(" ".join(ss_revised.split())))
					break
		
		# Sub in for all remaining non-LOL_EX (LB/HR) dataset items:
		rfcsplit2b = []
		for ss in rfcsplit2a:
			ssdict = {"ss_revised":ss}
			while True:
				ss_revised = ssdict["ss_revised"]
				
				# TIP: Reslog list object contain:
				# sublist[0] = match length
				# sublist[1] = match start index position and match end index position
				# sublist[2] = the matching text
				# sublist[3] = the 'ideal form' replacement string
				reslog = []
			
				for listitem in allposbutlolhrlollb:
					item_finditer = re.finditer(listitem[1], ss_revised)
					for res in item_finditer:
						reslog.append([res.end()-res.start(), [res.start(), res.end()], res.group(), listitem[2]])
				
				if reslog:
					# TIP: If the 'longest' match length is a tie, this code will select the 'first' in the list (arbitrary):
					reslog.sort(key=lambda x:x[0], reverse=True)  

					# Create spans from reslog sublist[1] index values:
					reslog_spans = [["_".join([str(i) for i in range(item[1][0],item[1][1])]), item[2], item[3]] for item in reslog]
					
					# Filter reslog to retain only longest *non-overlapping* spans:
					reslistoflists = []
					for listitem in reslog_spans:
						if not any(listitem[0] in lol[0] for lol in reslistoflists):
							reslistoflists.append(listitem)
					
					# Replace each matching text entity with its 'ideal form' replacement:
					for lol in reslistoflists:              
						ss_revised = ss_revised.replace(lol[1], lol[2], 1)
					
					# Reassign 'ss_revised', then continue with loop:
					ssdict["ss_revised"] = ss_revised   

				# Else if 0 new entries found, append and proceed to the next SS:
				else:
					rfcsplit2b.append(str(" ".join(ss_revised.split())))
					break
		
		#print '\nPOST-SENT TOKENIZATION/IDEAL FORM SUBS:'
		#for ss in rfcsplit2b:
			#print ss
		
		# (9) Tokenize and POS tag SSs:
		# TIP: TextBlob automatically tokenizes prior to POS tagging, so no need
		# to tokenize first.
		# TIP: TextBlob will not separate '/'-divided words, e.g. ('STAND/WALK').
		# TIP: TextBlob returns Unicode text.  Thus, converting back to ASCII below.
		rfcSStokensrawpos = []
		for ss in rfcsplit2b:
			rawtuplelist = tagger.tag(ss)
			rfcSStokensrawpos.append(rawtuplelist)
		
		#print 'rfcSStokensrawpos:'
		#for ss in rfcSStokensrawpos:
			#print ss

		# Convert TextBlob tokens and POS tags from unicode to ASCII:
		rfcSStokensrawpos_converted = []
		for ss in rfcSStokensrawpos:
			newss = [(tup[0].encode('ascii','ignore'), tup[1].encode('ascii','ignore')) for tup in ss]
			rfcSStokensrawpos_converted.append(newss)
		
		# (10) Substitute In Custom POS Tags From Raw POS Tags:
		# TIP: You've already converted to 'ideal form' language AND you've
		# already tokenized.  All 'ideal form' entries are only one token in
		# length AND they're uppercase, it should be extremely fast to run
		# through these and replace 'default' POS tags with the custom POS tags for the
		# single token matching entries.
		# TIP: This raises question of whether there are 'ideal form' collisions, 
		# i.e. same 'ideal form' language but different POS tags; while there are 
		# some 'ideal form' items with different custom POS tags (in every case, it's
		# a NN_FA_NONEX and NN_FA_ENVT), there is no practical consequence of this in 
		# terms of ultimate assignment to a particular function.
		rfcSStokenscustomposmods = []
		for ss in rfcSStokensrawpos_converted:
			new_ss = []
			for tup in ss:
				if "LBB" in tup[0] and "FREQ" not in tup[0]:
					new_ss.append((tup[0], 'LOL_EX_LB'))
				elif "HRR" in tup[0]:
					new_ss.append((tup[0], 'LOL_EX_HR'))
				elif "LBBFREQ" in tup[0]:
					new_ss.append((tup[0], 'XX_LOL'))
				else:
					matchver = 0
					for li in allpos_customposrepl:
						if tup[0] == li[2].strip():
							new_ss.append((tup[0], li[0]))
							matchver = 1
							break
					if matchver == 0:
						new_ss.append(tup)
			rfcSStokenscustomposmods.append(new_ss)
							
		#print "\nCUSTOM POS TAGS:"
		#for ss in rfcSStokenscustomposmods:
			#print ss
		
		# (X) Analyze parentheticals for possible splitting:
		# Rules:
		# - If the parenthetical contains 1+ complete LOL/FA pairing (e.g. 'but no stooping'), 
		# remove it and make it its own SS;
		# - Conversely, if the parenthetical is simply an aside, or contains only 1+ LOL or 
		# only 1+ FA, then remove the parentheses and retain it in current position.
		rfcSStokenscustomposmods_0 = []
		for ss in rfcSStokenscustomposmods:

			# This variable records where each loop of the analysis ended:
			analysis_end_ix_dict = {"ix":0}

			paren_cut_ix_tuplist = []

			while True:
				
				if analysis_end_ix_dict['ix'] == len(ss)-1 or analysis_end_ix_dict['ix'] == len(ss):
					break
				
				ix = analysis_end_ix_dict['ix']
				ssslice = ss[ix:]

				try:
					# Get ix of first instance of '(' tup:
					paren_open_ix = [tup[0] for tup in ssslice].index('(')
					# Get ix of first instance of ')' tup:
					paren_close_ix = [tup[0] for tup in ssslice].index(')')
				except ValueError:
					break

				ss_paren = ssslice[paren_open_ix:paren_close_ix]
				if any(tup[1].startswith("NN_FA") for tup in ss_paren) and (any(tup[1].startswith("LOL") for tup in ss_paren) or any(tup[1].startswith("XX_LOL") for tup in ss_paren)):
					paren_cut_ix_tuplist.append((paren_open_ix, paren_close_ix))
				
				paren_close_ix_plusaddons = paren_close_ix + 1 + analysis_end_ix_dict['ix']
				analysis_end_ix_dict['ix'] = paren_close_ix_plusaddons

			paren_cut_range_list = [range(tup[0],tup[1]+1) for tup in paren_cut_ix_tuplist]
			paren_cut_range_list = list(cfx.flatten_irreg(paren_cut_range_list))
			tup_reslist = []
			for i, tup in enumerate(ss):
				if i not in paren_cut_range_list:
					tup_reslist.append(tup)
			rfcSStokenscustomposmods_0.append(tup_reslist)
			
			
			# Now pull out individual tup ix's to be cut:
			for tup in paren_cut_ix_tuplist:
				tup_reslist = []
				tup_range = range(tup[0],tup[1])
				for r in tup_range:
					tup_reslist.append(ss[r])
				rfcSStokenscustomposmods_0.append(tup_reslist)

		# (11) Remove All SS's That Do Not Contain 1+ Targeted Physical Function
		# ('NN_FA' Tags) - Round 1:
		rfcSStokenscustomposmods_1 = []
		for ss in rfcSStokenscustomposmods_0:
			if any(tup[1].startswith("NN_FA") for tup in ss):
				rfcSStokenscustomposmods_1.append(ss)
			else:
				ss_catchall.append(ss)
		
		# (12) Perform Colon Parsing/Splitting of SS's:
		
		# Define generator function to split iterable of tuples on a target tuple:
		# TIP: Reference - http://stackoverflow.com/questions/4322705/split-a-list-into-nested-lists-on-a-value
		def _tupsplitter(tuplist, splitting_tup):
			current = []
			for tup in tuplist:
				if tup == splitting_tup:
					if current:
						yield current
						current = []
				else:
					current.append(tup)
			if current:
				yield current

		# Define call to generator function:
		def colonsplitter(tuplist, splitting_tup):
			return [i for i in _tupsplitter(tuplist, splitting_tup)]
		
		# Define 'single colon' parsing function:
		# TIP: Returns a list of lists in every instance.
		def parse_single_colon(tuplist, colon_index):
			try:

				# Isolate pre- and post-colon tuples:
				precolon_tuplist = tuplist[:colon_index]
				postcolon_tuplist = tuplist[colon_index+1:]

				# Count certain pre- and post-colon tuples:
				precolon_lol_tuplist = [tup for tup in precolon_tuplist if tup[1].startswith("LOL") or tup[1] == 'XX_MODPOS']
				precolon_fa_tuplist = [tup for tup in precolon_tuplist if tup[1].startswith("NN_FA")]
				postcolon_lol_tuplist = [tup for tup in postcolon_tuplist if tup[1].startswith("LOL") or tup[1] == 'XX_MODPOS']
				postcolon_fa_tuplist = [tup for tup in postcolon_tuplist if tup[1].startswith("NN_FA")]

				# Handle scenario 1 (1 LOL precolon, 0 LOL post but FAs: pre-colon LOL must apply to post-colon FA):
				if len(precolon_lol_tuplist) == 1:
					if len(precolon_fa_tuplist) == 0:
						if len(postcolon_lol_tuplist) == 0:
							# TIP: Removing any semicolons present so that this 'complete thought' is
							# not inadvertently split during semicolon parsing/splitting below:
							tuplist = [(',', ',') if tup[0] == ';' else tup for tup in tuplist]
							return [tuplist]
						else:
							# 'He can LOL [no or unknown function term(s)], as well as: stoop, crouch, and can crawl frequently.'
							# 'He can LOL: stoop and crouch; and can crawl frequently;' (less likely as it is illogical).
							# Verdict: I say split at colon, but keep semicolons in place.  Bottom line is on balance
							# I think it less likely the precolon LOL has a relation to a post-colon FA given
							# the presence of post-colon LOLs:
							return [precolon_tuplist, postcolon_tuplist]
							
					# If there's both an LOL and FA pre-colon, split (seems like
					# a complete pair) and keep semicolons in place:
					else:
						return [precolon_tuplist, postcolon_tuplist]
				
				# Handle scenario 2 (nothing of value before colon, so remove it):
				elif len(precolon_lol_tuplist) == 0:
					if len(precolon_fa_tuplist) == 0:
						return [postcolon_tuplist]
					else:
						# If there is even a possible LOL RB/JJ precolon, then split; otherwise, don't; as the examples
						# below make clear, in some cases you want to keep the precolon FAs with the post-colon language.
						# 'He can [FA} only [unknown LOL] and can also: stoop frequently; crouch constantly; and never crawl.'
						# 'He can finger, handle, and grip to the following degrees: occasionally with the right, frequently with the left.'
						anylol_tuplist = [tup for tup in precolon_tuplist if tup[1].startswith("RB") or tup[1].startswith("JJ")]
						if anylol_tuplist:
							return [precolon_tuplist, postcolon_tuplist]
						else:
							return [postcolon_tuplist]

				# Else, if 2+ LOL before the colon... I'd say for now you should leave the SS 'as is'
				# because I don't know what to do with that:
				else:
					return [tuplist]
			except Exception:
				#print "ERROR"
				return [tuplist]
		
		# Parse colons by SS (based on # of colons present):
		sslist1 = []
		for i, ss in enumerate(rfcSStokenscustomposmods_1):
			
			# Count # of colons present in SS's text:
			ss_text = " ".join([tup[0] for tup in ss])
			colon_tuplist = [tup for tup in ss if tup[0] == ':']
			colon_index_list = [i for i, tup in enumerate(ss) if tup[0] == ':']
			
			# If 0, add the SS untouched:
			if len(colon_index_list) == 0:
				sslist1.append(ss)
			
			# If 1, parse using rules developed in colon notes, etc.:
			elif len(colon_index_list) == 1:
				
				# (DEPRECATED - parse_single_colon handles this same way)
				# If the first or last token in the SS is the 1 colon, no parsing
				# is necessary; remove the ':' and add the SS:

				# Count semicolons:
				semic_tuplist = [tup for tup in ss if tup[0] == ';']
				semic_index_list = [i for i, tup in enumerate(ss) if tup[0] == ';']
				# If 1+ semicolons, check to ensure that all semicolons 
				# are located *after* the 1 colon at issue before colon parsing:
				# TODO: Study instances where this is NOT true to understand 
				# what to do in this instance.
				if len(semic_index_list) >= 1:
					if all(colon_index_list[0] < ind_val for ind_val in semic_index_list):
						ss_reslist = parse_single_colon(ss, colon_index_list[0])
						for tuplist in ss_reslist:
							sslist1.append(tuplist)
					# Else, add the SS untouched.  The odd pre-colon semicolon(s) 
					# can be split by semicolon parsing/splitting below.
					else:
						sslist1.append(ss)
				# Else you can proceed to single colon parsing directly:
				else:
					ss_reslist = parse_single_colon(ss, colon_index_list[0])
					for tuplist in ss_reslist:
						sslist1.append(tuplist)
			# If 2+ colons, split at colons:
			# TIP: 'semicolon_studies_08052016' revealed that only 1.4% 
			# of sentences with a colon contain 2 colons (with that figure 
			# reducing substantially above 2), thus anything you do here 
			# won't occur often.
			# TIP: Why would there be 2 colons in the same
			# sentence...?  /// Typically this appears where there's an introductory
			# colon and then a later 'list-introducing' colon, e.g. 'he has the following
			# limitations: he can stoop frequently; crawl; and perform the following
			# manipulative functions occasionally: reaching, handling, and fingering.'
			else:
				colon_tup = (':', ':',)
				res_tuplist = colonsplitter(ss, colon_tup)
				for res in res_tuplist:
					sslist1.append(res)

		# (13) Perform Semicolon Parsing/Splitting of SS's:
		# TIP: The colon splitter above has already removed semicolons
		# present as part of a single-LOL-precolon-followed-by-semicolon-list SS. 
		
		# Define semicolon splitting call to _tupsplitter:
		def semicolonsplitter(tuplist, splitting_tup):
			return [i for i in _tupsplitter(tuplist, splitting_tup)]

		# Parse semicolons by SS:
		sslist2 = []
		semicolon_tup = (';', ':')
		for ss in sslist1:
			res_tuplist = semicolonsplitter(ss, semicolon_tup)
			for res in res_tuplist:
				sslist2.append(res)
		
		#print 'sslist2 (post-semicolon split, pre-never part of list splits):'
		#for ss in sslist2:
			#print ss

		# (14) Perform 'Never Part of List' Conjunction Term Parsing/Splitting 
		# (a.k.a. 'never CCs'):

		# Define 'never CC' generator function:
		# TODO: Update this to prevent false splits. This erroneously splits 'intervening' clauses that use these
		# 'never CC'.  For example:
		# (A) "he can occasionally stoop, crouch, and, except for in outdoor environments, crawl" - erroneous split at 'except' despite 'crawling'
		# clearly going to 'occasional'.
		# (B) "he can frequently finger and, except for very large objects, handle"
		# New rule might be, if the except is preceded by a comma, and then there's another comma after the except clause
		# rather than the end of the SS, clearly it is likely to be an modifier not meant to break the SS.  For example:
		# "she can frequently perform posturals, except she cannot stoop; " should be split, while
		# "she can frequently finger and, except large objects, handle" should not be split.
		def _tupsplitter_nevercc(tuplist):
			current = []
			for i, tup in enumerate(tuplist):
				if tup[0].upper() in ['BUT', 'YET']:
					if current:
						yield current
						current = []
				elif tup[0] == ',':
					try:
						if tuplist[i+1][0].upper() in ['WHILE', 'HOWEVER', 'WHEREAS', 'EXCEPT', 'WITH THE EXCEPTION OF']:
							if tuplist[i+2][0].isalpha() or tuplist[i+2][0].isdigit():
								if current:
									yield current
									current = []
								else:
									current.append(tup)
							else:
								current.append(tup)
								
						elif tuplist[i+1][0].upper() == 'ONLY':
							nxt_tup_str = tuplist[i+2][0].upper()
							if not any(item for item in alllol if item[2] == nxt_tup_str):
								if current:
									yield current
									current = []
								else:
									current.append(tup)                             
							else:
								current.append(tup)
						else:
							current.append(tup)
					# If an IndexError occurs, meaning the never CC is very close
					# to the end of the SS text, don't split:
					except IndexError:
						current.append(tup)
				else:
					current.append(tup)
			if current:
				yield current
		
		# Define call to _tupsplitter_nevercc:
		def nevercc_splitter(tuplist):
			return [i for i in _tupsplitter_nevercc(tuplist)]   

		# Parse 'never CC' by SS:
		sslist3 = []
		for ss in sslist2:
			res_tuplist = nevercc_splitter(ss)
			for res in res_tuplist:
				sslist3.append(res)
		
		#print '\nsslist3 (after never CC):'
		#for ss in sslist3:
			#print ss
		
		# (15) Perform 'List Possible' Conjunction Term 
		# Parsing/Splitting (a.k.a. 'and CCs'):
		
		# Define 'and CC' generator function:
		def _andtupsplitter(tuplist, splitting_tup_ind_list):
			current = []
			for i, tup in enumerate(tuplist):
				if i in splitting_tup_ind_list:
					if current:
						yield current
						current = []
				else:
					current.append(tup)
			if current:
				yield current

		# Define call to _andtupsplitter:
		def andsplitter(tuplist, splitting_tup_ind_list):
			return [i for i in _andtupsplitter(tuplist, splitting_tup_ind_list)]

		# Define 'and CC' split verdict function, called where:
		# - There is 1+ 'and CC' present; and
		# - There are 2+ independent targeted/non-targeted LOL values present; and
		# - (From prior parsing) there is at least 1 targeted FA present.
		# TIP: Will return 'y' for 'split at this and CC' or 'n' for 'do not split'.
		def parse_andcc_splitver(ss, tgt_ind):

			# If any LOL/LOL phrase immediately follows the 'and CC', split:
			# Example: "..and occasional.."
			try:
				if ss[tgt_ind+1][1][:2] in ['LO', 'RB', 'JJ']:
					return 'y'
			except IndexError:
				pass
			
			try:
				if ss[tgt_ind+1][1] == 'XX_MODPOS':
					return 'y'
			except IndexError:
				pass

			# If the 'and CC' split is immediately followed by when/where as a highly likely
			# relative pronoun/subordinating conjunction:
			# Example: "She can reach occasionally and when cleaning can never be exposed to dusts"
			try:
				if ss[tgt_ind+1][0] in ['WHEN', 'WHERE', 'WHENEVER', 'WHEREVER']:
					return 'y'
			except IndexError:
				pass
			
			# If any LOL immediately precedes the 'and CC', split:
			# Example: "She can handle occasionally and ..."
			try:
				if ss[tgt_ind-1][1][:2] in ['LO', 'RB', 'JJ'] or ss[tgt_ind-1][1] == 'XX_MODPOS':
					return 'y'
			except IndexError:
				pass
			
			# If any LOL immediately precedes a comma that immediately precedes the 'and CC', split:
			# "She can handle occasionally, and ..."
			try:
				if ss[tgt_ind-1][0] == ',':
					if ss[tgt_ind-2][1][:2] in ['LO', 'RB', 'JJ'] or ss[tgt_ind-2][1] == 'XX_MODPOS':
						return 'y'
			except IndexError:
				pass

			# Catch-all for above two rules:  If there's a complete clause in that there's a NN_ somewhere before 
			# the 'and CC' plus some adverb ending in 'ly' immediately preceding the 'and_CC', split:
			# "She can NN intermittently and ..."
			try:
				if ss[tgt_ind-1][0][-2:] == 'LY' and ss[tgt_ind-1][1] in ['LO', 'RB', 'JJ']:
					ss_tgt_ind_fwd = ss[tgt_ind:]
					for tup in ss_tgt_ind_fwd:
						if 'NN_' in tup[1]:
							return 'y'
			except IndexError:
				pass
					
			# If all LOL entities appear on one side of the targeted 'and CC', don't split.
			# Ex. 1: 'stoop, crouch and crawl occasionally, finger frequently'
			# Ex. 2: 'finger occasionally and stoop frequently, and handle' (yes wrong, but still, worth splitting)
			lol_ind_list = [i for i, tup in enumerate(ss) if tup[1][:2] in ['LO', 'RB', 'JJ'] or tup[1] == 'XX_MODPOS']
			if all(i > tgt_ind for i in lol_ind_list) or all(i < tgt_ind for i in lol_ind_list):
					return 'n'
			
			# Else, you have a complex pattern where LOLs appear on either side of the targeted 'and CC'; in
			# this case, you'll have to continue your parsing using the new 'comma barrier/LOL outward parsing
			# strategy developed recently.
			return 'n'
		
		# Parse 'and CC' by SS:
		sslist4 = []
		for ss in sslist3:
			
			# Count 'and CC':
			andcc_index = [i for i, tup in enumerate(ss) if tup[0].upper() in ['AND', 'AS WELL AS', 'OR']]
			
			# Count # of LOL entities (broad measure):
			lol_ct = 'U'
			xx_modpos_index = [i for i, tup in enumerate(ss) if tup[1] == 'XX_MODPOS']
			other_lol_index = [i for i, tup in enumerate(ss) if tup[1][:2] in ['LO', 'RB', 'JJ']]
			# TODO: Nuance this further to account for MULTIPLE
			# XX_MODPOS that may be present.
			if len(xx_modpos_index) == 1 and len(other_lol_index) == 1 and xx_modpos_index[0] + 1 == other_lol_index:
				lol_ct = 1
			else:
				lol_ct = len(other_lol_index) + len(xx_modpos_index)
			
			# If 0 'and CC' present, stop:
			if len(andcc_index) == 0:
				sslist4.append(ss)
			
			# Else, proceed:
			else:
				
				# Define 'and CC' split verdict tuple list container where
				# tuple[0] == 'and CC' index integer and tuple[1] == split verdict:
				and_cc_index_splitverdict_tuplist = []
				
				# Iterate through each 'and CC' to generate a split verdict value:
				for i in andcc_index:
					
					# SIMPLE CASES:
					# If 0 targeted/non-targeted LOL values, do not split.
					# Symbolic Coverage:
					# (FA|AND_CC|XX)+
					# Examples: '; stoop and crouch as well as crawl;'
					if lol_ct == 0:
						and_cc_index_splitverdict_tuplist.append((i, 'n'))
					
					# COMPLEX CASES:
					# If 1+ targeted/non-targeted LOL value, continue with
					# split verdict parsing:
					else:
						splitver_res = parse_andcc_splitver(ss, i)
						and_cc_index_splitverdict_tuplist.append((i, splitver_res))
						
				# Split on 'y' verdict index integers:
				and_cc_index_splitverdict_tuplist_yes = [tup[0] for tup in and_cc_index_splitverdict_tuplist if tup[1] == 'y']
				for item in andsplitter(ss, and_cc_index_splitverdict_tuplist_yes):
					sslist4.append(item)
		
		#print '\nsslist4/post-AND splitting, pre-0 physical function removal filter:'
		#for ss in sslist4:
			#print ss

		# Define conservative 'complete clause' 'and CC' splitting function:
		def complete_cl_and_cc_splitter(ss):
			"""
			Split two 'complete', clause-like subsections containing a subject
			followed by a 'predicate' (here a word likely to be an LOL and
			a word likely to be an FA) that are divided by an 'and CC'.
			
			>>> complete_cl_and_cc_splitter([(u'CLAIMANT', u'NN'), (u'CAN', u'VB'), (u'FREQUENT', u'NN'), (u'run', u'VB'), (u'and', u'CC'), (u'CLAIMANT', u'NN'), (u'CAN', u'VB'), (u'NO', u'DT'), (u'STOOP', u'NN')])
			[4]
			
			>>> complete_cl_and_cc_splitter([(u'CAN', u'VB'), (u'FREQUENT', u'NN'), (u'run', u'VB'), (u'and', u'CC'), (u'CLAIMANT', u'NN'), (u'CAN', u'VB'), (u'NO', u'DT'), (u'STOOP', u'NN')])
			[]
			
			Args:
				ss {list}: A list of subsection tuples.
			Returns:
				andcc_indexlist_splitlist {list}: A list of 'and CC' index values
					in 'ss' to split on.
			Raises:
				N/A.
			"""
			try:
				# Gather 'and CC' index values that are NOT part of lists:
				andcc_indexlist = []
				for i, tup in enumerate(ss):
					if tup[0].upper() in ['AND', 'AS WELL AS']:
						nnver = 0
						try:
							if ss[i-1][1].startswith('NN') or (ss[i-2][1].startswith('NN') and ss[i-1][1] == ','):
								if ss[i+1][1].startswith('NN'):
									nnver = 1
						except IndexError:
							pass
						if nnver != 1:
							andcc_indexlist.append(i)
				if not andcc_indexlist:
					return []

				# Simple/conservative approach: For each 'and CC', if SS content before
				# and after contain the pattern [SUBJECT] -> [LOL-LIKE & FA-LIKE IN ANY ORDER], 
				# then split:
				andcc_indexlist_splitlist = []
				for ix, andcc_i in enumerate(andcc_indexlist):

					# Split at each 'and CC' in sequence, with the 'pre' 
					# consisting of only the discrete section prior any earlier
					# 'and CC' (or the start of the SS):
					# TIP: The 'and CC' will always fall into the 'post' split.
					andcc_indexlist_pre = 0
					if ix != 0:
						andcc_indexlist_pre = max(andcc_indexlist[:ix])
					ss_pre = ss[andcc_indexlist_pre:andcc_i]
					ss_post = ss[andcc_i:]
					#print 'ss_pre', ss_pre
					#print 'ss_post', ss_post

					# Determine if pre-'and CC' SS fits pattern:
					ss_pre_splitver = 0
					ss_pre_subj_ixlist = [i for i, tup in enumerate(ss_pre) if tup[0].upper() == 'CLAIMANT' or tup[1] in ['PRP']]
					ss_pre_lollk_ixlist = [i for i, tup in enumerate(ss_pre) if tup[1][:2] in ['LO', 'RB', 'JJ'] or tup[1] == 'XX_MODPOS']
					ss_pre_falk_ixlist = [i for i, tup in enumerate(ss_pre) if tup[1].upper().startswith('NN') or tup[1].upper().startswith('VB')]
					if ss_pre_subj_ixlist:
						for ix2 in ss_pre_subj_ixlist:
							if len([lol_ix for lol_ix in ss_pre_lollk_ixlist if ix2 < lol_ix]) >= 1 and len([fa_ix for fa_ix in ss_pre_falk_ixlist if ix2 < fa_ix]) >= 1:
								ss_pre_splitver = 1
					if ss_pre_splitver == 0:
						continue

					# Determine if post-'and CC' SS fits pattern:
					ss_post_splitver = 0
					ss_post_subj_ixlist = [i for i, tup in enumerate(ss_post) if tup[0].upper() == 'CLAIMANT' or tup[1] in ['PRP']]
					ss_post_lollk_ixlist = [i for i, tup in enumerate(ss_post) if tup[1][:2] in ['LO', 'RB', 'JJ'] or tup[1] == 'XX_MODPOS']
					ss_post_falk_ixlist = [i for i, tup in enumerate(ss_post) if tup[1].upper().startswith('NN') or tup[1].upper().startswith('VB')]
					if ss_post_subj_ixlist:
						for ix2 in ss_post_subj_ixlist:
							if len([lol_ix for lol_ix in ss_post_lollk_ixlist if ix2 < lol_ix]) >= 1 and len([fa_ix for fa_ix in ss_post_falk_ixlist if ix2 < fa_ix]) >= 1:
								ss_post_splitver = 1
					if ss_post_splitver == 0:
						continue

					andcc_indexlist_splitlist.append(andcc_i)
					
				return andcc_indexlist_splitlist
			except Exception:
				# logger.exception('EXCEPTION')
				return []

		# Parse conservative 'complete clause' 'and CC' splits by SS:
		sslist5 = []
		for ss in sslist4:
			ccacs_reslist = complete_cl_and_cc_splitter(ss)
			if not ccacs_reslist:
				sslist5.append(ss)
			else:
				for item in andsplitter(ss, ccacs_reslist):
					sslist5.append(item)

		#print '\nsslist5/post-COMPLETE CLAUSE AND CC splitting, pre-0 physical function removal filter:'
		#for ss in sslist4:
			#print ss


		# (16) Remove All SS's That Do Not Contain 1+ Targeted Physical Function
		# ('NN_FA' Tags) - Round 2:
		tuplelist6 = []
		for ss in sslist5:
			if any(tup[1].startswith("NN_FA") for tup in ss):
				tuplelist6.append(ss)
			else:
				ss_catchall.append(ss)
		
		
		# (17) Divide the SS's by the number and type of LOLs they contain 
		# (targeted vs. non-targeted):
		# TIP: We already know that every SS put in a bin here contains:
		# - At LEAST 1 targeted FA term.
		# - No spitting targets (besides commas) that haven't already been looked at.

		# 0 LOL OF ANY KIND:
		# TODO: Parse these for select XX_MODPOS that indicate 'nolim' language.
		sslist_0lol = []
		
		# 0 TGT_LOL, 1+ LOL_NLD, 0 OTHER LOL:
		# TODO: Send this forward as the LOL_NLD verdict and value!!! Because what 
		# you're saying for SS's in this container is: "you contain at least 1 
		# targeted physical FA term, you contain NO targeted LOL terms, and
		# you contain 1(+?) LOL_NLD!"
		sslist_0tgtlol_1pluslolnld_0otherlol = []
		
		# 0 TGT_LOL, 0 LOL_NLD, 1+ OTHER LOL:
		# TODO: Also sent THESE forward as LOL_NLD! Remember, there is 1+ targeted
		# physical FA term(s) in these SS's and yet they contain no TGT LOLs!
		sslist_0tgtlol_0lolnld_1plusotherlol = []
		
		# 0 TGT LOL, 1+ LOL_NLD, 1+ OTHER LOL:
		# TODO: This can also be put forward as LOL_NLD!
		sslist_0tgtlol_1pluslolnld_1plusotherlol = []
		
		# 1 LOL_TGT, 0 OTHER LOL:
		sslist_1tgtlol_0otherlol = []
		
		# 1 LOL_TGT, 2+ TOTAL LOL:
		# TIP: Any SS where there's exactly 1 LOL_TGT but also 1+ other types of LOLs.
		# TIP: You can apply your new comma parsing ideas to these SS's.
		sslist_1tgtlol_1plusotherlol = []
		
		# 2+ TGT_LOL, UNKNOWN OTHER LOL (not parsed):
		# TIP: You can apply your new comma parsing ideas to these SS's.
		sslist_2plustgtlol = []
		
		# Define LOL counting function:
		# TIP: Adds directly to list objects.
		# OPENQ: This does not evaluate 'free standing' XX_MODPOS, even though they
		# may be serving as 'no limitation' language.  What are your dataset's
		# 'no limitation' assets?  LOL_NLD dataset contains some 'no limitation'
		# patterns, but only those that are explicit in their denial of limitations,
		# e.g. 'no limitations in'.  It does NOT account for freestanding 'XX_MODPOS'.
		# VERDICT: I say proceed 'as is', and then later, parse 'sslist_0lol' to
		# search for free standing XX_MODPOS.  If 1+ present, suggests it's a 
		# LOL_NLD_NOLIM SS you should output for IQ.
		def lol_counter(ss):
			tgtlol_ct = 0
			ct = 0
			while ct != len(ss):
				try:
					if ss[ct][1] == 'XX_MODPOS':
						try:
							if ss[ct+1][1] in ['LOL_EX_HR', 'LOL_EX_LB', 'LOL_NONEX', 'LOL_ENVT']:
								tgtlol_ct += 1
								ct += 2
							else:
								ct += 1
						except IndexError:
							break
					else:
						if ss[ct][1] in ['LOL_EX_HR', 'LOL_EX_LB', 'LOL_NONEX', 'LOL_ENVT']:
							tgtlol_ct += 1
							ct += 1
						else:
							ct += 1
				except IndexError:
					break
			lolnld_ct = len([tup for tup in ss if tup[1].startswith('LOL_NLD')])
			otherlol_ct = len([tup for tup in ss if tup[1][:2].startswith('RB') or tup[1].startswith('JJ')])
			
			#print 'tgtlol_ct:' + str(tgtlol_ct)
			
			if tgtlol_ct == 0:
				if lolnld_ct == 0 and otherlol_ct == 0:
					sslist_0lol.append(ss)
				elif lolnld_ct >= 1 and otherlol_ct == 0:
					sslist_0tgtlol_1pluslolnld_0otherlol.append(ss)
				elif lolnld_ct == 0 and otherlol_ct >= 1:
					sslist_0tgtlol_0lolnld_1plusotherlol.append(ss)
				else:
					sslist_0tgtlol_1pluslolnld_1plusotherlol.append(ss)
			elif tgtlol_ct == 1:
				if lolnld_ct == 0 and otherlol_ct == 0:
					sslist_1tgtlol_0otherlol.append(ss)
				else:
					sslist_1tgtlol_1plusotherlol.append(ss)
			else:
				sslist_2plustgtlol.append(ss)

		# Parse by SS (also, add all SS's to 'ss_catchall' for Quality analysis usage):
		for ss in tuplelist6:
			lol_counter(ss)
			ss_catchall.append(ss)
		


		# TODO:
		# ALTERNATIVE/ADDITIONAL RULE:
		# If there's an AND clause, then evaluate whether there's *non-comma-divided*
		# targeted or non-stargeted LOL/FA pairs on either side of the AND.  If there is, then you can
		# be a bit more confident the items before the AND don't relate to the items
		# after.  Designed to handle more 'noisy' AND clause splitting. Examples:
		# "she can frequently stoop and she can occasionally handle"
		# "she can frequently stoop and is capable of handling occasionally"
		# "she can occasionally stoop and crawl frequently"
		#print '\nSSCATCHALL PRE BORDER PARSER OF 2+ LOL SS:'
		#for ss in ss_catchall:
			#print ss


		# IN DEVELOPMENT 10162017
		# New, very conservative ss splitter based on commas, 
		# 'and CC', and so on:
		def conservative_splitter(ss):
			"""
			Parse a 2+ LOL, 1+ FA subsection to 
			potentially return further divided
			subsections.
			
			Args:
				ss {list}: A subsection consisting of
					a list of tuples where tup[0] = a 
					word and tup[1] = a POS tag.
			Returns:
				snippet_reslist {list}: A list of 
					lists of subsection snippets 
					extracted from ss.
			Raises:
				N/A (returns empty list if exception
				occurs).
			"""
			try:
				snippet_reslist = []

				# Remove barriers between FA lists:
				# How? You could simply remove AND and ',' when the rules apply.
				# However, these 'rules' you're envisioning are VERY tricky:
				# WORKS: "; he can stoop, crouch, and crawl occasionally, handle frequently, and have only intermittent public contact; "
				# WORKS: "; he can occasionally stoop, crouch and crawl, frequently X"
				# DOESN'T WORK: "; he can occasionally stoop and crouch frequently"
				# DOESN'T WORK: "; he can occasionally stoop and crouch, frequently crawl"
				# DOESN'T WORK: "; he can occasionally stoop, crouch and crawl frequently, and never run"
				# This may mean that combining FA lists isn't feasible/accurate, at least not
				# without VERY complex parsing rules.
				# Yeah but you can still fix at least very simple lists of targeted (and even non-targeted NN):
				falist_removal_tgt_indlist = []
				for i, tup in enumerate(ss):
					try:
						# Longer Pattern: If FA list pattern == 'NN, NN, CC NN,' or 'NN, NN CC NN,', remove all ',' and CC:
						if tup[1].startswith('NN_FA') or tup[1].startswith('NN'):
							if ss[i+1][1] == ',':
								if ss[i+2][1].startswith('NN_FA') or ss[i+2][1].startswith('NN'):
									if ss[i+3][1] == ',' and ss[i+4][1] == 'CC' or ss[i+3][1] == 'CC':
										if ss[i+5][1].startswith('NN_FA') or ss[i+5][1].startswith('NN'):
											# TODO: Add ability to add this pattern if the above NN is the final tuple.
											if ss[i+6][1] == ',':
												falist_removal_tgt_indlist.append(i+1)
												if ss[i+3] == ',':
													falist_removal_tgt_indlist.append(i+3)
													falist_removal_tgt_indlist.append(i+4)
												else:
													falist_removal_tgt_indlist.append(i+3)
					except IndexError:
						pass
					try:
						# Midrange Pattern: If FA list pattern == 'NN, NN, CC NN', remove all ',' and CC:
						if tup[1].startswith('NN_FA') or tup[1].startswith('NN'):
							if ss[i+1][1] == ',':
								if ss[i+2][1].startswith('NN_FA') or ss[i+2][1].startswith('NN'):
									if ss[i+3][1] == ',':
										if ss[i+4][1] == 'CC':
											if ss[i+5][1].startswith('NN_FA') or ss[i+5][1].startswith('NN'):
												falist_removal_tgt_indlist.append(i+1)
												falist_removal_tgt_indlist.append(i+3)	
												falist_removal_tgt_indlist.append(i+4)	
					except IndexError:
						pass
					try:					
						# Shorter Pattern: If FA list pattern == 'NN_FA, NN_FA,', remove first ',':
						if tup[1].startswith('NN_FA') or tup[1].startswith('NN'):
							if ss[i+1][1] == ',':
								if ss[i+2][1].startswith('NN_FA') or ss[i+2][1].startswith('NN'):
									if ss[i+3][1] == ',':
										falist_removal_tgt_indlist.append(i+1)
					except IndexError:
						pass
				ss_rev = [t for i, t in enumerate(ss) if i not in falist_removal_tgt_indlist]

				# If 0 hard borders, then because we're not doing proximity assignment, 
				# there's no need to parse further:
				if len([tup for tup in ss_rev if tup[0] in [',', 'and']]) == 0:
					return snippet_reslist

				# Gateway: If 2+ LOL terms are so close as to not be 
				# divided by FA terms, then you have a complexity this parser
				# cannot handle - do not proceed further.
				# Example 1: "he cannot perform occasional stooping"
				# Example 2: "he "


				

				# Find location of each LOL-like term:
				lol_ind_list = []
				for i, tup in enumerate(ss_rev):
					if tup[1].startswith("LOL") or tup[1].startswith("RB") or tup[1].startswith("JJ"):
						lol_ind_list.append(i)

				# From each end of the LOL, expand out to the first of
				# the end of the SS, a comma, an 'and' CC, or another LOL:
				for ind in lol_ind_list:

					pre_lol_list = ss_rev[:ind]
					post_lol_list = ss_rev[ind+1:]

					pre_lol_reslist = []
					lolbridgever = 0
					for i, tup in reversed(list(enumerate(pre_lol_list))):
						if tup[0] == ',' or tup[0] == 'and':
							break
						elif tup[1].startswith("LOL") or tup[1].startswith("RB") or tup[1].startswith("JJ"):
							lolbridgever = 1
							break
						else:
							pre_lol_reslist.append(tup)

					post_lol_reslist = []
					for i, tup in enumerate(post_lol_list):
						if tup[0] == ',' or tup[0] == 'and':
							break
						elif tup[1].startswith("LOL") or tup[1].startswith("RB") or tup[1].startswith("JJ"):
							lolbridgever = 1
							break
						else:
							post_lol_reslist.append(tup)

					# If directly connected LOL detected, stop parsing this LOL
					# index location and move to next:
					if lolbridgever == 1:
						continue

					# Combine pre- and post- tuple lists:
					lol_reslist_combined = []
					for tup in reversed(pre_lol_reslist):
						lol_reslist_combined.append(tup)
					lol_reslist_combined.append(ss_rev[ind])
					for tup in post_lol_reslist:
						lol_reslist_combined.append(tup)

					# Examine for targeted FAs; if 1+, add to
					# reslist:
					if len([t for t in lol_reslist_combined if t[1].startswith('NN_FA')]) >= 1:
						snippet_reslist.append(lol_reslist_combined)

				return snippet_reslist
			except Exception:
				raise
				#logger.exception('EXCEPTION')
				return []


		# Conservative snippets:
		con_split_ssreslist = []
		for ss in sslist_1tgtlol_1plusotherlol:
			res_lol = conservative_splitter(ss)
			if res_lol:
				for r in res_lol:
					con_split_ssreslist.append(r)
		for ss in sslist_2plustgtlol:
			res_lol = conservative_splitter(ss)
			if res_lol:
				for r in res_lol:
					con_split_ssreslist.append(r)		

		# Route resulting conservative splits to
		# appropriate bucket:
		#print 'con_split_ssreslist:'
		#for ss in con_split_ssreslist:
			#print ss

		for ss in con_split_ssreslist:
			lol_counter(ss)


		# (TEMPORARILY DISABLED 10162017)
		# TODO - DEBUG:
		# ANSWERED: What type of syntax is this designed to parse? Syntax like this:
		# "she can frequently stoop, occasionally crawl, and never crouch" -> will split up "frequently stoop" from "occasionally crawl"
		# So it has value.  I think the thing you need to add is, if wherever you want to split contains 1+ LOL on either side AND a CC you might not get
		# the right items.  So what I'd say here is to either prune when this version 'triggers' or combine it with your updated TODO approach below
		# regarding 'nearest neighbors'.

		# (17) Perform additional 2+ LOL parsing/splitting centered on
		# conservative comma border detection:

		# OPENQ: How will this handle SS's like "can stoop, crouch occasionally,"?  It'll
		# presently return 'crouch occasionally'.  But what happens to 'can stoop'?  Need to
		# store these scraps, if only for study.

		# TIP: Will return list of sublists even if SS is unaffected.
		def extract_comma_divided_lolsnippets(ss):
			try:
				# If 0 commas, no comma borders to detect; return SS untouched:
				if len([tup for tup in ss if tup[0] == ',']) == 0:
					# TIP: Returning as list containing SS to mirror output structure below.
					return [ss]
				else:
					# Locate each LOL's index (of any stripe):
					lol_index_val_list = []





					ct = 0
					while ct != len(ss):
						try:
							if ss[ct][1] == 'XX_MODPOS':
								try:
									if ss[ct+1][1].startswith("LOL") or ss[ct+1][1].startswith("RB") or ss[ct+1][1].startswith("JJ"):
										lol_index_val_list.append(ct+1)
										ct += 2
									else:
										ct += 1
								except IndexError:
									break
							else:
								if ss[ct][1].startswith("LOL") or ss[ct][1].startswith("RB") or ss[ct][1].startswith("JJ"):
									lol_index_val_list.append(ct)
									ct += 1
								else:
									ct += 1
						except IndexError:
							break

					# TIP: List of sublists containing tuple clusters centered on LOLs out to their borders:
					res_tup_clusters = []

					# From each end of the LOL, expand out to the end of the SS or a bordering comma that is NOT a list comma.
					for ind in lol_index_val_list:
						pre_lol_list = ss[:ind]
						post_lol_list = ss[ind:]  # TIP: Will include the LOL.

						pre_lol_reslist = []
						# TIP: If a comma immediately precedes the LOL (EX1), stop.  This will break 
						# clause-separated NN_FA from their 'parent' LOL (EX2), but these should be rare.
						# EX1: 'occasional stooping, /// frequent reaching'
						# EX2: 'he can stoop, defined as bending at the waist, occasionally, reach frequently
						for i, tup in reversed(list(enumerate(pre_lol_list))):
							if tup[0] != ",":
								pre_lol_reslist.append(tup)
							else:
								break

						# If there is a comma immediately after the LOL,
						# e.g. "occasionally, ", add up to that comma
						# and then break:
						# TIP: Don't need other checking here (e.g. checking
						# if there are any LOLs after this comma-preceded LOL)
						# because in a complex comma-separated clause that won't
						# be probative, and besides, the point is to find non-
						# comma-separated semantic connections - if such a 
						# comma-preceded LOL is present, so be it.
						post_lol_reslist = []
						if len(post_lol_reslist) >= 2 and post_lol_reslist[1][0] == ',':
							post_lol_reslist.append(post_lol_reslist[0])
							break
						else:
							for i, tup in enumerate(post_lol_list):
								if tup[0] != ',':
									post_lol_reslist.append(tup)
								else:
									try:
										tupafter = post_lol_list[i+1]
										tupbefore = post_lol_list[i-1]
										if tupbefore[1].startswith('NN_FA') and (tupafter[1].startswith('NN_FA') or tupafter[0].upper() in ['AND', 'OR', 'AS WELL AS']):
											post_lol_reslist.append(tup)
										else:
											break
									except IndexError:
										post_lol_reslist.append(tup)

						# Combine pre- and post- tuple lists:
						lol_reslist_combined = []
						for tup in reversed(pre_lol_reslist):
							lol_reslist_combined.append(tup)
						for tup in post_lol_reslist:
							lol_reslist_combined.append(tup)
						res_tup_clusters.append(lol_reslist_combined)
					
					return res_tup_clusters
			except Exception, x:
				#print "RFCLOLFAPARSER - COMMA BORDER PARSING ERROR"
				#print str(x)
				return [ss]
				
				
		# # Parse 'sslist_1tgtlol_1plusotherlol' SS's:
		# sslist_1tgtlol_1plusotherlol_reslists = []
		# for ss in sslist_1tgtlol_1plusotherlol:
		# 	reslistofsublists = extract_comma_divided_lolsnippets(ss)
		# 	for reslist in reslistofsublists:
		# 		sslist_1tgtlol_1plusotherlol_reslists.append(reslist)
		
		# # Reset 'sslist_1tgtlol_1plusotherlol', then iterate through
		# # 'sslist_1tgtlol_1plusotherlol_reslists' to add each result to
		# # its appropriate container:
		# sslist_1tgtlol_1plusotherlol = []
		# for ss in sslist_1tgtlol_1plusotherlol_reslists:
		# 	lol_counter(ss)
		
		# # Parse 'sslist_2plustgtlol' SS's:
		# sslist_2plustgtlol_reslists = []
		# for ss in sslist_2plustgtlol:
		# 	reslistofsublists = extract_comma_divided_lolsnippets(ss)
		# 	for reslist in reslistofsublists:
		# 		sslist_2plustgtlol_reslists.append(reslist)
		
		# # Reset 'sslist_2plustgtlol', then iterate through
		# # 'sslist_2plustgtlol_reslists' to add each result to
		# # its appropriate container:
		# sslist_2plustgtlol = []
		# for ss in sslist_2plustgtlol_reslists:
		# 	lol_counter(ss)




		
		# (DEPRECATED - covered by new conservative comma border parser/splitter)
		# Try to split up [XX_MODPOS][LOL][FA/FA LIST][,][XX_MODPOS][LOL][FA/FA LIST]
		# Try to split up [LOL][FA][,][LOL][FA]
		# Try to split up FA [^,] LOL , FA [^,] LOL


		# (18) Perform Double Checks/Edge Case Parsing of 1 TGT_LOL SS's:
		# TIP: To increase accuracy before proceeding to associate LOL/FA pairs 
		# from the '1 TGT LOL' list, parsing its SSs for certain edge cases that 
		# may require exclusion, or may require additional splitting.
		
		# (18A): 
		# Locate all [words, including possibly targeted FA, not checking] 
		# [,]->[targeted LOL] [^,] [targeted FA], and split the latter 
		# LOL portion off as its own entity, then add it to the 1LOL_FINAL_REV.  
		# Do nothing with other portion:
		sslist_1tgtlol_0otherlol_REV1 = []
		if sslist_1tgtlol_0otherlol:
			for ss in sslist_1tgtlol_0otherlol:
				if any(tup for tup in ss if tup[0] == ','):
					append_ver = 0
					try:
						for i, tup in enumerate(ss):
							if tup[0] == ',':
								if ss[i+1][1] in ['LOL_EX_HR', 'LOL_EX_LB', 'LOL_NONEX', 'LOL_ENVT']:
									sslist_postlol = ss[i+1:]
									non_comma_divided_nnfa_pat_ver = 0
									for i, tup in enumerate(sslist_postlol):
										if tup[0] == ',':
											break
										else:
											if tup[1].startswith('NN_FA'):
												non_comma_divided_nnfa_pat_ver = 1
												break
									if non_comma_divided_nnfa_pat_ver == 1:
										append_ver = 1
										sslist_1tgtlol_0otherlol_REV1.append(sslist_postlol)
									else:
										append_ver = 1
										sslist_1tgtlol_0otherlol_REV1.append(ss)
					except IndexError:
						pass
					if append_ver == 0:
						sslist_1tgtlol_0otherlol_REV1.append(ss)
				else:
					sslist_1tgtlol_0otherlol_REV1.append(ss)

		# (18B) (DEPRECATED 09.07.2016 - handled by 18A)
		# IF the pattern is "[XX_MODPOS] [FA/FA LIST] [targeted LOL]" then 
		# NO targeted FAs, that's fine, do nothing. HOWEVER... if the pattern 
		# is "[modal/able to] [FA/FA LIST] [,]->[targeted LOL] [^,] [targeted FA]",
		# split.


		# TODO:
		# FINAL RULE: Similar to above, again re-parse and rebucket 2+ snippets.
		# OR basically just take 2+ snippets from all buckets, and apply the same
		# 'nearest neighbor' idea wherein if a targeted LOL is directly beside
		# an targeted FA, you can be fairily confident you have a match.  Won't catch
		# ALL (e.g. "occasionally stoop, crouch and crawl, reach frequently"), wouldn't
		# catch crouch or crawl.  But benefit is it's direction agnostic, so that
		# "she can stoop occasionally, crawl frequently, and..." captures STOOP-OCC
		# just as well as "she can occasionally stoop, frequently climb, and...".




		# print "\n\nFINAL CONTAINER RESULTS:"
		# print "0 TGT_LOL, 1+ LOL_NLD, 0 OTHER LOL:"
		# if sslist_0tgtlol_1pluslolnld_0otherlol:
			# for item in sslist_0tgtlol_1pluslolnld_0otherlol:
				# print item
		# else:
			# print "NONE"
		
		# print "0 TGT_LOL, 0 LOL_NLD, 1+ OTHER LOL:"
		# if sslist_0tgtlol_0lolnld_1plusotherlol:
			# for item in sslist_0tgtlol_0lolnld_1plusotherlol:
				# print item
		# else:
			# print "NONE"
		
		# print "0 TGT LOL, 1+ LOL_NLD, 1+ OTHER LOL:"
		# if sslist_0tgtlol_1pluslolnld_1plusotherlol:
			# for item in sslist_0tgtlol_1pluslolnld_1plusotherlol:
				# print item
		# else:
			# print "NONE"
		
		# print "1 LOL_TGT, 0 OTHER LOL:"
		# if sslist_1tgtlol_0otherlol_REV1:
			# for item in sslist_1tgtlol_0otherlol_REV1:
				# print item
		# else:
			# print "NONE"
		
		# print "1 LOL_TGT, 2+ TOTAL LOL:"
		# if sslist_1tgtlol_1plusotherlol:
			# for item in sslist_1tgtlol_1plusotherlol:
				# print item
		# else:
			# print "NONE"
		
		# print "2+ TGT_LOL, UNKNOWN OTHER LOL (not parsed):"
		# if sslist_2plustgtlol:
			# for item in sslist_2plustgtlol:
				# print item
		# else:
			# print "NONE"
		
		# (19) Parse 1 TGT LOL SS's to Assign LOL Value(s) to TGT FAs:
		# TIP: Parses all SS's to locate targeted FAs, then assigns the 
		# 1 LOL present in the SS to each such targeted FA found, PLUS 
		# tracking/reconciliation of cases where 2+ LOLs assigned to same 
		# targeted FA.
		
		# Set default values:
		rfcliftlolultimate = "U"
		rfccarrylolultimate = "U"
		rfcsitlolultimate = "U"
		rfcstandlolultimate = "U"
		rfcwalklolultimate = "U"
		rfcpushlolultimate = "U"
		rfcpulllolultimate = "U"
		rfcclimbrampstairlolultimate = "U"
		rfcclimblrslolultimate = "U"
		rfcbalancelolultimate = "U"
		rfcstooplolultimate = "U"
		rfckneellolultimate = "U"
		rfccrouchlolultimate = "U"
		rfccrawllolultimate = "U"
		rfcreachlolultimate = "U"
		rfchandlelolultimate = "U"
		rfcfingerlolultimate = "U"
		rfcfeellolultimate = "U"
		rfcnearacuitylolultimate = "U"
		rfcfaracuitylolultimate = "U"
		rfcdepthperceptionlolultimate = "U"
		rfcaccomodationlolultimate = "U"
		rfccolorvisionlolultimate = "U"
		rfcfieldofvisionlolultimate = "U"
		rfcfootcontrolslolultimate = "U"
		rfcexposuretoweatherlolultimate = "U"
		rfcextremeheatlolultimate = "U"
		rfcextremecoldlolultimate = "U"
		rfcwetnesslolultimate = "U"
		rfchumiditylolultimate = "U"
		rfcvibrationlolultimate = "U"
		rfcatmosphericconditionslolultimate = "U"
		rfchazardslolultimate = "U"
		rfcmovingmechanicallolultimate = "U"
		rfcexposedheightslolultimate = "U"
		rfctoxiccausticchemicalslolultimate = "U"
		rfctalklolultimate = "U"
		rfchearlolultimate = "U"
		rfctastelolultimate = "U"
		rfcsmelllolultimate = "U"

		rfcliftlolLIST = []
		rfccarrylolLIST = []
		rfcsitlolLIST = []
		rfcstandlolLIST = []
		rfcwalklolLIST = []
		rfcpushlolLIST = []
		rfcpulllolLIST = []
		rfcclimbrampstairlolLIST = []
		rfcclimblrslolLIST = []
		rfcbalancelolLIST = []
		rfcstooplolLIST = []
		rfckneellolLIST = []
		rfccrouchlolLIST = []
		rfccrawllolLIST = []
		rfcreachlolLIST = []
		rfchandlelolLIST = []
		rfcfingerlolLIST = []
		rfcfeellolLIST = []
		rfcnearacuitylolLIST = []
		rfcfaracuitylolLIST = []
		rfcdepthperceptionlolLIST = []
		rfcaccomodationlolLIST = []
		rfccolorvisionlolLIST = []
		rfcfieldofvisionlolLIST = []
		rfcfootcontrolslolLIST = []
		rfcexposuretoweatherlolLIST = []
		rfcextremeheatlolLIST = []
		rfcextremecoldlolLIST = []
		rfcwetnesslolLIST = []
		rfchumiditylolLIST = []
		rfcvibrationlolLIST = []
		rfcatmosphericconditionslolLIST = []
		rfchazardslolLIST = []
		rfcmovingmechanicallolLIST = []
		rfcexposedheightslolLIST = []
		rfctoxiccausticchemicalslolLIST = []
		rfctalklolLIST = []
		rfchearlolLIST = []
		rfctastelolLIST = []
		rfcsmelllolLIST = []

		# Define function that will add a targeted LOL value to a
		# 'found' targeted FA list based on that FA's data value name:
		def addtofalist(lol, targetedfa):

			if targetedfa == 'ACCOMODATION':
				rfcaccomodationlolLIST.append(lol)
			elif targetedfa == 'DEPTHPERCEPTION':
				rfcdepthperceptionlolLIST.append(lol)
			elif targetedfa == 'COLORVISION':
				rfccolorvisionlolLIST.append(lol)
			elif targetedfa == 'FIELDOFVISION':
				rfcfieldofvisionlolLIST.append(lol)
			elif targetedfa == 'NEARACUITY':
				rfcnearacuitylolLIST.append(lol)
			elif targetedfa == 'FARACUITY':
				rfcfaracuitylolLIST.append(lol)
			elif targetedfa == 'BALANCE':
				rfcbalancelolLIST.append(lol)
			elif targetedfa == 'CROUCH':
				rfccrouchlolLIST.append(lol)
			elif targetedfa == 'FINGER':
				rfcfingerlolLIST.append(lol)
			elif targetedfa == 'FEEL':
				rfcfeellolLIST.append(lol)
			elif targetedfa == 'CLIMBRAMPSTAIR':
				rfcclimbrampstairlolLIST.append(lol)
			elif targetedfa == 'CLIMBLRS':
				rfcclimblrslolLIST.append(lol)
			elif targetedfa == 'STOOP':
				rfcstooplolLIST.append(lol)
			elif targetedfa == 'KNEEL':
				rfckneellolLIST.append(lol)
			elif targetedfa == 'CRAWL':
				rfccrawllolLIST.append(lol)
			elif targetedfa == 'REACH':
				rfcreachlolLIST.append(lol)
			elif targetedfa == 'HANDLE':
				rfchandlelolLIST.append(lol)
			elif targetedfa == 'PUSH':
				rfcpushlolLIST.append(lol)
			elif targetedfa == 'PULL':
				rfcpulllolLIST.append(lol)
			elif targetedfa == 'FOOTCONTROLS':
				rfcfootcontrolslolLIST.append(lol)
			elif targetedfa == 'TALKING':
				rfctalklolLIST.append(lol)
			elif targetedfa == 'HEARING':
				rfchearlolLIST.append(lol)
			elif targetedfa == 'TASTE':
				rfctastelolLIST.append(lol)
			elif targetedfa == 'SMELLING':
				rfcsmelllolLIST.append(lol)
			elif targetedfa == 'EXPOSURETOWEATHER':
				rfcexposuretoweatherlolLIST.append(lol)
			elif targetedfa == 'EXTREMEHEAT':
				rfcextremeheatlolLIST.append(lol)
			elif targetedfa == 'EXTREMECOLD':
				rfcextremecoldlolLIST.append(lol)
			elif targetedfa == 'WETNESS':
				rfcwetnesslolLIST.append(lol)
			elif targetedfa == 'HUMIDITY':
				rfchumiditylolLIST.append(lol)
			elif targetedfa == 'VIBRATION':
				rfcvibrationlolLIST.append(lol)
			elif targetedfa == 'ATMOSPHERICCONDITIONS':
				rfcatmosphericconditionslolLIST.append(lol)
			elif targetedfa == 'MOVINGMECHANICAL':
				rfcmovingmechanicallolLIST.append(lol)
			elif targetedfa == 'HAZARDS':
				rfchazardslolLIST.append(lol)
			elif targetedfa == 'CHEMICALS':
				rfctoxiccausticchemicalslolLIST.append(lol)
			elif targetedfa == 'HEIGHTS':
				rfcexposedheightslolLIST.append(lol)
			elif targetedfa == 'LIFT':
				rfcliftlolLIST.append(lol)
			elif targetedfa == 'CARRY':
				rfccarrylolLIST.append(lol)
			elif targetedfa == 'SIT':
				rfcsitlolLIST.append(lol)
			elif targetedfa == 'STAND':
				rfcstandlolLIST.append(lol)
			elif targetedfa == 'WALK':
				rfcwalklolLIST.append(lol)

		# Define function that will parse a targeted FA's list of LOL 
		# values and return the ultimate value to be assigned as the RFCLOLFADICT
		# LOL value, whether "U", "N", "O", "F", "C", "CONC", "MOD", or a # of 
		# LB/HR).
		# TIP: These FA types (e.g. dust) should NEVER have 2 LOL assignments. 
		# If they do, either the ALJ messed up or you did, so you'll output "U" 
		# for these.
		def falistparserONELOL(falist):
			try:
				if len(falist) == 0:
					return "U"
				elif len(falist) == 1:
					return str(falist[0])
				elif len(falist) >= 2:
					falist = list(set(falist))
					if len(falist) == 1:
						return str(falist[0])
					else:
						return "U"
			except Exception:
				return "E"

		# Define function that will parse a targeted FA's list of targeted LOL 
		# values and return the ultimate value, which for the FA types passed 
		# to *this* function MAY include a string-ified list of LOL values (MAX=2).
		# TIP: This is for 'double body system potential' FA types.
		def falistparserTWOLOL(falist):
			try:
				if len(falist) == 0:
					return "U"
				elif len(falist) == 1:
					return str(falist[0])
				elif len(falist) >= 2:
					falist = list(set(falist))
					if len(falist) == 1:
						return str(falist[0])
					elif len(falist) == 2:
						return str(falist)
					else:
						return 'U'
			except Exception:
				return "E"

		# Parse each '1 TGT LOL' SS to create LOL value lists:
		for ss in sslist_1tgtlol_0otherlol_REV1:

			# Confirm again that there's only 1 LOL, then ID its type:
			tgt_lol_list = [tup for i, tup in enumerate(ss) if tup[1] in ['LOL_EX_HR', 'LOL_EX_LB', 'LOL_NONEX', 'LOL_ENVT']]
			if len(tgt_lol_list) == 1:

				# From the LOL tuple, extract the LOL text and LOL POS tag:
				tgt_lol_pos = tgt_lol_list[0][1]
				tgt_lol_txt = tgt_lol_list[0][0]
				tgt_lol_txt = tgt_lol_txt.strip()
				# Remove 'LB' and 'HR' from the LOL text, resulting in only an LOL value of a #.
				# TIP: No need to remove '_' from LB entries; already removed by chunker.
				tgt_lol_txt = tgt_lol_txt.replace("LBB", "")
				tgt_lol_txt = tgt_lol_txt.replace("HRR", "")

				# Search for the FA types you'd expect to be associated with that LOL type:
				if tgt_lol_pos == "LOL_EX_HR":
					for tup in ss:
						for listitem in nnfa_ex_hr:
							if str(tup[0]).strip() == str(listitem[2]).strip():
								listitemvarvals = listitem[3]

								if isinstance(listitemvarvals, list):
									for item in listitemvarvals:
										addtofalist(tgt_lol_txt, item)
								if isinstance(listitemvarvals, str):
									addtofalist(tgt_lol_txt, listitemvarvals)


				elif tgt_lol_pos == "LOL_EX_LB":
					for tup in ss:
						for listitem in nnfa_ex_lb:
							if str(tup[0]).strip() == str(listitem[2]).strip():
								listitemvarvals = listitem[3]
								if isinstance(listitemvarvals, list):
									for item in listitemvarvals:
										addtofalist(tgt_lol_txt, item)
								if isinstance(listitemvarvals, str):
									addtofalist(tgt_lol_txt, listitemvarvals)


				elif tgt_lol_pos == "LOL_ENVT":
					
					# Retrieve the shorthand variable value associated with this 'ideal form'
					# text:
					lol_envt_varval = ""
					for listitem in lol_envt:
						if tgt_lol_txt == str(listitem[2]).strip():
							lol_envt_varval = str(listitem[3]) # TIP: Pulls out the shorthand variable name (e.g. ideal form is ' OCCASIONAL ', varval name is 'O').
							break
					
					# Locate all relevant NN_FA in the SS:
					if lol_envt_varval != "":
						for tup in ss:
							for listitem in nnfa_envt:
								if tup[0] == listitem[2].strip():
									listitemvarvals = listitem[3]
									if isinstance(listitemvarvals, list):
										for item in listitemvarvals:
											addtofalist(lol_envt_varval, item)
									if isinstance(listitemvarvals, str):
										addtofalist(lol_envt_varval, listitemvarvals)


				elif tgt_lol_pos == "LOL_NONEX":
					lol_nonex_varval = ""
					for listitem in lol_nonex:
						if tgt_lol_txt == str(listitem[2]).strip():
							lol_nonex_varval = str(listitem[3])
							break

					if lol_nonex_varval != "":

						# Create list of both nonex and envt NN_FA terms because both must be searched for here:
						nnfa_nonexANDenvt = []
						for listitem in nnfa_nonex:
							nnfa_nonexANDenvt.append(listitem)
						for listitem in nnfa_envt:
							nnfa_nonexANDenvt.append(listitem)

						for tup in ss:
							for listitem in nnfa_nonexANDenvt:
								# TIP: What you're doing below is saying, if the actual text matches an FA 'ideal form', use that.
								# TIP: No need to 'join' ideal form tuples because the tuple ideal form entry can contain multiple words
								# exactly matching the ideal form entry.
								if str(tup[0]).strip() == str(listitem[2]).strip():

									listitemvarvals = listitem[3]

									if isinstance(listitemvarvals, list):
										for item in listitemvarvals:
											addtofalist(lol_nonex_varval, item)
									if isinstance(listitemvarvals, str):
										addtofalist(lol_nonex_varval, listitemvarvals)

		# (20) Now parse each targeted FA's LOL list to assign an ultimate FA LOL 
		# value of either "U", a single LOL, or a list if it's a 'double body system 
		# potential' FA type; then assign each ultimate value to the RFCLOLFA dictionary:

		# Parse ultimate targeted LOL value for 'should only be one LOL' FA types:
		rfcsitlolultimate = falistparserONELOL(rfcsitlolLIST)
		rfcstandlolultimate = falistparserONELOL(rfcstandlolLIST)
		rfcwalklolultimate = falistparserONELOL(rfcwalklolLIST)
		rfcclimbrampstairlolultimate = falistparserONELOL(rfcclimbrampstairlolLIST)
		rfcclimblrslolultimate = falistparserONELOL(rfcclimblrslolLIST)
		rfcbalancelolultimate = falistparserONELOL(rfcbalancelolLIST)
		rfcstooplolultimate = falistparserONELOL(rfcstooplolLIST)
		rfckneellolultimate = falistparserONELOL(rfckneellolLIST)
		rfccrouchlolultimate = falistparserONELOL(rfccrouchlolLIST)
		rfccrawllolultimate = falistparserONELOL(rfccrawllolLIST)
		rfcnearacuitylolultimate = falistparserONELOL(rfcnearacuitylolLIST)
		rfcfaracuitylolultimate = falistparserONELOL(rfcfaracuitylolLIST)
		rfcdepthperceptionlolultimate = falistparserONELOL(rfcdepthperceptionlolLIST)
		rfcaccomodationlolultimate = falistparserONELOL(rfcaccomodationlolLIST)
		rfccolorvisionlolultimate = falistparserONELOL(rfccolorvisionlolLIST)
		rfcfieldofvisionlolultimate = falistparserONELOL(rfcfieldofvisionlolLIST)
		rfcexposuretoweatherlolultimate = falistparserONELOL(rfcexposuretoweatherlolLIST)
		rfcextremeheatlolultimate = falistparserONELOL(rfcextremeheatlolLIST)
		rfcextremecoldlolultimate = falistparserONELOL(rfcextremecoldlolLIST)
		rfcwetnesslolultimate = falistparserONELOL(rfcwetnesslolLIST)
		rfchumiditylolultimate = falistparserONELOL(rfchumiditylolLIST)
		rfcvibrationlolultimate = falistparserONELOL(rfcvibrationlolLIST)
		rfcatmosphericconditionslolultimate = falistparserONELOL(rfcatmosphericconditionslolLIST)
		rfchazardslolultimate = falistparserONELOL(rfchazardslolLIST)
		rfcmovingmechanicallolultimate = falistparserONELOL(rfcmovingmechanicallolLIST)
		rfcexposedheightslolultimate = falistparserONELOL(rfcexposedheightslolLIST)
		rfctoxiccausticchemicalslolultimate = falistparserONELOL(rfctoxiccausticchemicalslolLIST)
		rfctalklolultimate = falistparserONELOL(rfctalklolLIST)
		rfchearlolultimate = falistparserONELOL(rfchearlolLIST)
		rfctastelolultimate = falistparserONELOL(rfctastelolLIST)
		rfcsmelllolultimate = falistparserONELOL(rfcsmelllolLIST)

		# Parse ultimate LOL value for 'double body system potential' FA types:
		rfcfootcontrolslolultimate = falistparserTWOLOL(rfcfootcontrolslolLIST)
		rfcliftlolultimate = falistparserTWOLOL(rfcliftlolLIST)
		rfccarrylolultimate = falistparserTWOLOL(rfccarrylolLIST)
		rfcpushlolultimate = falistparserTWOLOL(rfcpushlolLIST)
		rfcpulllolultimate = falistparserTWOLOL(rfcpulllolLIST)
		rfcreachlolultimate = falistparserTWOLOL(rfcreachlolLIST)
		rfchandlelolultimate = falistparserTWOLOL(rfchandlelolLIST)
		rfcfingerlolultimate = falistparserTWOLOL(rfcfingerlolLIST)
		rfcfeellolultimate = falistparserTWOLOL(rfcfeellolLIST)

		# Assign each ultimate value to the RFCLOLFA dictionary:
		rfcparsingdict['rfcsitlol'] = rfcsitlolultimate
		rfcparsingdict['rfcstandlol'] = rfcstandlolultimate
		rfcparsingdict['rfcwalklol'] = rfcwalklolultimate
		rfcparsingdict['rfcclimbrampstairlol'] = rfcclimbrampstairlolultimate
		rfcparsingdict['rfcclimblrslol'] = rfcclimblrslolultimate
		rfcparsingdict['rfcbalancelol'] = rfcbalancelolultimate
		rfcparsingdict['rfcstooplol'] = rfcstooplolultimate
		rfcparsingdict['rfckneellol'] = rfckneellolultimate
		rfcparsingdict['rfccrouchlol'] = rfccrouchlolultimate
		rfcparsingdict['rfccrawllol'] = rfccrawllolultimate
		rfcparsingdict['rfcnearacuitylol'] = rfcnearacuitylolultimate
		rfcparsingdict['rfcfaracuitylol'] = rfcfaracuitylolultimate
		rfcparsingdict['rfcdepthperceptionlol'] = rfcdepthperceptionlolultimate
		rfcparsingdict['rfcaccomodationlol'] = rfcaccomodationlolultimate
		rfcparsingdict['rfccolorvisionlol'] = rfccolorvisionlolultimate
		rfcparsingdict['rfcfieldofvisionlol'] = rfcfieldofvisionlolultimate
		rfcparsingdict['rfcexposuretoweatherlol'] = rfcexposuretoweatherlolultimate
		rfcparsingdict['rfcextremeheatlol'] = rfcextremeheatlolultimate
		rfcparsingdict['rfcextremecoldlol'] = rfcextremecoldlolultimate
		rfcparsingdict['rfcwetnesslol'] = rfcwetnesslolultimate
		rfcparsingdict['rfchumiditylol'] = rfchumiditylolultimate
		rfcparsingdict['rfcvibrationlol'] = rfcvibrationlolultimate
		rfcparsingdict['rfcatmosphericconditionslol'] = rfcatmosphericconditionslolultimate
		rfcparsingdict['rfchazardslol'] = rfchazardslolultimate
		rfcparsingdict['rfcmovingmechanicallol'] = rfcmovingmechanicallolultimate
		rfcparsingdict['rfcexposedheightslol'] = rfcexposedheightslolultimate
		rfcparsingdict['rfctoxiccausticchemicalslol'] = rfctoxiccausticchemicalslolultimate
		rfcparsingdict['rfctalklol'] = rfctalklolultimate
		rfcparsingdict['rfchearlol'] = rfchearlolultimate
		rfcparsingdict['rfctastelol'] = rfctastelolultimate
		rfcparsingdict['rfcsmelllol'] = rfcsmelllolultimate
		rfcparsingdict['rfcfootcontrolslol'] = rfcfootcontrolslolultimate
		rfcparsingdict['rfcliftlol'] = rfcliftlolultimate
		rfcparsingdict['rfccarrylol'] = rfccarrylolultimate
		rfcparsingdict['rfcpushlol'] = rfcpushlolultimate
		rfcparsingdict['rfcpulllol'] = rfcpulllolultimate
		rfcparsingdict['rfcreachlol'] = rfcreachlolultimate
		rfcparsingdict['rfchandlelol'] = rfchandlelolultimate
		rfcparsingdict['rfcfingerlol'] = rfcfingerlolultimate
		rfcparsingdict['rfcfeellol'] = rfcfeellolultimate
		
		# (22) Parse RFC Quality:
		
		# Define default variable values:
		rfc_vague_lol_ver_ultimate = "U"
		rfc_vague_lol_txt_ultimate = []
		rfc_lessthan_lol_ver_ultimate = "U"
		rfc_lessthan_lol_txt_ultimate = []
		rfc_vague_parblol_ver_ultimate = "U"
		rfc_vague_parblol_txt_ultimate = []
		rfc_minlang_ver_ultimate = "U"
		rfc_minlang_txt_ultimate = []
		rfc_nolimlang_ver_ultimate = "U"
		rfc_nolimlang_txt_ultimate = []
		
		# (22)(A) RFC Vague/Not Legally Defined Language Detection:
		# TODO: Design to only trigger where the LOL_NLD value is directed
		# at a targeted physical FA by ape-ing comma barrier parsing.
		#print 'SS_CATCHALL:'
		#print ss_catchall
		
		# Define custom comma barier parser:
		def extract_comma_divided_lolsnippets_vague(ss, indval):
			try:
				if any(tup[1].startswith("NN_FA") for tup in ss):
					res_tup_clusters = []
					
					pre_lol_list = ss[:indval]
					post_lol_list = ss[indval:]  # TIP: Will include the LOL.

					pre_lol_reslist = []
					# TIP: If a punctuation mark immediately precedes the LOL (EX1), stop.
					# EX1: 'occasional stooping[,|;|:] /// frequent reaching'
					for i, tup in reversed(list(enumerate(pre_lol_list))):
						if tup[0] not in [',', ';', ':']:
							pre_lol_reslist.append(tup)
						else:
							break
					
					post_lol_reslist = []
					# TIP: If comma immediately after LOL_NLD, break.
					# TIP: If comma *later* than immediately after LOL_NLD, continue.
					# TIP: If there is a semicolon immediately after LOL_NLD, break.
					# TIP: If semicolon *later* than immediately after LOL_NLD, break.
					# TIP: If colon immediately after LOL_NLD, continue.
					# TIP: # TIP: If colon *later* than immediately after LOL_NLD, continue.
					# TIP: If not a punctuation mark, continue.
					if len(post_lol_reslist) >= 2 and post_lol_reslist[1][0] in [',', ';']:
						post_lol_reslist.append(post_lol_reslist[0])
					else:
						for i, tup in enumerate(post_lol_list):
							if tup[0] not in [',', ';']:
								post_lol_reslist.append(tup)
							else:
								if tup[0] == ';':
									break
								elif tup[0] == ',':
									try:
										tupafter = post_lol_list[i+1]
										tupbefore = post_lol_list[i-1]
										if tupbefore[1].startswith('NN_FA') and (tupafter[1].startswith('NN_FA') or tupafter[0].upper() in ['AND', 'OR', 'AS WELL AS']):
											post_lol_reslist.append(tup)
										else:
											break
									except IndexError:
										post_lol_reslist.append(tup)
					#print "post_lol_reslist:"
					#print post_lol_reslist
					# Combine pre- and post- tuple lists:
					lol_reslist_combined = []
					for tup in reversed(pre_lol_reslist):
						lol_reslist_combined.append(tup)
					for tup in post_lol_reslist:
						lol_reslist_combined.append(tup)
					res_tup_clusters.append(lol_reslist_combined)
				
					return res_tup_clusters
				else:
					return []
			except Exception, x:
				#print "RFCLOLFAPARSER - COMMA BORDER PARSING ERROR"
				#print str(x)
				return []
		
		# Check each SS for LOL_NLD and, if found, parse:
		for ss in ss_catchall:
			for i, tup in enumerate(ss):
				if tup[1] == 'LOL_NLD':
					# Send SS to 'extract_comma_divided_lolsnippets':
					res_sslist = extract_comma_divided_lolsnippets_vague(ss, i)
					if res_sslist:
						for tuplist in res_sslist:
							if any(tup[1].startswith("NN_FA") for tup in tuplist):
								if any(tup[1].startswith("LOL_EX") for tup in tuplist) or any(tup[1].startswith("LOL_NONEX") for tup in tuplist) or any(tup[1].startswith("LOL_ENVT") for tup in tuplist):
									pass
								else:
									rfc_vague_lol_ver_ultimate  = '1'
									# TIP: 'LOL_NLD' all have perfectly corresponding
									# 'ideal form' language.
									vaguelang = tup[0].replace('/', ' ').strip().lower()
									rfc_vague_lol_txt_ultimate.append(vaguelang)                                
		
		# (22)(B) 'Less Than LOL' Language Detection:
		nlp_helper.sentence_splitter(rfclolfa)
		for ss in ss_catchall:
			for i, tup in enumerate(ss):
				if tup[1] == 'XX_LESSTHAN':
					try:
						if ss[i+1][1] in ['LOL_ENVT', 'LOL_NLD_PARB_CPP', 'LOL_NLD_PARB_SF', 'LOL_EX_HR', 'LOL_NLD_NOLIM', 'LOL_EX_LB', 'LOL_NLD', 'LOL_NONEX', 'LOL_NLD_PARB_ADL', 'LOL_NLD_PARB_GEN', 'XX_MENT']:
							rfc_lessthan_lol_ver_ultimate = "1"
							# TIP: 'XX_LESSTHAN' all have perfectly corresponding
							# 'ideal form' language.
							lessthanlang = tup[0].replace('/', ' ').strip().lower()
							rfc_lessthan_lol_txt_ultimate.append(lessthanlang)              
					except IndexError:
						pass
		
		# (22)(C) RFC 'Minimum LoL' Language Detection:
		# TIP: No need to limit function context; need only determine if
		# the 'XX_MIN' appears before an LOL or XX_MENT.
		# TIP: 'ss_catchall' should contain all SS's of the RFC (nothing lost)
		# including custom POS tags.
		for ss in ss_catchall:
			for i, tup in enumerate(ss):
				if tup[1] == 'XX_MIN':
					try:
						if ss[i+1][1][:2] in ['LO', 'RB', 'JJ'] or ss[i+1][1] in ['XX_MODPOS', 'XX_MENT']:
							rfc_minlang_ver_ultimate = '1'
							# Retrieve text of 'minimum LOL' tuple:
							# TIP: 'XX_MIN' all have perfectly corresponding
							# 'ideal form' language.
							minlang = tup[0].replace('/', ' ').strip().lower()
							rfc_minlang_txt_ultimate.append(minlang)
					except IndexError:
						pass
			
		# (22)(D) RFC 'No Limitation' Language Detection:
		# TIP: No real limits here.  If you see a 'LOL_NLD_NOLIM' tag,
		# raise this flag.
		for ss in ss_catchall:
			for i, tup in enumerate(ss):
				if tup[1] == 'LOL_NLD_NOLIM':
					rfc_nolimlang_ver_ultimate = '1'
					# Retrieve relevant RFC language:
					idealtxt = tup[0]
					idealcd_regex = [li[1] for li in lol_nld if li[2].strip() == idealtxt]
					if len(idealcd_regex) == 1:
						idealtxt_finditer = re.finditer(idealcd_regex[0], rfclolfa_presabsvsn)
						for res in idealtxt_finditer:
							res_grouped = res.group()
							rfc_nolimlang_txt_ultimate.append(res_grouped)
		
		# (22)(E) RFC 'Par B' Language Detection:
		# TIP: All of the LOL_NLD_PARB are pretty clear in their referencing
		# of Par. B concepts rather than just 'mild', etc., so this should be
		# as simple as checking for any 'LOL_NLD_PARB' subset 
		# (e.g. 'LOL_NLD_PARB_CPP') and then if found, checking the original 
		# cleaned up RFC text for any 'clarifying' mental limitation language
		# within that subset category.
		#print "SS_CATCHALL:"
		#print ss_catchall
		
		# Check for 'LOL_NLD_PARB'-starting POS tags:
		parb_reslist = [tup for ss in ss_catchall for tup in ss if tup[1].startswith('LOL_NLD_PARB')]
		
		# If found, check for 'clarifying language' by Par. B category before making the verdict '1':
		if parb_reslist:
			
			if any(tup[1] == 'LOL_NLD_PARB_CPP' for tup in parb_reslist):
				rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
				rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
				rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
				if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
					rfc_vague_parblol_ver_ultimate = "1"
					# Retrieve relevant RFC language:
					# TIP: This is an interesting approach - it is 'redoing' the REGEX pattern initially
					# found during substitution to pull out the precise language.  You should really test this...
					idealtxt_list = [tup[0] for tup in parb_reslist if tup[1] == 'LOL_NLD_PARB_CPP']
					if idealtxt_list:
						for idealtxt in idealtxt_list:
							idealcd_regex = [li[1] for li in lol_nld if li[2].strip() == idealtxt]
							if len(idealcd_regex) == 1:
								idealtxt_finditer = re.finditer(idealcd_regex[0], rfclolfa_presabsvsn)
								for res in idealtxt_finditer:
									res_grouped = res.group()
									rfc_vague_parblol_txt_ultimate.append(res_grouped)
			
			if any(tup[1] == 'LOL_NLD_PARB_SF' for tup in parb_reslist):
				rfc_parblol_clarifying_search4 = re.search(r"\bgeneral ?public|public(!? speaking)|non-public|\bthe ?public\b", rfclolfa_presabsvsn)
				rfc_parblol_clarifying_search5 = re.search(r"\bsocial(?! functioning)|interaction|interact ?with|public|co-workers|coworkers|colleagues|supervisor|superiors|non-confrontation|(objects|things) ?rather ?than ?people|object-focused|objects ?rather|proximity( ?to ?| ?with ?)others|others|other ?people", rfclolfa_presabsvsn)
				#print "PARB VERDICTS:"
				#print bool(rfc_parblol_clarifying_search4)
				#print bool(rfc_parblol_clarifying_search5)
				if bool(rfc_parblol_clarifying_search4) is False and bool(rfc_parblol_clarifying_search5) is False:
					rfc_vague_parblol_ver_ultimate = "1"
					# Retrieve relevant RFC language:
					idealtxt_list = [tup[0] for tup in parb_reslist if tup[1] == 'LOL_NLD_PARB_SF']
					if idealtxt_list:
						for idealtxt in idealtxt_list:
							idealcd_regex = [li[1] for li in lol_nld if li[2].strip() == idealtxt]
							if len(idealcd_regex) == 1:
								idealtxt_finditer = re.finditer(idealcd_regex[0], rfclolfa_presabsvsn)
								for res in idealtxt_finditer:
									res_grouped = res.group()
									rfc_vague_parblol_txt_ultimate.append(res_grouped)
			
			if any(tup[1] == 'LOL_NLD_PARB_ADL' for tup in parb_reslist):
				rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
				rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
				rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
				if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
					rfc_vague_parblol_ver_ultimate = "1"
					# Retrieve relevant RFC language:
					idealtxt_list = [tup[0] for tup in parb_reslist if tup[1] == 'LOL_NLD_PARB_ADL']
					if idealtxt_list:
						for idealtxt in idealtxt_list:
							idealcd_regex = [li[1] for li in lol_nld if li[2].strip() == idealtxt]
							if len(idealcd_regex) == 1:
								idealtxt_finditer = re.finditer(idealcd_regex[0], rfclolfa_presabsvsn)
								for res in idealtxt_finditer:
									res_grouped = res.group()
									rfc_vague_parblol_txt_ultimate.append(res_grouped)
			
			if any(tup[1] == 'LOL_NLD_PARB_GEN' for tup in parb_reslist):
				
				# Tracks whether a 'GEN' entity is (seemingly) not clarified:
				rfc_vague_parblol_gen_ver = "0"
				
				# If general language found, check for references to 'Par. B' category names
				# and, if found, check for that category's 'clarifying language' before making
				# the verdict '1':
				if bool(re.search(r"\bconcentration\b|\bpersistence\b|\bpace\b", rfclolfa_presabsvsn)):
					rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
					if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
						rfc_vague_parblol_ver_ultimate = "1"
						rfc_vague_parblol_gen_ver = "1"
				if bool(re.search(r"\bsocial.?function", rfclolfa_presabsvsn)):
					rfc_parblol_clarifying_search4 = re.search(r"\bgeneral ?public|public(!? speaking)|non-public|\bthe ?public\b", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search5 = re.search(r"\bsocial(?! functioning)|interaction|interact ?with|public|co-workers|coworkers|colleagues|supervisor|superiors|non-confrontation|(objects|things) ?rather ?than ?people|object-focused|objects ?rather|proximity( ?to ?| ?with ?)others|others|other ?people", rfclolfa_presabsvsn)
					if bool(rfc_parblol_clarifying_search4) is False and bool(rfc_parblol_clarifying_search5) is False:
						rfc_vague_parblol_ver_ultimate = "1"
						rfc_vague_parblol_gen_ver = "1"
				if bool(re.search(r"\bactivities ?of ?daily ?living\b|\bADLs?\b", rfclolfa_presabsvsn)):
					rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
					if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
						rfc_vague_parblol_ver_ultimate = "1"
						rfc_vague_parblol_gen_ver = "1"
				
				# If STILL no positive assignment, check for references to 'Par. B', and if
				# found, check for ANY clarifying language, and if none found, make the
				# verdict '1':
				# EX: "He has moderate Paragraph B rating limitations."
				if rfc_vague_parblol_ver_ultimate != "1":
					rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search4 = re.search(r"\bgeneral ?public|public(!? speaking)|non-public|\bthe ?public\b", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search5 = re.search(r"\bsocial(?! functioning)|interaction|interact ?with|public|co-workers|coworkers|colleagues|supervisor|superiors|non-confrontation|(objects|things) ?rather ?than ?people|object-focused|objects ?rather|proximity( ?to ?| ?with ?)others|others|other ?people", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfclolfa_presabsvsn)
					rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfclolfa_presabsvsn)
					if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
						if bool(rfc_parblol_clarifying_search4) is False and bool(rfc_parblol_clarifying_search5) is False:
							if bool(rfc_parblol_clarifying_search1) is False and bool(rfc_parblol_clarifying_search2) is False and bool(rfc_parblol_clarifying_search3) is False:
								rfc_vague_parblol_ver_ultimate = "1"
								rfc_vague_parblol_gen_ver = "1"
					
				# Finally, if you ultimately now have a positive value, and you
				# know it was unearthed from GEN values.  So retrieve text matching 
				# a GEN REGEX pattern:
				if rfc_vague_parblol_ver_ultimate != "1" and rfc_vague_parblol_gen_ver == "1":
					idealtxt_list = [tup[0] for tup in parb_reslist if tup[1] == 'LOL_NLD_PARB_GEN']
					if idealtxt_list:
						for idealtxt in idealtxt_list:
							idealcd_regex = [li[1] for li in lol_nld if li[2].strip() == idealtxt]
							if len(idealcd_regex) == 1:
								idealtxt_finditer = re.finditer(idealcd_regex[0], rfclolfa_presabsvsn)
								for res in idealtxt_finditer:
									res_grouped = res.group()
									rfc_vague_parblol_txt_ultimate.append(res_grouped)
		
		# (22)(F) Assign each ultimate value to the RFCLOLFA dictionary:
		rfcparsingdict["flag_rfc_vague_lol_ver"] = rfc_vague_lol_ver_ultimate
		if rfc_vague_lol_ver_ultimate == '1':
			rfcparsingdict["flag_rfc_vague_lol_val"] = str(list(set(rfc_vague_lol_txt_ultimate)))
		else:
			rfcparsingdict["flag_rfc_vague_lol_ver"] = '0'
			rfcparsingdict["flag_rfc_vague_lol_val"] = 'P'
		
		rfcparsingdict["flag_rfc_lessthan_lol_ver"] = rfc_lessthan_lol_ver_ultimate
		if rfc_lessthan_lol_ver_ultimate == '1':
			rfcparsingdict["flag_rfc_lessthan_lol_val"] = str(list(set(rfc_lessthan_lol_txt_ultimate)))
		else:
			rfcparsingdict["flag_rfc_lessthan_lol_ver"] = '0'
			rfcparsingdict["flag_rfc_lessthan_lol_val"] = 'P'       

		rfcparsingdict["flag_rfc_vague_parblol_ver"] = rfc_vague_parblol_ver_ultimate
		if rfc_vague_parblol_ver_ultimate == '1':
			rfcparsingdict["flag_rfc_vague_parblol_val"] = str(list(set(rfc_vague_parblol_txt_ultimate)))
		else:
			rfcparsingdict["flag_rfc_vague_parblol_ver"] = '0'
			rfcparsingdict["flag_rfc_vague_parblol_val"] = 'P'
		
		rfcparsingdict["flag_rfc_minlang_ver"] = rfc_minlang_ver_ultimate
		if rfc_minlang_ver_ultimate == '1':
			rfcparsingdict["flag_rfc_minlang_val"] = str(list(set(rfc_minlang_txt_ultimate)))
		else:   
			rfcparsingdict["flag_rfc_minlang_ver"] = '0'
			rfcparsingdict["flag_rfc_minlang_val"] = 'P'
		
		rfcparsingdict["flag_rfc_nolimlang_ver"] = rfc_nolimlang_ver_ultimate
		if rfc_nolimlang_ver_ultimate == '1':
			if rfc_nolimlang_txt_ultimate:
				rfcparsingdict["flag_rfc_nolimlang_val"] = str(list(set(rfc_nolimlang_txt_ultimate)))
			else:
				rfcparsingdict["flag_rfc_nolimlang_val"] = 'U'
		else:
			rfcparsingdict["flag_rfc_nolimlang_ver"] = '0'
			rfcparsingdict["flag_rfc_nolimlang_val"] = 'P'
		
		# (23) Return dictionary:
		return rfcparsingdict

	except Exception, x:
		raise
		#logger.exception('EXCEPTION')
		rfc_presabs_dict = presabs.rfc_presabs_parser(rfc_str)
		rfcparsingdict = dict(rfcparsingdict.items() + rfc_presabs_dict.items())
		rfcparsingdict = {k:'E' for k,v in rfcparsingdict.iteritems()}
		return rfcparsingdict

# Testing:
if __name__ == '__main__':

	# Test RFCs:
	test1 = '5. The claimant has the residual functional capacity to perform sedentary work except: occasional sitting, frequent stooping, constant crawling; he can sit, stand, and walk up to two hours during an eight-hour workday, with a sit/stand option at will every thirty minutes. He cannot finger or feel any more than occasionally with the right upper extremity. The claimant can frequently stoop, robustly crawl, and never jump in the air; he can rarely finger; he may occasionally climb ramps or stairs but never climb ladders, ropes, or scaffolds; he is limited to performing simple, routine, repetitive tasks in a non-production work environment.'
	test2 = " occasional handling, frequent stooping, constant crawling; he should not be required to taste or smell in his work; he is limited to simple, routine work"
	test3 = """4. After careful consideration of the entire record, I find that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 416.967(b), as the individual could stand and/or walk no more than six hours in an eight-hour workday; sit for up to six hours in an eight-hour workday; and lifting would be limited to 20 pounds occasionally and 10 pounds frequently. The individual would need to avoid operating vehicles and would need to avoid all hazards such as, but not limited to, open bodies of water, open flames, moving machinery, sharp objects, and unprotected heights. The individual would be limited to a non-production pace. The individual would be limited to simple, routine, one- to three-step tasks in a low-stress environment defined as no quick decision-making and no quick judgment required on the job."""
	test4 = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a), except he can stand and/or walk for less than two hours and sit for less than six hours in an eight-hour workday. He can never climb ladders, ropes, or scaffolds, can occasionally push/pull, climb ramps or stairs, balance, stoop, kneel, crouch, or crawl, and should avoid concentrated exposure to cold, heat, wetness, humidity, respiratory irritants, or chemicals, and even moderate exposure to hazard. Due to fatigue, he will likely be off-task at least 20 percent of a workday, absent from work at least twice a month, and need additional breaks allowing him to lie down."
	test5 = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a less than full range of light work as defined in 20 CFR 416.967(b). Specifically, the claimant remains able to lift and carry up to 10 pounds frequently and 20 pounds occasionally. He can sit for about 6 hours out of an 8-hour workday, but for no more than about 45 minutes without interruption, followed by an opportunity to stand and stretch briefly (1 to 2 minutes), without leaving the work station. The claimant can stand and/or walk for a combined total of about 6 hours out of an 8-hour workday, but for no more than about 30 minutes without interruption, followed by an opportunity to sit for up to 5 minutes. The claimant can frequently balance and stoop; occasionally stoop, crouch, kneel, crawl, and climb ramps and stairs; and never climb ladders, ropes or scaffolds, nor work around machinery that might require agility in order to evade. He can operate foot controls frequently using his left lower extremity and occasionally using his right. Mentally, the claimant remains able to understand, remember, and carry out instructions consistent with 1 to 2 step operations. Within that context, he can sustain attention for 2-hour blocks throughout an 8-hour workday; complete assigned tasks with ordinary supervision; exercise sufficient judgment to make basic work-related decisions; adjust to changes in a routine work environment; and adhere to a normal schedule. He can tolerate no more than occasional interaction with the public, but remains able to interact appropriately with supervisors and co-workers."
	text6 = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 404.1567(b) and 416.967(b). Specifically, the claimant can lift and/or carry 10 pounds frequently and 20 pounds occasionally. He can stand and/or walk for a total of 6 hours in an 8-hour workday with normal breaks, and sit for a total of 6 hours in an 8-hour workday with normal breaks. He has no other non-exertional limitations."
	test7 = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to lift and/or carry, push and/or pull 20 pounds occasionally and 10 pounds frequently (using the dominant left-upper extremity as a helper hand only); can sit, stand and/or walk up to 6 hours each in an 8-hour workday. She must be allowed a sit/stand option in which to change position between sitting and standing and standing to sitting (stretch) up to every thirty minutes, as needed. She can frequently balance, stoop, kneel, crouch, crawl, and climb ramps and stairs, and she must never climb ladders, ropes, or scaffolds. She can occasionally handle and finger with dominant left upper extremity. She can understand, remember, and carry out detailed, but not complex tasks, or semi-skilled work. (20 CFR 404.1567(b) and 416.967(b))."
	test8 = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 404.1567(b) with the following limitations: lift and/or carry twenty pounds frequently and ten pounds occasionally; stand and/or walk for a total of six hours in an eight-hour day; sit for a total of six hours in an eight-hour day; no work above shoulder level, bilaterally; no work with vibrating machinery or unprotected heights; occasional postural activities with the exception of a preclusion against climbing ladders, ropes, and scaffolds; no unprotected heights; no excessive air pollution (i.e., vapors, fumes, dusts); no excessive temperature changes; and a limitation to simple, object-oriented tasks involving simple work-related decisions."
	test9 = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a) except she can only frequently stoop, kneel, or crouch, occasionally crawl or climb ramps/stairs, and should never climb ladders, ropes, or scaffolds. The claimant should avoid concentrated exposure to extreme temperatures, humidity, pulmonary irritants, and workplace hazards."
	test10 = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a) except he needs a cane to ambulate and balance. He must use his dominant and non-dominant extremity for the cane. He can occasionally use his dominant upper extremity for fingering and handling. He requires stable, even flooring at the job site. He can occasionally balance, stoop, kneel, crouch, crawl, and climb stairs, but can never climb ladders. He must avoid even moderate exposure to hazards at the work site. He is capable of performing simple tasks on a sustained basis and would work best in familiar groups. Additionally, he would have to work from a reclining position with his lower extremities raised to waist level throughout the day."
	test11 = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) except the claimant requires a sit/stand option allowing the claimant to sit or stand at will. The claimant can never climb ladders, ropes, or scaffolds. The claimant can occasionally climb ramps or stairs. The claimant can occasionally stoop and crouch. The claimant can never kneel or crawl. The claimant should avoid all exposure to excessive vibration. The claimant should avoid all use of hazardous machinery and exposure to unprotected heights. Due to pain, work is limited to simple as defined in the DOT as SVP levels 1 and 2, routine and repetitive tasks."
	test12 = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work, meaning she can occasionally lift and carry 10 pounds and frequently lift and carry less than five pounds. She can stand and walk four hours of an eight-hour workday, and she is able to sit for six hours of an eight-hour workday as defined in 20 CFR 416.967(a) except she can occasionally push and pull in upper extremities. She cannot operate foot controls with either leg. She must change position every 30 minutes. She can occasionally climb ramps and stairs. She can never climb ladders, ropes and scaffolds. She can occasionally stoop, kneel, crouch, and crawl. She can reach frequently with the left and right in front and/or laterally and left and right overhead. She can frequently handle. She needs to avoid concentrated exposure to extreme cold and extreme heat. She needs to avoid concentrated exposure to wetness and humidity. She needs to avoid concentrated exposure to fumes, odors, dusts, gases, and poor ventilation. She needs to avoid concentrated exposure to hazards, dangerous machinery, and unprotected heights."
	test13 = "4. After careful consideration of the entire record, the undersigned finds that the     claimant has the residual functional capacity to perform medium work as defined in 20   CFR 416.967(c) in that she can lift and/or carry 50 pounds occasionally and 25 pounds   frequently. She can push and/or pull the same amount of weight as lifting and/or carrying.   The claimant can sit, stand and walk for up to 6 hours in an 8-hour day with normal   breaks every 2 hours. She can stoop, crouch, and crawl only rarely.  She has no limitation in her ability to climb. She can handle, finger, and feel objects no more than occasionally. She has moderate limitations in concentration, persistence, and pace.  She can bend for a minimum of two hours."
	test14 = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a range of light work as defined in 20 CFR 416.967(b). Specifically, she can stand and walk for four hours in an eight-hour work day; she can lift and carry twenty pounds occasionally and ten pounds frequently; she can occasionally crouch, crawl, kneel, and stoop; and she cannot work at unprotected heights or around hazards or climb ladders, ropes, scaffolds, ramps, or stairs. A determination in this case cannot be based on medical considerations alone. Therefore, it is necessary to proceed to steps four and five of the sequential evaluation. Steps four and five require a determination whether the claimant has, during the time at issue, retained the residual functional capacity to perform past relevant work, and if not, to perform other work existing in significant numbers in the national economy consistent with his age, education and past work experience. In order to make these determinations, it is necessary to assess the claimant's residual functional capacity. Residual functional capacity is what the claimant can still do despite limitations due to the impairments. (20 CFR Q 404.1545 and 416.945 and Social Security Ruling 96-8p)."
	test15 = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a full range of work at all exertional levels but with the following nonexertional limitations: The claimant is less than occasionally able to accept instructions and respond appropriately to criticism from authority, get along with associates or peers without unduly distracting them of exhibiting behavioral extremes, respond appropriately to changes in routine setting, and deal with simple stresses."    
	davidtest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 416.967(a), with the following provisos: the claimant must avoid concentrated exposure to temperature extremes of cold and heat, as well as concentrated exposure to pulmonary irritants, such as fumes, odors, dust, gases, poor ventilation, and the like. The claimant must also avoid concentrated exposure to work place hazards, such as dangerous moving machinery and unprotected heights. She must never climb ladders, ropes, or scaffolds. She can occasionally climb ramps and stairs, occasionally balance, stoop, kneel, crouch, and/or crawl."
	baselinetest = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a), except: he can occasionally stoop and crouch but never crawl; he cannot climb ladders, ropes, scaffolds, ramps, or stairs; and can only frequently be exposed to dusts and gases."
	miss1 = "He can perform no more than occasional handling."
	liftmiss1 = "5. The claimant has the residual functional capacity (RFC) to perform sedentary work as defined in 20 CFR Q 404.1567(a) and 416.967(a), except that due to musculoskeletal impairments, he can lift and carry 10 pounds occasionally and up to 10 pounds frequently; he can sit for 6 hours and stand/walk 2 hours in an 8-hour day, but must be allowed to sit or stand at will; he can occasionally climb ramps and stairs but never ladders, ropes or scaffolds"
	liftmiss2 = "5. The claimant has the residual functional capacity to perform less than the full range of sedentary work as defined in 20 CFR 404.1567(b) except that the claimant is limited to lifting and carrying no more than 5 pounds with her left upper extremity; occasionally climbing ramps and stairs, balancing, kneeling, crouching, and crawling; never climbing ropes, ladders and scaffolds; occasionally pushing/pulling with her left upper extremity; seldom reaching overhead with her left upper extremity; and sitting, standing, and walking no more than 5 minutes at a time. The claimant must avoid concentrated exposure to unprotected heights and hazards. She would be off task 20% of the workday due to pain and fatigue."
	testlift1 = "5. The claimant has the residual functional capacity to perform less than the full range of sedentary work as defined in 20 CFR 404.1567(b) except that the claimant can frequently lift and carry up to 10 pounds and occasionally lift and carry up to 10 pounds.  She can occasionally stoop."
	andtest = "he can stoop and jog to work on an occasional basis"
	lbtest1 = "he can occasionally lift 20 pounds and frequently lift 10 pounds"
	lifttest2 = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 416.967(b) except the claimant can lift/carry 20 pounds occasionally and 10 pounds frequently. She can stand/walk for up to 4 hours in an 8-hour workday. The claimant can sit for up to 6 hours in an 8-hour workday. She has the ability to occasionally climb, balance, stoop, kneel, crouch and crawl. The claimant can frequently performing handling and fingering. She maintains the ability to occasionally work around heights, moving machinery and vibrations. The claimant can occasionally drive. She can engage in only occasional interaction with supervisors and coworkers."
	carrytest1 = "He cannot be on his feet standing and walking more than 2 hours in an 8-hour day and should not lift or carry more than 10 pounds."
	negationtest_baseline = "she can occasionally crouch but cannot perform occasional stooping"
	negationtest_davidexample = "; no repetitive or constant push and pull with lower extremities, such as operating foot pedals; "
	complex_simplification_test1 = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a), except that she can never stoop, crouch, or crawl any more than occasionally."
	robyntest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 416.967(a) except he has occasional limitations in bending, climbing, stooping, squatting, and balancing; no climbing ropes, ladders or scaffolds; occasional limitations in the ability in feeling (skin receptors); occasional limitations in pushing and pulling with the upper extremities; no kneeling or crawling; occasional limitations in dealing with stress. The claimant cannot work in areas where he would be exposed to cold and wind. The claimant retains the ability to perform the basic mental demands of unskilled work including: the ability to understand, remember and carry out simple instructions; the ability to respond appropriately to supervision, coworkers and usual work situations and the ability to deal with changes in a routine work setting."
	test05202016 = "rfctxt: 5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work except: she has no manipulative limitations in speaking or handling whatsoever; she cannot finger, occasionally crawl, and can frequently reach, handle, and finger."
	testhr = "He can sit for six hours in an eight hour day.  Note that he can sit for a total of 6 hours. He can finger at least occasionally.  Additionally, he can engage in fingering on at most an occasional basis."
	newtest = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a full range of work at all exertional levels but with the following nonexertional limitations: he can avoid hazards; he should avoid stooping; he can lift a total of 10 pounds; and he cannot bend.  The claimant also can never be exposed to extreme heat."
	breaktest = "5. the claimant has the residual functional capacity to perform sedentary work as defined in 20 cfr 404.1567(a) and 416.967(a), except the claimant must have the ability to lay down or recline for one third of the workday to relieve pain, both lumbar and abdominal. the claimant requires a no stress environment, as normal work stress would lead to decompensation. the claimant would be absent from work one fourth of the month due to pain, medical treatment, and psychiatric symptoms."
	simpletest = "5. the claimant has the residual functional capacity to perform sedentary work as defined in 20 cfr 404.1567(a) and 416.967(a), except he can only lift a total of 10 pounds occasionally; he can only stand for 2 hours out of 8 hours per day."
	simpletest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a full range of work at all exertional levels but with mental restrictions. The claimant is able to understand, remember, and carry out only simple instructions. He is not able to respond appropriately to others in a work environment that requires even limited interaction with supervisors and coworkers, and he is unable to perform work requiring any interaction with the public. He is not able to respond appropriately to work pressures even in a low-stress work environment. He is unable to sustain the concentration, persistence, and pace required to complete even simple, routine, repetitive tasks or to complete a full workday and workweek on a regular and continuing basis."
	simpletest = "He can never stoop, crouch, or crawl in excess of occasionally. He must avoid concentrated exposure to exposed heights, and must have only frequent contact with poor ventilation."
	simpletest = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a).  He can occasionally perform the following postural functions: stooping, crouching, crawling, and climbing ladders/ropes/scaffolds.  He cannot finger or handle any more than occasionally, cannot be exposed to dusts, fumes, or gases, and can only perform simple, routine tasks."
	simpletest = "he can lift/carry 20 pounds frequently and 10 pounds occasionally"
	simpletest = "can occasionally stoop, can frequently crawl"
	simpletest = "he can stoop periodically; crouch at least occasionally; stoop less than frequently; he has moderate limitations in social functioning; he can lift a minimum of 20 pounds; he has no restrictions in his capacity to think clearly"
	simpletest = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform sedentary work except: she occasionally finger; can intermittently interact with the public; and can have less than occasional exposure to the public.  "
	simpletest = "he has moderate limitations in social functioning"
	simpletest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 416.967(b) except for occasionally lifting and carrying 20 pounds, frequently lifting and carrying 10 pounds, pushing and pulling within those exertional limitations, standing and walking for four hours in an eight hour workday, sitting for six hours in an eight hour workday, occasionally climbing stairs and ramps, never climbing ropes, ladders or scaffolds, occasionally stooping, kneeling, crouching, and crawling, avoiding concentrated exposure to fumes, odors, dust, mists, gases and poor ventilation, due to degenerative disc disease, radiculopathy, fibromyalgia, asthma, and a gastrointestinal disorder, and further being limited due to a bipolar disorder to the ability to understand, remember, and carry out detailed but not complex instructions, with no more than frequent interaction with the public and coworkers."
	simpletest = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a reduced range of medium work(See 20 CFR 404.1567(c)). The claimant could lift, carry, push, and pull 50 pounds occasionally and 20 pounds frequently. She could sit, stand, and walk for 6 hours for each named activity with normal breaks in an 8-hour workday. She has no limits with using her feet and hands for the operation of controls. She has no limits on seeing, hearing or speaking. The claimant has no limits on fingering, feeling or handling. She can frequently climb stairs and ramps. She can never climb ladders, ropes or scaffolds. She has no limits on balancing, stooping, kneeling, crouching or crawling. The claimant would need to avoid concentrated exposure to dusts, fumes, odors, gases, inhalants, poor ventilations, chemicals and to extreme cold as well as humidity and vibrations. She could perform simple routine repetitive job duties, understand, remember, and carry out job instructions related to simple routine repetitive unskilled type of job tasks. The claimant can maintain attention, concentration, and pace if allowed scheduled work breaks of 15 minutes each in the first and second half of the workday plus a 30 minute midday break. The claimant can work within a set schedule and be punctual. She requires no special supervision to complete her assigned job duties. The claimant can make simple work related decision regarding unskilled type of job duties. She can accept supervision, interact frequently with co- workers and occasionally with the general public but she works best with objects and not with people. The claimant can adapt to work place changes if the changes are introduced gradually and infrequently."
	simpletest = "He can lift up to 10 pounds frequently and up to 20 pounds occasionally, sit and stand and/or walk about 6 hours each in an 8-hour day (with normal breaks)."
	#simpletest = "Specifically, the claimant can stand for 4 to 8 hours and must be able to alternate between sitting and standing in place every 1/2 hour. The claimant can never climb ladders, ropes or scaffolds, kneel, or crawl;"
	#simpletest = "he can sit for less than 5 - hours total in an 8 hour day"
	simpletest = "She is able to be on her feet, standing and/or walking, with normal breaks for a total of 6 of 8 hours in an 8-hour day and can sit for 6 of 8 hours with normal breaks in an 8-hour day."
	simpletest = "She is able to lift/carry less than 10 pounds occasionally, and to stand/walk for less than 2 hours and sit for less than 6 hours in an 8-hour workday;"
	simpletest = "The claimant would be limited to lifting-carrying and/or pushing-pulling a maximum of 10 pounds occasionally, 13 with the ability to sit at least six (6) hours in an eight-hour workday, and the ability to stand and/or walk a maximum of two (2) hours in an eight-hour workday."
	simpletest = "She can stand/walk for less than 2 hours and sit for less than 6 hours in an 8-hour workday"
	simpletest = "stand and walk for six of eight hours per day"
	simpletest = "Specifically, the claimant can stand for 4 to 8 hours and must be able to alternate between sitting and standing in place every 1/2 hour."
	simpletest = "5. The claimant has the residual functional capacity to perform light work as defined in 20 CFR 404.1567(b) except that he is able to lift up to 20 pounds occasionally, but no frequent lifting; no repetitive or frequent grasping, pushing or pulling of arm controls or f'me manipulation; no repetitive or frequent use of foot controls; no bending, squatting, crawling, climbing; must to alternate sitting and standing every 45 minutes; can sit for two hours in an eight-hour workday; stand and/or walk three hours in an eight-hour workday; occasional overhead reaching. He is limited to simple, repetitive tasks, no in tandem tasks with coworkers; and supervision should be direct and concrete, with little or no changes in work tasks."
	simpletest = "avoid concentrated exposure to fumes and all exposure to machinery"
	simpletest = "The claimant would need to avoid concentrated exposure to dusts, fumes, odors, gases, inhalants, poor ventilations, chemicals and to extreme cold as well as humidity and vibrations"
	#simpletest = "he can only occasionally be exposed to high elevations"
	simpletest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a restricted range of light work as defined in 20 CFR 416.967(b). The claimant can lift up to 20 pounds occasionally, lift and carry up to 10 pounds frequently; never climb ladders, ropes, or scaffolds; frequently climb ramps or stairs; frequently balance; occasionally stoop, crouch, kneel, and crawl; the claimant should avoid concentrated exposure to dangerous machinery with moving mechanical parts, except vehicles, and exposure to unprotected heights (high, exposed); the claimant can remember and carry out simple instructions, make simple work related decisions, with no work with the public and occasional interaction with coworkers and supervisors, and he should work in a repetitive work setting."
	simpletest = "5. The claimant has the residual functional capacity to perform light work as defined in 20 CFR 404.1567(b) and 416.967(b) including lifting and carrying 20 pounds occasionally and 10 pounds frequently. He is able to communicate orally in English, but writing in English is limited to the 7m grade level. He can stand and/or walk for four hours total in an eight-hour day and needs a cane to ambulate, but has no limit on sitting. He can occasionally climb stairs, but can perform no stooping, kneeling, crouching, crawling, and balancing and no climbing of ladders, ropes, and scaffolds. He can occasionally handle, finger, and feel with the upper extremities, can frequently reach, and can occasionally operate foot controls. He can have no exposure to heights or dangerous machinery."
	simpletest = "4. The claimant has the residual functional capacity to perform light work as defined in 20 CFR 416.967(b) except he would be limited to occasionally climbing ramps and stairs and never climbing ladders, ropes, or scaffolds. He is able to understand, remember and carry out simple to moderately complex instructions consistent with routine unskilled work and semiskilled work."
	simpletest = "4. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform a full range of work at all exertional levels but with the following nonexertional limitations: the claimant is restricted from concentrated exposure to hazardous machinery and heights."
	simpletest = "5. The claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a). Claimant can lift/carry 2-3 pounds frequently and no more than 10 pounds occasionally. She can sit for 6 hours and stand/walk no more than 2 hours in an 8-hour day. She must be afforded the option to sit and stand during the workday for brief periods of 1-2 minutes every 30 minutes or so. She must avoid concentrated prolonged exposure to environments with temperature extremes, excessive vibration, extreme dampness, and humidity. She is limited to occupations that do not require exposure to dangerous machinery and unprotected heights. Mentally, she is limited to occupations requiring no more than simple, routine, repetitive tasks, not performed in a fast-paced production environment, involving only simple work-related decisions, and in general, relatively few work place changes. The claimant has a number of medical problems, including fibromyalgia, chronic fatigue syndrome, lumbar spine disorder including degenerative disc disease, degenerative joint disease, and facet syndrome, and major depressive disorder. These impairments are severe insof ar as they limit the claimant to a range of unskilled sedentary work as set forth above, and they are severe enough to be completely disabling. Considering the claimant's age, education, work experience, and residual functional capacity, a finding of disabled is directed by Medical-Vocational Rule 201.14."
	simpletest = "5. Based on the vocational expert's interrogatories and a careful consideration of the entire record, the undersigned finds that since February 23, 2012, the claimant has the residual functional capacity to lift, carry, push or pull up to 20 pounds occasionally and up to 10 pounds frequently; sit for 6 out of 8 hours in a day for up to 1 hour at a time; stand or walk 2 out of 8 hours in a day for up to 30 minutes at a time; occasionally able to climb ramps and stairs; never climb ladders, ropes, or scaffolding; must avoid hazards, including unprotected heights and moving mechanical parts; can occasionally stoop, kneel, crouch, crawl and balance; occasionally push or pull with bilateral lower extremities; occasionally operate foot controls with bilateral extremities; and can frequently perform handling, fingering and feeling. The claimant must avoid dust, fumes, odors or areas without ventilation; must avoid extremes of heat or cold, humidity and wetness; and the claimant is able to understand, remember and carry out simple instructions but not at an assembly line pace. Assigned tasks must be performed in a setting where production is measured no earlier than the end of the workday and the claimant is able to make simple work related decisions; and adapt to routine changes in the workplace that are occasional and that are gradually introduced. Due to frequent lapses in concentration the claimant would be off task 5% of the day and due to ailments would be absent up to 1 day per month."
	simpletest = "5. After careful consideration of the entire record, the undersigned finds that the claimant has the RFC to perform a full range of work at all exertional levels but with the following nonexertional limitations: Roger Duane Fry was 29 years of age on the alleged onset date of disability (August 29, 2012) (he is currently 33 years of age with a birth date of August 21, 1983) with a high school education (2001) past relevant work as an infantryman (2002-2006) and armed security officer (2008-2012). He is able to perform a full range of exertion work (heavy included). He is unable to climb ropes, ladders, and scaffolds, and is unable to work in environments where he would be exposed to unprotected heights and dangerous moving machinery parts. He is able to understand, remember, and carry out simple to moderately detailed instructions in a work-related setting, and is able to interact with co-workers and supervisors, under routine supervision."
	
	
	manualtest = 1

	if manualtest == 1:
		print "Beginning test..."
		start = time.clock()
		testrfc = simpletest
		rfcparsingdictRESULT = rfcparser(testrfc)
		print "\n\nRFCLOLFA RESULTS (all non-default values):"
		print "ORIGINAL RFC: " + testrfc
		for key, value in sorted(rfcparsingdictRESULT.items(), key=lambda x:x[0]):
			if value not in ['U', 'P', '', '0'] or key.startswith('rfc_') or 'flag' in key:
				print str(value) + "  (" + str(key) + ")"
		print "Time: " + str(time.clock()-start)