# INSIGHT DATABASE ACTIONS
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# SUMMARY:
# Contains functions to perform common database actions required by
# INSIGHT, such as adding/updating table rows or retrieving table row
# data.
#
# DATE LAST UPDATED: 
# 10.25.2016
#
# UPDATES/NOTES:
# 10.25.2016: 
# - Worked with DCS to ensure remote access to NLPDEV;
# - Updated record existence SQL to faster method per http://stackoverflow.com/questions/30342758/fastest-way-to-check-the-records-if-exists-in-the-sql-table
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#==============================================================================

# Import modules:
import sys
import os
import datetime
import math
import os.path
import logging
import urllib
from sqlalchemy import create_engine, MetaData, Table, select, text
import pyodbc
import pypyodbc
import pandas
import config as cfg
import common_fx as cfx

# Import config_sec:
# secdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../../sec"))
# sys.path.insert(0, secdir)
import config_sec as cfg_sec

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
inputdir = os.path.join(insightdir, "Input/Input")
processingdir = os.path.join(insightdir, "Input/Processing")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Retrieve entire contents of table:
def retrieve_all_ifs_tbl(tbl_nm):
    db_cnxn_str = "Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s" % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
    params = urllib.quote_plus(db_cnxn_str)
    engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
    conn = engine.connect()
    metadata = MetaData(conn)
    sql_str = "SELECT * FROM %s" % tbl_nm
    sql = text(sql_str)
    df = pandas.read_sql(sql, conn)
    conn.close()
    return df

# Retrieve all instances of a given column from a given table (schema 2):
def retrieve_column_values(tbl_nm_str, column_nm_str):
	'''Retrieves all values for a target column
	name housed in a target IFS database table.
	
	Args:
		tbl_nm_str {str}: Name of the table to query
			(within IFS database).
		column_nm_str {str}: Name of the column whose
			values are to be retrieved.
	Returns:
		A Python list containing all values associated
			with the target column name; if no values
			returns empty list.
	Raises:
		N/A (if exception, returns empty list).'''
	try:
		# Connect to INSIGHTDEV database:
		ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
		connection_SQLNLP = pypyodbc.connect(ifs_db_cnxn_str)
		cursor_SQLNLP = connection_SQLNLP.cursor()
		tbl_list = [row[2] for row in cursor_SQLNLP.tables() if row[1] == 'dbo' and row[3] == 'TABLE']
		if tbl_nm_str not in tbl_list:
			err_str = "database_actions.retrieve_column_values(%s, %s) - tbl_nm_str not in tbl_list" % (tbl_nm_str, column_nm_str)
			logger.critical(err_str)
			cursor_SQLNLP.close()
			del cursor_SQLNLP
			connection_SQLNLP.close()
			return []
		else:
			# TIP: Cannot parameterize table name.
			SQLStatement = "SELECT %s FROM %s" % (column_nm_str, tbl_nm_str)
			cursor_SQLNLP.execute(SQLStatement)
			reslist = cursor_SQLNLP.fetchall()
			reslist = [r[0] for r in reslist]
			cursor_SQLNLP.close()
			del cursor_SQLNLP
			connection_SQLNLP.close()
			return reslist
	except Exception:
		logger.exception('Exception')
		return []


# Retrieve all instances of a given column from a given table where 
# its REQID value = X (schema 2):
def retrieve_select_schema2(reqid, tbl_nm, col_nm):
	try:
		# Connect to INSIGHT database:
		ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
		connection_SQLNLP = pypyodbc.connect(ifs_db_cnxn_str)
		cursor_SQLNLP = connection_SQLNLP.cursor()

		# Add parent table values (if any):
		col_names = [col_nm]
		sql = "SELECT %s FROM %s WHERE REQID = ?" % (col_nm, tbl_nm)
		cursor_SQLNLP.execute(sql, [reqid])
		# TIP: Should only be one 'dspn_doc' entry per REQID:
		res = cursor_SQLNLP.fetchall()
		if not res:
			return []
		else:
			res = list(cfx.flatten_irreg(res))
			return res
		
		# Close database connections:
		cursor_SQLNLP.close()
		del cursor_SQLNLP
		connection_SQLNLP.close()
			
	except Exception:
		logger.exception('EXCEPTION')
		err_str = 'REQID PASSED = %s' % str(reqid)
		logger.critical(err_str)
		return []
		
		
# Iterate through table names to retrieve its colum INSIGHT data point names (column names) present in that table:
def retrieve_case_entity_schema2(reqid):
	'''Retrieves a case entity's data from the
	INSIGHT OAO database (schema 2) using the
	REQID value associated with that case entity.
	
	Args:
		reqid {str}: An INSIGHT 'REQID' value.
	Returns:
		resdict {dict}: A dict where each key
			is either a column name from the 
			'dspn_doc' parent table or the name
			of a child table (e.g. 'struct_hodisp').
			
			Each 'dspn_doc' column name key's value
			will be the value associated with that
			column name (e.g. a value of '1' for the
			column name key 'verefbg').
			Each child table key's value will be a 
			list containing a dictionary for each 
			observation associated with that REQID
			in that child table. If none, the list
			will be empty.
			
			If no observations are found in 'dspn_doc'
			for the REQID value passed, the dictionary
			will be empty.
	Raises:
		N/A (if exception occurs, an empty dictionary is
		returned).
	'''
	try:
		reqid_dict = {}
		
		# Connect to INSIGHT database:
		ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
		connection_SQLNLP = pypyodbc.connect(ifs_db_cnxn_str)
		cursor_SQLNLP = connection_SQLNLP.cursor()

		# Add parent table values (if any):
		col_names = [row[3] for row in cursor_SQLNLP.columns(table=cfg.ifs_database_tblnm_list_s2_nonstruct_parent)]
		sql = "SELECT * FROM %s WHERE REQID = ?" % cfg.ifs_database_tblnm_list_s2_nonstruct_parent
		cursor_SQLNLP.execute(sql, [reqid])
		# TIP: Should only be one 'dspn_doc' entry per REQID:
		res = cursor_SQLNLP.fetchone()
		if not res:
			return {}
		else:
			par_resdict = dict(zip(col_names, res))
			for k,v in par_resdict.iteritems():
				if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
					reqid_dict[k] = 'U'
				else:
					reqid_dict[k] = v

		# Add child table values:
		for tbl_nm in cfg.ifs_database_tblnm_list_s2_nonstruct_child:
			try:
				col_names = [row[3] for row in cursor_SQLNLP.columns(table=tbl_nm)]
				sql = "SELECT * FROM %s WHERE REQID = ?" % tbl_nm
				cursor_SQLNLP.execute(sql, [reqid])
				res = cursor_SQLNLP.fetchall()
				if not res:
					reqid_dict[tbl_nm] = []
				else:
					chd_reqid_dictlist = []
					chd_resdictlist = [dict(zip(col_names, indivres)) for indivres in res]
					for chd_dict in chd_resdictlist:
						chd_dict_cleaned = {}
						for k,v in chd_dict.iteritems():
							if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
								chd_dict_cleaned[k] = 'U'
							else:
								chd_dict_cleaned[k] = v
						chd_reqid_dictlist.append(chd_dict_cleaned)
					reqid_dict[tbl_nm] = chd_reqid_dictlist
			except Exception:
				logger.exception('EXCEPTION')
				logger.critical(tbl_nm)
				logger.critical(reqid)
				# res_dict[tbl_nm] = []
				
		# Add struct table values:
		for tbl_nm in cfg.ifs_database_tblnm_list_s2_struct:
			try:
				col_names = [row[3] for row in cursor_SQLNLP.columns(table=tbl_nm)]
				sql = "SELECT * FROM %s WHERE REQID = ?" % tbl_nm
				cursor_SQLNLP.execute(sql, [reqid])
				res = cursor_SQLNLP.fetchall()
				if not res:
					reqid_dict[tbl_nm] = []
				else:
					chd_reqid_dictlist = []
					chd_resdictlist = [dict(zip(col_names, indivres)) for indivres in res]
					for chd_dict in chd_resdictlist:
						chd_dict_cleaned = {}
						for k,v in chd_dict.iteritems():
							if v is None or (isinstance(v, float) and math.isnan(v)) or v == '':
								chd_dict_cleaned[k] = 'U'
							else:
								chd_dict_cleaned[k] = v
						chd_reqid_dictlist.append(chd_dict_cleaned)
					reqid_dict[tbl_nm] = chd_reqid_dictlist
			except Exception:
				logger.exception('EXCEPTION')
				logger.critical(tbl_nm)
				logger.critical(reqid)
				# res_dict[tbl_nm] = []
				
		# Close database connections:
		cursor_SQLNLP.close()
		del cursor_SQLNLP
		connection_SQLNLP.close()

		return reqid_dict
							
	except Exception:
		logger.exception('EXCEPTION')
		err_str = 'REQID PASSED = %s' % str(reqid)
		logger.critical(err_str)
		return {}
		
# Retrieve a specific case entity data:
def retrieve_case_entity(uid_nm, uid_val):
    '''Retrieves a case entity's data from the
    INSIGHT OAO database (schema 2) using the
    a passed UID value.

    Args:
        uid_nm {str}: Unique identifer (UID) name, equal
            to an INSIGHT database column name for a common
            UID in the 'dspn_doc', 'struct_hodisp', or
            'struct_oao' table.  Acceptable values are
            'HOFC_WRK_UNIT_UID', 'EFLDR_NUM', 'hofc_wrk_unit_AC',
            or 'DOCU_CTL_ID'.
        uid_val {str}: The 'uid_nm' value associated
            with the case entity whose data is targeted
            for retrieval.
    Returns:
        resdict {dict}: A dict where each key
            is either a column name from the 
            'dspn_doc' parent table or the name
            of a child table (e.g. 'struct_hodisp').

            Each 'dspn_doc' column name key's value
            will be the value associated with that
            column name (e.g. a value of '1' for the
            column name key 'verefbg').
            Each child table key's value will be a 
            list containing a dictionary for each 
            observation associated with that REQID
            in that child table. If none, the list
            will be empty.

            If no observations are found in 'dspn_doc'
            for the REQID value passed, the dictionary
            will be empty.
    Raises:
        N/A (if exception occurs, an empty dictionary is
        returned).
    '''
    try:
        # Parse arguments:
        if uid_nm.upper() == 'REQID':
            reqid_dict = retrieve_case_entity_schema2(uid_val)
            return reqid_dict
        else:
            # Retrieve REQID:
            # TIP: Should only be one REQID for any of these
            # values *except* for CLMT_SSN.  If that's passed, only
			# the first case entity associated with that will be returned
			# for now.
            ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
            connection_SQLNLP = pypyodbc.connect(ifs_db_cnxn_str)
            cursor_SQLNLP = connection_SQLNLP.cursor()
            reqid = 'U'
            if uid_nm in ['HOFC_WRK_UNIT_UID', 'EFLDR_NUM', 'CLMT_SSN']:
                sql = "SELECT REQID FROM struct_hodisp WHERE %s = ?" % uid_nm
                cursor_SQLNLP.execute(sql, [uid_val])
                res = cursor_SQLNLP.fetchone()
                if res:
                    reqid = res[0]
            elif uid_nm == 'hofc_wrk_unit_AC':
                sql = "SELECT REQID FROM struct_oao WHERE %s = ?" % uid_nm
                cursor_SQLNLP.execute(sql, [uid_val])
                res = cursor_SQLNLP.fetchone()
                if res:
                    reqid = res[0]
            else:
                sql = "SELECT REQID FROM dspn_doc WHERE %s = ?" % uid_nm
                cursor_SQLNLP.execute(sql, [uid_val])
                res = cursor_SQLNLP.fetchone()
                if res:
                    reqid = res[0]
            cursor_SQLNLP.close()
            del cursor_SQLNLP
            connection_SQLNLP.close()
            if reqid == 'U':
                return {}
            else:
                reqid_dict = retrieve_case_entity_schema2(reqid)
                return reqid_dict
    except Exception:
        logger.exception('EXCEPTION')
        logger.critical(uid_nm)
        logger.critical(uid_val)
        return {}
