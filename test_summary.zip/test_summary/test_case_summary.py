import os
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select

# Set directories:
#setup_config
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)

class TestCaseSummary(object):

    def test_case_summary(self):
        #driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        driver = webdriver.Ie("C:\\IEDriver\\chromedriver.exe")         
        driver.get("http://localhost:8080/oaoapp/444")
        index = 1
        rowElements = driver.find_elements_by_xpath("//td/div[contains(@class, 'ffbutton')]")
        
        #print rowElements

        for ele in rowElements: 
            #print (rowElements.get_attribute("innerHTML"))
            if index >=1:                   
                #title = driver.find_elements_by_xpath("//td/div/button[contains(@id, 'reportsectionbtn_casesummary')]")
                sbi =1
                print index
                #item=ele.find_elements_by_xpath("//table/td/div/button[contains(@class, 'reportsectionbtn')]")
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//table/td/h1[contains(@id,'navsummary')]")]
                time.sleep(1)     
                print data, 'Bhavin'
                    #numele = items.find_element_by_class_name('KambiBC-bet-offer-category__title js-bet-offer-category-title')
                   # numele = items.find_elements_by_xpath("//table/td/div/button[contains(@class, 'reportsectionbtn')]")
                    #time.sleep(1)
                #print (title.text)
                item =  driver.find_elements_by_tag_name('h1')
                for iele in item:
                    print iele.text, iele.tag_name

                #driver.find_elements_by_xpath("//table/td[contains(@id,'navsummary')]")
                #System.out.println(ele.getText()) #driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
                #print 'Success'       
                #ele.click()
                #print ele.text  
                index = index + 1
                time.sleep(1)
                #print ele.text, "item"
               
                #time.sleep(1)
    def tearDown(self):
        '''Tear Down test'''
        self.driver.close()
