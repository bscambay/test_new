# INSIGHT FULL SUITE - OAO ETL/BATCH PROCESSING
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 10.25.2017
# 
# SUMMARY:
# This is an ETL/batch processing script to generate INSIGHT data about the
# content of issued hearing decisions.	It supports INSIGHT's
# OAO product.
#
# This script is designed to be executed directly.	It will instantiate the
# INSIGHT logger.
#
# WARNING: 
# The following is prototype software whose output quality has not
# yet been formally validated and whose documentation is not yet fully formed.
# ==============================================================================

# Import modules:
import os.path
import logging
import time
import datetime
import multiprocessing
import subprocess
import pandas
import ifs
import config as cfg
import date_helper as dh
import common_fx as cfx
import common_calcs as cc
import database_actions_batch as ifsdab
import database_actions as ifsda
import batch_decision_text_retrieval
import batch_struct_data_retrievers as bsdr

# Disable Pandas chained assignment warning:
pandas.options.mode.chained_assignment = None

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")
batch_temp_dir = cfg.batch_temp_dir
batch_decisionfiles_dir = cfg.batch_decisionfiles_dir
outputdir = cfg.outputdir

# Set up parent logger:
# TIP: logger.exception() is associated with the ERROR level.
# TIP: If root logger level were not modified, default would be WARNING.
logger = logging.getLogger('ifs')
log_fh = logging.FileHandler('ifs_log.log')
log_fh.setLevel(logging.DEBUG)
log_ch = logging.StreamHandler()
log_ch.setLevel(logging.DEBUG)
log_formatter = logging.Formatter('%(asctime)s || %(name)s || %(levelname)s || %(message)s')
log_fh.setFormatter(log_formatter)
log_ch.setFormatter(log_formatter)
logger.addHandler(log_fh)
logger.addHandler(log_ch)
logger.setLevel(logging.DEBUG)


# Function to process individual observations through
# ifs.runsuite_batch() to return a dictionary containing
# all data in input dictionary and all ifs.py-generated
# data (primarily derived from a decision document).
def batch_process_obs(input_tup):
    """Function to process individual observations through
	ifs.runsuite_batch() to return a dictionary containing all data
	in input dictionary and all runsuite_batch()-generated
	data (primarily derived from a decision document).

	Args:
		input_tup {tuple}: Tuple where tuple[0] = input
		dict and tuple[1] = cfg.batch_tgt_uid_nm.
	Returns:
		Dictionary containing all structured data already
		in input_dict as well as generated data.
	Raises:
		Exception (logged).
	"""
    try:
        input_dict = input_tup[0]
        tgt_uid_colnm = input_tup[1]
        obs_resdict = ifs.runsuite_batch(input_dict, tgt_uid_colnm)
        if obs_resdict == 'E':
            runsuite_batch_errstr = 'batch.py - batch_runsuite() - ifs.py runsuite_batch() returned E on UID %s' % str(
                input_dict[tgt_uid_colnm])
            logger.critical(runsuite_batch_errstr)
        else:
            return obs_resdict
    except Exception:
        logger.critical(input_tup)
        logger.exception('EXCEPTION')
        raise


# Function to save results as CSV
def savetofile(batch_merge_df, batch_exp_df):
    batch_merge_df_colnms = batch_merge_df.columns.tolist()
    batch_merge_df_colnms_sorted = sorted(batch_merge_df_colnms)
    batch_merge_df_sorted = batch_merge_df[batch_merge_df_colnms_sorted]
    batch_merge_df_sorted.to_csv(os.path.join(outputdir, cfg.batch_output_fn_fromroot), index=False)
    batch_exp_df.to_csv(os.path.join(outputdir, cfg.batch_exp_output_fp_fromroot))
    logger.info('batch.py - ETL file save successful!')


# ETL/batch processing execution loop:


if __name__ == '__main__':
    '''ETL/batch processing execution loop.

	Args:
		N/A
	Returns:
		N/A
	Raises:
		Exception (logged).
	'''
    try:
        # Create loop with X second pause between intervals:
        while True:

            # Do not execute between 11 PM and 5 AM:
            if datetime.datetime.now().hour >= 23 or datetime.datetime.now().hour < 5:
                logger.info('OUTSIDE TIME BOUNDARIES')
                time.sleep(int(cfg.batch_loop_interval))
                pass
            else:

                # Begin performance clock:
                logger.info("batch.py - ETL loop starting")
                totalstart = time.clock()

                # Retrieve batch configuration settings:
                batch_tgt_uid_nm = cfg.batch_tgt_uid_nm

                # Retrieve & parse latest OAO ANWK data:
                # TIP: Includes DOCU_CTL_ID values.
                batch_struct_df, batch_exp_df = bsdr.retrieve_oao_struct_case_ent_schema2()
                logger.info('batch.py - retrieve_oao_struct_case_ent_schema2() initial len: ')
                logger.info(str(len(batch_struct_df)))

                # If empty (due to error, etc.), restart loop:
                if len(batch_struct_df) == 0:
                    # Execute loop interval pause:
                    logger.info('batch.py - Waiting: '+cfg.batch_loop_interval)
                    time.sleep(int(cfg.batch_loop_interval))
                    continue

                # Filter batch_struct_df to only observations whose 'DOCU_CTL_ID'
                # value is not already in IFS DB (meaning it's already been
                # processed):
                if cfg.batch_filter_existing_ver is True:
                    existing_decid_list = ifsda.retrieve_column_values('dspn_doc', 'DOCU_CTL_ID')
                    batch_struct_df = batch_struct_df.loc[~batch_struct_df['DOCU_CTL_ID'].isin(existing_decid_list)]
                logger.info('batch.py - post-DOCU_CTL_ID/existing filter len:')
                logger.info(len(batch_struct_df))

                if len(batch_struct_df) == 0:
                    # Execute loop interval pause:
                    logger.info('batch.py - Waiting: ' + cfg.batch_loop_interval)
                    time.sleep(int(cfg.batch_loop_interval))
                    continue

                # Identify DOCU_CTL_ID values that do NOT have an associated text file,
                # then retrieve each such text file:
                batch_decisionfiles_dir_fn_list = [os.path.splitext(d)[0] for d in os.listdir(batch_decisionfiles_dir)
                                                   if d.endswith('.txt')]
                missing_decid_list = list(
                    set(batch_struct_df['DOCU_CTL_ID'].tolist()) - set(batch_decisionfiles_dir_fn_list))
                logger.info('batch.py - missing_decid_list len:')
                logger.info(len(missing_decid_list))

                # If missing DOCU_CTL_ID files, download/process them:
                # TIP: Downloads TIFs to cfg.batch_temp_dir
                # using each DOCU_CTL_ID as its TIF's file name.
                ocr_time = 0
                if len(missing_decid_list) != 0:
                    decid_download_ver = batch_decision_text_retrieval.retrieve_from_tif_noocr_batch(missing_decid_list)
                    temp_decid_list = [os.path.splitext(d)[0] for d in os.listdir(batch_temp_dir) if d.endswith('.tif')]
                    decid_downloaded_list = [d for d in missing_decid_list if d in temp_decid_list]
                    decid_nondownloaded_list = list(set(missing_decid_list) - set(decid_downloaded_list))

                    # Filter Non-downloaded from batch_struct_df
                    # and store in OAO database.
                    if len(decid_nondownloaded_list) > 0 and cfg.batch_store_no_doc_download:
                        decid_nondownloaded_list_index = batch_struct_df.index[batch_struct_df['DOCU_CTL_ID'].isin(decid_nondownloaded_list)]
                        # Get all the records that were not downloaded as a dataframe
                        decid_nondownloaded_df = batch_struct_df.loc[batch_struct_df.DOCU_CTL_ID.isin(decid_nondownloaded_list)]
                        # Filter out non-downloaded records.
                        batch_struct_df = batch_struct_df.drop(decid_nondownloaded_list_index)

                        # Store all non-downloaded records
                        print(decid_nondownloaded_list)
                        ifsdab.insert_failed_schema2(decid_nondownloaded_df, "No DMA document downloaded.")

                        errstr = 'batch.py - batch_decision_text_retrieval.retrieve_from_tif_noocr_batch() - unable ' \
                                 'to retrieve %s' % ', '.join(
                            decid_nondownloaded_list)
                        logger.critical(errstr)

                    if decid_download_ver == 'E':
                        errstr = 'batch.py - batch_decision_text_retrieval.retrieve_from_tif_noocr_batch() - unable ' \
                                 'to retrieve %s' % ', '.join(
                            decid_nondownloaded_list)
                        logger.critical(errstr)

                    # In the case nothing was downloaded
                    # stop processing.
                    if len(batch_struct_df) == 0:
                        # Execute loop interval pause:
                        logger.info('batch.py - Waiting: ' + cfg.batch_loop_interval)
                        time.sleep(int(cfg.batch_loop_interval))
                        continue

                    # OCR downloaded TIFs to output HTML files carrying
                    # same file names:
                    ocr_start = time.clock()
                    subprocess.call(['python', 'batch_ocr.py'])
                    ocr_stop = time.clock()
                    ocr_time = ocr_stop - ocr_start

                    # Extract text from all OCR-generated HTML files and move copy
                    # of each text file to cfg.batch_decisionfiles_dir:
                    for d in decid_downloaded_list:
                        postocr_res = batch_decision_text_retrieval.retrieve_from_tif_postocr(d)

                        if postocr_res == '0':
                            errstr = 'ifs_batch.py - ifs_batch_decision_text_retrieval.retrieve_from_tif_postocr() - unable to process %s' % d
                            logger.critical(errstr)

                            # Store failed dataframes in failed_struct_oao
                            if cfg.batch_store_tiff_txt_fail:
                                decid_downloaded_list_index = batch_struct_df.index[
                                    batch_struct_df['DOCU_CTL_ID'] == d]

                                # Get record that failed OCR conversion
                                decid_downloaded_df = batch_struct_df.loc[
                                    batch_struct_df.DOCU_CTL_ID == d]

                                # Filter out failed record.
                                batch_struct_df = batch_struct_df.drop(decid_downloaded_list_index)

                                # Store  failed record
                                ifsdab.insert_failed_schema2(decid_downloaded_df, "TIF to TXT document conversion failed.")

                # Filter out observations where a DOCU_CTL_ID does not have an
                # associated text file in cfg.batch_decisionfiles_dir:
                # TESTING:
                batch_decisionfiles_dir_fn_list = [os.path.splitext(d)[0] for d in os.listdir(batch_decisionfiles_dir)
                                                   if d.endswith('txt')]
                batch_struct_df = batch_struct_df[
                    batch_struct_df[batch_tgt_uid_nm].isin(batch_decisionfiles_dir_fn_list)]
                logger.info('batch.py - batch_struct_df len, post-decision file verification/final:')
                logger.info(len(batch_struct_df))

                if len(batch_struct_df) == 0:
                    # Execute loop interval pause:
                    logger.info('batch.py - Waiting: ' + cfg.batch_loop_interval)
                    time.sleep(int(cfg.batch_loop_interval))
                    continue

                # Convert each case entity's data into a dictionary in preparation for
                # processing in ifs.runsuite_batch():
                # TIP: Each dictionary will contain 1 DOCU_CTL_ID
                batch_struct_dict_list = []
                batch_struct_df_decid_unique = list(set(batch_struct_df['DOCU_CTL_ID'].tolist()))
                for uid in batch_struct_df_decid_unique:

                    batch_struct_subdf = batch_struct_df.loc[batch_struct_df['DOCU_CTL_ID'] == uid]

                    batch_struct_resdict = {'DOCU_CTL_ID': uid, 'CLMT_DOB': 'U', 'FNL_DSPN_DT': 'U', 'DLI': 'U',
                                            'CLMT_SSN': 'U', 'CLMT_ST': 'U',
                                            'CLAIMDISP_STRUCT': cc.convert_struct_claimdisp(batch_struct_subdf),
                                            'EXP': [], 'HT_INCH': 'U', 'WT_LB': 'U', 'SEX': 'U'}

                    batch_struct_resdict['CLAIMDISP_STRUCT'] = cc.parse_disp_type_struct(
                        batch_struct_resdict['CLAIMDISP_STRUCT'])

                    # Following dict values only assigned if 1 and only 1 value (as expected):
                    batch_struct_subdf_dob = list(set(batch_struct_subdf['CLMT_DOB'].tolist()))
                    if len(batch_struct_subdf_dob) == 1:
                        batch_struct_resdict['CLMT_DOB'] = dh.parse_datetime_to_ifs_date(batch_struct_subdf_dob[0])

                    batch_struct_subdf_dli = list(set(batch_struct_subdf['DLI'].tolist()))
                    if len(batch_struct_subdf_dli) == 1:
                        batch_struct_resdict['DLI'] = dh.parse_datetime_to_ifs_date(batch_struct_subdf_dli[0])

                    batch_struct_subdf_dspndt = list(set(batch_struct_subdf['FNL_DSPN_DT'].tolist()))
                    if len(batch_struct_subdf_dspndt) == 1:
                        batch_struct_resdict['FNL_DSPN_DT'] = dh.parse_datetime_to_ifs_date(
                            batch_struct_subdf_dspndt[0])

                    batch_struct_subdf_clmtssn = list(set(batch_struct_subdf['CLMT_SSN'].tolist()))
                    if len(batch_struct_subdf_clmtssn) == 1:
                        batch_struct_resdict['CLMT_SSN'] = str(batch_struct_subdf_clmtssn[0])

                    batch_struct_subdf_clmt_st = list(set(batch_struct_subdf['CLMT_ST'].tolist()))
                    if len(batch_struct_subdf_clmt_st) == 1:
                        batch_struct_resdict['CLMT_ST'] = batch_struct_subdf_clmt_st[0]

                    batch_struct_subdf_ht_inch = list(set(batch_struct_subdf['HT_INCH'].tolist()))
                    if len(batch_struct_subdf_ht_inch) == 1:
                        batch_struct_resdict['HT_INCH'] = batch_struct_subdf_ht_inch[0]

                    batch_struct_subdf_wt_lb = list(set(batch_struct_subdf['WT_LB'].tolist()))
                    if len(batch_struct_subdf_wt_lb) == 1:
                        batch_struct_resdict['WT_LB'] = batch_struct_subdf_wt_lb[0]

                    batch_struct_subdf_sex = list(set(batch_struct_subdf['SEX'].tolist()))
                    if len(batch_struct_subdf_sex) == 1:
                        batch_struct_resdict['SEX'] = batch_struct_subdf_sex[0]

                    # Write subset of expert data to dictionary:
                    subdf_hofc_list = batch_struct_subdf['HOFC_WRK_UNIT_UID'].tolist()
                    batch_exp_subdf = batch_exp_df.loc[batch_exp_df['HOFC_WRK_UNIT_UID'].isin(subdf_hofc_list)]
                    batch_exp_subdf = batch_exp_subdf.loc[batch_exp_subdf['EXPERT_TYP'] == 'M']
                    batch_exp_subdf.drop_duplicates(subset='EXPERT_UID', keep='first', inplace=True)
                    batch_struct_resdict['EXP'] = batch_exp_subdf.to_dict('records')

                    batch_struct_dict_list.append(batch_struct_resdict)

                # In prep for batch_process_obs(), transform each case entity dict
                # into a tuple where tup[0] = dict and tup[1] = cfg.batch_tgt_uid_nm:
                batch_struct_tup_list = [(ud, batch_tgt_uid_nm) for ud in batch_struct_dict_list]

                # Execute ifs.runsuite_batch() processing via batch_process_obs()
                # function using either single or multiprocessing:
                ifs_start = time.clock()
                if cfg.batch_mp_ver is False:
                    resdict_list = []
                    for i, tup in enumerate(batch_struct_tup_list):
                        logger.info('batch.py - batch_struct_tup_list tup: %s' % str(tup))
                        logger.info('batch.py - batch_struct_tup_list ct: ' + str(i))
                        resdict = batch_process_obs(tup)
                        resdict_list.append(resdict)
                else:
                    # logger = multiprocessing.log_to_stderr()
                    # logger.setLevel(multiprocessing.SUBDEBUG)
                    batch_mp_process_ct = cfg.batch_mp_process_ct
                    if batch_mp_process_ct == 'U':
                        cpu_count = multiprocessing.cpu_count()
                        batch_mp_process_ct = int(round(cpu_count * float(0.5)))
                    pool = multiprocessing.Pool(processes=batch_mp_process_ct)
                    results = pool.map_async(batch_process_obs, batch_struct_tup_list)
                    resdict_list = results.get()
                    logger.info('resdict_list len:')
                    logger.info(len(resdict_list))
                    pool.close()
                    pool.join()

                # Stop IFS performance timer:
                ifs_stop = time.clock()

                # Merge results back into batch_struct_df by joining on
                # DOCU_CTL_ID and hofc_wrk_unit_AC:
                # TESTING:
                res_df = pandas.DataFrame(resdict_list)
                batch_merge_df = pandas.merge(batch_struct_df, res_df, how='inner', on='DOCU_CTL_ID')
                logger.info('batch.py - batch_merge_df len:')
                logger.info(len(batch_merge_df))

                # Save results to file with columns alphabetically sorted:
                if cfg.batch_savetofile_ver is True:
                    savetofile(batch_merge_df, batch_exp_df)

                # Save results to IFS database tables:
                if cfg.batch_savetodatabase_ver is True:
                    savetodatabase_ver = ifsdab.insert_schema2(batch_merge_df, batch_exp_df, 'DOCU_CTL_ID')
                    logger.critical('savetodatabase_ver')
                    logger.critical(savetodatabase_ver)
                    # TIP: If database save fails and data hasn't already been
                    # saved to file, save to file as a backup measure:
                    if savetodatabase_ver == 'E' and cfg.batch_savetofile_ver is not True:
                        logger.info(
                            'batch.py - ETL database save unsuccessful - rerouting results to savetofile() as a '
                            'backup measure!')
                        savetofile(batch_merge_df, batch_exp_df)
                    else:
                        logger.info('batch.py - ETL database save successful!')

                # Empty batch_temp_dir:
                # TODO:
                # Per http://stackoverflow.com/questions/6946040/deleting-large-numbers-of-files-in-python
                # fastest method may be to move the temp directory to a new name, create a new temp folder,
                # then have a separate process delete the moved directory at a specified interval, say once
                # at midnight or once per weekend.

                # Log performance data:
                total_ocr_str = "batch.py - total OCR time for %s observations: %s" % (
                    str(len(batch_struct_tup_list)), str(ocr_time))
                logger.info(total_ocr_str)
                ifs_time = ifs_stop - ifs_start
                ifs_time_str = "batch.py - ifs time for %s observations: %s" % (
                    str(len(batch_struct_tup_list)), str(ifs_time))
                logger.info(ifs_time_str)
                totalstop = time.clock()
                total_time = totalstop - totalstart
                total_time_str = "batch.py - total time for %s observations: %s" % (
                    str(len(batch_struct_tup_list)), str(total_time))
                logger.info(total_time_str)

                # Execute loop interval pause:
                time.sleep(int(cfg.batch_loop_interval))

    except Exception as ex:
        logger.exception('EXCEPTION: ' + str(ex))
        raise
