
"""Setup relevant unit test path configurations."""

import os
import sys
class TestConfiguration(object):
    """Test Configuration class"""
    def __init__(self):
        """Configuration constructor"""
        self.data = None
        self.src = None
        self.test_dir = None
        self.insightdir = None
        self.unittest_dir = None

    def setup(self):
        """Setup test directories"""
        self.unittest_dir = os.path.dirname(os.path.realpath(__file__))
        if os.path.exists(self.unittest_dir):
            self.test_dir = os.path.abspath(os.path.join(self.unittest_dir, os.pardir))
            self.insightdir = os.path.abspath(os.path.join(self.test_dir, os.pardir))

    @property
    def data_dir(self):
        """The data directory property - getter"""
        return self.data
    @data_dir.setter
    def data_dir(self, data_directory):
        """The data directory property - setter"""
        self.data = os.path.join(self.src, data_directory)

    @property
    def src_dir(self):
        """The source directory property - getter"""
        return self.src
    @src_dir.setter
    def src_dir(self, source_directory):
        """The source directory property - setter"""
        self.src = os.path.join(self.insightdir, source_directory)
        sys.path.insert(0, self.src)

CONFIG = TestConfiguration()
CONFIG.setup()
CONFIG.src_dir = "src"
CONFIG.data_dir = "data"
