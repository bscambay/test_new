# ==============================================================================
# TEST Classifier
# ==============================================================================

import pytest

from its_sklearn_classifier import classify

@pytest.mark.parametrize("classification_str, expected_result", [
    ('The claimant is unable to sustain work for an eight hour day.', 'y'),
    ('The claimant can occasionally stoop, crouch, and crawl.', 'n'),
])
def test_classification(classification_str, expected_result):
    classification_result = classify(classification_str)
    classification = classification_result[0][1]
    assert isinstance(classification_result, list)
    assert classification == expected_result
