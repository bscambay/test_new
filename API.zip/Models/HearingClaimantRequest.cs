﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INSIGHT_Request.Models
{
    public class HearingClaimantRequest
    {
        public string cossn { get; set; } = "";
        public string decisionText { get; set; } = "";

        public bool displayJson { get; set; } = false;
        public string pin { get; set; } = "";
        


    }
}