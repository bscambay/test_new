﻿using INSIGHT_Request.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace INSIGHT_Request.Util
{
    partial class apiDocument
    {
        public string title { get; set; } = "";
        public int length { get; set; } = 0;
        public ApiDescriptor api { get; set; } = new ApiDescriptor();
        public apiDocument(ApiDescriptor _api = null)
        {
            this.api = _api;
            this.length = _api.Apis.Count;
        }
    }
}
