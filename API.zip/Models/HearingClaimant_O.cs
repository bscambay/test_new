﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class HearingClaimant_O : HearingClaimant
    {
        
        public override string CLMT_SSN
        {
            get { return base.CLMT_SSN.Trim(); }
        }
        public override string CLMT_NM25
        {
            get { return base.CLMT_NM25.Trim(); }
        }
        public override string WG_ERNR_SSN
        {
            get { return base.WG_ERNR_SSN.Trim(); }
        }
        public override string OHA_DAA_CD
        {
            get { return base.OHA_DAA_CD.Trim(); }
        }
        public override string HEDULVL_CD
        {
            get { return base.HEDULVL_CD.Trim(); }
        } 
    }
}
