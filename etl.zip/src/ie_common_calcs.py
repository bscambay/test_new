# INSIGHT HEARING DECISION EXTRACTION MODULE (INSIGHT Extract)
# COMMON CALCULATIONS MODULE
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 11.28.2016
#
# SUMMARY: 
# Contains functions that perform miscellaneous/common calculation tasks
# required by INSIGHT Extract (ie.py).
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os
import os.path
import shutil
import time
import sys
import io
import re
import ast
import datetime
import logging
import time
import pandas
import Levenshtein as ls
import ie_data_loader as iedl
import nlp_helper as nlp
import regex_strings as rs

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
inputdir = os.path.join(insightdir, "Input/Input")
processingdir = os.path.join(insightdir, "Input/Processing")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
# TEMPORARY: Set decisionfiledir value.
decisionfiledir = os.path.join(insightdir, 'test/functional/IFS_BATCH_TEST/decisionfiles')

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Circuit parser:
# TODO: Create backup that utilizes structured claimant
# address data in instances where INSIGHT could not locate
# the claimant's address.
def circuitparser(clnmadd_input):
	'''Parse federal circuit applicable to the state
	cited in an INSIGHT Extract 'clnmadd' value, which
	originates from hearing decision text.
	
	Args:
		clnmadd_input {str}: A string containing an INSIGHT
			observation's 'clnmadd' data point value.
	Returns:
		A string naming the circuit applicable to the state
			cited in 'clnmadd_input'.
		'U': Circuit unknown.
		'E': Error occurred.
	'''
	try:
		if clnmadd_input in ['U', 'P', 'E', '']:
			return 'U'
		else:
			# Normalize clnmadd input value:
			# TIP: Multiple values not permitted in IE for 'clnmadd';
			# no need to parse for that possibility.
			clnmadd = clnmadd_input.strip()
			clnmadd = ' '.join(clnmadd.split())
			clnmadd = clnmadd.upper()
			# Retrieve substring containing state information, ensuring reliability 
			# by only proceeding if exactly 1 result:
			state_substring_findall = re.findall(r" ([A-Z\.]+ ?)([A-Z\.]+ ?)?([A-Z\.]+ ?)?([A-Z\.]+ ?)?([\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])(\-[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])?", clnmadd)
			if state_substring_findall:
				state_substring_res = ''.join(state_substring_findall[-1])
				state_search_regex_list = [rs.state_search1_regex, rs.state_search2_regex, rs.state_search3_regex]
				state_res = 'U'
				for regex in state_search_regex_list:
					state_search = re.search(regex, state_substring_res, re.I)
					if bool(state_search):
						state_res = state_search.group(1)
						state_res = state_res.strip()
						break
				if state_res == 'U':
					state_ocr_search = re.search(r"M0|C0", state_substring_res)
					if bool(state_ocr_search):
						state_ocr_search_res = state_ocr_search.group()
						state_res = state_ocr_search_res.replace('0', 'O').strip()
				if state_res == 'U':
					return 'U'
				else:
					# Attempt to use state_res string to identify circuit:
					circuit_res = 'U'
					for cn in ['state_nm', 'state_abbrev_gpo', 'state_abbrev_standard']:
						res = iedl.circuitdf.loc[iedl.circuitdf[cn] == state_res]
						if len(res) == 1:
							circuit_res = res['circuit'].tolist()[0]
							break
					if circuit_res == 'U':
						return 'U'
					else:
						return circuit_res
	except Exception:
		logger.exception("EXCEPTION")
		return 'E'


# Circuit parser (structured data sources):
def circuitparser_struct(clmt_st_input):
	'''Parse federal circuit applicable to the state
	cited in an INSIGHT Extract 'ARCHWKUT.CLMT_ST' value.
	
	Args:
		clmt_st_input {str}: A string containing an INSIGHT
			observation's 'ARCHWKUT.CLMT_ST' data point value.
	Returns:
		- A string naming the circuit applicable to the state
			cited in 'clnmadd_input'.
		- 'U': Circuit unknown.
		- 'E': Error occurred.
	'''
	try:
		if not clmt_st_input or clmt_st_input in ['']:
			return 'U'
		else:
			try:
				return iedl.circuitdf.loc[iedl.circuitdf['state_abbrev_standard'] == clmt_st_input]['circuit'].tolist()[0]
			except IndexError:
				return 'E'
	except Exception:
		logger.exception("EXCEPTION")
		return 'E'
		
	
# (DEVELOPMENT -) Extract Targeted Sentence Using Snippet:
# TODO: To increase accuracy, limit the matching sentence
# to the snippet's text and thereafter.
def extract_tgt_sent(sentlist, snippet):
	'''Attempts to extract a single targeted sentence result
	from an NLP-tokenized list of sentences.  If 0 or >1 found, 
	returns 'U', otherwise returns sentence result.
	
	Arguments:
		sentlist {list}: A list of sentence strings.
		snippet {str}: A sentence snippet string.
	Returns:
		'U' {str}: Either target sentence not found or too
		many results found.
		[target sentence] {str}: The targeted sentence.
	Raises:
		N/A (Exceptions will be logged)'''
	try:
		# First, calculate number of sentences in snippet (sometimes more than
		# one, e.g. Step 4 finding headings), then concatenate sentlist to corresponding length
		# to compensate for it.
		# TIP: If more than 3 sentences in snippet, for now outputting 'U'.
		sentlist_final = []
		snippet_sentct = len(nlp.sentence_splitter(snippet))
		if snippet_sentct == 1:
			sentlist_final = sentlist
		elif snippet_sentct == 2:
			for i,s in enumerate(sentlist):
				try:
					s_rev = s + ' '  + sentlist[i+1]
					sentlist_final.append(s_rev)
				except IndexError:
					break
		elif snippet_sentct == 3:
			for i,s in enumerate(sentlist):
				try:
					s_rev = s + ' '  + sentlist[i+1] + ' ' + sentlist[i+2]
					sentlist_final.append(s_rev)
				except IndexError:
					break
		else:
			return 'U'

		# Sent list should already be slightly normalized (single spacing, etc.),
		# so do same for 'snippet' before searching for it:
		
		# First attempt a very fast raw membership test.  If found, great, output.
		reslist1 = [s for s in sentlist_final if snippet in s]
		if len(reslist1) == 1:
			return reslist1[0]
		
		# Next, try REGEX membership checks:
		# TIP: If more than one result, because currently no
		# further parsing to determine which is 'more correct',
		# return 'U'.
		snippetre = snippet.replace("'", "")
		snippetre = re.escape(snippetre)
		snippetre = snippetre.replace(" ", " ?")
		
		reslist2 = []
		for s in sentlist:
			sre = s.replace("'", "")
			snippetsearch = re.search(snippetre, sre, re.I|re.M|re.S)
			if bool(snippetsearch):
				reslist2.append(s)
		if len(reslist2) != 1:
			return 'U'
		else:
			return reslist2[0]
	except Exception:
		logger.exception("EXCEPTION")
		raise
		

# Extract target text index locations from
# a larger source text
def extract_tgt_sent_ind(tgt_txt_input, src_txt_input):
	'''Attempts to extract target text index locations from
	a larger source text.
	
	Arguments:
		tgt_txt_input {str}: A target string whose
			index location we would like to retrieve.
		src_txt_input {str}: The larger source text
			we will parse to find the index location
			of the target text.
	Returns:
		restup {tuple}: A tuple where tup[0] = the
			target text's starting index location
			as an integer and tup[1] equals the
			target text's ending index location as
			an integer. If cannot return index
			locations, will output empty tuple.
	Raises:
		N/A (exceptions logged logged)'''
	try:
		
		src_txt_input = src_txt_input.replace("'", "")
		tgt_txt_input_re = tgt_txt_input.replace("'", "")
		tgt_txt_input_re = re.escape(tgt_txt_input_re)
		tgt_txt_input_re = tgt_txt_input_re.replace(" ", "\s{0,6}")
		
		restuplist = []
		tgt_txt_finditer = re.finditer(tgt_txt_input_re, src_txt_input, re.I|re.M|re.S)
		for res in tgt_txt_finditer:
			restuplist.append((res.start(), res.end()))
		
		if len(restuplist) == 1:
			return restuplist[0]
		else:
			return ()
	except Exception:
		logger.exception("EXCEPTION")
		return ()


# Meets/equals text parser:
def parse_mteq(input_str):
	"""Parse whether FIT language indicates
	a claimant 'meets' or 'equals' listings.
	
	Args:
		input_str {str}: String containing
			FIT language.
	Returns:
		A single character string whose value
		corresponds to an INSIGHT Extract
		dictionary value for 's3mteqver'.
	Raises:
		N/A.
	"""
	try:
		input_str = ' '.join(input_str.split())
		s3meetssearch1 = re.search(r"\b(meets|meet|met)\b", input_str, re.I)
		s3equalssearch1 = re.search(r"\b(medically\s*equals|medically\s*equal|equals|equal)\b", input_str, re.I)
		if bool(s3meetssearch1) is True and bool(s3equalssearch1) is False:
			return '2'
		elif bool(s3meetssearch1) is False and bool(s3equalssearch1) is True:
			return '3'
		elif bool(s3meetssearch1) is True and bool(s3equalssearch1) is True:
			negationsearch1 = re.search(r"(does ?not|doesn\'t|did ?not|not) ?(meet|met)", input_str, re.I)
			negationsearch2 = re.search(r"(does ?not|doesn\'t|did ?not|not) ?(medically ?equals|medically ?equal|equals|equal)", input_str, re.I)
			if bool(negationsearch1) is False and bool(negationsearch2) is True:
				return '2'
			elif bool(negationsearch1) is True and bool(negationsearch2) is False:
				return '3'
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'


# Listing number text parser:
def parse_lnum(input_str):
	"""Listing number text parser.
	
	Extracts listing numbers from targeted input
	text.
	
	Args:
		input_str {str}: Text containing listing
			numbers.
	Returns:
		lnum_reslist {list}: A list of listing number
			strings.
	Raises:
		N.A.
	"""
	try:
		lnum_reslist = []
		input_str = re.sub("\(20 C\.? ?F\.? ?R\.? ?.*|20 C\.? ?F\.? ?R\.? ?.*|404\.\d+|416\.\d+|Part ?404|Part ?416", " ", input_str, flags=re.I)
		input_str = re.sub(r"\s+of\s+20\s+(C\.? ?F\.? ?R\.? ?).*", "", input_str, flags=re.I)
		input_str = ' '.join(input_str.split())
		lnumfindall1 = re.findall(r"10\d\.\d\d(?!\d)|11\d\.\d\d(?!\d)|10\.\d\d(?!\d)|11\.\d\d(?!\d)|12\.\d\d(?!\d)|13\.\d\d(?!\d)|14\.\d\d(?!\d)|\d\.\d\d(?!\d)", input_str, re.I)
		if len(lnumfindall1) == 1:
			res = lnumfindall1[0]
			res = res.lower()
			res = res.strip()
			lnum_reslist.append(res)
		elif len(lnumfindall1) > 1:
			for item in lnumfindall1:
				item = item.lower()
				item = item.strip()
				lnum_reslist.append(item)
		return lnum_reslist
	except Exception:
		logger.exception('EXCEPTION')
		return []
		
		
# FIT FE Rating Parser
def s3fe_rating_parser(res_end_input_int, decision_input):
	"""Functional equivalence rating parser.
	Extracts F.E. ratings from targeted input
	text.
	
	Args:
		res_end_input_int {int}: An integer representing
			the beginning of decisional text after the
			functional equivalence finding heading at issue.
	Returns:
		ferat_res_dict {dict}: A dict where each K = an FE
			rating category name and each V = its rating value.
	Raises:
		N.A.
	"""
	try:
		rating_parser_decision = decision_input[res_end_input_int:]
		ferat_res_dict = {'s3feqacquiring':'U', 's3feqattending':'U', 's3feqinteracting':'U', 's3feqmoving':'U', 's3feqcaring':'U', 's3feqcaring':'U', 's3feqhealth':'U'}
		feratingscomp1 = re.compile(r"(\s{0,6}no\s{0,6})|(\s{0,6}less\s{0,6}than\s{0,6}marked\s{0,6})|(\s{0,6}marked\s{0,6})|(\s{0,6}extreme\s{0,6})")
		feratingsdict = {"NO":"1", "LESS THAN MARKED":"2", "MARKED":"3", "EXTREME":"4"}
		feratingsdictkeys = feratingsdict.keys()
		s3acquiringusinginfocomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}acquiring\s{0,6}and\s{0,6}using\s{0,6}information", re.S|re.M|re.I)
		s3acquiringusinginfosearchpt1 = re.search(s3acquiringusinginfocomppt1, rating_parser_decision)
		if bool(s3acquiringusinginfosearchpt1):
			s3acquiringusinginforesultpt1 = s3acquiringusinginfosearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3acquiringusinginforesultpt1)
			if bool(ratingsearch):
				s3acquiringusinginfores = ratingsearch.group()
				s3acquiringusinginfores = s3acquiringusinginfores.strip()
				s3acquiringusinginfores = s3acquiringusinginfores.upper()
				s3acquiringusinginfores = re.sub(r" {2,10}", " ", s3acquiringusinginfores)
				if s3acquiringusinginfores in feratingsdictkeys:
					ferating = feratingsdict[s3acquiringusinginfores]
					ferat_res_dict['s3feqacquiring'] = ferating			
		
		s3attendingcompletingtaskscomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}attending\s{0,6}and\s{0,6}completing\s{0,6}tasks\s{0,6}(\.)", re.S|re.M|re.I)
		s3attendingcompletingtaskssearchpt1 = re.search(s3attendingcompletingtaskscomppt1, rating_parser_decision)
		if bool(s3attendingcompletingtaskssearchpt1):
			s3attendingcompletingtasksresultpt1 = s3attendingcompletingtaskssearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3attendingcompletingtasksresultpt1)
			if bool(ratingsearch):
				s3attendingcompletingtasksres = ratingsearch.group()
				s3attendingcompletingtasksres = s3attendingcompletingtasksres.strip()
				s3attendingcompletingtasksres = s3attendingcompletingtasksres.upper()
				s3attendingcompletingtasksres = re.sub(r" {2,10}", " ", s3attendingcompletingtasksres)
				if s3attendingcompletingtasksres in feratingsdictkeys:
					ferating = feratingsdict[s3attendingcompletingtasksres]
					ferat_res_dict['s3feqattending'] = ferating
		
		s3interactingrelatingcomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}interacting\s{0,6}and\s{0,6}relating\s{0,6}with\s{0,6}others\s{0,6}(\.)", re.S|re.M|re.I)
		s3interactingrelatingsearchpt1 = re.search(s3interactingrelatingcomppt1, rating_parser_decision)
		if bool(s3interactingrelatingsearchpt1):
			s3interactingrelatingresultpt1 = s3interactingrelatingsearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3interactingrelatingresultpt1)
			if bool(ratingsearch):
				 s3interactingrelatingres = ratingsearch.group()
				 s3interactingrelatingres =	 s3interactingrelatingres.strip()
				 s3interactingrelatingres =	 s3interactingrelatingres.upper()
				 s3interactingrelatingres = re.sub(r" {2,10}", " ", s3interactingrelatingres)
				 if s3interactingrelatingres in feratingsdictkeys:
					 ferating = feratingsdict[s3interactingrelatingres]
					 ferat_res_dict['s3feqinteracting'] = ferating
		
		s3movingmanipulatingcomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}moving\s{0,6}about\s{0,6}and\s{0,6}manipulating\s{0,6}objects\s{0,6}(\.)", re.S|re.M|re.I)
		s3movingmanipulatingsearchpt1 = re.search(s3movingmanipulatingcomppt1, rating_parser_decision)
		if bool(s3movingmanipulatingsearchpt1):
			s3movingmanipulatingresultpt1 = s3movingmanipulatingsearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3movingmanipulatingresultpt1)
			if bool(ratingsearch):
				s3movingmanipulatingres = ratingsearch.group()
				s3movingmanipulatingres = s3movingmanipulatingres.strip()
				s3movingmanipulatingres = s3movingmanipulatingres.upper()
				s3movingmanipulatingres = re.sub(r" {2,10}", " ", s3movingmanipulatingres)
				if s3movingmanipulatingres in feratingsdictkeys:
					ferating = feratingsdict[s3movingmanipulatingres]
					ferat_res_dict['s3feqmoving'] = ferating
		
		s3caringforyourselfcomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}the\s{0,6}ability\s{0,6}to\s{0,6}care\s{0,6}for\s{0,6}(himself|herself)", re.S|re.M|re.I)
		s3caringforyourselfsearchpt1 = re.search(s3caringforyourselfcomppt1, rating_parser_decision)
		if bool(s3caringforyourselfsearchpt1):
			s3caringforyourselfresultpt1 = s3caringforyourselfsearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3caringforyourselfresultpt1)
			if bool(ratingsearch):
				s3caringforyourselfres = ratingsearch.group()
				s3caringforyourselfres = s3caringforyourselfres.strip()
				s3caringforyourselfres = s3caringforyourselfres.upper()
				s3caringforyourselfres = re.sub(r" {2,10}", " ", s3caringforyourselfres)
				if s3caringforyourselfres in feratingsdictkeys:
					ferating = feratingsdict[s3caringforyourselfres]
					ferat_res_dict['s3feqcaring'] = ferating
		
		s3healthphysicalwellbeingcomppt1 = re.compile(r"^The\s{0,6}claimant\s{0,6}has.{1,25}limitation\s{0,6}in\s{0,6}health\s{0,6}and\s{0,6}physical", re.S|re.M|re.I)
		s3healthphysicalwellbeingsearchpt1 = re.search(s3healthphysicalwellbeingcomppt1, rating_parser_decision)
		if bool(s3healthphysicalwellbeingsearchpt1):
			s3healthphysicalwellbeingresultpt1 = s3healthphysicalwellbeingsearchpt1.group()
			ratingsearch = re.search(feratingscomp1, s3healthphysicalwellbeingresultpt1)
			if bool(ratingsearch):
				 s3healthphysicalwellbeingres = ratingsearch.group()
				 s3healthphysicalwellbeingres =	 s3healthphysicalwellbeingres.strip()
				 s3healthphysicalwellbeingres =	 s3healthphysicalwellbeingres.upper()
				 s3healthphysicalwellbeingres = re.sub(r" {2,10}", " ", s3healthphysicalwellbeingres)
				 if s3healthphysicalwellbeingres in feratingsdictkeys:
					 ferating = feratingsdict[s3healthphysicalwellbeingres]
					 ferat_res_dict['s3feqhealth'] = ferating
					 
		return ferat_res_dict
	except Exception:
		logger.exception('EXCEPTION')
		return {'s3feqacquiring':'E', 's3feqattending':'E', 's3feqinteracting':'E', 's3feqmoving':'E', 's3feqcaring':'E', 's3feqhealth':'E'}		
		
		
# RFC 'Parsed' Exertional Level Findings/References Parsing Function:
# TIP: This value corresponds to 'rfcexlvl_parsed' in the INSIGHT data 
# dictionary.
def rfcexlvlparser(input_dict):
	'''Identifies every 'clear' RFC exertional level 
	finding/reference present in an RFC and returns all
	unique exertional level values identified as a list.
	
	The value of each returned list element can be found
	in the INSIGHT data dictionary's value keys for
	'rfcfitexlvl'.
	
	Args:
		input_dict {dict}: A dictionary containing
			an INSIGHT 'rfc' child observation's data:
	Returns:
		A string either consisting of semicolon-divided
			exertional values, or 'U', or 'E'.
	Raises:
		N/A (returns empty list if exception occurs).'''
	try:
	
		rfcexlvl_reslist = []
		
		# Add each FIT exertional level reference to reslist:
		rfcfitexlvl = input_dict['rfcfitexlvl']
		if rfcfitexlvl not in ['U', 'P', '']:
			rfcfitexlvl_list = rfcfitexlvl.split('; ')
			for exlvl in rfcfitexlvl_list:
				rfcexlvl_reslist.append(exlvl)
		
		# Add other exertional levels to reslist based individual exertional
		# 'key value' heuristics:
		# TIP: Logic applied in this section is described
		# in 'OUTLINE OF MVR VS RFC EXERTIONAL LEVEL CHECK.doc'.
		# TODO: Consider allowing 'approximate matching' in future
		# so that if, for example, carry amount were 25, there is
		# still a match triggering addition of light exertion.
		rfcstandlol = input_dict['rfcstandlol']
		rfcwalklol = input_dict['rfcwalklol']
		rfcliftlol = input_dict['rfcliftlol']
		rfccarrylol = input_dict['rfccarrylol']
		
		# If stand or walk level <= 2, safe to say sedentary exertion is at issue:
		# OPENQ: Would you output a LIST here?  Why wouldn't you output a semicolon-divided
		# string of values?
		if rfcstandlol not in ['U', 'P', 'E', '']  and rfcstandlol.isdigit():
			if int(rfcstandlol) <= 2:
				rfcexlvl_reslist.append('S')
		if rfcwalklol not in ['U', 'P', 'E', '']  and rfcwalklol.isdigit():
			if int(rfcwalklol) <= 2:
				rfcexlvl_reslist.append('S')

		# Pre-process lift/carry values to account for possible
		# false inclusion of 'FREQ' value:
		# TODO: I believe you've deprecated FREQ values being output, so
		# update this portion of the code:
		if '[' in rfcliftlol:
			rfcliftlol = ast.literal_eval(rfcliftlol)
			rfcliftlol = [val for val in rfcliftlol if 'FREQ' not in val]
			if len(rfcliftlol) == 1:
				rfcliftlol = rfcliftlol[0]
			else:
				rfcliftlol = 'U'
		if '[' in rfccarrylol:
			rfccarrylol = ast.literal_eval(rfccarrylol)
			rfccarrylol = [val for val in rfccarrylol if 'FREQ' not in val]
			if len(rfccarrylol) == 1:
				rfccarrylol = rfccarrylol[0]
			else:
				rfccarrylol = 'U'
		
		# If lift or carry = 10, safe to say sedentary exertion is at issue:
		if isinstance(rfcliftlol, str):
			if rfcliftlol not in ['U', 'P', 'E', ''] and '[' not in rfcliftlol:
				if int(rfcliftlol) == 10:
					rfcexlvl_reslist.append('S')
		if isinstance(rfccarrylol, str):
			if rfccarrylol not in ['U', 'P', 'E', '']  and '[' not in rfccarrylol:
				if int(rfccarrylol) == 10:
					rfcexlvl_reslist.append('S')

		# If lift or carry = 20, safe to say light exertion is at issue:
		if isinstance(rfcliftlol, str):
			if rfcliftlol not in ['U', 'P', 'E', ''] and '[' not in rfcliftlol:
				if int(rfcliftlol) == 20:
					rfcexlvl_reslist.append('L')
		if isinstance(rfccarrylol, str):
			if rfccarrylol not in ['U', 'P', 'E', ''] and '[' not in rfccarrylol:
				if int(rfccarrylol) == 20:
					rfcexlvl_reslist.append('L')
					
		# If lift or carry = 50, safe to say medium exertion is at issue:
		if isinstance(rfcliftlol, str):
			if rfcliftlol not in ['U', 'P', 'E', ''] and '[' not in rfcliftlol:
				if int(rfcliftlol) == 50:
					rfcexlvl_reslist.append('M')
		if isinstance(rfccarrylol, str):
			if rfccarrylol not in ['U', 'P', 'E', ''] and '[' not in rfccarrylol:
				if int(rfccarrylol) == 50:
					rfcexlvl_reslist.append('M')
				
		# If lift or carry = 100, safe to say medium exertion is at issue:
		if isinstance(rfcliftlol, str):
			if rfcliftlol not in ['U', 'P', 'E', ''] and '[' not in rfcliftlol:
				if int(rfcliftlol) == 100:
					rfcexlvl_reslist.append('H')
		if isinstance(rfccarrylol, str):
			if rfccarrylol not in ['U', 'P', 'E', ''] and '[' not in rfccarrylol:
				if int(rfccarrylol) == 100:
					rfcexlvl_reslist.append('H')
		
		# Unique-ify and result:
		rfcexlvl_reslist = list(set(rfcexlvl_reslist))
		if rfcexlvl_reslist:
			rfcexlvl_reslist_str = "; ".join(rfcexlvl_reslist)
			return str(rfcexlvl_reslist_str)
		else:
			return 'U'

	except KeyError:
		logger.exception('EXCEPTION')
		return 'E'
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'


# (DEVELOPMENT) Calculate the number of jobs present in a 's4jobscanperf' string:
def calc_jobct(s4jobscanperf_str):
	'''Calculate the number of individual job entities that
	appear to be cited in an INSIGHT 's4jobscanperf' string.
	
	Args:
		s4jobscanperf_str {string}: A string containing
			an INSIGHT 's4jobscanperf' value.
	Returns:
		A string value indicating the number of job
		entities (e.g. '4');
		'U': Number unknown
		'E': Error occurred.
	Raises:
		N/A
	'''	
	try:
		# Define default value:
		s4jobscanperf_num = 'U'
			
		# Set custom stopword list:
		customstopwordlist = ["me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", "they", "them", "their", "theirs", "themselves", "what", "which", "who", "whom", "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "having", "does", "did", "doing", "the", "if", "because", "as", "until", "while", "of", "for", "with", "about", "against", "between", "into", "through", "during", "before", "after", "above", "below", "to", "from", "up", "down", "in", "out", "on", "off", "over", "under", "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very", "can", "will", "just", "don", "should", "now", "a", "an"]
		
		# Normalize text:
		s4jobscanperf = s4jobscanperf_str.strip().lower()
		s4jobscanperf = " ".join(s4jobscanperf.split())
		
		# Remove common job-related language that might otherwise muddy this result:
		s4jobscanperf = re.sub(r"\bsvp.?(of)?.?[0-9]|\bspecific ?vocational ?preparation.?(of)?.?[0-9]", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"(dictionag|dict\.) ?of ?occupational ?titles|\bd\.?o\.?t\.|\bdot\b", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"#", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"^as ?a ?", "", s4jobscanperf)
		s4jobscanperf = re.sub(r" ?[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}\.\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}-\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo] ?", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"this work does not require.*", "", s4jobscanperf)
						
		# Remove all trailing splitting items that could otherwise cause the program to believe there's
		# a job item after it:
		s4jobscanperf_dict = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"\:$|\.$|;$|,$|\band$|\bas ?well ?as$|\bin ?addition ?to$|\bor$|\bbut ?also$", "", s4jobscanperf_dict["s4jobscanperf"], flags=re.I|re.S)
			s4jobscanperf_dict["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict["s4jobscanperf"]
		
		# Remove all LEADING splitting items for same reasons:
		s4jobscanperf_dict2 = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"^:|^\.|^;\b|^,\b|^and\b|^as ?well ?as\b|^in ?addition ?to\b|^or\b|^but ?also\b", "", s4jobscanperf_dict2["s4jobscanperf"], flags=re.I|re.S)
			s4jobscanperf_dict2["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict2["s4jobscanperf"]
		
		
		# Normalize common conjunctions to ' and ':
		s4jobscanperf = re.sub(r"\bas ?well ?as\b|\band ?also\b|\bin ?addition ?to\b|\bbut ?also\b|\bor\b", " and ", s4jobscanperf)
		
		# Remove stopwords:
		for item in customstopwordlist:
			item = "\\b" + item + "\\b"
			s4jobscanperf = re.sub(item, "", s4jobscanperf)
		
		# The above may remove mid-text splitting item-enclosed text, resulting in langauge like "; ;" - clean these:
		s4jobscanperf_dict1 = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"(\:|\.|;|,) +(\:|\.|;|,)", r"\1", s4jobscanperf_dict1["s4jobscanperf"])
			s4jobscanperf_dict1["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict1["s4jobscanperf"]
		
		# Now actually split and count the number of resulting entities using the splitting items:
		s4jobscanperf_num = len(re.split(r";|,|\band\b", s4jobscanperf))
		return s4jobscanperf_num
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'


# Calculate the number of jobs present in a 's4jobscanperf' string:
# TODO: Update to parse via UMLS-like fast 'in' membership testing
# against a large dataset of job names/titles, then remove stopwords,
# then perhaps using POS tagging split up remaning NP's or at CC's.
def calc_s4jobscanperf(s4jobscanperf_str):
	'''Split up the individual job entities that
	appear to be cited in an INSIGHT 's4jobscanperf' string.
	
	Args:
		s4jobscanperf_str {string}: A string containing
			an INSIGHT 's4jobscanperf' value.
	Returns:
		A string value indicating the individual jobs cited
		in the text, e.g. 'welder; baker';
		'U': Number unknown
		'E': Error occurred.
	Raises:
		N/A
	'''	
	try:
		# Define default value:
		s4jobscanperf_num = 'U'
			
		# Set custom stopword list:
		customstopwordlist = ["me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", "they", "them", "their", "theirs", "themselves", "what", "which", "who", "whom", "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "having", "does", "did", "doing", "the", "if", "because", "as", "until", "while", "of", "for", "with", "about", "against", "between", "into", "through", "during", "before", "after", "above", "below", "to", "from", "up", "down", "in", "out", "on", "off", "over", "under", "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very", "can", "will", "just", "don", "should", "now", "a", "an"]
		
		# Normalize text:
		s4jobscanperf = s4jobscanperf_str.strip().lower()
		s4jobscanperf = " ".join(s4jobscanperf.split())
		
		# Remove common job-related language that might otherwise muddy this result:
		s4jobscanperf = re.sub(r"\bsvp.?(of)?.?[0-9]|\bspecific ?vocational ?preparation.?(of)?.?[0-9]", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"(dictionag|dict\.) ?of ?occupational ?titles|\bd\.?o\.?t\.|\bdot\b", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"#", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"^as ?a ?", "", s4jobscanperf)
		s4jobscanperf = re.sub(r" ?[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}\.\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}-\s{0,2}[0-9lo]\s{0,2}[0-9lo]\s{0,2}[0-9lo] ?", "", s4jobscanperf)
		s4jobscanperf = re.sub(r"this work does not require.*", "", s4jobscanperf)
						
		# Remove all trailing splitting items that could otherwise cause the program to believe there's
		# a job item after it:
		s4jobscanperf_dict = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"\:$|\.$|;$|,$|\band$|\bas ?well ?as$|\bin ?addition ?to$|\bor$|\bbut ?also$", "", s4jobscanperf_dict["s4jobscanperf"], flags=re.I|re.S)
			s4jobscanperf_dict["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict["s4jobscanperf"]
		
		# Remove all LEADING splitting items for same reasons:
		s4jobscanperf_dict2 = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"^:|^\.|^;\b|^,\b|^and\b|^as ?well ?as\b|^in ?addition ?to\b|^or\b|^but ?also\b", "", s4jobscanperf_dict2["s4jobscanperf"], flags=re.I|re.S)
			s4jobscanperf_dict2["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict2["s4jobscanperf"]
		
		# Normalize common conjunctions to ' and ':
		s4jobscanperf = re.sub(r"\bas ?well ?as\b|\band ?also\b|\bin ?addition ?to\b|\bbut ?also\b|\bor\b", " and ", s4jobscanperf)
		
		# Remove stopwords:
		for item in customstopwordlist:
			item = "\\b" + item + "\\b"
			s4jobscanperf = re.sub(item, "", s4jobscanperf)
		
		# The above may remove mid-text splitting item-enclosed text, resulting in langauge like "; ;" - clean these:
		s4jobscanperf_dict1 = {"s4jobscanperf":s4jobscanperf}
		resval = 1
		while resval >= 1:
			res = re.subn(r"(\:|\.|;|,) +(\:|\.|;|,)", r"\1", s4jobscanperf_dict1["s4jobscanperf"])
			s4jobscanperf_dict1["s4jobscanperf"] = res[0].strip()
			resval = res[1]
		s4jobscanperf = s4jobscanperf_dict1["s4jobscanperf"]
		
		# Now actually split and count the number of resulting entities using the splitting items:
		s4jobscanperf_split = re.split(r";|,|\band\b", s4jobscanperf, flags=re.I)
		return '; '.join(s4jobscanperf_split)
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'











