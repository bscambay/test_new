# INSIGHT COMMON NLP HELPER FUNCTIONS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 12.13.2016

# SUMMARY:
# Contains functions that perform miscellaneous/common NLP calculation tasks
# required by INSIGHT modules.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os.path
import re

import Levenshtein as ls
import nltk.data as nltkdata
from nltk.corpus import stopwords

import regex_strings as rs
import text_cleaner as tc
import util

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load/define datasets:

# Load English stopwords:
stop_words = [str(sw) for sw in stopwords.words('english')]
stop_words_minus_conjunctions = [sw for sw in stop_words if
                                 sw not in ['and', 'or', 'but', 'yet', 'although', 'as well as', 'and/or', 'with']]
stop_words_plus_punct = stop_words + ['.', ',', '"', "'", '?', '!', ':', ';', '(', ')', '[', ']', '{', '}', '-', '@',
                                      '$', '%', '&']

# Load postnominal data into dictionary where k=postnominal REGEX pattern
# and v=cleaned/bordering-space-added string version of postnominal; also
# create list of string versions:
postnominaldict = {}
with open(os.path.join(datadir, "source_postnominal_list.txt"), "r") as postnominal_data:
    postnominal_data_lines = postnominal_data.readlines()
    postnominal_data_lines = [line.strip() for line in postnominal_data_lines]
    postnominal_data_lines = [line for line in postnominal_data_lines if
                              line != "" and bool(line.startswith("#")) is False]
    for repat in postnominal_data_lines:
        repat_new = repat.replace(r'\.? ?', '')
        repat_new = repat_new.replace(r'\b', r'')
        repat_new = repat_new.replace(r'\.?(?!\.[A-Za-z])(?![A-Za-z])', r'')
        repat_new = ''.join(repat_new.split())
        repat_new = ' ' + repat_new + ' '
        postnominaldict[repat] = repat_new
postnominallist = [''.join(pn.split()) for pn in postnominaldict.values()]
# Define other datasets:
nersa_med_customswlist = ["me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself",
                          "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its",
                          "itself", "they", "them", "their", "theirs", "themselves", "what", "which", "who", "whom",
                          "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", "been", "being",
                          "have", "has", "had", "having", "does", "did", "doing", "the", "and", "but", "if", "because",
                          "as", "until", "while", "of", "for", "with", "about", "against", "between", "into", "through",
                          "during", "before", "after", "above", "below", "to", "from", "up", "down", "in", "out", "on",
                          "off", "over", "under", "again", "further", "then", "once", "here", "there", "when", "where",
                          "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
                          "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very", "can", "will", "just",
                          "don", "should", "now"]


# Customized sentence tokenizer:
# WARNING: The sentence splitter WILL NOT split if the sentence ends with a non-whitelisted abbreviation.
def sentence_splitter(rawtext):
    try:
        # Set up sentence tokenizer:
        # punkt_params = PunktParameters()
        abbrev_whitelist = set(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'mr', 'mrs', 'mr',
                                'sgt', 'dr', ']', 'C.F.R', 'ms', 'exh', 'lbs', 'd.o.t', 'drs', 'etc',
                                'al', 'ph.d', 'u.s.a', 'u.s', 'ex', 'exh', 'u.s.c', 'p', 'pg', 'seq'])
        # punkt_params.abbrev_types = abbrev_whitelist
        # sentence_splitter = PunktSentenceTokenizer(punkt_params)

        sentence_tokenizer = nltkdata.load('tokenizers/punkt/english.pickle')
        sentence_tokenizer._params.abbrev_types.update(abbrev_whitelist)

        # Preprocess abbreviations for exhibit number:
        # TIP: Required because Punkt sentence splitting white list only operates on single tokens
        # that are followed by periods, and we can't just add in 'no', or it'd never split even where
        # a sentence legitimately ended with the common word 'no'.	Thus, we have to transform 'no.'
        # abbreviations where contextually appropriate (i.e. before 'exhibit'-like references).
        rawtext = re.sub(r'\b(exhibit|exh\.?|ex\.?) {0,6}no\.', 'exhibit number', rawtext, flags=re.I)

        # Tokenize raw text and return list of sentences:
        sent_list = sentence_tokenizer.tokenize(rawtext)
        sent_list = [' '.join(s.split()) for s in sent_list]
        return sent_list
    except Exception:
        logger.exception('EXCEPTION')
        raise


# NERSA customized sentence tokenizer:
# WARNING: The sentence splitter WILL NOT split if the sentence ends with a non-whitelisted abbreviation.
def sentence_splitter_nersa(rawtext):
    try:
        # Set up sentence tokenizer:
        abbrev_whitelist = set(
            ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'mr', 'mrs', 'mr', 'sgt', 'dr', ']', 'C.F.R', 'ms',
             'exh', 'lbs', 'd.o.t', 'drs', 'etc', 'al', 'ph.d', 'u.s.a', 'u.s', 'ex', 'exh', 'u.s.c', 'p', 'pg', 'seq'])
        sentence_tokenizer = nltkdata.load('tokenizers/punkt/english.pickle')
        sentence_tokenizer._params.abbrev_types.update(abbrev_whitelist)

        # Preprocess rawtext:

        # Remove spaces/periods between postnominal letters in rawtext that may
        # otherwise cause a faulty sentence tokenization:
        # WARNING: If a postnominal appears at the end of a sentence, this will
        # strip the period that might otherwise have gramatically been used to
        # terminate that sentence, e.g. "His name is Kurt Glaze, M.D. He is..."
        # to "His name is Kurt Glaze, MD He is...".  However, for NERSA purposes
        # this shouldn't compromise accuracy.
        for k, v in postnominaldict.iteritems():
            rawtext = re.sub(k, v, rawtext, re.I)

        # Normalize spacing:
        rawtext = ' '.join(rawtext.split())

        # Fix bizarre first/middle initial lack of spacing:
        rawtext = re.sub(r"(\bDrs\.|\bDr\.|\bProfessor|\bProf\.|\bMiss|\bMrs\.|\bMr\.|\bMs\.)( ?)([A-Z]\.)([A-Z]\.)",
                         r"\1 \3 \4", rawtext, flags=re.I)

        # Normalize abbreviations for exhibit number:
        # TIP: Required because Punkt sentence splitting white list only operates on single tokens
        # that are followed by periods, and we can't just add in 'no', or it'd never split even where
        # a sentence legitimately ended with the common word 'no'.	Thus, we have to transform 'no.'
        # abbreviations where contextually appropriate (i.e. before 'exhibit'-like references).
        rawtext = re.sub(r'\b(exhibit|exh\.?|ex\.?) {0,6}no\.', 'exhibit number', rawtext, flags=re.I)

        # Tokenize raw text and return list of sentences:
        sent_list = sentence_tokenizer.tokenize(rawtext)
        sent_list = [' '.join(s.split()) for s in sent_list]
        return sent_list
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Attempt to retrieve a SINGLE full name of a person from a snippet of text:
# TIP: Designed to retrieve a name from a snippet that should contain only ONE
# name - will not function properly if 2+ names are present.
# TIP: Presently only used for IE VE name parsing.
def name_searcher(text_snippet):
    try:

        # Assemble list of human name REGEX patterns:
        name_search_regex_list = [
            rs.name_search0_regex,
            rs.name_search1_regex,
            rs.name_search2_regex,
            rs.name_search3_regex,
            rs.name_search4_regex,
            rs.name_search5_regex,
            rs.name_search6_regex,
            rs.name_search7_regex]

        # Normalize input string:
        text_snippet = ' '.join(text_snippet.split())

        # Search for names:
        # TODO: 're.search()' won't find all!  Update to findall/finditer
        # using REGEX module with 'overlapping matches' turned on.
        name_list_raw = []
        for regexpat in name_search_regex_list:
            name_search = re.finditer(regexpat, text_snippet)
            for res in name_search:
                name_list_raw.append(res.group())

        # If 0 results, return 'U':
        if len(name_list_raw) == 0:
            return 'U'
        # If only one result, return it:
        elif len(name_list_raw) == 1:
            name_ultimate = name_list_raw[0]
            name_ultimate = ' '.join(name_ultimate.split())
            return name_ultimate
        # If more than one result (a common occurrence, e.g.
        # 'Kurt A. Glaze' and 'A. Glaze') return LONGEST match:
        # TODO: If tie on longest match, return 'U'.
        else:
            name_ultimate = max(name_list_raw, key=len)
            name_ultimate = ' '.join(name_ultimate.split())
            return name_ultimate
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Correct decision text:
def correct_decision_text(decision_text):
    try:
        # Remove any non-ASCII characters:
        decision_text = "".join([char for char in decision_text if ord(char) < 128])

        # Correct common misspellings, fix critical numeric string OCR errors,
        # fix numeric spacing errors:
        # TIP: tc.final_spelling_corrections() does not normalize spacing.
        # TIP: Shouldn't affect addresses because they come out of OCR as
        # space separated values (e.g. 'Kurt Glaze 4567 Amy Dr. Copley, OH 44321'):
        decision_text = tc.final_spelling_corrections(decision_text)

        # (TEMPORARILY DEPRECATING DUE TO ERROR IN PARSING REP NAME, ETC.)
        # Fix erroneously intervening newline sentence separations
        # (e.g. 'He went to\n\n\nthe store.')
        # TIP: Testing shows this works well (see 'sandbox_12292016_IFS_IE'):
        # decision_text = re.sub(r"(?<=[a-z])([ \t]*)?([ \n\r\f\v]{2,})(?=[a-z])", " ", decision_text, flags=re.S)

        return decision_text
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Generate a list of normalized/cleaned sentences:
# TIP: 'slight cleaner' normalizes spacing and removes
# block margin text.
def generate_sents(decision_text):
    try:
        decision_text = tc.slight_cleaner(decision_text)
        return sentence_splitter(decision_text)
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Search for sentences that contain at least one of the regex elements.
# The first time one of the regex in the list match, it adds that sentence
# to 'result_list'.
# NOTE: This is for at least the Step 4 actually/generally parser.
def regex_list_sent_search(text, regex_list):
    try:
        sents = sentence_splitter(text)
        result_list = []

        for sent in sents:
            # Normalize each sent:
            sent = tc.normalize_spacing(sent)
            sent = sent.lower()

            for regex in regex_list:
                search_result = re.search(regex, sent)
                if bool(search_result):
                    result_list.append(sent)
                    break

        return result_list
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Stopword removal:
def remove_stopwords(text):
    try:
        text = tc.normalize_spacing(text)
        text_split = text.split()
        text_split_nosw = [i for i in text_split if i.lower() not in stop_words]
        return ' '.join(text_split_nosw)
    except Exception:
        logger.exception('EXCEPTION')
        return text


# Stopword (plus punctuation) removal:
def remove_stopwords_pluspunct(text):
    try:
        text = tc.normalize_spacing(text)
        text_split = text.split()
        text_split_nosw = [i for i in text_split if i.lower() not in stop_words_plus_punct]
        return ' '.join(text_split_nosw)
    except Exception:
        logger.exception('EXCEPTION')
        return text


# Stopword (minus coordinating conjunctions) removal:
def remove_stopwords_minusconjunctions(text):
    try:
        text = tc.normalize_spacing(text)
        text_split = text.split()
        text_split_nosw = [i for i in text_split if i.lower() not in stop_words_minus_conjunctions]
        return ' '.join(text_split_nosw)
    except Exception:
        logger.exception('EXCEPTION')
        return text


# Text2int function:
def text2int(string):
    try:

        newstring = string
        numwordsdict = {'zero':0, 'one':1, 'two':2, 'three':3, 'four':4, 'five':5, 'six':6, 'seven':7, 'eight':8,
                        'nine':9, 'ten':10, 'eleven':11, 'twelve':12, 'thirteen':13, 'fourteen':14, 'fifteen':15,
                        'sixteen':16, 'seventeen':17, 'eighteen':18, 'nineteen':19, 'twenty':20, 'thirty':30,
                        'forty':40, 'fifty':50, 'sixty':60, 'seventy':70, 'eighty':80, 'ninety':90, 'one hundred':100}

        # (1) Convert 21-99:
        largenumfindall1 = re.findall(
            r"(\btwenty|\bthirty|\bforty|\bfifty|\bsixty|\bseventy|\beighty|\bninety)( ?- ?| |)(one\b|two\b|three\b|four\b|five\b|six\b|seven\b|eight\b|nine\b|)",
            newstring, re.I)
        if largenumfindall1:
            for numstr in largenumfindall1:
                try:
                    numstrjoined = "".join(numstr)
                    numstrnew = numwordsdict[str(numstr[0]).lower()]
                    try:
                        latterint = numwordsdict[str(numstr[2]).lower()]
                        numstrnew += latterint
                    except KeyError, x:
                        pass
                    numstrnew = " " + str(numstrnew) + " "
                    newstring = re.sub(numstrjoined, numstrnew, newstring, flags=re.I, count=1)
                except Exception, x:
                    pass
        newstring = " ".join(newstring.split())

        # (2) Convert 0-20:
        smallnumfindall1 = re.findall(
            r"\bone\b|\btwo\b|\bthree\b|\bfour\b|\bfive\b|\bsix\b|\bseven\b|\beight\b|\bnine\b|\bten\b|\beleven\b|\btwelve\b|\bthirteen\b|\bfourteen\b|\bfifteen\b|\bsixteen\b|\bseventeen\b|\beighteen\b|\bnineteen\b|\btwenty\b",
            newstring, re.I)
        if smallnumfindall1:
            for numstr in smallnumfindall1:
                try:
                    numstrjoined = "".join(numstr)
                    numstrnew = " " + str(numwordsdict[numstrjoined.lower()]) + " "
                    newstring = re.sub(numstrjoined, numstrnew, newstring, flags=re.I, count=1)
                except Exception, x:
                    pass
        newstring = " ".join(newstring.split())

        # (3) Convert 100-500 complex references:
        for res in re.findall(r"(1 ?hundred)( ?and ?| ?)(\d{1,2})", newstring, re.I):
            if len(res[2]) == 1:
                resjoined = "".join(res)
                resnew = "10" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            elif len(res[2]) == 2:
                resjoined = "".join(res)
                resnew = "1" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            else:
                pass

        for res in re.findall(r"(2 ?hundred)( ?and ?| ?)(\d{1,2})", newstring, re.I):
            if len(res[2]) == 1:
                resjoined = "".join(res)
                resnew = "20" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            elif len(res[2]) == 2:
                resjoined = "".join(res)
                resnew = "2" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            else:
                pass

        for res in re.findall(r"(3 ?hundred)( ?and ?| ?)(\d{1,2})", newstring, re.I):
            if len(res[2]) == 1:
                resjoined = "".join(res)
                resnew = "30" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            elif len(res[2]) == 2:
                resjoined = "".join(res)
                resnew = "3" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            else:
                pass

        for res in re.findall(r"(4 ?hundred)( ?and ?| ?)(\d{1,2})", newstring, re.I):
            if len(res[2]) == 1:
                resjoined = "".join(res)
                resnew = "40" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            elif len(res[2]) == 2:
                resjoined = "".join(res)
                resnew = "4" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            else:
                pass

        for res in re.findall(r"(5 ?hundred)( ?and ?| ?)(\d{1,2})", newstring, re.I):
            if len(res[2]) == 1:
                resjoined = "".join(res)
                resnew = "50" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            elif len(res[2]) == 2:
                resjoined = "".join(res)
                resnew = "5" + res[2]
                newstring = re.sub(resjoined, resnew, newstring, count=1)
            else:
                pass

                # (4) Convert 100-500 simple references:
        newstring = re.sub(r"\b(1|one) ?hundred(?!( ?and ?| ?)(\d{1,2}))", " 100 ", newstring, flags=re.I)
        newstring = re.sub(r"\b(2|two) ?hundred(?!( ?and ?| ?)(\d{1,2}))", " 200 ", newstring, flags=re.I)
        newstring = re.sub(r"\b(3|three) ?hundred(?!( ?and ?| ?)(\d{1,2}))", " 300 ", newstring, flags=re.I)
        newstring = re.sub(r"\b(4|four) ?hundred(?!( ?and ?| ?)(\d{1,2}))", " 400 ", newstring, flags=re.I)
        newstring = re.sub(r"\b(5|five) ?hundred(?!( ?and ?| ?)(\d{1,2}))", " 500 ", newstring, flags=re.I)
        newstring = " ".join(newstring.split())

        # (5) Convert fraction terms:
        fractionwordsdict = {"half":"2", "third":"3", "fourth":"4", "fifth":"5", "sixth":"6", "seventh":"7",
                             "eighth":"8", "ninth":"9", "tenth":"10", "halfs":"2", "thirds":"3", "fourths":"4",
                             "fifths":"5", "sixths":"6", "sevenths":"7", "eighths":"8", "ninths":"9", "tenths":"10"}
        for res in re.findall(
                r"(\d{1,2})( ?)(/|-| )( ?)(halfs\b|thirds\b|fourths\b|fifths\b|sixths\b|sevenths\b|eighths\b|ninths\b|tenths\b|half\b|third\b|fourth\b|fifth\b|sixth\b|seventh\b|eighth\b|ninth\b|tenth\b)",
                newstring, re.I):
            resjoined = "".join(res)
            resnew = res[0] + "/" + fractionwordsdict[str(res[4]).lower()]
            newstring = re.sub(resjoined, resnew, newstring, count=1)

        # (6) Return converted newstring:
        return newstring

    except Exception:
        logger.exception('EXCEPTION')
        raise


# Date conversion function:
# TIP: Converts fully written date to INSIGHT-formatted date (##/##/####).
# OPENQ: Isn't this deprecated by date helper?
def dateconvert(datestring):
    try:
        datestring = datestring.lower()
        datestring = ' '.join(datestring.split()).lower()
        monthnumdict = {'january':1, 'february':2, 'march':3, 'april':4, 'may':5, 'june':6, 'july':7, 'august':8,
                        'september':9, 'october':10, 'november':11, 'december':12}

        # -- Validation:
        datedayverifierunstructured = re.search("\d {0,1}(\d {0,1})?, {0,1}\d {0,1}\d {0,1}\d {0,1}\d", datestring)

        datemonthverifierprep1 = re.sub('[^a-z]', '', datestring)
        datemonthverifierunstructured = re.search(
            '(january|february|march|april|may|june|july|august|september|october|november|december)',
            datemonthverifierprep1)

        dateyearverifierparse1 = re.search("(\d)( {0,2})(\d)( {0,2})(\d)( {0,2})(\d)", datestring)
        if bool(dateyearverifierparse1) is True:
            dateyearverifierunstructured = re.search("(\d)( {0,2})(\d)( {0,2})(\d)( {0,2})(\d)", datestring)
        else:
            dateyearverifierunstructured = re.search("\d\d\d\d", datestring)

        # -- Conversion:
        if bool(datedayverifierunstructured) is True:
            dateconvertday1 = datedayverifierunstructured.group()
            dateconvertday2 = dateconvertday1.split(',')[0]
            dateconvertday3 = ''.join(dateconvertday2.split())
            dateconvertday4 = str(dateconvertday3)
            if len(dateconvertday4) == 1:
                dateconvertdayunstructured = "0" + dateconvertday4
            else:
                dateconvertdayunstructured = dateconvertday4
        else:
            dateconvertdayunstructured = "[?]"

        if bool(datemonthverifierunstructured) is True:
            dateconvertmonth1 = datemonthverifierunstructured.group()
            dateconvertmonth2 = monthnumdict[dateconvertmonth1]
            dateconvertmonth3 = str(dateconvertmonth2)
            if len(dateconvertmonth3) == 1:
                dateconvertmonthunstructured = "0" + dateconvertmonth3
            else:
                dateconvertmonthunstructured = dateconvertmonth3
        else:
            dateconvertmonthunstructured = "[?]"

        if bool(dateyearverifierunstructured) is True:
            dateconvertyearunstructured = dateyearverifierunstructured.group()
            dateconvertyearunstructured = re.sub("( {0,2})", "", dateconvertyearunstructured)
            dateconvertyearunstructured = dateconvertyearunstructured.strip()
        else:
            dateconvertyearunstructured = "[?]"

        # -- Output Formatters:

        result = (dateconvertmonthunstructured + "/" + dateconvertdayunstructured + "/" + dateconvertyearunstructured)

        unknownsearch = re.search('[?]', result)

        if bool(unknownsearch) is True:
            return (
                dateconvertmonthunstructured + "/" + dateconvertdayunstructured + "/" + dateconvertyearunstructured + " [Original: " + datestring + "]")
        else:
            return (dateconvertmonthunstructured + "/" + dateconvertdayunstructured + "/" + dateconvertyearunstructured)
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Attempt to trim a document so that its content
# starts at a specified target string:
def trim_start(start_tgt, document):
    '''Attempt to trim a document so that its content
    starts at a specified target string.

    Will only return trimmed document string if ONLY one match
    for the target string is located.

    Note that use of this function presupposes relatively
    equivalent target/document strings (e.g. no chunks
    of content are missing from one vs. the other).

    Known issues: If finding language is present 2+ times,
    this will fail.  This is at higher risk of occurring
    where decisions contain multiple SEP findings, say for
    different time periods, etc.

    Args:
        start_tgt {str}: The target for where the
            document's start should be trimmed to.
        document {str}: The document to be trimmed.
    Returns:
        Trimmed document string, with normalized spacing and no
        apostrophes.  If trim unsuccessful, original document.
    Exceptions:
        N/A'''
    try:
        # Double check for substantive inputs:
        if start_tgt in ['U', 'P', 'E', ''] or document in ['U', 'P', 'E', '']:
            return document
        else:
            # Normalize start_tgt:
            start_tgt_re = start_tgt.replace("'", "")
            start_tgt_re = ' '.join(start_tgt_re.split())
            start_tgt_re = re.escape(start_tgt_re)
            start_tgt_re = start_tgt_re.replace(" ", " ?")
            # Equivalently normalize document:
            document_re = document.replace("'", "")
            document_re = ' '.join(document_re.split())
            # Determine number of start_tgt matches:
            start_tgt_re_findall = re.findall(start_tgt_re, document_re, re.I)
            if len(start_tgt_re_findall) != 1:
                return document
            else:
                start_tgt_re = start_tgt_re + ".*"
                start_tgt_re_search = re.search(start_tgt_re, document_re, re.S | re.I)
                if bool(start_tgt_re_search) is False:
                    return document
                else:
                    start_tgt_re_res = start_tgt_re_search.group()
                    return start_tgt_re_res
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Contraction expansion:
def contractionexpand(string):
    try:
        contractiondict = {"ain't":"am not",
                           "aren't":"are not",
                           "cannot":"can not",
                           "can't":"can not",
                           "could've":"could have",
                           "couldn't":"could not",
                           "couldn't've":"could not have",
                           "didn't":"did not",
                           "doesn't":"does not",
                           "don't":"do not",
                           "hadn't":"had not",
                           "hadn't've":"had not have",
                           "hasn't":"has not",
                           "haven't":"have not",
                           "he'd":"he would",
                           "he'd've":"he would have",
                           "he'll":"he will",
                           "he's":"he is",
                           "how'd":"how would",
                           "how'll":"how will",
                           "how's":"how is",
                           "I'd":"I would",
                           "I'd've":"I would have",
                           "I'll":"I will",
                           "I'm":"I am",
                           "I've":"I have",
                           "isn't":"is not",
                           "it'd":"it would",
                           "it'd've":"it would have",
                           "it'll":"it will",
                           "it's":"it is",
                           "let's":"let us",
                           "ma'am":"madam",
                           "mightn't":"might not",
                           "mightn't've":"might not have",
                           "might've":"might have",
                           "mustn't":"must not",
                           "must've":"must have",
                           "needn't":"need not",
                           "not've":"not have",
                           "o'clock":"of the clock",
                           "oughtn't":"ought not",
                           "shan't":"shall not",
                           "she'd":"she would",
                           "she'd've":"she would have",
                           "she'll":" she will",
                           "she's":"she is",
                           "should've":"should have",
                           "shouldn't":"should not",
                           "shouldn't've":"should not have",
                           "somebody'd":"somebody would",
                           "somebody'd've":"somebody would have",
                           "somebody'll":"somebody will",
                           "somebody's":"somebody is",
                           "someone'd":"someone would",
                           "someone'd've":"someone would have",
                           "someone'll":"someone will",
                           "someone's":"someone is",
                           "something'd":"something would",
                           "something'd've":"something would have",
                           "something'll":"something will",
                           "something's":"something is",
                           "that'll":"that will",
                           "that's":"that is",
                           "there'd":"there would",
                           "there'd've":"there would have",
                           "there're":"there are",
                           "there's":"there is",
                           "they'd":"they would",
                           "they'd've":"they would have",
                           "they'll":"they will",
                           "they're":"they are",
                           "they've":"they have",
                           "'twas":"it was",
                           "wasn't":"was not",
                           "we'd":"we would",
                           "we'd've":"we would have",
                           "we'll":"we will",
                           "we're":"we are",
                           "we've":"we have",
                           "weren't":"were not",
                           "what'll":"what will",
                           "what're":"what are",
                           "what's":"what is / what does",
                           "what've":"what have",
                           "when's":"when is",
                           "where'd":"where did",
                           "where's":"where is",
                           "where've":"where have",
                           "who'd":"who had",
                           "who'd've":"who would have",
                           "who'll":"who will",
                           "who're":"who are",
                           "who's":"who is",
                           "who've":"who have",
                           "why'll":"why will",
                           "why're":"why are",
                           "why's":"why is",
                           "won't":"will not",
                           "would've":"would have",
                           "wouldn't":"would not",
                           "wouldn't've":"would not have",
                           "y'all":"you all",
                           "y'all'll":"you all will",
                           "you'd":"you would",
                           "you'd've":"you would have",
                           "you'll":"you will",
                           "you're":"you are",
                           "you've":"you have"}

        newstring = string
        for key, val in contractiondict.iteritems():
            key = r"\b" + key + r"\b"
            newstring = re.sub(key, val, newstring, flags=re.I)
        return newstring
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Named Entity Recognition Support Algorithm (NERSA)
# for Medical Source Name Identification from 'Findings'
# section of disability decision text:
# NOTE: Presently designed to only locate names in the 'Findings'
# section (as opposed to the Notice or List of Exhibits).
# NOTE: Designed to only output name results containing at least 3
# components (1+ prefix and/or postnominal AND 2+ name components).
def nersa_med(input_decision_text, name_whitelist):
    try:

        # NERSA Non-Name Capitalized Words List:
        ie_nersa_blacklist = util.load_data_into_list(os.path.join(datadir, "IE_NERSA_BLACKLIST.txt"))
        ie_nersa_nonhumancapwords = util.load_data_into_list(os.path.join(datadir, "IE_NERSA_NONHUMANCAPWORDS.txt"))
        ie_nersa_nonhumancapwords_single_upper = []
        for item in ie_nersa_nonhumancapwords:
            itemsplit = item.split()
            for subitem in itemsplit:
                ie_nersa_nonhumancapwords_single_upper.append(subitem.upper())

        # Trim decision text and normalize spacing:
        text = input_decision_text
        text = " ".join(text.split())
        text_trim_search_1 = re.search(r"FINDINGS ?(0|O)F ?FACT ?AND.*", text, re.S)
        if bool(text_trim_search_1):
            text = text_trim_search_1.group()
        text = re.sub(r"LIST ?(0|O)F ?EXHIBITS.*", "", input_decision_text, re.S)
        # TIP: Trims text after *last* found 'DECISION' (it appears 2+ times).
        decision_finditer = re.finditer("DECISION", text)
        decision_startindex_reslist = []
        for res in decision_finditer:
            decision_startindex_reslist.append(res.start())
        if decision_startindex_reslist:
            text = text[:decision_startindex_reslist[-1]]

        # Remove dates:
        text = re.sub(r"(January|February|March|April|May|June|July|August|September|October|November|December) ?\d",
                      "", text)
        text = " ".join(text.split())

        # Replace NERSA blacklist capitalized terms/phrases with 'REPLACED':
        for term in ie_nersa_blacklist:
            term_re = re.escape(term)
            term_re = term_re.replace(' ', ' ?')
            text = re.sub(term_re, ' 1224 ', text, flags=re.I)

        # Use a sentence tokenizer to split up the remaining text.
        # TIP: Sentence tokenization helps prevent false positives for cases
        # like "The clinic is on 14th & N. B. Dalton, M.D., is old."
        textsentences = sentence_splitter_nersa(text)

        # Normalize full names in whitelist:
        # WARNING: This does open door to false matching (e.g. if ME name
        # were "A SMITH MD" (for Alan Smith, M.D.) but another source name
        # in the decision were "CHARLES A SMITH MD", this would erroneously
        # remove "CHARLES A SMITH MD" as a likely DUP of the ME name...
        # I think it makes more sense to if anything use the Levenschtein
        # Distance approach you outlined with a high threshold to catch the
        # most obvious overlaps (almost always this will be the ME or CE
        # if you can get the CE name data).
        name_whitelist_nml = []
        if name_whitelist:
            name_whitelist_nml = [nm.replace('.', '') for nm in name_whitelist]
            name_whitelist_nml = [nm.replace(',', '') for nm in name_whitelist_nml]
            name_whitelist_nml = [' '.join(nm.split()) for nm in name_whitelist_nml]
        # (DEPRECATED - using LS ratio now, so keep any postnominal or prefix to
        # extent present in data) Strip whitelist names down to first/middle/last,
        # removing any prefixes/postnominals, to create 'lean' version of list items:
        # for nm in name_whitelist_nml:
        # nm_split = nm.split(' ')
        # nm_res = []
        # for nm_elmt in nm_split:
        # nm_elmt = nm_elmt.strip().upper()
        # if nm_elmt not in ['PROFESSOR', 'PROF', 'DOCTOR', 'DRS', 'DR', 'MISS', 'MRS', 'MR', 'MS']:
        # if nm_elmt not in postnominallist:
        # nm_res.append(nm_elmt)
        # if len(nm_res) >= 2:
        # name_whitelist_nml_lean.append(' '.join(nm_res))

        # Capture all name variations with a professional (primarily medically oriented) postnominal:
        # TODO: Update using best practice REGEXES:
        postnominalnamelistraw = []
        prefixnamelistraw = []
        for sentence in textsentences:

            # Capture all standard full name variations where the post-nominal is divided by periods:
            # Kurt Aaron Anistatius Glaze, Jr., M.D.
            medproviderfinditer1a = re.finditer(
                r"([A-Z]'?[A-Za-z\-]+ ){3}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\2?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1a:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # Kurt Aaron Glaze, Jr., M.D.
            medproviderfinditer1a2 = re.finditer(
                r"([A-Z]'?[A-Za-z\-]+ ){2}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1a2:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # Kurt A. Glaze
            medproviderfinditer1b = re.finditer(
                r"[A-Z][A-Za-z\-]+ [A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1b:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # K. Aaron Glaze
            medproviderfinditer1c = re.finditer(
                r"[A-Z]{1}\.? [A-Z]'?[A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1c:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # Kurt Glaze
            medproviderfinditer1e = re.finditer(
                r"[A-Z][A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)

            for item in medproviderfinditer1e:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # K. A. Glaze
            medproviderfinditer1f = re.finditer(
                r"([A-Z]{1}\.? ?){2} ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1f:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)
            # K. Glaze
            medproviderfinditer1g = re.finditer(
                r"[A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?[,\s]{0,2}(C\.?P\.?S\.?N\.?|P\.? ?A\.? ?C\.?|D\.? ?D\.? ?S\.?|D\.? ?M\.? ?D\.?|L\.? ?L\.? ?M\.? ?S\.? ?W\.?|L\.? ?G\.? ?S\.? ?W\.?|L\.? ?B\.? ?S\.? ?W\.?|C\.?R\.?R\.?N\.?|P\.?C\.?C\.?N\.?|C\.?T\.?R\.?N\.?|C\.?P\.?N\.?|F\.?N\.?P\.?|B\.?N\.?|M\.?I\.?C\.?T\.?|P\.?M\.?H\.?N\.?P\.?|I\.?B\.?Q\.?H\.?|S\.?A\.?N\.?E\.?-\.?P\.?|R\.?N\.?F\.?A\.?|C\.?C\.?M\.?|C\.?S\.?|F\.?N\.?C\.?|A\.?C\.?H\.?R\.?N\.?|C\.?A\.?N\.?P\.?|B\.?S\.?|C\.?T\.?R\.?S\.?|C\.?O\.?R\.?L\.?N\.?|C\.?P\.?T\.?|B\.?Sc\.?N\.?|B\.? Sc\.? N\.?|B\.?M\.?T\.?C\.?N\.?|F\.?A\.?A\.?P\.?M\.?|L\.?N\.?C\.?C\.?|A\.?G\.?P\.?C\.?N\.?P\.?-\.?B\.?C\.?|L\.?C\.?C\.?E\.?|L\.?C\.?M\.?H\.?C\.?|C\.?E\.?N\.?P\.?|R\.?R\.?T\.?-\.?N\.?P\.?S\.?|R\.?I\.?N\.?|M\.?E\.?N\.?P\.?|S\.?A\.?N\.?E\.?|A\.?C\.?N\.?S\.?-\.?B\.?C\.?|S\.?P\.?N\.?|R\.?V\.?T\.?|P\.?N\.?P\.?-\.?B\.?C\.?|R\.?N\.?|C\.?T\.?|C\.?F\.?N\.?P\.?|R\.?N\.?C\.?-\.?N\.?I\.?C\.?|S\.?V\.?N\.?|G\.?P\.?N\.?|C\.?L\.?N\.?C\.?|N\.?C\.?-\.?B\.?C\.?|C\.?H\.?P\.?L\.?N\.?|P\.?A\.?L\.?S\.?|A\.?P\.?R\.?N\.?|B\.?H\.? Sc\.?|C\.?H\.?N\.?|Psy\.?N\.?P\.?|Psy\.? N\.?P\.?|L\.?P\.?N\.?|M\.?A\.?P\.?C\.?|D\.?N\.?S\.?|R\.?N\.?C\.?-\.?O\.?B\.?|R\.?N\.?C\.?-\.?L\.?R\.?N\.?|C\.?N\.?O\.?R\.?|G\.?N\.?|C\.?E\.?T\.?N\.?|L\.?P\.?C\.?|N\.?N\.?P\.?-\.?B\.?C\.?|M\.?I\.?C\.?N\.?|C\.?O\.?H\.?N\.?|L\.?C\.?S\.?W\.?|A\.?O\.?C\.?N\.?P\.?|P\.?H\.?N\.?|D\.? ?P\.? ?M\.?|D\.? ?P\.?|A\.?O\.?C\.?N\.?S\.?|N\.?E\.?-\.?B\.?C\.?|L\.?M\.?S\.?W\.?|I\.?P\.?N\.?|A\.?B\.?P\.?P\.?|N\.?P\.?C\.?|L\.?A\.?C\.?|A\.?C\.?L\.?S\.?|A\.?P\.?N\.?|Pod\.? ?D\.?|T\.?N\.?S\.?|N\.?V\.?R\.?N\.?|F\.?A\.?C\.?O\.?F\.?P\.?|C\.?B\.?C\.?N\.?|C\.?M\.?D\.?S\.?C\.?|N\.?P\.?P\.?|F\.?A\.?E\.?N\.?|A\.?O\.?C\.?N\.?|M\.?H\.?N\.?|O\.?D\.?|W\.?H\.?N\.?P\.?-\.?B\.?C\.?|C\.?R\.?T\.?|O\.?C\.?N\.?|M\.?S\.?N\.?|B\.?D\.?L\.?S\.?|R\.?N\.?C\.?S\.?|C\.?M\.?C\.?|C\.?M\.?A\.?|P\.?N\.?P\.?-\.?A\.?C\.?|C\.?H\.?S\.?E\.?-\.?A\.?|F\.?R\.?C\.?N\.?|C\.?N\.?S\.?N\.?|C\.?C\.?D\.?S\.?|C\.?M\.?T\.?|C\.?P\.?H\.?Q\.?|C\.?T\.?N\.?|C\.?R\.?T\.?T\.?|Pharm\.?D\.?|Pharm\.? D\.?|R\.?N\.?-\.?B\.?C\.?|C\.?D\.?D\.?N\.?|C\.?N\.?P\.?|P\.?T\.?|L\.?S\.?N\.?|A\.?D\.?L\.?S\.?|P\.?T\.?A\.?|C\.?A\.?T\.?N\.?-\.?P\.?|C\.?M\.?A\.?S\.?|C\.?H\.?S\.?E\.?|C\.?N\.?N\.?|C\.?A\.?T\.?N\.?-\.?I\.?|C\.?C\.?N\.?S\.?|L\.?C\.?M\.?T\.?|S\.?A\.?N\.?E\.?-\.?A\.?|C\.?H\.?E\.?S\.?|P\.?A\.?-\.?C\.?|A\.?L\.?N\.?C\.?|A\.?P\.?H\.?N\.?-\.?B\.?C\.?|E\.?N\.?|R\.?N\.?C\.?-\.?M\.?N\.?N\.?|Ed\.?D\.?|Ed\.? D\.?|P\.?M\.?H\.?C\.?N\.?S\.?-\.?B\.?C\.?|C\.?N\.?L\.?C\.?P\.?|B\.?L\.?S\.?|N\.?E\.?A\.?-\.?B\.?C\.?|C\.?C\.?T\.?N\.?|C\.?S\.?C\.?|G\.?R\.?N\.?|C\.?C\.?T\.?C\.?|C\.?U\.?N\.?P\.?|F\.?N\.?P\.?-\.?C\.?|C\.?A\.?P\.?A\.?|S\.?H\.?N\.?|M\.?E\.?|M\.?D\.?|R\.?R\.?T\.?-\.?S\.?D\.?S\.?|C\.?W\.?C\.?N\.?|R\.?N\.?M\.?|D\.?W\.?C\.?|R\.?N\.?C\.?|C\.?D\.?M\.?S\.?|C\.?O\.?H\.?N\.?|C\.?M\.?C\.?N\.?|C\.?B\.?N\.?|W\.?C\.?C\.?|M\.?P\.?H\.?|S\.?C\.?R\.?N\.?|M\.?S\.?|T\.?N\.?C\.?C\.?|C\.?P\.?A\.?N\.?|S\.?E\.?N\.?|C\.?-\.?E\.?F\.?M\.?|R\.?P\.?N\.?|I\.?N\.?C\.?|C\.?F\.?C\.?N\.?|D\.?N\.?|H\.?N\.?C\.?|A\.?T\.?C\.?|C\.?P\.?N\.?L\.?|C\.?P\.?N\.?A\.?|F\.?P\.?N\.?P\.?|A\.?B\.?Q\.?A\.?U\.?R\.?P\.?|C\.?O\.?H\.?N\.?-\.?S\.?|D\.?P\.?T\.?|F\.?A\.?H\.?A\.?|E\.?T\.?|C\.?U\.?R\.?N\.?|T\.?N\.?C\.?C\.?-\.?I\.?|Q\.?C\.?S\.?W\.?|C\.?P\.?N\.?P\.?|M\.?A\.?|C\.?N\.?M\.?|Psy\.?D\.?|Psy\.? D\.?|C\.?G\.?N\.?|A\.?C\.?N\.?P\.?C\.?|B\.?S\.?W\.?|N\.?D\.?|L\.?N\.?P\.?|M\.?S\.?W\.?|B\.?S\.?N\.?|C\.?U\.?C\.?N\.?S\.?|N\.?P\.?|C\.?O\.?C\.?N\.?|I\.?B\.?C\.?L\.?C\.?|R\.?R\.?T\.?|R\.?M\.?N\.?|A\.?S\.?N\.?|L\.?N\.?C\.?|C\.?P\.?E\.?N\.?|C\.?-\.?S\.?P\.?I\.?|C\.?M\.?|A\.?N\.?V\.?P\.?|H\.?A\.?C\.?P\.?|L\.?C\.?A\.?T\.?|C\.?L\.?C\.?|L\.?T\.?C\.?|C\.?A\.?R\.?N\.?|D\.?N\.?P\.?|C\.?U\.?A\.?|R\.?M\.?|A\.?D\.?N\.?|C\.?P\.?H\.?O\.?N\.?|P\.?M\.?H\.?N\.?P\.?-\.?B\.?C\.?|L\.?M\.?H\.?C\.?|C\.?N\.?R\.?N\.?|C\.?D\.?E\.?|F\.?A\.?A\.?N\.?|A\.?R\.?N\.?P\.?|A\.?N\.?E\.?F\.?|A\.?C\.?N\.?P\.?-\.?B\.?C\.?|C\.?M\.?S\.?R\.?N\.?|E\.?C\.?R\.?N\.?|C\.?D\.?N\.?|M\.?S\.?Ed\.?|M\.?S\.? Ed\.?|L\.?M\.?T\.?|C\.?P\.?L\.?C\.?|C\.?C\.?R\.?N\.?|O\.?M\.?S\.?|L\.? Psy\.?|L\.?Psy\.?|N\.?M\.?D\.?|S\.?N\.?|N\.?Z\.?C\.?F\.?N\.?|W\.?O\.?C\.?N\.?|C\.?H\.?R\.?N\.?|F\.?A\.?A\.?P\.?|T\.?N\.?P\.?|E\.?N\.?P\.?C\.?|C\.?-\.?N\.?P\.?T\.?|C\.?I\.?C\.?|D\.?O\.?|G\.?N\.?P\.?|M\.?N\.?|C\.?O\.?H\.?N\.?|M\.?Ed\.?|M\.? Ed\.?|D\.?r\.?N\.?P\.?|A\.?A\.?N\.?|O\.?N\.?C\.?|D\.?C\.?|Ph\.?D\.?|Ph\.? D\.?|C\.?V\.?N\.?|M\.?S\.?N\.?|B\.?P\.?S\.?|A\.?C\.?H\.?P\.?N\.?|M\.?R\.?C\.?N\.?A\.?|A\.?A\.?S\.?|C\.?S\.?H\.?A\.?|R\.?Ph\.?|R\.? Ph\.?|M\.?S\.?C\.?|T\.?N\.?C\.?C\.?-\.?P\.?|M\.?S\.?A\.?|F\.?A\.?C\.?O\.?G\.?|R\.?P\.? \.?R\.?C\.?P\.?|P\.?H\.?R\.?N\.?|C\.?P\.?O\.?N\.?|F\.?N\.?P\.?-\.?B\.?C\.?|C\.?P\.?D\.?N\.?|L\.?C\.?P\.?C\.?|C\.?R\.?N\.?|C\.?H\.?S\.?O\.?S\.?|C\.?R\.?R\.?N\.?-\.?A\.?|C\.?H\.?P\.?P\.?N\.?|C\.?H\.?P\.?N\.?|P\.?M\.?H\.?N\.?-\.?B\.?C\.?|D\.?M\.?F\.?T\.?|C\.?W\.?O\.?C\.?N\.?|C\.?N\.?M\.?L\.?|C\.?D\.?O\.?N\.?A\.?|A\.?N\.?P\.?-\.?B\.?C\.?|C\.?N\.?S\.?|A\.?N\.?L\.?C\.?|I\.?C\.?C\.?|C\.?R\.?N\.?P\.?|C\.?W\.?S\.?|C\.?F\.?R\.?N\.?|C\.?R\.?N\.?I\.?|M\.?L\.?S\.?|P\.?C\.?N\.?S\.?|C\.?N\.?E\.?|C\.?R\.?N\.?L\.?|C\.?R\.?N\.?O\.?|C\.?N\.?A\.?|C\.?R\.?N\.?A\.?|C\.?N\.?O\.?|C\.?N\.?L\.?|L\.?V\.?N\.?|C\.?C\.?C\.?N\.?|A\.?N\.?P\.?-\.?C\.?|S\.?N\.?S\.?C\.?|C\.?F\.?N\.?|C\.?H\.?P\.?N\.?A\.?|C\.?G\.?R\.?N\.?|C\.?R\.?N\.?F\.?A\.?|F\.?R\.?C\.?N\.?A\.?|S\.?R\.?N\.?A\.?|F\.?A\.?C\.?C\.?|M\.?A\.?N\.?|L\.?M\.?F\.?T\.?|F\.?A\.?C\.?D\.?|F\.?A\.?C\.?E\.?|L\.?S\.?C\.?S\.?W\.?|N\.?C\.?S\.?N\.?|R\.?R\.?T\.?-\.?A\.?C\.?C\.?S\.?|C\.?E\.?N\.?|F\.?A\.?C\.?S\.?|F\.?A\.?C\.?P\.?|N\.?R\.?P\.?|A\.?C\.?R\.?N\.?)",
                sentence)
            for item in medproviderfinditer1g:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                postnominalnamelistraw.append(item)

            # Capture all names preceded by a prefix/honorific:

            # Kurt Aaron Anistatius Glaze, Jr.
            medproviderfinditer3a = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)([A-Z]'?[A-Za-z\-]+ ){3}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3a:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # Kurt Aaron Glaze, Jr.
            medproviderfinditer3a2 = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)([A-Z]'?[A-Za-z\-]+ ){2}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3a2:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # Kurt A. Glaze
            medproviderfinditer3b = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)[A-Z][A-Za-z\-]+ [A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3b:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # K. Aaron Glaze
            medproviderfinditer3c = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)[A-Z]{1}\.? [A-Z]'?[A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3c:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # Kurt Glaze
            medproviderfinditer3e = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)[A-Z][A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3e:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # K. A. Glaze
            medproviderfinditer3f = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)([A-Z]{1}\.? ?){2} ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3f:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)
            # K. Glaze
            medproviderfinditer3g = re.finditer(
                r"(Mr\.|Mrs\.|Ms\.|Miss|Drs\.|Dr\.|Prof\.|Mr|Mrs|Ms|Miss|Drs|Dr|Prof|Professor|Doctor)( ?)[A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?",
                sentence)
            for item in medproviderfinditer3g:
                item = item.group()
                item = item.strip()
                sentence = sentence.replace(item, "")
                prefixnamelistraw.append(item)

        # For all results passing that test, make the 'raw' results more uniform by removing "." and ",",
        # normalizing spacing:
        postnominalnamelistrawuniform = []
        for item in postnominalnamelistraw:
            item = item.replace(".", "")
            item = item.replace(",", "")
            item = re.sub(r"^(Professor|Prof|Doctor|Drs|Dr|Mrs|Mr|Ms)", r"\1 ", item, flags=re.I)
            item = ' '.join(item.split())
            postnominalnamelistrawuniform.append(item)
        prefixnamelistrawuniform = []
        for item in prefixnamelistraw:
            item = item.replace(".", "")
            item = item.replace(",", "")
            item = re.sub(r"^(Professor|Prof|Doctor|Drs|Dr|Mrs|Mr|Ms)", r"\1 ", item, flags=re.I)
            item = ' '.join(item.split())
            prefixnamelistrawuniform.append(item)

        # Remove exact duplicates from each result list:
        postnominalnamelistrev1 = list(set(postnominalnamelistrawuniform))
        prefixnamelistrev1 = list(set(prefixnamelistrawuniform))
        # FOR TESTING:
        # print "postnominalnamelistrev1: " + str(postnominalnamelistrev1)
        # print "prefixnamelistrev1: " + str(prefixnamelistrev1)

        # Remove any result from prefixlist not beginning with a potential
        # medical source prefix, e.g. 'Dr', as well as any result that
        # when split is only one item in length:
        prefixnamelistrev2 = []
        for item in prefixnamelistrev1:
            itemsplit = item.split(' ')
            if len(itemsplit) > 2:
                if itemsplit[0].upper().strip() in ['PROFESSOR', 'PROF', 'DOCTOR', 'DRS', 'DR']:
                    prefixnamelistrev2.append(item)
        # FOR TESTING:
        # print "prefixnamelistrev2: " + str(prefixnamelistrev2)

        # Remove prefix name pluralizations (round 1):
        # If the name contains less than 3 components including
        # the prefix, drop it:
        prefixnamelistrev3 = []
        if prefixnamelistrev2:
            for name in prefixnamelistrev2:
                namesplit = name.split(" ")
                if len(namesplit) >= 3:
                    lastname = namesplit[-1]
                    lastname = lastname.strip()
                    if bool(lastname.endswith("'s")) is True:
                        lastnamefixed = lastname[:-2]
                        othernames = " ".join(namesplit[:-1])
                        lastnamefixedrejoined = othernames + " " + lastnamefixed
                        prefixnamelistrev3.append(lastnamefixedrejoined)
                    else:
                        prefixnamelistrev3.append(name)
        # FOR TESTING:
        # print "prefixnamelistrev3: " + str(prefixnamelistrev3)

        # MERGE the postnominal and prefix lists into a 'merged' list:
        mergedcustomnamelist1 = []
        for name in postnominalnamelistrev1:
            mergedcustomnamelist1.append(name)
        for name in prefixnamelistrev3:
            mergedcustomnamelist1.append(name)
        # FOR TESTING:
        # print "mergedcustomnamelist1: " + str(mergedcustomnamelist1)

        # Remove any merged result that is more than 85% similar to
        # a whitelisted name:
        mergedcustomnamelist2 = []
        if not name_whitelist_nml:
            mergedcustomnamelist2 = mergedcustomnamelist1
        else:
            for nm in mergedcustomnamelist1:
                ls_ratio_list = []
                for wlnm in name_whitelist_nml:
                    ls_ratio_list.append(ls.ratio(nm, wlnm))
                if any(r > 0.85 for r in ls_ratio_list):
                    pass
                else:
                    mergedcustomnamelist2.append(nm)
        # print "mergedcustomnamelist2: " + str(mergedcustomnamelist2)

        # (DEPRECATING - is 'Dr. Kurt Glaze' necessarily same
        # as 'Kurt Glaze, D.O'?  Logically cannot tell, thus
        # deprecating this and all similar 'de-duplication'
        # mechanisms) Strip all prefixes, then if what remains matches
        # something with a postnominal, remove that prefix name:

        # Cut out any merged name result wherein a non-prefix/non-
        # postnominal component >= 3 characters is (a) all caps or (b) a stopword:
        mergedcustomnamelist3 = []
        if mergedcustomnamelist2:
            for name in mergedcustomnamelist2:
                namesplit = name.split(" ")
                if len(namesplit) >= 3:
                    namesplit = [n for n in namesplit if n not in postnominallist]
                    namesplit = [n for n in namesplit if
                                 n.upper() not in ['PROFESSOR', 'PROF', 'DOCTOR', 'DRS', 'DR', 'MISS', 'MRS', 'MR',
                                                   'MS']]
                    if len([n for n in namesplit if len(n) >= 3 and n.isupper()]) == 0:
                        mergedcustomnamelist3.append(name)
                        # OPENQ: Add this check for stopwords to reduce false positives?
                        # if bool(any(n for n in namesplit if n in nersa_med_customswlist)):
                        # mergedcustomnamelist3.append(name)
        # print "mergedcustomnamelist3: " + str(mergedcustomnamelist3)

        # (IN DEVELOPMENT) Remove any name containing a non-human capitalized word:
        mergedcustomnamelist4 = []
        if mergedcustomnamelist3:
            for name in mergedcustomnamelist3:
                namesplit = name.split(" ")
                if len(namesplit) >= 3:
                    namesplit = [n for n in namesplit if n not in postnominallist]
                    namesplit = [n for n in namesplit if
                                 n.upper() not in ['PROFESSOR', 'PROF', 'DOCTOR', 'DRS', 'DR', 'MISS', 'MRS', 'MR',
                                                   'MS']]
                    nonhumanver = 0
                    for nm in namesplit:
                        if nm.upper() in ie_nersa_nonhumancapwords_single_upper:
                            nonhumanver = 1
                    for nhct in ie_nersa_nonhumancapwords:
                        if nhct.upper() in name.upper():
                            nonhumanver = 1
                    if nonhumanver == 0:
                        mergedcustomnamelist4.append(name)

        # Perform one final DUP removal:
        mergedcustomnamelistFINAL = list(set(mergedcustomnamelist4))

        # Return results:
        return mergedcustomnamelistFINAL
    except Exception:
        logger.exception('EXCEPTION')


# Step 2 Text Cleaner (Non-FIT):
def s2txt_cleaner_nonfit(s2txt_input):
    '''Attemps to clean an input 's2txt' INSIGHT-parsed
    string to output a version that excludes program/generic
    language where the text was NOT derived via searches
    for FIT language (i.e. the language is non-standard).

    Arguments:
        s2txt_input {str}: A single 's2txt' value, i.e. a string
            containing the content of a single Step 2 finding
            heading.
    Returns:
        A cleaned version of 's2txt_input' with program/generic
        language removed. If an exception such as a TypeError occurs,
        returns 'E'.
    Raises:
        N/A.
    '''
    try:
        if bool(isinstance(s2txt_input, str)) is False:
            return 'E'
        else:
            # Remove program/generic language (use fuzzier versions
            # of FIT language):
            s2txt = s2txt_input
            s2txt = re.sub(r'.*?(FOLLOWING\s{0,6}MEDICALLY\s{0,6}DETERMINABLE|FOLLOWING\s{0,6}SEVERE)', '', s2txt)
            s2txt = re.sub(r'\(20 C\.?F\.?R.*', '', s2txt)
            # (2)(a) SEVERE MDIS PRESENT - Verified FIT language where severe MDIs present in UNFAV CONCURRENT + FFAV + UNFAV DWB + DAA UNFAV + T16 CHILD (these are typically the same MDIs except for the substance use):
            s2txt = re.sub(
                r"\d\d?\. ?(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?(has had|has|had) ?(the)? ?(following)? ?(.{1,3}severe.{1,3})? ?impairments?",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(b) SEVERE MDIS PRESENT + PREFATORY LANGUAGE - Verified FIT language where severe MDIs present with prefatory language, e.g. an UNFAV T2 DIB w/ remote DLI:
            s2txt = re.sub(
                r"\d\d?\. ?Through ?the ?(date ?last ?insured|DLI).{0,5}(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?(has had|had|has) ?(the)? ?(following)? ?.{1,3}severe.{1,3}",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(c) MDIS BUT NONE SEVERE - Verified FIT language where MDIs but none severe in UNFAV:
            s2txt = re.sub(
                r"\d\d?\. ?(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?(has had|had|has) ?the ?following ?medically ?determinable",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(d) MDIS BUT NONE SEVERE + PREFATORY LANGUAGE - Verified FIT language where MDIs but none severe in UNFAV:
            s2txt = re.sub(
                r"\d\d?\. ?Through ?the ?(date ?last ?insured|DLI).{0,5}(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?(has had|had|has) ?the ?following ?medically ?determinable",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(e) NO MDIS AT ALL - Verified FIT language where NO MDIs present in UNFAV:
            s2txt = re.sub(
                r"\d\d?\. ?There ?are ?no ?medical ?signs ?or ?laboratory ?findings ?to ?substantiate ?the ?existence ?of ?a? ?medically ?determinable",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(f) NO MDIS AT ALL + PREFATORY LANGUAGE - Verified FIT language where NO MDIs present in UNFAV:
            s2txt = re.sub(
                r"\d\d?\. ?Through ?the ?(date ?last ?insured|DLI).{0,5}there ?(were|are) ?no ?medical ?signs ?or ?laboratory ?findings ?to ?substantiate",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(g) NO MDIS AT ALL (DAA) - Verified FIT language where NO severe MDIs present excluding the DAA MDIs:
            s2txt = re.sub(
                r"\d\d?\. ?If ?(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?stopped ?the ?substance ?use.{0,5}the ?remaining ?limitations ?would ?not ?cause ?more ?than ?a ?minimal",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(h) CHILD->ADULT DECISIONS HAVE 2 MDI-RELATED FINDINGS - Verified FIT language where severe MDIs present both in childhood and adulthood in child->adult SSI (both should be in same decision):
            s2txt = re.sub(
                r"\d\d?\. ?Before ?attaining ?age.{1,20}(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?(has had|had|has) ?(the)? ?(following)? ?.{1,3}severe.{1,3}",
                " ", s2txt, flags=re.M | re.S | re.I)
            s2txt = re.sub(
                r"\d\d?\. ?Since ?attaining ?age.{1,20}(The ?claimant|(Miss|Mrs\.|Mr\.|Ms\.) ?\w+) ?has ?continued",
                " ", s2txt, flags=re.M | re.S | re.I)
            # (2)(i) FIT-LIKE BENCH DECISION STEP 2 LANGUAGE:
            s2txt = re.sub(
                r"\d?\d?\.? ?The ?claimant ?has ?the ?following ?severe ?(impairments|impairment|combination ?of ?impairments)",
                " ", s2txt, flags=re.M | re.I)
            # (2)(j) Remove any lingering FIT CFR References:
            s2txt = re.sub(
                r"as ?defined ?in ?(20 ?cfr ?|20 ?c\.f\.r\. ?)(404\.[0-9]{4}\((a|b|c|d|e)\)\(?.?\)?\(?.?\)? ?and ?416\.[0-9]{3}\((a|b|c|d|e)\)\(?.?\)?\(?.?\)?|416\.[0-9]{3}\((a|b|c)\)\(?.?\)?\(?.?\)?|404\.[0-9]{4}\((a|b|c)\)\(?.?\)?\(?.?\)?)",
                " ", s2txt, flags=re.I)
            s2txt = re.sub(
                r"404\.[0-9]{4}\(.?\)\(?.?\)?\(?.?\)?|416\.[0-9]{3}\(.?\)\(?.?\)?\(?.?\)?|404\.[0-9]{4}|416\.[0-9]{3}",
                " ", s2txt, flags=re.I)
            s2txt = re.sub(r"20 ?(c\.f\.\r.|cfr)", " ", s2txt, flags=re.I)
            # Remove trailing punctuation/coordinating conjunctions:
            s2txt_dict = {'s2txt':s2txt}
            while True:
                s2txt_v = s2txt_dict['s2txt']
                if bool(re.search(r" ?\band$|[^a-zA-Z]\)$| ?(,|;|\.)$", s2txt_v, re.I)):
                    s2txt_v = re.sub(r" ?\band$|[^a-zA-Z]\)?\)?\)?\)$| ?(,|;|\.)$", "", s2txt_v, flags=re.I)
                    s2txt_v = ' '.join(s2txt_v.split())
                    s2txt_dict['s2txt'] = s2txt_v
                else:
                    break
            s2txt = s2txt_dict['s2txt']

            # Remove certain post-cleaning erroneously residual characters:
            residual_char_list = [')', '(', '[', ']']
            for c in residual_char_list:
                if s2txt.count(c) == 1:
                    s2txt = s2txt.replace(c, ' ')

            s2txt = ' '.join(s2txt.split())
            return s2txt
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Step 2 Text Cleaner (FIT):
def s2txt_cleaner_fit(s2txt_input):
    '''Attemps to clean an input 's2txt' INSIGHT-parsed
    string to output a version that excludes program/generic
    language where the text WAS derived via searches
    for FIT language (i.e. the language is FIT standard).

    Arguments:
        s2txt_input {str}: A single 's2txt' value, i.e. a string
            containing the content of a single Step 2 finding
            heading.
    Returns:
        A cleaned version of 's2txt_input' with FIT language removed.
        If an exception such as a TypeError occurs, returns 'E'.
    Raises:
        N/A.
    '''
    try:
        if bool(isinstance(s2txt_input, str)) is False:
            return 'E'
        else:
            # Remove FIT language:
            s2txt = s2txt_input
            s2txt = re.sub(
                r"(\d\d\. |\d\. )the ?claimant ?(has had|has|had) ?the ?following ?severe ?(medically ?determinable ?impairments?|impairments?)?:?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"\(?20 ?cfr ?404\.1520\(c\) ?and ?416\.920\(c\)|\(?20 ?cfr ?404\.1520\(c\)\)?|\(?20 ?cfr ?416\.920\(c\)\)?|\(?20 ?cfr ?416\.924\(c\)\)?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"(\d\d\. |\d\. )through ?the ?(date ?last ?insured|dli).{0,5}the ?claimant ?(has had|had|has) ?the ?following ?severe ?(medically ?determinable ?impairments?|impairments?)?:?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"(\d\d\. |\d\. )the ?claimant ?(has had|had|has) ?the ?following ?medically ?determinable ?impairments?:?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(r"\(?20 ?cfr ?404\.1521\)?|\(?20 ?cfr ?416\.921\)?|\(?20 ?cfr ?416\.924\(c\)\)?", "", s2txt,
                           flags=re.I)
            s2txt = re.sub(
                r"(\d\d\. |\d\. )through ?the ?(date ?last ?insured|dli).{0,5}the ?claimant ?(has had|had|has) ?the ?following ?medically ?determinable ?impairments?:?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"(\d\d\. |\d\. )before ?attaining ?age.{1,20}the ?claimant ?(has had|had|has) ?the ?following ?severe ?(medically ?determinable ?impairments?|impairments?)?:?",
                "", s2txt, flags=re.I)
            s2txt = re.sub(r"\(?20 CFR 416.924\(c\)\)?", "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"the ?claimant ?has ?the ?following ?severe ?(medically ?determinable ?impairments?|combination ?of ?impairments|impairments?):?",
                "", s2txt, flags=re.I)
            # Further normalize remaining s2txt language:
            s2txt = re.sub(r"combination of impairments:", "", s2txt, flags=re.I)
            s2txt = re.sub(
                r"\(?\[?20 ?c\.?f\.?r\.? ?(416|404)\.[0-9]+\)?(\(?[a-z0-9]{1}\)?\)?){0,5}( ?,? ?and ?| ?, ?)(416|404)\.[0-9]+\)?(\(?[a-z0-9]{1}\)?\)?){0,5}",
                "", s2txt, flags=re.I)
            s2txt = re.sub(r"(416|404)\.[0-9]+(\(?[a-z0-9]{1}\)?){0,5}( ?,? ?and ?| ?, ?)?", "", s2txt, flags=re.I)
            s2txt = re.sub(r"\(?20 CFR", "", s2txt, flags=re.I)
            s2txt = re.sub(r"^(\d\d\. |\d\. )", "", s2txt, flags=re.I)
            s2txt = s2txt.strip()
            # Remove trailing punctuation/coordinating conjunctions:
            s2txt_dict = {'s2txt':s2txt}
            while True:
                s2txt_v = s2txt_dict['s2txt']
                if bool(re.search(r" ?\band$|[^a-zA-Z]\)$| ?(,|;|\.)$", s2txt_v, re.I)):
                    s2txt_v = re.sub(r" ?\band$|[^a-zA-Z]\)?\)?\)?\)$| ?(,|;|\.)$", "", s2txt_v, flags=re.I)
                    s2txt_v = ' '.join(s2txt_v.split())
                    s2txt_dict['s2txt'] = s2txt_v
                else:
                    break
            s2txt = s2txt_dict['s2txt']

            # Remove certain post-cleaning erroneously residual characters:
            residual_char_list = [')', '(', '[', ']']
            for c in residual_char_list:
                if s2txt.count(c) == 1:
                    s2txt = s2txt.replace(c, ' ')
            s2txt = ' '.join(s2txt.split())
            return s2txt
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'
