'''
    this will contain utility functions which are to be used accross the application; convert it to be a class if necessary
'''
import io
import logging
import os
from shutil import copyfile

from env_loader import load_dotenv

# Set data directory:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


def load_data_into_list(dataset_path):
    """
        Function to convert individual lines of a dataset from a text file
        into a list of strings:
    """
    try:
        data_list = []
        with io.open(dataset_path, "rt", encoding="utf8", errors="ignore") as data:
            for line in data:
                line = line.strip()
                if bool(line.startswith('#')) is False and line != '':
                    data_list.append(line.strip())
        return data_list
    except Exception:
        logger.exception('EXCEPTION')
        raise


def graceful_import(library_to_import, error_message):
    """
        Function to import a library or fail gracefully with an error message
    """
    try:
        library = __import__(library_to_import)
        return library
    except ImportError:
        raise ImportError(error_message)

def get_value_from_env(environment_key):
    """
        Function retrieves the value of the key form the environment.
        The principal purpose of this function is to correct for windows
        returning all environment variables in unicode.

        :param environment_key:
        :return: environment value encoded in utf8
    """
    return os.environ.get(environment_key).encode("utf8")


def get_raw_value_from_env(environment_key):
    """
        Function retrieves the value of the key form the environment.
        The principal purpose of this function is to correct for windows
        returning all environment variables in unicode.

        :param environment_key:
        :return: environment value formatted in raw
    """
    env_value = os.environ.get(environment_key)
    return r'%s'%env_value


def is_insight_env_loaded():
    """
        Function checks the environment to see if insight related settings are loaded.
        :return: True or False depending on the check
    """
    if os.environ.get('INSIGHT_LOADED'):
        return True
    return False


def load_insight_env():
    """
        Function that loads the env from the .env file.
        If the .env file does not exist then it copies the sample.env and loads that.
    """
    env_path = os.path.dirname(os.path.realpath(__file__))
    if not os.path.isfile(os.path.join(env_path, '.env')):
        copyfile(os.path.join(env_path, 'sample.env'), os.path.join(env_path, '.env'))
    load_dotenv(dotenv_path=os.path.join(env_path, '.env'), verbose=True)
