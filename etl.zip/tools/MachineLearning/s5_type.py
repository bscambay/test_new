# step 5 finding, I don't know what type is here

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S5VERDICTTYPEFEATURESREV2.txt", 'OneVsRestClassifier', 3, logging_dir)
ml.run()
