﻿using INSIGHT_Request.Models;
using INSIGHT_Request.Util;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace INSIGHT_Request.Controllers
{
    public class InsightUserController : ApiController
    {
        private static ILog logger = log4net.LogManager.GetLogger(typeof(InsightUserController));
        private Dictionary<string, string> routeParameterValues = new Dictionary<string, string>();
        private string searchResultJSON = string.Empty;
        private string casepin = string.Empty;
        private string adminpin = string.Empty;
        private string searchssn = string.Empty;
        //Retrieve all Case details associated with user PIN
        //after authentication in ARPS and Postgres
        //user pin is passed in the request header
        [HttpPost]
        [Route("insight-request/insightuser/casepinsearch")]

        public HttpResponseMessage casepinsearch()
        {                        
            try
            {
                logger.Info(string.Format("Invoking method.....: {0}",Utils.GetCurrentMethod()));

                GetHeaderRouteParameters();

                if (routeParameterValues.Count >= 1)
                {
                    routeParameterValues.TryGetValue("casepin", out casepin);
                    if (!string.IsNullOrEmpty(casepin))
                    {
                        logger.Info(string.Format("Invoking cases for user: {0}", casepin));
                        searchResultJSON = WWData.PACARCaseByPIN(casepin);

                        return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON);
                    }
                }
                else
                {
                    logger.Info("Method invoke incomplete. Not enough parameters");
                }
            }
            catch (Exception x)
            {            
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }            

            return Request.CreateResponse(HttpStatusCode.InternalServerError, "Missing PIN/Some error occurred");
        }

        //Retrieve Case details based on SSN Search        
        //user pin is passed in the request header
        //ssn is passed in the request body
        
        [HttpPost]
        [Route("insight-request/insightuser/casessnsearch")]
        public HttpResponseMessage casessnsearch([FromBody] OAORouteParameters rqst)
        {                                
            try
            {
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));

                GetHeaderRouteParameters(); 
                GetBodyRouteParameters(rqst);

                if (routeParameterValues.Count >= 2)
                {
                    routeParameterValues.TryGetValue("casepin", out casepin);
                    routeParameterValues.TryGetValue("searchssn", out searchssn);

                    if (!string.IsNullOrEmpty(casepin) && !string.IsNullOrEmpty(searchssn))
                    {
                        logger.Info(string.Format("Invoking cases for user: {0} //// ssn: *****-{1}", casepin, searchssn.Substring(5,(searchssn.Length - 5))));

                        searchResultJSON = WWData.PACARCaseBySSN(casepin, searchssn);
                        
                        return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON); ;
                    }
                }
                else
                {
                    logger.Info("Method invoke incomplete. Not enough parameters");
                }
                
            }
            catch (KeyNotFoundException kx)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
            }
            catch (Exception x) 
            {
                logger.Error("Error Details:->" + (string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace)));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }            

            return Request.CreateResponse(HttpStatusCode.InternalServerError, "Missing PIN/SSN");
        }

        //Admin to be able to view cases
        //associated with user PIN
        //after authentication in ARPS and Postgres
        //Admin to be checked for admin role in 
        //postgres permissions table
        [HttpPost]
        [Route("insight-request/insightuser/admincases/{checkaccess:regex(^1$)?}")]

        public HttpResponseMessage admincases(int checkaccess=0)
        {
            
            try
            {
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));

                GetHeaderRouteParameters();

                if (checkaccess == 1)
                {
                    searchResultJSON = "Error: Missing admin pin";

                    if (routeParameterValues.Count >= 1)
                    {                        
                        routeParameterValues.TryGetValue("adminpin", out adminpin);

                        if (!string.IsNullOrEmpty(adminpin))
                        {
                            logger.Info(string.Format("Admin verification invoked for: {0}", adminpin));

                            searchResultJSON = WWData.AdminCasesByPin(casepin, adminpin, checkaccess);                            
                        }                                                                     
                    }

                    return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON);
                }

                if (routeParameterValues.Count >= 2)
                {
                    routeParameterValues.TryGetValue("casepin", out casepin);
                    routeParameterValues.TryGetValue("adminpin", out adminpin);
                    if (!string.IsNullOrEmpty(casepin) && (!string.IsNullOrEmpty(adminpin)))
                    {
                        logger.Info(string.Format("Admin: {0} invoking cases for user: {1}", adminpin, casepin));

                        searchResultJSON = WWData.AdminCasesByPin(casepin, adminpin, checkaccess);                                                

                        return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON);
                    }
                }
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

            return Request.CreateResponse(HttpStatusCode.InternalServerError, "Missing PIN/Some error occurred");
        }


        private void GetHeaderRouteParameters()
        {            
            try
            {
                //Get Route Parameter values
                //from request Header for casepin, adminpin and searchssn              
                HttpRequestMessage requestMsg = Request;
                var headers = requestMsg.Headers;                

                if (headers.Contains("casepin"))
                {                    
                    routeParameterValues.Add("casepin", casepin = headers.GetValues("casepin").First());

                    logger.Info(string.Format("Header Parameter casepin found: {0}", casepin ));
                }

                if (headers.Contains("adminpin"))
                {                    
                    routeParameterValues.Add("adminpin", adminpin = headers.GetValues("adminpin").First());

                    logger.Info(string.Format("Header Parameter adminpin found: {0}", adminpin));
                }

                if (headers.Contains("searchssn"))
                {                    
                    routeParameterValues.Add("searchssn", searchssn = headers.GetValues("searchssn").First());

                    logger.Info(string.Format("Header Parameter searchssn found: {0}", searchssn.Substring(5, (searchssn.Length - 5))));
                }                                
                              
            }
            catch(KeyNotFoundException kx)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }            
        
        }

        private void GetBodyRouteParameters(OAORouteParameters rq)
        {
            try
            {               
                //Get Route Parameter values
                //from request Body for ssn                
                if (rq != null)
                {                    
                    if (!routeParameterValues.ContainsKey("casepin"))
                    {
                        if (rq.casepin.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter casepin: {0}", rq.casepin));
                            routeParameterValues.Add("casepin", rq.casepin);
                        }
                    }
                    if (!routeParameterValues.ContainsKey("adminpin"))
                    {
                        if (rq.casepin.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter adminpin: {0}", rq.adminpin));
                            routeParameterValues.Add("adminpin", rq.adminpin);
                        }
                    }
                    if (!routeParameterValues.ContainsKey("searchssn"))
                    {
                        if (rq.searchssn.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter searchssn: {0}", rq.searchssn));
                            routeParameterValues.Add("searchssn", rq.searchssn);
                        }
                    }
                }

            }
            catch (KeyNotFoundException kx)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }
    }
}
