# INSIGHT HEARING DECISION DATA EXTRACTION ALGORITHM (INSIGHT Extract)
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# DATE LAST UPDATED: 
# 05.01.2017
# 
# SUMMARY: 
# Analyzes 'raw' disability hearing decision text to extract a broad
# range of data about the content of that decision text.
# 
# WARNING: The following is alpha-level/prototype software whose output
# quality has not yet been formally validated and whose documentation is not
# yet fully formed.
#=============================================================================

# Import modules:
import sys
import re
import os
import os.path
import timeit
import io
from datetime import datetime
from operator import itemgetter
import logging
import multiprocessing
from string import translate
from collections import Counter, OrderedDict, defaultdict
import pandas
import numpy as np
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
import ie_data_loader as iedl
import text_cleaner as tc
import nlp_helper
from s4actgen_classifier import S4ActgenClassifier
import date_helper as dh
import common_calcs as cc
import ie_common_calcs as iecc
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
testdir = os.path.join(insightdir, "test/functional")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Perform misc. setup actions:
multiprocessingcount = 0
s4actgenclassifier = S4ActgenClassifier()


# Define INSIGHT Extract:
def insightextract(decision):
	'''Extracts structured data from a disability hearing decision
	text string.

	Argument:
		decision {str}: Decision text string.
	Returns:
		- decisiondatadict {dict}: A dictionary containing the extracted
		data.
		- decisionfindingsltd {str}: A 'cleaned' version of the input decision
		text string that corrects common misspellings, removes non-ASCII,
		corrects erroneously intervening newline sentence separations,
		and slices text to ideally between 'FINDINGS OF FACT'
		and 'LIST OF EXHIBITS' (but with sequential redundant trimming).
	Raises:
		N/A.
	'''

	# Set up multiprocessing tracking:
	global multiprocessingcount
	if str(multiprocessingcount).endswith("00"):
		logger.info(str(multiprocessingcount))
	multiprocessingcount += 1

	# Create IE dictionary and set default values:

	# 'dspn_doc' data points:
	# TIP: Most of these will have only 1 value; however,
	# in cases where there are 2+ values, the following
	# dividing characters are used:
	# - For data points with categorical/predictible
	# values, each value will be separated by '; '.
	# - For data points with text/unpredictable
	# values, each value will be separated by ' /// '.
	decisiondatadict = {}
	decisiondatadict['ssn'] = 'U'
	decisiondatadict['ssnxref'] = 'U'
	decisiondatadict['clnmadd'] = 'U'
	decisiondatadict['clnm'] = 'U'
	decisiondatadict['clzip'] = 'U'
	decisiondatadict['repnmadd'] = 'U'
	decisiondatadict['repnm'] = 'U'
	decisiondatadict['repzip'] = 'U'
	decisiondatadict['adjudicator'] = 'U'
	decisiondatadict['daamat'] = 'U'
	decisiondatadict['aod'] = 'U'
	decisiondatadict['aodamendver'] = 'U'
	decisiondatadict['dli'] = 'U'
	decisiondatadict['did'] = 'U'
	decisiondatadict['mip'] = 'U'
	decisiondatadict['merefbg'] = 'U'
	decisiondatadict['merefbody'] = 'U'
	decisiondatadict['verefbg'] = 'U'
	decisiondatadict['verefbody'] = 'U'
	decisiondatadict['venm'] = 'U'
	decisiondatadict['otrref'] = 'U'
	decisiondatadict['ssnsrc'] = 'U'
	decisiondatadict['ssnxrefsrc'] = 'U'
	decisiondatadict['clnmaddsrc'] = 'U'
	decisiondatadict['clnmsrc'] = 'U'
	decisiondatadict['clzipsrc'] = 'U'
	decisiondatadict['repnmaddsrc'] = 'U'
	decisiondatadict['repnmsrc'] = 'U'
	decisiondatadict['repzipsrc'] = 'U'
	decisiondatadict['adjudicatorsrc'] = 'U'
	decisiondatadict['daamatsrc'] = 'U'
	decisiondatadict['aodsrc'] = 'U'
	decisiondatadict['aodamendversrc'] = 'U'
	decisiondatadict['dlisrc'] = 'U'
	decisiondatadict['didsrc'] = 'U'
	decisiondatadict['mipsrc'] = 'U'
	decisiondatadict['edver'] = 'U'
	decisiondatadict['dob'] = 'U'
	decisiondatadict['txskillsver'] = 'U'
	decisiondatadict['edversrc'] = 'U'
	decisiondatadict['dobsrc'] = 'U'
	decisiondatadict['txskillsversrc'] = 'U'
	decisiondatadict['s5mvrlookuperr'] = 'U'

	# Child table data points:
	decisiondatadict['claimdisp'] = {}
	decisiondatadict['s1sga'] = {}
	decisiondatadict['s2'] = {}
	decisiondatadict['s3mteq'] = {}
	decisiondatadict['s3feq'] = {}
	decisiondatadict['rfc'] = {}
	decisiondatadict['s4'] = {}
	decisiondatadict['s4dot'] = {}
	decisiondatadict['s5'] = {}
	decisiondatadict['s5dot'] = {}
	decisiondatadict['mvr'] = {}
	decisiondatadict['srcnm'] = {}

	# Begin INSIGHT Extract parsing:
	try:

		# If no decisional text to parse, return 'E' values:
		if decision in ['U', 'E', '']:
			decisiondatadict = {k:'E' for k,v in decisiondatadict.iteritems()}
			return decisiondatadict, 'E'

		# Perform preliminary corrections on decision text
		# and create normalized 'sentence list' version:

		# *Lightly* correct decision text:
		# TIP: 'correct_decision_text' corrects common misspellings,
		# removes non-ASCII, and corrects erroneously intervening newline
		# sentence separations.  It does NOT normalize spacing OR remove
		# margin text.
		decision = nlp_helper.correct_decision_text(decision)
		if decision == 'E':
			decisiondatadict = {k:'E' for k,v in decisiondatadict.iteritems()}
			return decisiondatadict, 'E'

		# Create version of 'decision' that also removes
		# margin text as a block (more conservative) and corrects any resulting
		# erroneously intervening newline sentence separations:
		decision_nomargin = tc.remove_see_next_page_and_errnl(decision)

		# Create normalized 'sentence list' version of 'decision_nomargin'
		# with normalized spacing:
		# TIP: Presently used for VE name parsing.
		decision_nomargin_nmlspacing = tc.normalize_spacing(decision_nomargin)
		decision_nomargin_sentlist = nlp_helper.sentence_splitter(decision_nomargin_nmlspacing)

		# Create 'decisionfindingsltd', i.e. decision text ideally between 'FINDINGS OF FACT'
		# and 'LIST OF EXHIBITS' (but with sequential redundant trimming):
		# TIP: Randomized examination of 3000 decision files reveal -
		# r"JURISDICTI(0|O)N ?AND ?PROCEDURAL ?HIST(0|O)RY" exactly 1 match frequency: 98.83%
		# r"\bISSUES\b" exactly 1 match frequency: 99.05%
		# r"FINDINGS ?(0|O)F ?FACT" exactly 1 match frequency: 99.067%
		# r"DECISION" (after above) exactly 1 match frequency: 98.9%
		# r"LIST ?(0|O)F ?EXHIBIT" is much more frequently omitted, but when present its
		# exact 1 match frequency was 100%.
		decisionfindingsltd = decision_nomargin
		jph_fwd_search = re.search(r"JURISDICTI(0|O)N ?AND ?PROCEDURAL ?HIST(0|O)RY.*", decisionfindingsltd, re.S)
		if bool(jph_fwd_search):
			decisionfindingsltd = jph_fwd_search.group()
		issues_fwd_search = re.search(r"\bISSUES.*", decisionfindingsltd, re.S)
		if bool(issues_fwd_search):
			decisionfindingsltd = issues_fwd_search.group()
		fof_fwd_search = re.search(r"FINDINGS ?(0|O)F ?FACT.*", decisionfindingsltd, re.S)
		if bool(fof_fwd_search):
			decisionfindingsltd = fof_fwd_search.group()
		decisionfindingsltd = re.sub(r"LIST ?OF ?EXHIBIT.*", "", decisionfindingsltd, flags=re.S)

		# Create space normalized 'sentence list' version of 'decisionfindingsltd':
		# TIP: Not calling 'nlp_helper.generate_sents()' because already
		# removed block margin text in creating 'decision_nomargin'.
		# TIP: Presently used for FIT RFC text parsing.
		# TIP: In theory, this could provide more complete finding heading text in cases where
		# a newline inadvertently breaks the middle of a sentence (not due to margin text, which
		# has already been removed)
		decisionfindingsltd_nmlspc = tc.normalize_spacing(decisionfindingsltd)
		decisionfindingsltd_sentlist = nlp_helper.sentence_splitter(decisionfindingsltd_nmlspc)

		# Set default variable values:
		ssnunstructured = []
		ssnstructured = ''
		ssnchecked = 'U'
		ssncheckedsrc = 'U'
		ssnxrefunstructured = []
		ssnxrefchecked = 'U'
		ssnxrefcheckedsrc = 'U'
		clnmaddunstructured = []
		clnmaddstructured = ''
		clnmaddchecked = 'U'
		clnmaddcheckedsrc = 'U'
		clnmunstructured = []
		clnmstructured = ''
		clnmchecked = 'U'
		clnmcheckedsrc = 'U'
		clzipunstructured = []
		clzipstructured = ''
		clzipchecked = 'U'
		clzipcheckedsrc = 'U'
		repnmaddunstructured = []
		repnmaddstructured = ''
		repnmaddchecked = 'U'
		repnmaddcheckedsrc = 'U'
		repnmunstructured = []
		repnmstructured = ''
		repnmchecked = 'U'
		repnmcheckedsrc = 'U'
		repzipunstructured = []
		repzipstructured = ''
		repzipchecked = 'U'
		repzipcheckedsrc = 'U'
		adjudicatorunstructured = []
		adjudicatorstructured = ''
		adjudicatorchecked = 'U'
		adjudicatorcheckedsrc = 'U'
		disptypeunstructured = []
		disptypestructured = ''
		disptypechecked = 'U'
		disptypecheckedsrc = 'U'
		claimtypeunstructured = []
		claimtypestructured = ''
		claimtypechecked = 'U'
		claimtypecheckedsrc = 'U'
		daamatunstructured = []
		daamatstructured = ''
		daamatchecked = 'U'
		daamatcheckedsrc = 'U'
		dofunstructured = []
		dofstructured = ''
		dofchecked = 'U'
		dofcheckedsrc = 'U'
		aodunstructured = []
		aodstructured = ''
		aodchecked = 'U'
		aodcheckedsrc = 'U'
		aodamendverunstructured = []
		aodamendverstructured = ''
		aodamendverchecked = 'U'
		aodamendvercheckedsrc = 'U'
		dliunstructured = []
		dlistructured = ''
		dlichecked = 'U'
		dlicheckedsrc = 'U'
		didunstructured = []
		didstructured = ''
		didchecked = 'U'
		didcheckedsrc = 'U'
		mipunstructured = []
		mipchecked = 'U'
		mipcheckedsrc = 'U'
		merefbgunstructured = []
		merefbgchecked = 'U'
		merefbgcheckedsrc = 'U'
		merefbodyunstructured = []
		merefbodychecked = 'U'
		merefbodycheckedsrc = 'U'
		verefbgunstructured = []
		verefbgchecked = 'U'
		verefbodyunstructured = []
		verefbodychecked = 'U'
		venmunstructured = []
		venmstructured = ''
		venmchecked = 'U'
		otrrefunstructured = []
		otrrefchecked = 'U'
		s5mvrlookuperrchecked = []

		edunstructured = []
		edstructured = ''
		edchecked = 'U'
		edcheckedsrc = 'U'
		dobunstructured = []
		dobstructured = ''
		dobchecked = 'U'
		dobcheckedsrc = 'U'
		txskillsverdictunstructured = []
		txskillsverdictstructured = ''
		txskillsverdictchecked = 'U'
		txskillsverdictcheckedsrc = 'U'

		# TIP: Schema 2 child table-friendly
		# list of dict containers:
		claimdispchecked = []
		s1sgaunstructured = []
		s1sgachecked = []
		s2unstructured = []
		s2checked = []
		s3mtequnstructured = []
		s3mteqchecked = []
		s3fequnstructured = []
		s3feqchecked = []
		rfcunstructured = []
		rfcchecked = []
		s4unstructured = []
		s4checked = []
		s4dotunstructured = []
		s4dotchecked = []
		s5unstructured = []
		s5checked = []
		s5dotunstructured = []
		s5dotchecked = []
		s5mvrunstructured = []
		s5mvrchecked = []

		### 'FIRST TIER' FIT/NEAR FIT BACKGROUND DATA PARSING:

		# FIT SSN Parser:
		try:
			ssnfindall1 = re.findall(r"See\s{0,}Next\s{0,}Page.{5,100}\([\dl\s-]{9,19}\)", decision, re.S|re.I|re.M)
			if ssnfindall1:
				for item in ssnfindall1:
					ssnsrch1 = re.search(r"\([\dlO\s-]{9,19}\)", item, re.I)
					if bool(ssnsrch1):
						ssnsrch1res = ssnsrch1.group()
						ssnsrch1res = translate(ssnsrch1res, None, "()-\t\n\r\f\v ")
						ssnsrch1res = ssnsrch1res.replace("l", "1")
						ssnsrch1res = ssnsrch1res.replace("O", "0")
						if len(ssnsrch1res) == 9:
							if ssnsrch1res.isdigit():
								ssnunstructured.append(ssnsrch1res)

			ssnfindall2 = re.findall(r"(Refer\s{0,6}to:\s{0,6}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{0,1}\s{0,}[\dOl-]{0,1})([^0-9]+)", decision, re.I)
			if ssnfindall2:
				for item in ssnfindall2:
					ssnres = item[0]
					ssnres = translate(ssnres, None, ":()-\t\n\r\f\v ")
					ssnres = re.sub(r"refer\s{0,}to", "", ssnres, flags=re.I)
					ssnres = ssnres.replace("l", "1")
					ssnres = ssnres.replace("O", "0")
					if len(ssnres) == 9:
						if ssnres.isdigit():
							ssnunstructured.append(ssnres)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT SSN XREF Parser:
		try:
			ssnxreffindall1 = re.findall(r"(XREF:\s{0,6}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{1}\s{0,}[\dOl-]{0,1}\s{0,}[\dOl-]{0,1})([^0-9]+)", decision, re.I)
			ssnxrefreslist = []
			if ssnxreffindall1:
				for item in ssnxreffindall1:
					itemres = item[0]
					itemres = translate(itemres, None, "xrefXREF:()-\t\n\r\f\v ")
					itemres = itemres.replace("l", "1")
					itemres = itemres.replace("O", "0")
					if len(itemres) == 9:
						if itemres.isdigit():
							ssnxrefunstructured.append(itemres)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Claimant Name/Address Parser:
		try:
			claimantfulldatasearch1 = re.search(r"(Date:)(.{5,200}?)(^Notice\s{0,6}of)", decision, re.I|re.S|re.M)
			if bool(claimantfulldatasearch1):
				claimantfulldatares1 = claimantfulldatasearch1.group(2)
				claimantfulldatares1 = re.sub(r"(january|february|march|april|may|june|july|august|september|october|november|december)\s*\d{1,2},\s*\d\s*\d\s*\d\s*\d", "", claimantfulldatares1, flags=re.I)
				claimantfulldatares1search = re.search(r"((^[^\t\r\n\v\f]{0,15}?\d\d\d\d {0,6}?)(\n\n|\r\r))(.*\d\d\d\d\d)", claimantfulldatares1, re.S)
				if bool(claimantfulldatares1search):
					claimantfulldatares1 = claimantfulldatares1search.group(4)
					claimantfulldatares1 = " ".join(claimantfulldatares1.split())
					claimantfulldatares1 = re.sub(r"^[^A-Za-z]*", "", claimantfulldatares1)
					clnmaddunstructured.append(claimantfulldatares1)
				else:
					claimantfulldatares1 = " ".join(claimantfulldatares1.split())
					claimantfulldatares1 = claimantfulldatares1.strip()
					claimantfulldatares1 = re.sub(r"^[^A-Za-z]*", "", claimantfulldatares1)
					clnmaddunstructured.append(claimantfulldatares1)
			# TIP: If no results thus far, search for Spanish language notice language:
			if not clnmaddunstructured:
				claimantfulldataSPANISHsearch1 = re.search(r"(Fecha:)(.{5,200}?)(^Aviso\s{0,6}de)", decision, re.I|re.S|re.M)
				if bool(claimantfulldataSPANISHsearch1):
					claimantfulldatares1 = claimantfulldataSPANISHsearch1.group(2)
					claimantfulldatares1search = re.search(r"(^[^\t\r\n\v\f]{0,20}?\d\d\d\d(  )(\r\v|\v\r|\r\n|\n\r|\n\n|\r\r))(.*\d\d\d\d\d)", claimantfulldatares1, re.S)
					if bool(claimantfulldatares1search):
						claimantfulldatares1 = claimantfulldatares1search.group(4)
						claimantfulldatares1 = " ".join(claimantfulldatares1.split())
						claimantfulldatares1 = re.sub(r"^[^A-Za-z]*", "", claimantfulldatares1)
						clnmaddunstructured.append(claimantfulldatares1)
			# TIP: If no results thus far, remove requirement that 'Notice of' be present:
			if not clnmaddunstructured:
				claimantfulldatasearch2 = re.search(r"(Date:)(.{5,200}?)(Notice\s{0,1}of\s{0,1}[A-Z])", decision, re.I|re.S|re.M)
				if bool(claimantfulldatasearch2):
					claimantfulldatares1 = claimantfulldatasearch2.group(2)
					claimantfulldatares1 = re.sub(r"(january|february|march|april|may|june|july|august|september|october|november|december)\s*\d{1,2},\s*\d\s*\d\s*\d\s*\d", "", claimantfulldatares1, flags=re.I)
					claimantfulldatares1search = re.search(r"((^[^\t\r\n\v\f]{0,15}?\d\d\d\d {0,6}?)(\n\n|\r\r))(.*\d\d\d\d\d)", claimantfulldatares1, re.S)
					if bool(claimantfulldatares1search):
						claimantfulldatares1 = claimantfulldatares1search.group(4)
						claimantfulldatares1 = " ".join(claimantfulldatares1.split())
						claimantfulldatares1 = re.sub(r"^[^A-Za-z]*", "", claimantfulldatares1)
						clnmaddunstructured.append(claimantfulldatares1)
					else:
						claimantfulldatares1 = " ".join(claimantfulldatares1.split())
						claimantfulldatares1 = claimantfulldatares1.strip()
						claimantfulldatares1 = re.sub(r"^[^A-Za-z]*", "", claimantfulldatares1)
						clnmaddunstructured.append(claimantfulldatares1)

			# Clean/uniqify results:
			clnmaddunstructured = [tc.remove_margin_text(nmadd) for nmadd in clnmaddunstructured]
			clnmaddunstructured = [' '.join(nmadd.split()) for nmadd in clnmaddunstructured]
			clnmaddunstructured = list(set(clnmaddunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Claimant Name Parser:
		try:
			clnmunstructured = []
			claimantnamefindall1 = re.findall(r"See\s{0,}Next\s{0,}Page.{5,100}\([\d\|l\s-]{9,19}\)", decision, re.S|re.I|re.M)
			if claimantnamefindall1:
				for clnmstr in claimantnamefindall1:
					clnmstrrev = re.sub(r"See\s{0,}Next\s{0,}Page", "", clnmstr, flags=re.I)
					clnmstrrev = re.sub(r"\([\|\dl\s-]{9,19}\)", "", clnmstrrev, flags=re.I)
					clnmstrrev = re.sub(r"Exhibit ?Number ?([A-Z]{1})?([0-9]{1,2})?([A-Z]{1})?|Exhibit ?N(o|0)\. ?([A-Z]{1})?([0-9]{1,2})?([A-Z]{1})?|Exhibit ?([A-Z]{1})?([0-9]{1,2})?([A-Z]{1})?|Exh\. ?([A-Z]{1})?([0-9]{1,2})?([A-Z]{1})?|Ex\. ?([A-Z]{1})?([0-9]{1,2})?([A-Z]{1})?", "", clnmstrrev, flags=re.I)
					clnmstrrev = " ".join(clnmstrrev.split())
					clnmunstructured.append(clnmstrrev)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Claimant ZIP Parser:
		# OPENQ: Evaluate whether the additional ZIP parsing mechanism
		# here (presently in action) should be retained or expanded to 'repzip'.
		try:
			# Search first tier 'clnmadd' results:
			if clnmaddunstructured:
				for nmaddstr in clnmaddunstructured:
					# TIP: Remove margin text robustly:
					nmaddstr = tc.remove_margin_text(nmaddstr)
					nmaddstr = ' '.join(nmaddstr.split())
					clzipsearch1 = re.search(r"\b(Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming|District of Columbia|Puerto Rico|Guam|American Samoa|U.S. Virgin Islands|Northern Mariana Islands|AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|AS|DC|FM|GU|MH|MP|PW|PR|VI)(\s{1,6}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d])", nmaddstr, re.M|re.S|re.I)
					if bool(clzipsearch1):
						clzipres = clzipsearch1.group(2)
						clzipres = translate(clzipres, None, "\t\n\r\f\v ")
						clzipres = clzipres.replace("|", "1")
						clzipres = clzipres.replace("l", "1")
						if len(clzipres) == 5:
							clzipunstructured.append(clzipres)

				if not clzipunstructured:
					for nmaddstr in clnmaddunstructured:
						# Remove margin text robustly:
						nmaddstr = tc.remove_margin_text(nmaddstr)
						nmaddstr = ' '.join(nmaddstr.split())
						# Locate all 5 digit entities in nmaddstr
						# and take latest indexed (contextually
						# zip codes appear at close of address data, so
						# this helps reduce false positive matches from
						# earlier 5 digit street addresses):
						clzipfindall1 = re.findall(r"([\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d])(?:[^\d]|$)", nmaddstr)
						if clzipfindall1:
							clzipunstructured.append(clzipfindall1[-1])

				clzipunstructured = list(set(clzipunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Rep Name/Address Parser:
		try:
			repfulldatasearch1 = re.search("(^cc:\s{0,6}|^c:\s{0,6})((.{5,200}?)(Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming|District of Columbia|Puerto Rico|Guam|American Samoa|U.S. Virgin Islands|Northern Mariana Islands|AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|AS|DC|FM|GU|MH|MP|PW|PR|VI)(\s{1,6}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]))", decision, re.M|re.S|re.I)
			if bool(repfulldatasearch1):
				repfulldatares1 = repfulldatasearch1.group(2)
				# Clean result:
				repfulldatares1 = tc.remove_margin_text(repfulldatares1)
				repfulldatares1 = " ".join(repfulldatares1.split())
				repnmaddunstructured.append(repfulldatares1)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Rep ZIP Parser:
		try:
			if repnmaddunstructured:
				for nmaddstr in repnmaddunstructured:
					nmaddstr = ' '.join(nmaddstr.split())
					repzipsearch1 = re.search(r"(Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming|District of Columbia|Puerto Rico|Guam|American Samoa|U.S. Virgin Islands|Northern Mariana Islands|AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|AS|DC|FM|GU|MH|MP|PW|PR|VI)(\s{1,6}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d])", nmaddstr, re.M|re.S|re.I)
					if bool(repzipsearch1):
						repzipres = repzipsearch1.group(2)
						repzipres = translate(repzipres, None, "\t\n\r\f\v ")
						repzipres = repzipres.replace("|", "1")
						repzipres = repzipres.replace("l", "1")
						repzipres = repzipres.strip()
						if len(repzipres) == 5:
							repzipunstructured.append(repzipres)
				if not repzipunstructured:
					for nmaddstr in repnmaddunstructured:
						# Remove margin text robustly:
						nmaddstr = tc.remove_margin_text(nmaddstr)
						nmaddstr = ' '.join(nmaddstr.split())
						# Locate all 5 digit entities in nmaddstr
						# and take latest indexed (contextually
						# zip codes appear at close of address data, so
						# this helps reduce false positive matches from
						# earlier 5 digit street addresses):
						repzipfindall1 = re.findall(r"([\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d]\s{0,3}[\|l\d])(?:[^\d]|$)", nmaddstr)
						if repzipfindall1:
							repzipunstructured.append(repzipfindall1[-1])

		except Exception:
			logger.exception('EXCEPTION')

		# FIT Rep Name Parser:
		# TODO: Update code to utilize Stanford NER or equivalent NER to parse
		# *sentences* matching these REGEX patterns for names.
		try:
			repnamesearch1 = re.search(r"(The\s{0,6}claimant\s{0,6}(also)?\s{0,6}is\s{0,6}(also)?\s{0,6}represented\s{0,6}by)(.{5,100}?)(,|\band\b|\bas\s{0,6}well\s{0,6}as\b)", decision, re.I|re.S)
			repnamesearch2 = re.search(r"(The\s{0,6}claimant\s{0,6}(also)?\s{0,6}is\s{0,6}(also)?\s{0,6}represented\s{0,6}by)(.{5,150}?)(,|\bof\b|\bfrom\b)", decision, re.I|re.S)
			if bool(repnamesearch1):
				repnameres1 = repnamesearch1.group(4)
				repnameres1 = re.sub(r"attorneys?|non\-attorneys?|representatives?|lawyers?", " ", repnameres1, flags=re.I)
				repnameres1 = ' '.join(repnameres1.split())
				# Reduce positive value noise by requiring at least 2 consecutive
				# upper case words at the beginning of this string:
				repnameres1split = repnameres1.split()
				if len(repnameres1split) >= 2:
					repnameres1splitcapslist = []
					for word in repnameres1split:
						if word != "":
							if word[0].isupper():
								repnameres1splitcapslist.append(word)
							# TIP: Accept nobillary particles.
							elif word in ["de", "van", "der", "la", "von", "y"]:
								repnameres1splitcapslist.append(word)
							else:
								break
					if len(repnameres1splitcapslist) >= 2:
						repnameres1joined = " ".join(repnameres1splitcapslist)
						repnameres1joined = re.sub(r",\Z", "", repnameres1joined)
						repnmunstructured.append(repnameres1joined)
			if bool(repnamesearch2):
				repnameres2 = repnamesearch2.group(4)
				repnameres2 = re.sub(r"attorneys?|non\-attorneys?|representatives?|lawyers?", " ", repnameres2, flags=re.I)
				repnameres2 = ' '.join(repnameres2.split())
				repnameres2split = re.split(r"\band\b|\bas ?well ?as\b", repnameres2, flags=re.I)
				for res in repnameres2split:
					# Reduce positive value noise by requiring at least 2 consecutive
					# upper case words at the beginning of this string:
					for word in res.split():
						repnameres2splitcapslist = []
						if word != "":
							if word[0].isupper():
								repnameres2splitcapslist.append(word)
							# TIP: Accept nobillary particles.
							elif word in ["de", "van", "der", "la", "von", "y"]:
								repnameres2splitcapslist.append(word)
							else:
								break
						if len(repnameres2splitcapslist) >= 2:
							repnameres2joined = " ".join(repnameres2splitcapslist)
							repnameres2joined = re.sub(r",\Z", "", repnameres2joined)
							repnmunstructured.append(repnameres2joined)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Adjudicator Name Parser:
		# TIP: FIT presently outputs the adjudicator's name at the end of
		# the notice *and* after the 'DECISION' paragraph.
		# TODO: Update code to utilize Stanford NER or equivalent NER to parse
		# *sentences* matching these REGEX patterns for names.
		try:
			# TODO: Revise using name_searcher() REGEX pattern lessons.
			adjudicatornamesearch1 = re.search(r"^([A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Z'a-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
			adjudicatornamesearch2 = re.search(r"^([A-Z]{1}[A-Za-z\-]+\s+[A-Z\.]{1,2}\s+[A-Z]{1}[A-Za-z'\-]+\s+(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
			adjudicatornamesearch3 = re.search(r"^(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Z'a-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
			adjudicatornamesearch4 = re.search(r"^([A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Z'a-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
			adjudicatornamesearch5 = re.search(r"^(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Z'a-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
			adjudicatornamesearch6 = re.search(r"^(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Z'a-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\. {0,1}S\. {0,1}|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)

			if bool(adjudicatornamesearch1):
				item = adjudicatornamesearch1.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if bool(adjudicatornamesearch2):
				item = adjudicatornamesearch2.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if bool(adjudicatornamesearch3):
				item = adjudicatornamesearch3.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if bool(adjudicatornamesearch4):
				item = adjudicatornamesearch4.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if bool(adjudicatornamesearch5):
				item = adjudicatornamesearch5.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if bool(adjudicatornamesearch6):
				item = adjudicatornamesearch6.group()
				item = " ".join(item.split())
				if bool(re.search("Regional ?Chief", item, re.I)) is False:
					item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
					item = re.sub(r"United ?States|U\. {0,1}S\. {0,1}", "", item, flags=re.I)
					item = item.strip()
					item = item.replace(",", "")
					adjudicatorunstructured.append(item)
			if len(adjudicatorunstructured) > 1:
				adjudicatorunstructuredset = set(adjudicatorunstructured)
				adjudicatorunstructured = []
				for item in adjudicatorunstructuredset:
					adjudicatorunstructured.append(item)
			if len(adjudicatorunstructured) > 1:
				adjudicatorunstructuredmax = max(adjudicatorunstructured, key=len)
				adjudicatorunstructured = []
				adjudicatorunstructured.append(adjudicatorunstructuredmax)

			if not adjudicatorunstructured:
				adjudicatornamesearch1 = re.search(r"(^[\d\sA-Za-z-'.,]{5,45})( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decision, re.M)
				if bool(adjudicatornamesearch1):
					adjudicatornamesearch1res = adjudicatornamesearch1.group(1)
					adjudicatornamesearch1res = re.sub("\s+", " ", adjudicatornamesearch1res)
					adjudicatornamesearch2 = re.search(r"(^[A-Z][A-Za-z-'.]+(?= [A-Z])(?: [A-Z][A-Za-z-'.]+)+)", adjudicatornamesearch1res)
					if bool(adjudicatornamesearch2):
						adjudicatornamesearch2res = adjudicatornamesearch2.group()
						adjudicatorunstructured.append(adjudicatornamesearch2res)

			# If still no result, try searching without the requirement that the name appear at the beginning of a line:
			if not adjudicatorunstructured:
				adjudicatornamesearch1 = re.search(r"([A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Za-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
				adjudicatornamesearch2 = re.search(r"([A-Z]{1}[A-Za-z\-]+\s+[A-Z\.]{1,2}\s+[A-Z]{1}[A-Za-z\-]+\s+(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
				adjudicatornamesearch3 = re.search(r"(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Za-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
				adjudicatornamesearch4 = re.search(r"([A-Z]{1}[A-Za-z\-]+\s+[A-Z]{1}[A-Za-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
				adjudicatornamesearch5 = re.search(r"(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Za-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)
				adjudicatornamesearch6 = re.search(r"(([A-Z]{1,2}\s+|[A-Z]{1,2}\.\s+)[A-Z]{1}[A-Za-z\-]+\s{0,6}(, Jr\.|, Sr\.|, II|, III|, IV|, V|, Esquire|, Esq\.|Jr\.|Sr\.|II|III|IV|V|Esquire|Esq\.|))( {0,6}United {0,6}States| {0,6}U\.S\.|)( {0,6}Administrative {0,6}Law {0,6}Judge| {0,6}Attorney {0,6}Advisor)", decisionfindingsltd, re.M)

				if bool(adjudicatornamesearch1):
					item = adjudicatornamesearch1.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if bool(adjudicatornamesearch2):
					item = adjudicatornamesearch2.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if bool(adjudicatornamesearch3):
					item = adjudicatornamesearch3.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if bool(adjudicatornamesearch4):
					item = adjudicatornamesearch4.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if bool(adjudicatornamesearch5):
					item = adjudicatornamesearch5.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if bool(adjudicatornamesearch6):
					item = adjudicatornamesearch6.group()
					item = " ".join(item.split())
					if bool(re.search("Regional ?Chief", item, re.I)) is False:
						item = re.sub(r"Administrative ?Law ?Judge|Attorney ?Advisor", "", item, flags=re.I)
						item = re.sub(r"United ?States|U\.S\.", "", item, flags=re.I)
						item = item.strip()
						item = item.replace(",", "")
						adjudicatorunstructured.append(item)
				if len(adjudicatorunstructured) > 1:
					adjudicatorunstructuredset = set(adjudicatorunstructured)
					adjudicatorunstructured = []
					for item in adjudicatorunstructuredset:
						adjudicatorunstructured.append(item)
				if len(adjudicatorunstructured) > 1:
					adjudicatorunstructuredmax = max(adjudicatorunstructured, key=len)
					adjudicatorunstructured = []
					adjudicatorunstructured.append(adjudicatorunstructuredmax)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Disposition Type Parser:
		# TODO: Update to detect T16 dismissal + T2 non-dismissal.
		try:
			disptypeunstructuredTEMP = []
			unfavfindall1 = re.search(r"^Notice\s{0,6}of\s{0,6}(Decision|Amended\s{0,6}Decision).{1,5}Unfavorable", decision, re.S|re.I|re.M)
			pfavfindall1 = re.search(r"^Notice\s{0,6}of\s{0,6}(Decision|Amended\s{0,6}Decision).{1,5}Partially\s{0,6}Favorable", decision, re.S|re.I|re.M)
			ffavfindall1 = re.search(r"^Notice\s{0,6}of\s{0,6}(Decision|Amended\s{0,6}Decision).{1,5}Fully\s{0,6}Favorable", decision, re.S|re.I|re.M)
			ffavfindall2 = re.search(r"^Notice\s{0,6}of\s{0,6}Attorney.{1,3}Advisor\s{0,6}(Decision|Amended\s{0,6}Decision).{1,5}Fully\s{0,6}Favorable", decision, re.S|re.I|re.M)
			dismissfindall1 = re.search(r"^Notice\s{0,6}of\s{0,6}Dismissal", decision, re.S|re.I|re.M)
			if bool(unfavfindall1):
				disptypeunstructuredTEMP.append("1")
			if bool(pfavfindall1):
				disptypeunstructuredTEMP.append("3")
			if bool(ffavfindall1):
				disptypeunstructuredTEMP.append("5")
			if bool(ffavfindall2):
				disptypeunstructuredTEMP.append("5")
			if bool(dismissfindall1):
				disptypeunstructuredTEMP.append("7")
			# If you've extracted a decision type, check for FIT T2 dismissal language in "Decision" section; if found, replace the existing decision type with its more detailed counterpart:
			# TODO: Update for T16 dismissals.
			t2decisionsecdismisssearch1 = re.search(r"a\s{0,6}period\s{0,6}of\s{0,6}disability\s{0,6}and\s{0,6}disability\s{0,6}insurance\s{0,6}benefits\s{0,6}under\s{0,6}Sections\s{0,6}216\(i\)\s{0,6}and\s{0,6}223\(a\)\s{0,6}of\s{0,6}the\s{0,6}Social\s{0,6}Security\s{0,6}Act\s{0,6}is\s{0,6}(hereby|)\s{0,6}dismissed", decision, re.I)
			if bool(t2decisionsecdismisssearch1):
				if disptypeunstructuredTEMP:
					for dispositiontype in disptypeunstructuredTEMP:
						if dispositiontype == "1":
							disptypeunstructured.append("2")
						elif dispositiontype == "3":
							disptypeunstructured.append("4")
						elif dispositiontype == "5":
							disptypeunstructured.append("6")
						elif dispositiontype == "7":
							disptypeunstructured.append("7")
			else:
				for dispositiontype in disptypeunstructuredTEMP:
					disptypeunstructured.append(dispositiontype)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Claim Type Parser (NOTE: No exclusivity req b/c haven't
		# verified that these appear only once):
		try:
			#NOTE: Search lang does NOT appear in T2 CDB or T2 CDR decisions.
			t2regcomp1 = re.compile(r"Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}a\s{0,6}period\s{0,6}of\s{0,6}disability\s{0,6}and disability\s{0,6}insurance\s{0,6}benefits", re.S|re.I)
			t2regsearch1 = re.search(t2regcomp1, decision)
			#NOTE: Search lang does NOT appear in T2 REG or T2 CDR decisions.
			t2cdbcomp1 = re.compile(r"the\s{0,6}claimant\s{0,6}had\s{0,6}not\s{0,6}attained\s{0,6}age\s{0,6}22", re.S|re.I)
			t2cdbsearch1 = re.search(t2cdbcomp1, decision)
			#NOTE: Search lang DOES appear in T16 CHILD decisions. Does NOT appear in T16 AGE 18 or T16 CDR decisions.
			t16regcomp1 = re.compile(r"Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}supplemental\s{0,6}security\s{0,6}income", re.S|re.I)
			t16regsearch1 = re.search(t16regcomp1, decision)
			#NOTE: Search lang does NOT appear in T16 REG decisions.
			t16childcomp1 = re.compile(r"1614\(a\)\(3\)\(C\)", re.S|re.I)
			t16childsearch1 = re.search(t16childcomp1, decision)
			#NOTE: Search lang is unique to T16 child->adult decisions:
			t16childadultcomp1 = re.compile(r"claimant\s{0,6}was\s{0,6}under\s{0,6}age\s{0,6}18\s{0,6}at\s{0,6}the\s{0,6}time\s{0,6}of\s{0,6}the\s{0,6}application\s{0,6}and\s{0,6}attained\s{0,6}age\s{0,6}18\s{0,6}before\s{0,6}the\s{0,6}date\s{0,6}of\s{0,6}this\s{0,6}decision")
			t16childadultsearch1 = re.search(t16childadultcomp1, decision)
			#NOTE: Search lang does NOT appear in T16 REG decisions.
			t16age18comp1 = re.compile(r"continuing\s{0,6}eligibility\s{0,6}for\s{0,6}supplemental\s{0,6}security\s{0,6}income\s{0,6}upon\s{0,6}attaining\s{0,6}age\s{0,6}18", re.S|re.I)
			t16age18search1 = re.search(t16age18comp1, decision)
			#NOTE: Search lang does NOT appear in either T2 REG or T16 REG claim decisions.
			cdrcomp1 = re.compile(r"To\s{0,6}determine\s{0,6}if\s{0,6}the\s{0,6}claimant\s{0,6}continues\s{0,6}to\s{0,6}be\s{0,6}disabled", re.S|re.I)
			cdrsearch1 = re.search(cdrcomp1, decision)
			#NOTE: Search lang does NOT appear in other CDR claim types:
			cdrchildcomp1 = re.compile(r"medical\s*improvement\s*review\s*standard|To\s*determine\s*if\s*(the|)\s*claimant\s*continues\s*to\s*be\s*disabled\s*as\s*an\s*individual\s*who\s*has\s*not\s*attained\s*age\s*18", re.I)
			cdrchildsearch1 = re.search(cdrchildcomp1, decision)
			#NOTE: Search lang does NOT appear in any other claim type:
			t2dwbcomp1 = re.compile(r"Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}disabled\s{0,6}widow", re.S|re.I)
			t2dwbsearch1 = re.search(t2dwbcomp1, decision)
			# Assign claim types:
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2cdbsearch1) is False:
						if bool(t16age18search1) is False:
							if bool(t2dwbsearch1) is False:
								claimtypeunstructured.append("T2 DIB")
			if bool(t2cdbsearch1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2regsearch1) is False:
						if bool(t16age18search1) is False:
							claimtypeunstructured.append("T2 CDB")
			if bool(t2dwbsearch1) is True:
				if bool(t2regsearch1) is False:
					if bool(t16regsearch1) is False:
						claimtypeunstructured.append("T2 DWB")
			if bool(t16regsearch1) is True:
				if bool(t2regsearch1) is False:
					if bool(t2cdbsearch1) is False:
						if bool(t16childsearch1) is False:
							if bool(t2dwbsearch1) is False:
								claimtypeunstructured.append("T16 SSI")
			if bool(t16childsearch1) is True:
				if bool(t16childadultsearch1) is False:
					if bool(cdrchildsearch1) is False:
						claimtypeunstructured.append("T16 SSI Child")
			if bool(t16childadultsearch1) is True:
				claimtypeunstructured.append("T16 SSI Child+Adult")
			if bool(t16age18search1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2regsearch1) is False:
						if bool(t2cdbsearch1) is False:
							if bool(t2dwbsearch1) is False:
								claimtypeunstructured.append("T16 SSI Age 18 Redetermination")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is False:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T16 SSI")
			if bool(t2regsearch1) is False:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 CDB")
									claimtypeunstructured.append("T16 SSI")
			if bool(t2regsearch1) is False:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is False:
						if bool(t2dwbsearch1) is True:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 DWB")
									claimtypeunstructured.append("T16 SSI")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T2 CDB")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2cdbsearch1) is False:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is True:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T16 SSI Age 18 Redetermination")
			if bool(t2regsearch1) is False:
				if bool(t16regsearch1) is False:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is True:
									claimtypeunstructured.append("T2 CDB")
									claimtypeunstructured.append("T16 SSI Age 18 Redetermination")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T2 CDB")
									claimtypeunstructured.append("T16 SSI")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is False:
						if bool(t2dwbsearch1) is True:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is False:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T2 DWB")
									claimtypeunstructured.append("T16 SSI")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is False:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is True:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T2 CDB")
									claimtypeunstructured.append("T16 SSI Age 18 Redetermination")
			if bool(t2regsearch1) is True:
				if bool(t16regsearch1) is True:
					if bool(t2cdbsearch1) is True:
						if bool(t2dwbsearch1) is False:
							if bool(t16childsearch1) is False:
								if bool(t16age18search1) is True:
									claimtypeunstructured.append("T2 DIB")
									claimtypeunstructured.append("T2 CDB")
									claimtypeunstructured.append("T16 SSI Age 18 Redetermination")
									claimtypeunstructured.append("T16 SSI")
			if bool(cdrsearch1) is True:
				if bool(cdrchildsearch1) is False:
					cdrt16search1 = re.search(r"disability\s{0,6}under\s{0,6}section\s{0,6}1614", decision, re.I)
					cdrt2search1 = re.search(r"disability\s{0,6}under\s{0,6}(sections|section)\s{0,6}216", decision, re.I)
					if bool(cdrt2search1) is True:
						claimtypeunstructured.append("T2 DIB CDR")
					if bool(cdrt16search1) is True:
						claimtypeunstructured.append("T16 SSI CDR")
					if (bool(cdrt2search1) is False) and (bool(cdrt16search1) is False):
						claimtypeunstructured.append("CDR")
			if bool(cdrchildsearch1) is True:
				claimtypeunstructured.append("T16 SSI CDR Child")
			# FIT "Claim For" claim type crosschecking:
			claimforclaimlist = []
			claimforsearch1 = re.search(r"(IN\s{0,6}THE\s{0,6}CASE\s{0,6}OF\s{0,6}CLAIM\s{0,6}FOR)(.*?)(\(Social Security Number\))", decision, re.S)
			if bool(claimforsearch1):
				claimforres = claimforsearch1.group(2)
				if bool(re.search(r"period\s{0,6}of\s{0,6}disability", claimforres, re.I)):
					claimforclaimlist.append("T2 DIB")
				if bool(re.search(r"widow", claimforres, re.I)) is True:
					claimforclaimlist.append("T2 DWB")
				if bool(re.search(r"supplemental\s{0,6}security", claimforres, re.I)) is True:
					claimforclaimlist.append("T16 SSI")
				if bool(re.search(r"child\s{0,6}disability", claimforres, re.I)) is True:
					claimforclaimlist.append("T2 CDB")
			# If 'claimtypeunstructured' and 'claimforclaimlist' have entries, check if 'claimfor' claims are present in 'unstructured'; if not, add them.	If no 'unstructured' entries, append all claimforclaims to 'unstructured':
			if claimtypeunstructured:
				if claimforclaimlist:
					claimtypeunstructuredstring = " ".join(claimtypeunstructured)
					for claimforclaim in claimforclaimlist:
						if bool(re.search(claimforclaim, claimtypeunstructuredstring)) is False:
							claimtypeunstructured.append(claimforclaim)
						else:
							pass
			else:
				for claimforclaim in claimforclaimlist:
					claimtypeunstructured.append(claimforclaim)
			# Remove erroneous duplicates and assign as a string:
			if len(claimtypeunstructured) > 1:
				claimtypeunstructured = list(set(claimtypeunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT DAA Materiality Parser (NOTE: No exclusivity because
		# frequency is irrelevant; if this FIT language is present, it
		# strongly suggests a material DAA finding):
		try:
			fitdaamaterialsearch1 = re.search("(\d\.\s{1,3}|\d\d\.\s{1,3})The\s{1,3}substance\s{1,3}use\s{1,3}disorder\s{1,3}is\s{1,3}a\s{1,3}contributing\s{1,3}factor\s{1,3}material\s{1,3}to\s{1,3}the\s{1,3}determination\s{1,3}of\s{1,3}disability\s{1,3}because", decision, re.I|re.M)
			if bool(fitdaamaterialsearch1) is True:
				daamatunstructured.append("1")
		except Exception:
			logger.exception('EXCEPTION')

		# FIT DOF Parser:
		# TIP: Solely T16 age 18 redetermination and CDRs do NOT reference
		# DOF in 2014 FIT templates.
		try:
			t2regdofunstructured = "U"
			t2dwbdofunstructured = "U"
			t2cdbdofunstructured = "U"
			t16regorchilddofunstructured = "U"
			t2regdofsearch1 = re.search(r"(Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}a\s{0,6}period\s{0,6}of\s{0,6}disability\s{0,6}and\s{0,6}disability\s{0,6}insurance\s{0,6}benefits.{1,25}on\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			t2cdbdofsearch1 = re.search(r"(Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}child.{1,25}insurance\s{0,6}benefits.{1,25}on\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			t2dwbdofsearch1 = re.search(r"(Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}disabled\s{0,6}widow.{1,15}benefits.{1,25}on\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			t16regorchilddofsearch1 = re.search(r"(Based\s{0,6}on\s{0,6}the\s{0,6}application\s{0,6}for\s{0,6}supplemental\s{0,6}security\s{0,6}income.{1,25}on\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			t16regorchilddofsearch2 = re.search(r"The\s{0,6}claimant\s{0,6}has\s{0,6}been\s{0,6}disabled\s{0,6}under\s{0,6}section\s{0,6}1614.{0,15}of\s{0,6}the\s{0,6}Social\s{0,6}Security\s{0,6}Act\s{0,6}since\s{0,6}((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d),\s{0,6}the\s{0,6}date\s{0,6}the\s{0,6}(prior|)\s{0,6}application\s{0,6}for\s{0,6}supplemental\s{0,6}security\s{0,6}income\s{0,6}was\s{0,6}filed", decision, re.I|re.S)

			if bool(t2regdofsearch1) is True:
				t2regdofunstructured = t2regdofsearch1.group(2)
				t2regdofunstructured = dh.parse_date_tostr(t2regdofunstructured)
			if bool(t2dwbdofsearch1) is True:
				t2dwbdofunstructured = t2dwbdofsearch1.group(2)
				t2dwbdofunstructured = dh.parse_date_tostr(t2dwbdofunstructured)
			if bool(t2cdbdofsearch1) is True:
				t2cdbdofunstructured = t2cdbdofsearch1.group(2)
				t2cdbdofunstructured = dh.parse_date_tostr(t2cdbdofunstructured)
			if bool(t16regorchilddofsearch1) is True:
				t16regorchilddofunstructured = t16regorchilddofsearch1.group(2)
				t16regorchilddofunstructured = dh.parse_date_tostr(t16regorchilddofunstructured)
			if bool(t16regorchilddofsearch2) is True:
				t16regorchilddofunstructured = t16regorchilddofsearch2.group(1)
				t16regorchilddofunstructured = dh.parse_date_tostr(t16regorchilddofunstructured)
			# Assign DOF values to *pertinent* claim types found in
			# claimtypeunstructured (e.g. those where DOF would be mentioned)
			# by # of pertinent claims; if claimtypeunstructured is empty, assign
			#$ manually:
			if claimtypeunstructured:
				if len(claimtypeunstructured) == 1:
					if claimtypeunstructured[0] == "T2 DIB":
						if t2regdofunstructured != "U":
							dofunstructured.append(t2regdofunstructured)
					if claimtypeunstructured[0] == "T2 CDB":
						if t2cdbdofunstructured != "U":
							dofunstructured.append(t2cdbdofunstructured)
					if claimtypeunstructured[0] == "T2 DWB":
						if t2dwbdofunstructured != "U":
							dofunstructured.append(t2dwbdofunstructured)
					if claimtypeunstructured[0] == "T16 SSI":
						if t16regorchilddofunstructured != "U":
							dofunstructured.append(t16regorchilddofunstructured)
					if claimtypeunstructured[0] == "T16 SSI Child":
						if t16regorchilddofunstructured != "U":
							dofunstructured.append(t16regorchilddofunstructured)
					if claimtypeunstructured[0] == "T16 SSI Child+Adult":
						if t16regorchilddofunstructured != "U":
							dofunstructured.append(t16regorchilddofunstructured)
				elif len(claimtypeunstructured) > 1:
					if "T2 DIB" in claimtypeunstructured:
						if t2regdofunstructured != "U":
							entry = t2regdofunstructured + " (T2 DIB)"
							dofunstructured.append(entry)
					if "T2 CDB" in claimtypeunstructured:
						if t2cdbdofunstructured != "U":
							entry = t2cdbdofunstructured + " (T2 CDB)"
							dofunstructured.append(entry)
					if "T2 DWB" in claimtypeunstructured:
						if t2dwbdofunstructured != "U":
							entry = t2dwbdofunstructured + " (T2 DWB)"
							dofunstructured.append(entry)
					if "T16 SSI" in claimtypeunstructured:
						if t16regorchilddofunstructured != "U":
							entry = t16regorchilddofunstructured + " (T16 SSI)"
							dofunstructured.append(entry)
					if "T16 SSI Child" in claimtypeunstructured:
						if t16regorchilddofunstructured != "U":
							entry = t16regorchilddofunstructured + " (T16 SSI Child)"
							dofunstructured.append(entry)
					if "T16 SSI Child+Adult" in claimtypeunstructured:
						if t16regorchilddofunstructured != "U":
							entry = t16regorchilddofunstructured + " (T16 SSI Child+Adult)"
							dofunstructured.append(entry)
			else:
				if t2regdofunstructured != "U":
					t2regdofunstructuredwrite = t2regdofunstructured + " (T2 DIB)"
					dofunstructured.append(t2regdofunstructuredwrite)
				if t2cdbdofunstructured != "U":
					t2cdbdofunstructuredwrite = t2cdbdofunstructured + " (T2 CDB)"
					dofunstructured.append(t2cdbdofunstructuredwrite)
				if t2dwbdofunstructured != "U":
					t2dwbdofunstructuredwrite = t2dwbdofunstructured + " (T2 DWB)"
					dofunstructured.append(t2dwbdofunstructuredwrite)
				if t16regorchilddofunstructured != "U":
					t16regorchilddofunstructuredwrite = t16regorchilddofunstructured + " (T16 SSI)"
					dofunstructured.append(t16regorchilddofunstructuredwrite)
		except Exception:
			logger.exception('EXCEPTION')

		# FIT/Near FIT Amended AOD/AOD Parser:
		try:
			# FIT normal AOD language variations (in the 'Background' section):
			aodsearch1 = re.search(r"(alleged\s{0,6}disability\s{0,6}beginning\s{0,6}on|alleged\s{0,6}disability\s{0,6}beginning|alleging\s{0,6}disability\s{0,6}beginning\s{0,6}on|alleging\s{0,6}disability\s{0,6}beginning|alleges\s{0,6}disability\s{0,6}beginning\s{0,6}on|alleges\s{0,6}disability\s{0,6}beginning|disability\s{0,6}beginning\s{0,6}on|disability\s{0,6}beginning|with\s{0,6}an\s{0,6}alleged\s{0,6}disability\s{0,6}onset\s{0,6}date\s{0,6}of|alleged\s{0,6}disability\s{0,6}onset\s{0,6}date\s{0,6}of|alleging\s{0,6}disability\s{0,6}since)(\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.S|re.I)
			# FIT '[AOD], the alleged onset date' AOD language (in the 'Issues' or 'Findings' section):
			aodsearch2 = re.search(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)(,\s{0,6}the\s{0,6}alleged\s{0,6}onset\s{0,6}date)", decision, re.S|re.I)
			# Bench decision unique AOD language:
			aodsearch3 = re.search(r"(disability\s{0,6}is\s{0,6}alleged\s{0,6}beginning\s{0,6}on\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.S|re.I)
			# Bench decision unique amended AOD language:
			amendedaodsearch1 = re.search(r"(has\s{0,6}amended\s{0,6}the\s{0,6}alleged\s{0,6}onset\s{0,6}date\s{0,6}from\s{0,6}.{1,25}\d {0,2}\d {0,2}\d {0,2}\d\s{0,6}to\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.S|re.I)
			# FIT amended AOD language search (in the 'Background' section):
			amendedaodsearch2 = re.search(r"(The\s{0,6}claimant\s{0,6}has\s{0,6}amended\s{0,6}(the|his|her|their)\s{0,6}alleged\s{0,6}onset\s{0,6}date\s{0,6}of\s{0,6}disability\s{0,6}to\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.S|re.I)
			# FIT amended AOD language search (likely in the 'Findings' section):
			amendedaodsearch3 = re.search(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)(,\s{0,6}the\s{0,6}amended\s{0,6}alleged\s{0,6}onset\s{0,6}date)", decision, re.S|re.I)
			# Non-FIT amended AOD language search (likely in the 'Background' section):
			amendedaodsearch4 = re.search(r"(amended\s{0,6}(his|her|their)\s{0,6}onset\s{0,6}to\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.S|re.I)
			# Assign 1+ amended AODs:
			if bool(amendedaodsearch1):
				amendedaodres1 = amendedaodsearch1.group(2)
				amendedaodres1 = dh.parse_date_tostr(amendedaodres1)
				aodunstructured.append(amendedaodres1)
				aodamendverunstructured.append("1")
			if bool(amendedaodsearch2):
				amendedaodres2 = amendedaodsearch2.group(3)
				amendedaodres2 = dh.parse_date_tostr(amendedaodres2)
				aodunstructured.append(amendedaodres2)
				aodamendverunstructured.append("1")
			if bool(amendedaodsearch3):
				amendedaodres3 = amendedaodsearch3.group(1)
				amendedaodres3 = dh.parse_date_tostr(amendedaodres3)
				aodunstructured.append(amendedaodres3)
				aodamendverunstructured.append("1")
			if bool(amendedaodsearch4):
				amendedaodres4 = amendedaodsearch4.group(3)
				amendedaodres4 = dh.parse_date_tostr(amendedaodres4)
				aodunstructured.append(amendedaodres4)
				aodamendverunstructured.append("1")
			if len(aodunstructured) > 1:
				aodunstructured = list(set(aodunstructured))
			# If no amended AOD found at all, but 1+ regular AOD found:
			if not aodamendverunstructured:
				if bool(aodsearch1):
					aodres1 = aodsearch1.group(3)
					aodres1 = dh.parse_date_tostr(aodres1)
					aodunstructured.append(aodres1)
				if bool(aodsearch2):
					aodres2 = aodsearch2.group(1)
					aodres2 = dh.parse_date_tostr(aodres2)
					aodunstructured.append(aodres2)
				if bool(aodsearch3):
					aodres3 = aodsearch3.group(2)
					aodres3 = dh.parse_date_tostr(aodres3)
					aodunstructured.append(aodres3)
				if len(aodunstructured) > 1:
					aodunstructured = list(set(aodunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT DLI Parser:
		try:
			# FIT DLI from "Issues" section:
			dlifitsearch1 = re.search(r"(claimant\s{0,6}has\s{0,6}acquired\s{0,6}sufficient\s{0,6}quarters\s{0,6}of\s{0,6}coverage\s{0,6}to\s{0,6}remain\s{0,6}insured\s{0,6}through\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			# FIT DLI from "Findings" section:
			dlifitsearch2 = re.search(r"(claimant\s{0,6}(last\s{0,6}met|meets)\s{0,6}the\s{0,6}insured\s{0,6}status\s{0,6}requirements\s{0,6}of\s{0,6}the\s{0,6}Social\s{0,6}Security\s{0,6}Act\s{0,6}(on\s{0,6}|through\s{0,6}))((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			# FIT DLI from "Decision" section:
			dlifitsearch3 = re.search(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)(,\s{0,6}the\s{0,6}date\s{0,6}last\s{0,6}insured)", decision, re.I|re.S)
			# FIT DLI from "Findings" section (apparently in FFAV only):
			dlifitsearch4 = re.search(r"((\d\.\s{1,3}|\d\d\.\s{1,3})The\s{0,6}claimant['si\s]{0,6}date\s{0,6}last\s{0,6}insured\s{0,6}is\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decision, re.I|re.S)
			if bool(dlifitsearch1):
				dlires1 = dlifitsearch1.group(2)
				dlires1 = dh.parse_date_tostr(dlires1)
				dliunstructured.append(dlires1)
			if bool(dlifitsearch2):
				dlires2 = dlifitsearch2.group(4)
				dlires2 = dh.parse_date_tostr(dlires2)
				dliunstructured.append(dlires2)
			if bool(dlifitsearch3):
				dlires3 = dlifitsearch3.group(1)
				dlires3 = dh.parse_date_tostr(dlires3)
				dliunstructured.append(dlires3)
			if bool(dlifitsearch4):
				dlires4 = dlifitsearch4.group(3)
				dlires4 = dh.parse_date_tostr(dlires4)
				dliunstructured.append(dlires4)
			if len(dliunstructured) > 1:
				dliunstructured = list(set(dliunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT DID Parser:
		try:
			# Attempt to isolate text after the 'Refer to:' SSN portion
			# (sometimes decisional cover sheets and other erroneously
			# placed/scanned materials were resulting in errors in extracting
			# this datapoint):
			diddecisioncut = decision
			diddecisioncutsearch = re.search(r"refer\s{0,}to:.*", decision, re.S|re.I)
			if bool(diddecisioncutsearch):
				diddecisioncut = diddecisioncutsearch.group()
			didsearch1 = re.search(r"(Date:\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", diddecisioncut, re.M|re.I)
			if bool(didsearch1):
				didres1 = didsearch1.group(2)
				didres1 = dh.parse_date_tostr(didres1)
				didunstructured.append(didres1)
			didsearch2 = re.search(r"(Administrative\s{0,6}Law\s{0,6}Judge\s{1,8})((^january|^february|^march|^april|^may|^june|^july|^august|^september|^october|^november|^december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", diddecisioncut, re.S|re.I|re.M)
			if bool(didsearch2):
				didres2 = didsearch2.group(2)
				didres2 = dh.parse_date_tostr(didres2)
				didunstructured.append(didres2)
			if len(didunstructured) > 1:
				didunstructured = list(set(didunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# FIT Medical Improvement Period Parser:
		# TIP: If anything, will output a single month approximation
		# (rounded to the nearest month after conversion) as a
		# stringified integer.
		try:
			mipsearch1 = re.search(r"(Medical\s{0,6}improvement\s{0,6}is\s{0,6}expected\s{0,6}with\s{0,6}appropriate\s{0,6}treatment[.\s]{0,6}\s{0,6}Consequently[,\s]{0,6}a\s{0,6}continuing\s{0,6}disability\s{0,6}review\s{0,6}is\s{0,6}recommended\s{0,6}in\s{0,6})([0-9]{1,3})(\s{0,6}month|\s{0,6}year|\s{0,6}day)", decision, re.I)
			if bool(mipsearch1):
				mipres = mipsearch1.group(2).strip()
				temporalres = mipsearch1.group(3).lower().strip()
				# Normalize result to month approximation:
				if temporalres == 'month':
					mipunstructured.append(mipres)
				elif temporalres == 'year':
					mipres = str(int(mipres)*12)
					mipunstructured.append(mipres)
				else:
					mipres = str(int(round(mipres/float(30))))
					mipunstructured.append(mipres)
			else:
				mipsearch2 = re.search(r"(a\s{0,6}continuing\s{0,6}disability\s{0,6}review\s{0,6}is\s{0,6}recommended\s{0,6}in\s{0,6})([0-9]{1,3})(\s{0,6}month|\s{0,6}year|\s{0,6}day)", decision, re.I)
				if bool(mipsearch2):
					mipres = mipsearch2.group(2).strip()
					temporalres = mipsearch2.group(3).lower().strip()
					# Normalize result to month approximation:
					if temporalres == 'month':
						mipunstructured.append(mipres)
					elif temporalres == 'year':
						mipres = str(int(mipres)*12)
						mipunstructured.append(mipres)
					else:
						mipres = str(int(round(mipres/float(30))))
						mipunstructured.append(mipres)
		except Exception:
			logger.exception('EXCEPTION')

		# ME and VE 'Background' and 'Body Text' Reference Parsers:
		# TIP: Cannot rely on already parsed versions of decision because
		# here you must CONFIRM that the slicing was successful.
		# TODO: Consider functionalizing these negation detection methods.
		try:
			# 'Background' (JPH) Section Ref. Parsing:
			me_nonfindings_decision = decision_nomargin
			me_nonfindings_decision = re.sub(r"FINDINGS ?(0|O)F ?FACT", "", me_nonfindings_decision, flags=re.S)
			me_nonfindings_decision = re.sub(r"\bISSUES.*", "", me_nonfindings_decision, flags=re.S)
			if me_nonfindings_decision != decision:
				me_nonfindings_decision = tc.normalize_spacing(me_nonfindings_decision)
				# State agency and strict superficial negation detection:
				# TIP: This strict level of negation detection will work for background section parsing,
				# where negation seems relatively uncommon, but will NOT work for body section parsing,
				# as often sentences will naturally also contain negation langauge that doesn't relate to
				# the ME (e.g. 'The medical expert opined the claimant did not equal a listing...').
				me_nonfindings_decision_sents = nlp_helper.sentence_splitter(me_nonfindings_decision)
				for sent in me_nonfindings_decision_sents:
					if bool(re.search(r"(psychological|medical) ?experts?[^a-z]", sent, re.I)):
						# Split sentence into subsections:
						me_nonfindings_decision_sent_sslist = re.split(r"\bbut\b|\byet\b|\bwhile\b|\bwhereas\b|\bexcept\b|; | :|, ?and", sent)
						for ss in me_nonfindings_decision_sent_sslist:
							me_nonfindings_finditer = re.finditer(r"(psychological|medical) ?experts?[^a-z]", ss, re.I)
							for res in me_nonfindings_finditer:
								ss_prior = ss[:res.start()]
								if bool(re.search(r"\bstate ?agency", ss_prior, re.I)) is False and bool(re.search(r"\bno\b|\bnot\b|\bneither\b", ss, re.I)) is False:
									merefbgunstructured.append("1")
					if bool(re.search(r"vocational ?experts?[^a-z]", sent, re.I)):
						if bool(re.search(r"\bno\b|\bnot\b|\bneither\b", sent, re.I)) is False:
							verefbgunstructured.append("1")
				#--- Present code:
				me_nonfindings_decision = tc.normalize_spacing(me_nonfindings_decision)
				me_nonfindings_search = re.search(r"[^A-Za-z\-](psychological|medical) ?experts?[^a-z]", me_nonfindings_decision, re.I)
				if bool(me_nonfindings_search):
					merefbgunstructured.append("1")
				ve_nonfindings_search = re.search(r"[^A-Za-z\-](vocational) ?experts?[^a-z]", me_nonfindings_decision, re.I)
				if bool(ve_nonfindings_search):
					verefbgunstructured.append("1")

			# 'Body Text' (Findings) Section Ref. Parsing:
			me_findings_decision = decision_nomargin
			fof_fwd_search = re.search(r"FINDINGS ?(0|O)F ?FACT.*", me_findings_decision, re.S)
			if bool(fof_fwd_search):
				me_findings_decision = fof_fwd_search.group()
			if me_findings_decision != decision:
				me_findings_decision = tc.normalize_spacing(me_findings_decision)
				#--- (IN DEVELOPMENT 12.29.2016 - Adds state agency and conservative superficial negation detection protocols):
				# TODO: This negation protocol will not detect negation if separated by comma-separated lists, e.g.
				# '...NO treating, examinining, or MEDICAL EXPERT opinion...' -> negation not detected.
				me_findings_decision_sents = nlp_helper.sentence_splitter(me_findings_decision)
				for sent in me_findings_decision_sents:
					if bool(re.search(r"(?<!no )(?<!neither a )(psychological|medical) ?expert(.{1})?s?(?! has not appear)(?! did not appear)", sent, re.I)):
						# Split sentence into subsections:
						me_findings_decision_sent_sslist = re.split(r"\bbut\b|\byet\b|\bwhile\b|\bwhereas\b|\bexcept\b|; | :|, ?and", sent)
						for ss in me_findings_decision_sent_sslist:
							me_findings_finditer = re.finditer(r"(?<!no )(?<!neither a )(psychological|medical) ?expert(.{1})?s?(?! has not appear)(?! did not appear)", ss, re.I)
							for res in me_findings_finditer:
								ss_prior = ss[:res.start()]
								if bool(re.search(r"\bstate ?agency", ss_prior, re.I)) is False:
									negation_finditer_1 = re.finditer(r"\bno\b|\bnot\b|\bnor\b|\bneither\b", ss_prior, re.I|re.S)
									negation_finditer_1_ressnippets = []
									for res2 in negation_finditer_1:
										res2_start = res2.start()
										ss_negation_fwd = ss_prior[res2_start:]
										negation_finditer_1_ressnippets.append(ss_negation_fwd)
									if not negation_finditer_1_ressnippets:
										merefbodyunstructured.append("1")
									else:
										negation_finditer_1_nocommaver = 0
										for item in negation_finditer_1_ressnippets:
											if ',' not in item:
												negation_finditer_1_nocommaver = 1
												break
										if negation_finditer_1_nocommaver == 0:
											merefbodyunstructured.append("1")
					if bool(re.search(r"(?<!no )(?<!neither a )vocational ?expert(.{1})?s?(?! has not appear)(?! did not appear)", sent, re.I)):
						if bool(re.search(r"\bno\b|\bnot\b|\bneither\b", sent, re.I)) is False:
							verefbodyunstructured.append("1")
		except Exception:
			logger.exception('EXCEPTION')

		# VE Name Parser:
		# TODO: Confirm search patterns below reflect latest FIT VE name language.
		# OPENQ: Why take a sentence by sentence approach given current REGEX patterns?
		try:
			venm_res_snippets_list = []
			for sent in decision_nomargin_sentlist:
				# TIP: Max length of 70 reached based anecdotally on UK
				# government name data guidelines.	Open to better sources.
				# http://webarchive.nationalarchives.gov.uk/+/http://www.cabinetoffice.gov.uk/media/254290/GDS%20Catalogue%20Vol%202.pdf
				venamefitfindall1 = re.findall(r"(appearing ?and ?testifying|appearing|testifying) ?(were|was)(.{5,70}), ?an ?impartial ?vocational ?expert", sent, flags=re.I)
				if venamefitfindall1:
					for res in venamefitfindall1:
						res_snippet = res[2]
						res_snippet = res_snippet.strip()
						# TIP: Quickly checks for at least one intervening space
						# in result snippet to further confirm name-like structure:
						if ' ' in res_snippet:
							venm_res_snippets_list.append(res_snippet)
				venamefitfindall2 = re.findall(r"(^.{5,70}?)(, ?an ?impartial ?vocational ?expert, also ?(appeared|testified))", sent, flags=re.I)
				if venamefitfindall1:
					for res in venamefitfindall1:
						res_snippet = res[0]
						res_snippet = res_snippet.strip()
						if ' ' in res_snippet:
							venm_res_snippets_list.append(res_snippet)

			# Parse snippet results:
			if venm_res_snippets_list:
				venm_res_snippets_list = list(set(venm_res_snippets_list))
				venm_res_list = []
				for snip in venm_res_snippets_list:
					snip_res = nlp_helper.name_searcher(snip)
					if snip_res not in ['U','E']:
						venm_res_list.append(snip_res)
				if venm_res_list:
					venm_res_list = list(set(venm_res_list))
					venmunstructured = venm_res_list

		except Exception:
			logger.exception('EXCEPTION')

		# On the Record (OTR) Verdict Parser:
		try:
			# TIP: 05/2016 FFAV FIT EBB LANG: The evidence of record supports a fully favorable decision <if DIB Dismissal> based on the claimant's application/applications for supplemental security income/ disabled widow's benefits/ disabled widow's benefits and supplemental security income<endif>; therefore no hearing has been held (20 CFR <if 405>405.340(a)<else> <T2> 404.948(a) <T16> 416.1448(a) <Tboth> 404.948(a) and 416.1448(a)<endif>).
			otrrefsearch1 = re.search(r"The\s{0,3}evidence\s{0,3}of\s{0,3}record\s{0,3}supports\s{0,3}a\s{0,3}fully\s{0,3}favorable\s{0,3}decision(based\s{0,3}on\s{0,3}the\s{0,3}claimant.{0,2}s\s{0,3}applications?\s{0,3}for\s{0,3}(disabled\s{0,3}widow.{0,2}s\s{0,3}benefits\s{0,3}and\s{0,3}supplemental\s{0,3}security\s{0,3}income|supplemental\s{0,3}security\s{0,3}income|disabled\s{0,3}widow.{0,2}s\s{0,3}benefits)|.{0,5})therefore,?\s{0,3}no\s{0,3}hearing\s{0,3}has\s{0,3}been\s{0,3}held", decision, re.I)
			if bool(otrrefsearch1):
				otrrefunstructured.append('1')
		except Exception:
			logger.exception('EXCEPTION')

		### 'SECOND TIER' FIT/NEAR FIT BACKGROUND DATA PARSING ###

		# Second Tier SSN Parser:
		try:
			if ssnunstructured:
				# 1 FIT result (unusual scenario):
				if len(ssnunstructured) == 1:
					ssnchecked = ssnunstructured[0]
					ssncheckedsrc = "0"
				# 2+ FIT results (most likely scenario):
				elif len(ssnunstructured) > 1:
					ssnunstructuredcounted = Counter(ssnunstructured)
					ssnunstructuredcountedMC = ssnunstructuredcounted.most_common()
					ssnunstructuredcountedMCmaxct = ssnunstructuredcountedMC[0][1]
					ssnwinnerlist = []
					# TIP: If tie, this outputs each SSN carrying
					# highest count.
					for item in ssnunstructuredcountedMC:
						if item[1] == ssnunstructuredcountedMCmaxct:
							ssnwinnerlist.append(item[0])
					if len(ssnwinnerlist) == 1:
						ssnchecked = ssnwinnerlist[0]
						ssncheckedsrc = "0"
					elif len(ssnwinnerlist) > 1:
						ssnchecked = "; ".join(ssnwinnerlist)
						ssncheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier SSN XREF Parser:
		try:
			if ssnxrefunstructured:
				# 1 FIT result (unusual scenario):
				if len(ssnxrefunstructured) == 1:
					ssnxrefchecked = ssnxrefunstructured[0]
					ssnxrefcheckedsrc = "0"
				# 2+ FIT results (most likely scenario):
				elif len(ssnxrefunstructured) > 1:
					ssnxrefunstructuredcounted = Counter(ssnxrefunstructured)
					ssnxrefunstructuredcountedMC = ssnxrefunstructuredcounted.most_common()
					ssnxrefunstructuredcountedMCmaxct = ssnxrefunstructuredcountedMC[0][1]
					ssnxrefwinnerlist = []
					for item in ssnxrefunstructuredcountedMC:
						if item[1] == ssnxrefunstructuredcountedMCmaxct:
							ssnxrefwinnerlist.append(item[0])
					if len(ssnxrefwinnerlist) == 1:
						ssnxrefchecked = ssnxrefwinnerlist[0]
						ssnxrefcheckedsrc = "0"
					elif len(ssnxrefwinnerlist) > 1:
						ssnxrefchecked = "; ".join(ssnxrefwinnerlist)
						ssnxrefcheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Claimant Name Parser:
		try:
			if clnmunstructured:
				# 1 FIT Result:
				if len(clnmunstructured) == 1:
					clnmchecked = clnmunstructured[0]
					clnmchecked = " ".join(clnmchecked.split())
					clnmcheckedsrc = "0"
				# 2+ FIT Results (most likely scenario):
				# UPDATE (06.01.2017)
				elif len(clnmunstructured) > 1:
					clnmunstructuredcounted = Counter(clnmunstructured)
					clnmunstructuredcountedMC = clnmunstructuredcounted.most_common()
					clnmunstructuredcountedMCmaxct = clnmunstructuredcountedMC[0][1]
					clnmwinnerlist = []
					for item in clnmunstructuredcountedMC:
						if item[1] == clnmunstructuredcountedMCmaxct:
							clnmwinnerlist.append(item[0])
					if len(clnmwinnerlist) == 1:
						clnmchecked = clnmwinnerlist[0]
						clnmcheckedsrc = "0"
					# TIP: If more than 1 other name variation, it most likely means
					# your simple 'unstructured' parsing ran into an error removing
					# noise characters from margin text.  Thus, to avoid numerous
					# erroneous outputs, omitting any output if more than 2 max results:
					elif len(clnmwinnerlist) == 2:
						clnmchecked = "; ".join(clnmwinnerlist)
						clnmcheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Claimant Full Data Parser:
		try:
			if clnmaddunstructured:
				# 1 FIT Result:
				if len(clnmaddunstructured) == 1:
					claimantfulldatatest = clnmaddunstructured[0]
					claimantfulldatatest = " ".join(claimantfulldatatest.split())
					# TIP: Including hard minimum length to reduce
					# errant output.
					if len(claimantfulldatatest) > 5:
						clnmaddchecked = claimantfulldatatest
						clnmaddcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			 # 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Claimant ZIP Parser:
		try:
			if clzipunstructured:
				# 1 FIT Result:
				if len(clzipunstructured) == 1:
					clzipchecked = clzipunstructured[0]
					clzipcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Rep Full Data Parser:
		try:
			if repnmaddunstructured:
				# 1 FIT Result:
				if len(repnmaddunstructured) == 1:
					repfulldatatest = repnmaddunstructured[0]
					repfulldatatest = repfulldatatest.strip()
					if bool(repfulldatatest.startswith("If you have any questions")) is False:
						repnmaddchecked = repfulldatatest
						repnmaddchecked = " ".join(repnmaddchecked.split())
						repnmaddcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results (NOTE: There's no 'full data' equivalent in your current structured data).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Rep Name Parser:
		try:
			if repnmunstructured:
				# 1 FIT Result:
				if len(repnmunstructured) == 1:
					repnmchecked = repnmunstructured[0]
					repnmchecked = " ".join(repnmchecked.split())
					repnmcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				elif len(repnmunstructured) > 1:
					repnmchecked = "; ".join(repnmunstructured)
					repnmchecked = " ".join(repnmchecked.split())
					repnmcheckedsrc = "2"
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Rep ZIP Parser:
		try:
			if repzipunstructured:
				# 1 FIT Result:
				if len(repzipunstructured) == 1:
					repzipchecked = repzipunstructured[0]
					repzipcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Adjudicator Name Parser:
		try:
			if adjudicatorunstructured:
				# 1 FIT Result:
				if len(adjudicatorunstructured) == 1:
					adjudicatornametest = adjudicatorunstructured[0]
					adjudicatornametest = " ".join(adjudicatornametest.split())
					if len(adjudicatornametest) > 5:
						adjudicatorchecked = adjudicatornametest
						adjudicatorcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				elif len(adjudicatorunstructured) > 1:
					adjudicatornametestlist = []
					for item in adjudicatorunstructured:
						adjudicatornametest = " ".join(item.split())
						if len(adjudicatornametest) > 5:
							adjudicatornametestlist.append(adjudicatornametest)
					if len(adjudicatornametestlist) == 1:
						adjudicatorchecked = adjudicatornametestlist[0]
						adjudicatorcheckedsrc = "0"
					elif len(adjudicatornametestlist) > 1:
						adjudicatorchecked = "; ".join(adjudicatornametestlist)
						adjudicatorcheckedsrc = "2"
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Disposition Type Parser:
		try:
			if disptypeunstructured:
				# 1 FIT Result:
				if len(disptypeunstructured) == 1:
					disptypechecked = disptypeunstructured[0]
					disptypecheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				elif len(disptypeunstructured) > 1:
					disptypechecked = "; ".join(disptypeunstructured)
					disptypecheckedsrc = "2"
			# 0 FIT Results (NOTE 06.24.15: Direct retrieval of structured data deprecated; will simply merge all pertinent structured data and call for it where necessary (e.g. Quality parsing).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Claim Type Parser:
		try:
			if claimtypeunstructured:
				# 1 FIT Result:
				if len(claimtypeunstructured) == 1:
					claimtypechecked = claimtypeunstructured[0]
					claimtypecheckedsrc = "0"
				if len(claimtypeunstructured) > 1:
					claimtypechecked = "; ".join(claimtypeunstructured)
					claimtypecheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier DAA Materiality Verdict Parser:
		try:
			if daamatunstructured:
				# 1 FIT Result:
				if len(daamatunstructured) == 1:
					daamatchecked = daamatunstructured[0]
					daamatcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier DOF Parser:
		try:
			if dofunstructured:
				# 1 FIT Result:
				if len(dofunstructured) == 1:
					dofchecked = dofunstructured[0]
					dofcheckedsrc = "0"
				elif len(dofunstructured) > 1:
					dofchecked = "; ".join(dofunstructured)
					dofcheckedsrc = "0"
			# 0 FIT Results (NOTE: Not pulling this structured data b/c not critical to SS functioning/data parsing).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Amended AOD Verdict Parser:
		try:
			if aodamendverunstructured:
				# 1 FIT Result:
				aodamendverchecked = aodamendverunstructured[0]
				aodamendvercheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
			# 0 FIT Results (NOTE: There is no CPMS/DMIA data for this datapoint).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier AOD Parser:
		try:
			if aodunstructured:
				# 1 FIT Result:
				if len(aodunstructured) == 1:
					aodchecked = aodunstructured[0]
					aodchecked = dh.parse_date_tostr(aodchecked)
					aodcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				elif len(aodunstructured) > 1:
					aodchecked = [dh.parse_date_tostr(d) for d in aodunstructured]
					aodchecked = str("; ".join(aodchecked))
					aodcheckedsrc = "2"
			# 0 FIT Results (NOTE: Not pulling this structured data b/c not critical to SS functioning/data parsing).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier DLI Parser:
		try:
			if dliunstructured:
				# 1 FIT Result:
				if len(dliunstructured) == 1:
					dlichecked = dliunstructured[0]
					dlichecked = dh.parse_date_tostr(dlichecked)
					dlicheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				elif len(dliunstructured) > 1:
					dlichecked = [dh.parse_date_tostr(d) for d in dliunstructured]
					dlichecked = str("; ".join(dlichecked))
					dlicheckedsrc = "2"
			# 0 FIT Results (NOTE 06.24.15: Passing non-critical data to improve performance)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier DID Parser:
		try:
			if didunstructured:
				# 1 FIT Result:
				if len(didunstructured) == 1:
					didchecked = didunstructured[0]
					didchecked = dh.parse_date_tostr(didchecked)
					didcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
				elif len(didunstructured) > 1:
					didchecked = [dh.parse_date_tostr(d) for d in didunstructured]
					didchecked = str("; ".join(didchecked))
					didcheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Medical Improvement Period Parser:
		try:
			if mipunstructured:
				# 1 FIT Result:
				# TIP: Will always only contain exactly 1 result.
				mipchecked = mipunstructured[0]
				mipcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A]
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier ME 'Background' Reference Parser:
		try:
			# 1 Result:
			if len(merefbgunstructured):
				merefbgchecked = "1"
			# 0 Results (means no ME text was found, but doesn't definitively prove one wasn't present).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier ME 'BODY' Reference Parser:
		try:
			# 1 Result:
			if len(merefbodyunstructured):
				merefbodychecked = "1"
			# 0 Results (means no ME text was found, but doesn't definitively prove one wasn't present).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier VE 'Background' & 'Body' Reference Parser:
		try:
			# 1 Result:
			if verefbgunstructured:
				verefbgchecked = "1"
			# 0 Results (means no VE text was found, but doesn't definitively prove one wasn't present).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier VE 'Background' & 'Body' Reference Parser:
		try:
			# 1 Result:
			if verefbodyunstructured:
				verefbodychecked = "1"
			# 0 Results (means no VE text was found, but doesn't definitively prove one wasn't present).
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier VE Name Parser:
		try:
			# 1 FIT Result:
			if len(venmunstructured) == 1:
				venmchecked = venmunstructured[0]
			# 2+ FIT Results:
			elif len(venmunstructured) >= 1:
				venmchecked = '; '.join(venmunstructured)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier On the Record (OTR) Verdict Parser:
		try:
			# 1 Result:
			if otrrefunstructured:
				otrrefchecked = '1'
			# 0 Results (means no FIT OTR text was found, but doesn't definitively prove no OTR was issued)
		except Exception:
			logger.exception('EXCEPTION')

		### 'FIRST TIER' SEP/FINDINGS DATA PARSING ###

		# Precheck - If non-covered decision type (dismissal,
		# dual-SEP, etc.), output 'P' values:
		if '2' in disptypechecked or '3' in disptypechecked or bool(len(disptypechecked) == len([dt for dt in disptypechecked if dt == '7'])) or daamatchecked == '1' or 'CDR' in claimtypechecked:
			for k,v in decisiondatadict.iteritems():
				if v == 'U':
					decisiondatadict[k] = 'P'
			for dpt_nm in ['claimdisp', 's1sga', 's2', 's3mteq', 's3feq', 'rfc', 's4', 's4dot', 's5', 's5dot', 's5mvr', 'srcnm']:
				decisiondatadict[dpt_nm] = {}
			return decisiondatadict, decisionfindingsltd

		# Step 1 SGA Verdict/Text/Start Date/End Date Parser:
		try:
			# NOTE: Verified FIT language for "1" for adult FFAV+UNFAV+DAA UNFAV+child->adult SSI, etc. (ALSO COVERS CASES WHERE A UWA IS FOUND - could ID those by just running a search for "unsuccessful work attempt" in the Step 1 body):
			s1sgafinditer1 = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}since.*", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "1" for adult T2 remote DLI cases:
			s1sgafinditer2 = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}period\s{0,6}from\s{0,6}(his|her)\s{0,6}alleged\s{0,6}onset\s{0,6}date\s{0,6}of.{1,25}through\s{0,6}(his|her)\s{0,6}date\s{0,6}last\s{0,6}insured.*", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "1" in CDR claims since the CPD (in DIB/SSDC cases):
			s1sgafinditer3 = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}since\s{0,6}the\s{0,6}CPD.*", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "1" in DWB claims:
			s1sgafinditer4 = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}at\s{0,6}any\s{0,6}time\s{0,6}relevant\s{0,6}to\s{0,6}this\s{0,6}decision", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "YES SGA FULL PERIOD" for adult T2 denial with post-DID DLI:
			s1sgasearch5 = re.search(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}since.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}There\s{0,6}has\s{0,6}been\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer5 = re.finditer(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}since.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}There\s{0,6}has\s{0,6}been\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer5a = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}has\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}since.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?", decisionfindingsltd, re.I|re.M)
			s1sgafinditer5b = re.finditer(r"\d\d?\.\s{1,3}There\s{0,6}has\s{0,6}been\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}not\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "YES SGA FULL PERIOD" for adult T2 denial with remote DLI:
			s1sgasearch6 = re.search(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}from.{1,25}through.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}Through.{1,25},\s{0,6}there\s{0,6}was\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer6 = re.finditer(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}from.{1,25}through.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}Through.{1,25},\s{0,6}there\s{0,6}was\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer6a = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}from.{1,25}through.{1,25}\(20\s{0,6}C\.? ?F\.? ?R\.? ?", decisionfindingsltd, re.I|re.M)
			s1sgafinditer6b = re.finditer(r"\d\d?\.\s{1,3}Through.{1,25},\s{0,6}there\s{0,6}was\s{0,6}no\s{0,6}continuous\s{0,6}12-month\s{0,6}period\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "YES SGA PARTIAL PERIOD" for adult T2 w/ post-DID DLI:
			# TODO: Modify data dictionary to indicate that 's1sga_startdt' and 's1sga_enddt' *only*
			# pertain to Step 1 finding headings indicating a partial period of SGA.
			# TODO: Update REGEX patterns to search for specific CFR terminals.
			s1sgasearch7 = re.search(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods?:)(.{4,30}to.{4,30})(\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}However,\s{0,8}there\s{0,8}has\s{0,8}been\s{0,8}a\s{0,8}continuous\s{0,8}12-month\s{0,8}(periods|period)\s{0,8}during\s{0,8}which\s{0,8}the\s{0,8}claimant\s{0,8}did\s{0,8}not\s{0,8}engage\s{0,8}in\s{0,8}substantial\s{0,8}gainful\s{0,8}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer7 = re.finditer(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods?:)(.{4,30}to.{5,30})(\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}However,\s{0,8}there\s{0,8}has\s{0,8}been\s{0,8}a\s{0,8}continuous\s{0,8}12-month\s{0,8}(periods|period)\s{0,8}during\s{0,8}which\s{0,8}the\s{0,8}claimant\s{0,8}did\s{0,8}not\s{0,8}engage\s{0,8}in\s{0,8}substantial\s{0,8}gainful\s{0,8}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer7a = re.finditer(r"(\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods?:)(.{4,30}to.{4,30})\(20\s{0,6}C\.? ?F\.? ?R\.? ?", decisionfindingsltd, re.I|re.M)
			s1sgafinditer7b = re.finditer(r"\d\d?\.\s{1,3}However,\s{0,8}there\s{0,8}has\s{0,8}been\s{0,8}a\s{0,8}continuous\s{0,8}12-month\s{0,8}(periods|period)\s{0,8}during\s{0,8}which\s{0,8}the\s{0,8}claimant\s{0,8}did\s{0,8}not\s{0,8}engage\s{0,8}in\s{0,8}substantial\s{0,8}gainful\s{0,8}activity", decisionfindingsltd, re.I|re.M)

			# NOTE: Verified FIT language for "YES SGA PARTIAL PERIOD" for adult T2 w/ remote DLI:
			s1sgasearch8 = re.search(r"(\d\d?\.\s{1,3}Through.{4,30},\s{0,6}the\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods:.{4,30}to.{4,30}\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}However,\s{0,6}there\s{0,6}(has\s{0,6}been\s{0,6}a\s{0,6}|have\s{0,6}been\s{0,6})continuous\s{0,6}12-month\s{0,6}(periods|period)\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer8 = re.finditer(r"(\d\d?\.\s{1,3}Through.{4,30},\s{0,6}the\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods:)(.{4,30}to.{4,30})(\(20\s{0,6}C\.? ?F\.? ?R\.? ?)(.*?)(\d\d?\.\s{1,3}However,\s{0,6}there\s{0,6}(has\s{0,6}been\s{0,6}a\s{0,6}|have\s{0,6}been\s{0,6})continuous\s{0,6}12-month\s{0,6}(periods|period)\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity)", decisionfindingsltd, re.I|re.M|re.S)
			s1sgafinditer8a = re.finditer(r"(\d\d?\.\s{1,3}Through.{4,30},\s{0,6}the\s{0,6}claimant\s{0,6}engaged\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity\s{0,6}during\s{0,6}the\s{0,6}following\s{0,6}periods:)(.{4,30}to.{4,30})\(20\s{0,6}C\.? ?F\.? ?R\.? ?", decisionfindingsltd, re.I|re.M)
			s1sgafinditer8b = re.finditer(r"\d\d?\.\s{1,3}However,\s{0,6}there\s{0,6}(has\s{0,6}been\s{0,6}a\s{0,6}|have\s{0,6}been\s{0,6})continuous\s{0,6}12-month\s{0,6}(periods|period)\s{0,6}during\s{0,6}which\s{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}engage\s{0,6}in\s{0,6}substantial\s{0,6}gainful\s{0,6}activity", decisionfindingsltd, re.I|re.M)

			for res in s1sgafinditer1:
				s1sgaunstructured.append({"s1sgaver":"1", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			for res in s1sgafinditer2:
				s1sgaunstructured.append({"s1sgaver":"1", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			for res in s1sgafinditer3:
				s1sgaunstructured.append({"s1sgaver":"1", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			for res in s1sgafinditer4:
				s1sgaunstructured.append({"s1sgaver":"1", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			if bool(s1sgasearch5):
				for res in s1sgafinditer5:
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group(1)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.start() + len(res.group(1))})
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group(3)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.end() - len(res.group(3)), "loc_end":res.end()})
			# TIP: If no 'both component' full period of SGA language is not found,
			# parse any individual components found:
			else:
				for res in s1sgafinditer5a:
					s1sgaunstructured.append({"s1sgaver":"4", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
				for res in s1sgafinditer5b:
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			if bool(s1sgasearch6):
				for res in s1sgafinditer6:
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group(1)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.start() + len(res.group(1))})
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group(3)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.end() - len(res.group(3)), "loc_end":res.end()})
			# TIP: If no 'both component' full period of SGA language is not found,
			# parse any individual components found:
			else:
				for res in s1sgafinditer6a:
					s1sgaunstructured.append({"s1sgaver":"4", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
				for res in s1sgafinditer6b:
					s1sgaunstructured.append({"s1sgaver":"3", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			if bool(s1sgasearch7):
				for res in s1sgafinditer7:
					pdstr = res.group(2)
					pdstr_split = re.split(r"\bto\b", pdstr)
					pd_dict = {'startdt':'U', 'enddt':'U'}
					if len(pdstr_split) == 2:
						pd_start_str = pdstr_split[0].strip()
						pd_start_str_ifsdate = dh.parse_date_tostr(pd_start_str)
						pd_dict['startdt'] = pd_start_str_ifsdate
						pd_end_str = pdstr_split[1].strip()
						pd_end_str_ifsdate = dh.parse_date_tostr(pd_end_str)
						pd_dict['enddt'] = pd_end_str_ifsdate
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group(1)), "s1sgatype":"U", "s1sga_startdt":pd_dict['startdt'], "s1sga_enddt":pd_dict['enddt'], "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.start() + len(res.group(1))})
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group(3)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.end() - len(res.group(3)), "loc_end":res.end()})
			# TIP: If no 'both component' partial period of SGA language is not found,
			# parse any individual components found:
			else:
				for res in s1sgafinditer7a:
					pdstr = res.group(2)
					pdstr_split = re.split(r"\bto\b", pdstr)
					pd_dict = {'startdt':'U', 'enddt':'U'}
					if len(pdstr_split) == 2:
						pd_start_str = pdstr_split[0].strip()
						pd_start_str_ifsdate = dh.parse_date_tostr(pd_start_str)
						pd_dict['startdt'] = pd_start_str_ifsdate
						pd_end_str = pdstr_split[1].strip()
						pd_end_str_ifsdate = dh.parse_date_tostr(pd_end_str)
						pd_dict['enddt'] = pd_end_str_ifsdate
					s1sgaunstructured.append({"s1sgaver":"4", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":pd_dict["startdt"], "s1sga_enddt":pd_dict["enddt"], "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
				for res in s1sgafinditer7b:
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			if bool(s1sgasearch8):
				for res in s1sgafinditer8:
					pdstr = res.group(2)
					pdstr_split = re.split(r"\bto\b", pdstr)
					pd_dict = {'startdt':'U', 'enddt':'U'}
					if len(pdstr_split) == 2:
						pd_start_str = pdstr_split[0].strip()
						pd_start_str_ifsdate = dh.parse_date_tostr(pd_start_str)
						pd_dict['startdt'] = pd_start_str_ifsdate
						pd_end_str = pdstr_split[1].strip()
						pd_end_str_ifsdate = dh.parse_date_tostr(pd_end_str)
						pd_dict['enddt'] = pd_end_str_ifsdate
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group(1)), "s1sgatype":"U", "s1sga_startdt":pd_dict["startdt"], "s1sga_enddt":pd_dict["enddt"], "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.start() + len(res.group(1))})
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group(3)), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.end() - len(res.group(3)), "loc_end":res.end()})
			# TIP: If no 'both component' partial period of SGA language is not found,
			# parse any individual components found:
			else:
				for res in s1sgafinditer8a:
					pdstr = res.group(2)
					pdstr_split = re.split(r"\bto\b", pdstr)
					pd_dict = {'startdt':'U', 'enddt':'U'}
					if len(pdstr_split) == 2:
						pd_start_str = pdstr_split[0].strip()
						pd_start_str_ifsdate = dh.parse_date_tostr(pd_start_str)
						pd_dict['startdt'] = pd_start_str_ifsdate
						pd_end_str = pdstr_split[1].strip()
						pd_end_str_ifsdate = dh.parse_date_tostr(pd_end_str)
						pd_dict['enddt'] = pd_end_str_ifsdate
					s1sgaunstructured.append({"s1sgaver":"4", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":pd_dict["startdt"], "s1sga_enddt":pd_dict["enddt"], "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
				for res in s1sgafinditer8b:
					s1sgaunstructured.append({"s1sgaver":"2", "s1sgatxt":tc.slight_cleaner_findings(res.group()), "s1sgatype":"U", "s1sga_startdt":"U", "s1sga_enddt":"U", "s1sgatxtsrc":"0", "s1sgaversrc":"0", "loc_st":res.start(), "loc_end":res.end()})
		except Exception:
			logger.exception('EXCEPTION')

		# Step 2 MDI Verdict/Text Parser:
		try:
			# SEVERE MDIS PRESENT - Verified FIT language where severe MDIs present in UNFAV CONCURRENT + FFAV + UNFAV DWB + DAA UNFAV + T16 CHILD (these are typically the same MDIs except for the substance use):
			# TIP: Attempt to define FIT language via trailing FIT CFR references, else at end of line:
			step2yesseveremdissearch1 = re.search(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|has|had)\s{0,6}the\s{0,6}following\s{0,6}severe)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)\s{0,6}and\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I)
			if bool(step2yesseveremdissearch1):
				for res in re.finditer(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|has|had)\s{0,6}the\s{0,6}following\s{0,6}severe)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)\s{0,6}and\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I):
					s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			else:
				for res in re.finditer(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|has|had)\s{0,6}the\s{0,6}following\s{0,6}severe)(.*)", decisionfindingsltd, re.M|re.I):
					s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# SEVERE MDIS PRESENT + PREFATORY LANGUAGE - Verified FIT language where severe MDIs present with prefatory language, e.g. an UNFAV T2 DIB w/ remote DLI:
			# TIP: Attempt to define FIT language via trailing FIT CFR references, else at end of line:
			step2yesseveremdissearch2 = re.search(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)\s{0,6}and\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I)
			if bool(step2yesseveremdissearch2):
				for res in re.finditer(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)\s{0,6}and\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1520\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.920\(c\)|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I):
					s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			else:
				for res in re.finditer(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.*)", decisionfindingsltd, re.M|re.I):
					s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# MDIS BUT NONE SEVERE - Verified FIT language where MDIs but none severe in UNFAV:
			# TIP: Attempt to define FIT language via trailing FIT CFR references, else at end of line:
			step2nonseveremdissearch1 = re.search(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1521|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.921|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I)
			if bool(step2nonseveremdissearch1):
				for res in re.finditer(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1521|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.921|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I):
					s2unstructured.append({"s2ver":"2", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			else:
				for res in re.finditer(r"(\d\d?\.\s{1,3})(The\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.*)", decisionfindingsltd, re.M|re.I):
					s2unstructured.append({"s2ver":"2", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# MDIS BUT NONE SEVERE + PREFATORY LANGUAGE - Verified FIT language where MDIs but none severe in UNFAV:
			step2nonseveremdissearch2 = re.search(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1521|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.921|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.M|re.S|re.I)
			if bool(step2nonseveremdissearch2):
				for res in re.finditer(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.{5,500}?)(20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}404\.1521|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.921|20\s{0,6}C\.? ?F\.? ?R\.? ?\s{0,6}416\.924\(c\))", decisionfindingsltd, re.I):
					s2unstructured.append({"s2ver":"2", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})
			else:
				for res in re.finditer(r"(\d\d?\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}medically\s{0,6}determinable\s{0,6}impairment)(.*)", decisionfindingsltd, re.M|re.I):
					s2unstructured.append({"s2ver":"2", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# NO MDIS AT ALL - Verified FIT language where NO MDIs present in UNFAV:
			step2nomdisfinditer1 = re.finditer(r"(\d\d?\.\s{1,3})There\s{0,6}are\s{0,6}no\s{0,6}medical\s{0,6}signs\s{0,6}or\s{0,6}laboratory\s{0,6}findings\s{0,6}to\s{0,6}substantiate\s{0,6}the\s{0,6}existence\s{0,6}of\s{0,6}a?\s{0,6}medically\s{0,6}determinable", decisionfindingsltd, re.M|re.S|re.I)
			for res in step2nomdisfinditer1:
				s2unstructured.append({"s2ver":"3", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# NO MDIS AT ALL + PREFATORY LANGUAGE - Verified FIT language where NO MDIs present in UNFAV:
			step2nomdisfinditer2 = re.finditer(r"(\d\d?\.\s{1,3})Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI).{0,5}there\s{0,6}(were|are)\s{0,6}no\s{0,6}medical\s{0,6}signs\s{0,6}or\s{0,6}laboratory\s{0,6}findings\s{0,6}to\s{0,6}substantiate", decisionfindingsltd, re.M|re.S|re.I)
			for res in step2nomdisfinditer2:
				s2unstructured.append({"s2ver":"3", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# NO MDIS AT ALL (DAA) - Verified FIT language where NO severe MDIs present excluding the DAA MDIs:
			step2nomdisfinditer3 = re.finditer(r"(\d\d?\.\s{1,3})If\s{0,6}the\s{0,6}claimant\s{0,6}stopped\s{0,6}the\s{0,6}substance\s{0,6}use.{0,5}the\s{0,6}remaining\s{0,6}limitations\s{0,6}would\s{0,6}not\s{0,6}cause\s{0,6}more\s{0,6}than\s{0,6}a\s{0,6}minimal", decisionfindingsltd, re.M|re.S|re.I)
			for res in step2nomdisfinditer2:
				s2unstructured.append({"s2ver":"3", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# CHILD->ADULT DECISIONS HAVE 2 MDI-RELATED FINDINGS - Verified FIT language where severe MDIs present both in childhood and adulthood in child->adult SSI (both should be in same decision):
			if "T16 SSI Child+Adult" in claimtypechecked:
				age18s2verdictsearch1 = re.search(r"(\d\d?\.\s{1,3}Before\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.*?)(\d\d?\.\s{1,3}Since\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}has\s{0,6}continued)", decisionfindingsltd, re.M|re.S|re.I)
				if bool(age18s2verdictsearch1):
					age18s2verdictfinditer1 = re.finditer(r"(\d\d?\.\s{1,3}Before\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.*?)(\d\d?\.\s{1,3}Since\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}has\s{0,6}continued)", decisionfindingsltd, re.M|re.S|re.I)
					for res in age18s2verdictfinditer1:
						s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group(1)), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.start() + len(res.group(1))})
						s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group(3)), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.end() - len(res.group(3)), "loc_end":res.end()})
				else:
					for res in re.finditer(r"(\d\d?\.\s{1,3}Before\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}(has had|had|has)\s{0,6}the\s{0,6}following\s{0,6}severe)(.*)", decisionfindingsltd, re.M|re.I):
						s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "loc_st":res.start(), "loc_end":res.end()})
					for res in re.finditer(r"(\d\d?\.\s{1,3}Since\s{0,6}attaining\s{0,6}age.{1,20}the\s{0,6}claimant\s{0,6}has\s{0,6}continued)(.*)", decisionfindingsltd, re.M|re.I):
						s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# If no FIT MDI text result found, search for near FIT bench decision severe MDI text parser:
			if not s2unstructured:
				for res in re.finditer(r"(^The\s{0,6}claimant\s{0,6}has\s{0,6}the\s{0,6}following\s{0,6}severe\s{0,6}(impairments|impairment|combination\s{0,6}of\s{0,6}impairments))(.*)", decisionfindingsltd, re.M|re.I):
					s2unstructured.append({"s2ver":"1", "s2txt":tc.slight_cleaner_findings(res.group()), "s2txtsrc":"0", "s2versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

		except Exception:
			logger.exception('EXCEPTION')

		# Step 3 'Meets/Equals' Verdict/Text/Listing # Parser:
		try:
			# Standard 'Does Not Meet/Equal' Step 3 FIT Language:
			fits3finditer1 = re.finditer(r"\d\d?\.\s{1,3}The\s{0,6}claimant\s{0,6}does\s{0,6}not\s{0,6}have\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}that\s{0,6}meets\s{0,6}or\s{0,6}medically\s{0,6}equals\s{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}one\s{0,6}of\s{0,6}the\s{0,6}listed\s{0,6}impairments[^\t\r\n\f]+", decisionfindingsltd, re.I|re.M)
			for res in fits3finditer1:
				s3mtequnstructured.append({"s3mteqver":"1", "s3mteqtxt":tc.slight_cleaner_findings(res.group()), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'U', "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

			# Remote DLI 'Did Not Meet/Equal' Step 3 FIT Language:
			fits3finditer2 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI)[,\s]{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}have\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}that\s{0,6}met\s{0,6}or\s{0,6}medically\s{0,6}equaled\s{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}one\s{0,6}of\s{0,6}the\s{0,6}listed\s{0,6}impairments)[^\t\r\n\f]+", decisionfindingsltd, re.I|re.M)
			for res in fits3finditer2:
				s3mtequnstructured.append({"s3mteqver":"1", "s3mteqtxt":tc.slight_cleaner_findings(res.group()), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'U', "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

			# Adult CDR 'Present Functioning' 'Did Not Meet/Equal' Step 3 Language:
			fits3finditer3 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Since.{1,35}the\s{0,6}claimant\s{0,6}(has\s{0,6}not\s{0,6}had|did\s{0,6}not\s{0,6}have)\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}which\s{0,6}(met\s{0,6}or\s{0,6}medically\s{0,6}equaled|meets\s{0,6}or\s{0,6}medically\s{0,6}equals)\s{0,6}the\s{0,6}severity)[^\t\r\n\f]+", decisionfindingsltd, re.I|re.M|re.S)
			for res in fits3finditer3:
				s3mtequnstructured.append({"s3mteqver":"1", "s3mteqtxt":tc.slight_cleaner_findings(res.group()), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'U', "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

			# Adult T2 CDB 'Did Not Meet/Equal' Step 3 Language:
			fits3finditer4 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Prior\s{0,6}to\s{0,6}attaining\s{0,6}age\s{0,6}22[,\s]{0,6}the\s{0,6}claimant\s{0,6}did\s{0,6}not\s{0,6}have\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}that\s{0,6}(met\s{0,6}or\s{0,6}medically\s{0,6}equaled|meets\s{0,6}or\s{0,6}medically\s{0,6}equals)\s{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}one\s{0,6}of\s{0,6}the\s{0,6}listed\s{0,6}impairments)[^\t\r\n\f]+", decisionfindingsltd, re.I|re.M)
			for res in fits3finditer4:
				s3mtequnstructured.append({"s3mteqver":"1", "s3mteqtxt":tc.slight_cleaner_findings(res.group()), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'U', "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})



			# Adult/Child T16 Meets/Medically Equals:
			fits3finditer5 = re.finditer(r"(\d\d?\.\s{1,3}The\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}claimant['si\s]{0,6}impairments?\s{0,6})(.{0,50}?(medically\s{0,6}equals|medically\s{0,6}equal|medically\s{0,6}equaled|meets|meet|met).{0,50}?)(\s{0,6}the\s{0,6}criteria\s{0,6}of\s{0,6}sections?)([^\t\r\n\f]+)", decisionfindingsltd, re.M|re.I)
			for res in fits3finditer5:
				res_txt = res.group()
				res_mteq_txt = res.group(2)
				res_listing_txt = res.group(5)
				res_ver = iecc.parse_mteq(res_mteq_txt)
				lnum_reslist = iecc.parse_lnum(res_listing_txt)
				s3mtequnstructured.append({"s3mteqver":res_ver, "s3mteqtxt":tc.slight_cleaner_findings(res_txt), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'; '.join(lnum_reslist), "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})


			# Adult Meets/Medically Equals Remote DLI:
			fits3finditer6 = re.finditer(r"(\d\d?\.\s{1,3}Through\s{0,6}the\s{0,6}(date\s{0,6}last\s{0,6}insured|DLI)[,\s]{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}claimant['si\s]{0,6}impairments?\s{0,6})(.{0,50}?(medically\s{0,6}equals|medically\s{0,6}equal|medically\s{0,6}equaled|meets|meet|met).{0,50}?)(\s{0,6}the\s{0,6}criteria\s{0,6}of\s{0,6}section)([^\t\r\n\f]{1,30})", decisionfindingsltd, re.M|re.I)
			for res in fits3finditer6:
				res_txt = res.group()
				res_mteq_txt = res.group(3)
				res_listing_txt = res.group(5)
				res_ver = iecc.parse_mteq(res_mteq_txt)
				lnum_reslist = iecc.parse_lnum(res_listing_txt)
				s3mtequnstructured.append({"s3mteqver":res_ver, "s3mteqtxt":tc.slight_cleaner_findings(res_txt), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'; '.join(lnum_reslist), "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

			# Adult Meets/Medically Equals Adult CDR:
			fits3finditer7 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Since.{1,35}the\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}claimant['si\s]{0,6}(impairments|impairment)\s{0,6}(medically\s{0,6}equals|medically\s{0,6}equal|medically\s{0,6}equaled|meets|meet|met)\s{0,6}the\s{0,6}criteria\s{0,6}of\s{0,6}section)([^\t\r\n\f]{1,30})", decisionfindingsltd, re.M|re.I)
			for res in fits3finditer7:
				res_txt = res.group()
				res_mteq_txt = res.group(2)
				res_listing_txt = res.group(5)
				res_ver = iecc.parse_mteq(res_mteq_txt)
				lnum_reslist = iecc.parse_lnum(res_listing_txt)
				s3mtequnstructured.append({"s3mteqver":res_ver, "s3mteqtxt":tc.slight_cleaner_findings(res_txt), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'; '.join(lnum_reslist), "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

			# Adult Meets/Medically Equals T2 CDB:
			fits3finditer8 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Prior\s{0,6}to\s{0,6}attaining\s{0,6}age\s{0,6}22[,\s]{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}claimant['si\s]{0,6}(impairments|impairment)\s{0,6}(medically\s{0,6}equals|medically\s{0,6}equal|medically\s{0,6}equaled|meets|meet|met)\s{0,6}the\s{0,6}criteria\s{0,6}of\s{0,6}section)([^\t\r\n\f]{1,30})", decisionfindingsltd, re.M|re.I|re.S)
			for res in fits3finditer8:
				res_txt = res.group()
				res_mteq_txt = res.group(2)
				res_listing_txt = res.group(5)
				res_ver = iecc.parse_mteq(res_mteq_txt)
				lnum_reslist = iecc.parse_lnum(res_listing_txt)
				s3mtequnstructured.append({"s3mteqver":res_ver, "s3mteqtxt":tc.slight_cleaner_findings(res_txt), "s3mteqtxtsrc":"0", "s3mteqversrc":"0", "s3mteqlistnum":'; '.join(lnum_reslist), "loc_st":res.start(), "loc_end":res.end(), "s3parbadl":"U", "s3parbsf":"U", "s3parbcpp":"U", "s3parbdecomp":"U"})

		except Exception:
			logger.exception('EXCEPTION')

		# Step 3 'Functionally Equals' Verdict/Text Parser:
		# TIP: I have yet to see a dual sequential functional equivalence analysis, so this
		# code's location/context agnostic approach is acceptable for the time being.
		try:
			# FIT Child 'Did Not Functionally Equal' Step 3 Language:
			fits3fefinditer1 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})The\s{0,6}claimant\s{0,6}does\s{0,6}not\s{0,6}have\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}that\s{0,6}functionally\s{0,6}equals\s{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}listings([^\t\r\n\f]{1,30})", decisionfindingsltd, re.I|re.M)
			for res in fits3fefinditer1:
				res_txt = res.group()
				fe_rating_resdict = iecc.s3fe_rating_parser(res.end(), decisionfindingsltd)
				res_ver = '2'
				res_dict = {"s3feqtxt":tc.slight_cleaner_findings(res_txt), "s3feqver":"2", "s3feqtxtsrc":"0", "s3feqversrc":"0", "loc_st":res.start(), "loc_end":res.end()}
				for k,v in fe_rating_resdict.iteritems():
					res_dict[k] = v
				s3fequnstructured.append(res_dict)

			# FIT Child 'Does Functionally Equal' Step 3 Language:
			fits3fefinditer2 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})The\s{0,6}claimant\s{0,6}has\s{0,6}an\s{0,6}impairment\s{0,6}or\s{0,6}combination\s{0,6}of\s{0,6}impairments\s{0,6}that\s{0,6}functionally\s{0,6}equals\s{0,6}the\s{0,6}severity\s{0,6}of\s{0,6}the\s{0,6}listings([^\t\r\n\f]{1,30})", decisionfindingsltd, re.I|re.M)
			for res in fits3fefinditer2:
				res_txt = res.group()
				fe_rating_resdict = iecc.s3fe_rating_parser(res.end(), decisionfindingsltd)
				res_ver = '2'
				res_dict = {"s3feqtxt":tc.slight_cleaner_findings(res_txt), "s3feqver":"1", "s3feqtxtsrc":"0", "s3feqversrc":"0", "loc_st":res.start(), "loc_end":res.end()}
				for k,v in fe_rating_resdict.iteritems():
					res_dict[k] = v
				s3fequnstructured.append(res_dict)

		except Exception:
			logger.exception('EXCEPTION')

		# RFC Text Parser:
		try:
			# UNFAV/FFAV Adult FIT RFC Options:
			for res in re.finditer(r"(1?[0-9]{1}\. ?)((After ?careful ?consideration ?of ?the ?entire ?record,? ?)?(the ?undersigned ?finds|I ?find) ?(that ?)?the ?claimant ?(has ?had|has|had) ?the ?(residual ?functional ?capacity|RFC))(.*?)(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent)", decisionfindingsltd_nmlspc, re.I|re.M|re.S):
				res_txt = res.group()
				res_start = res.start()
				res_end = res.end()
				subres_tuplist = []
				for subres in re.finditer(r"(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", res_txt, re.I|re.M|re.S):
					subres_tuplist.append((subres.group(), subres.start()))
				if subres_tuplist and len(subres_tuplist) == 1:
					res_end = res_end - len(subres_tuplist[0][0])
					res_txt = res_txt[:subres_tuplist[0][1]]
				rfcunstructured.append({"rfctxt":tc.slight_cleaner_findings(res_txt), "rfctxtsrc":"0", "loc_st":res_start, "loc_end":res_end})

			for res in re.finditer(r"(1?[0-9]{1}\. ?)(The ?claimant ?(has ?had|has|had) ?the ?(residual ?functional ?capacity|RFC))(.*?)(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", decisionfindingsltd_nmlspc, re.I|re.M|re.S):
				res_txt = res.group()
				res_start = res.start()
				res_end = res.end()
				subres_tuplist = []
				for subres in re.finditer(r"(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", res_txt, re.I|re.M|re.S):
					subres_tuplist.append((subres.group(), subres.start()))
				if subres_tuplist and len(subres_tuplist) == 1:
					res_end = res_end - len(subres_tuplist[0][0])
					res_txt = res_txt[:subres_tuplist[0][1]]
				rfcunstructured.append({"rfctxt":tc.slight_cleaner_findings(res_txt), "rfctxtsrc":"0", "loc_st":res_start, "loc_end":res_end})

			for res in re.finditer(r"(1?[0-9]{1}\. ?)((After ?careful ?consideration ?of ?the ?entire ?record,? ?)?(the ?undersigned ?finds|I ?find) ?(that ?|),? ?through ?the ?date ?last ?insured,? ?the ?claimant ?(has ?had|has|had) ?the ?(residual ?functional ?capacity|RFC))(.*?)(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", decisionfindingsltd_nmlspc, re.I|re.M|re.S):
				res_txt = res.group()
				res_start = res.start()
				res_end = res.end()
				subres_tuplist = []
				for subres in re.finditer(r"(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", res_txt, re.I|re.M|re.S):
					subres_tuplist.append((subres.group(), subres.start()))
				if subres_tuplist and len(subres_tuplist) == 1:
					res_end = res_end - len(subres_tuplist[0][0])
					res_txt = res_txt[:subres_tuplist[0][1]]
				rfcunstructured.append({"rfctxt":tc.slight_cleaner_findings(res_txt), "rfctxtsrc":"0", "loc_st":res_start, "loc_end":res_end})

			# T16 SSI Child-To-Adult FIT RFC Options:
			for res in re.finditer(r"(1?[0-9]{1}\. ?)((After ?careful ?consideration ?of ?the ?entire ?record,? ?)?(the ?undersigned ?finds|I ?find) ?(that ?|),? ?since ?attaining ?age ?18,? ?the ?claimant ?(has ?had|has|had) ?the ?(residual ?functional ?capacity|RFC))(.*?)(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", decisionfindingsltd_nmlspc, re.I|re.M|re.S):
				res_txt = res.group()
				res_start = res.start()
				res_end = res.end()
				subres_tuplist = []
				for subres in re.finditer(r"(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", res_txt, re.I|re.M|re.S):
					subres_tuplist.append((subres.group(), subres.start()))
				if subres_tuplist and len(subres_tuplist) == 1:
					res_end = res_end - len(subres_tuplist[0][0])
					res_txt = res_txt[:subres_tuplist[0][1]]
				rfcunstructured.append({"rfctxt":tc.slight_cleaner_findings(res_txt), "rfctxtsrc":"0", "loc_st":res_start, "loc_end":res_end})

			# CDR Adult FIT RFC Options (Current RFC):
			for res in re.finditer(r"(1?[0-9]{1}\. ?)((After ?careful ?consideration ?of ?the ?entire ?record,? ?)?(the ?undersigned ?finds|I ?find) ?(that ?|),? ?based ?on ?the ?current ?impairments,? ?the ?claimant ?(has ?had|has|had) ?the ?(residual ?functional ?capacity|RFC))(.*?)(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", decisionfindingsltd_nmlspc, re.I|re.M|re.S):
				res_txt = res.group()
				res_start = res.start()
				res_end = res.end()
				subres_tuplist = []
				for subres in re.finditer(r"(In ?making ?this ?finding,? ?(the ?undersigned ?has|the ?undersigned|I ?have|I) ?considered ?all ?symptoms ?and ?the ?extent|considered ?all ?symptoms ?and ?the ?extent ?to ?which ?these ?symptoms ?can ?reasonably ?be ?accepted)", res_txt, re.I|re.M|re.S):
					subres_tuplist.append((subres.group(), subres.start()))
				if subres_tuplist and len(subres_tuplist) == 1:
					res_end = res_end - len(subres_tuplist[0][0])
					res_txt = res_txt[:subres_tuplist[0][1]]
				rfcunstructured.append({"rfctxt":tc.slight_cleaner_findings(res_txt), "rfctxtsrc":"0", "loc_st":res_start, "loc_end":res_end})

		except Exception:
			logger.exception('EXCEPTION')

		# Step 4 Verdict/Text/Jobs Claimant Can Perform Parser:
		try:
			# Step 4 FIT 'able to perform PRW':
			step4finditer1 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Prior\s{0,6}to\s{0,6}attaining\s{0,6}age\s{0,6}22[,\s]{0,4}the\s{0,6}claimant|Since.{1,25}the\s{0,6}claimant|At\s{0,6}all\s{0,6}times\s{0,6}relevant\s{0,6}to\s{0,6}this\s{0,6}decision[,\s]{0,4}the\s{0,6}claimant|Through\s{0,6}the\s{0,6}date\s{0,6}last\s{0,6}insured[,\s]{0,4}the\s{0,6}claimant|The\s{0,6}claimant)(\s{0,6}has\s{0,6}been\s{0,6}|\s{0,6}was\s{0,6}|\s{0,6}is\s{0,6})(capable\s{0,6}of\s{0,6}performing\s{0,6}past\s{0,6}relevant\s{0,6}work\s{0,6}as)(.*)", decisionfindingsltd, re.I|re.M)
			for res in step4finditer1:
				res_txt = res.group()
				res_txt_jobstr = res.group(5)
				res_txt_jobstr = re.sub(r"This\s{0,6}work\s{0,6}does\s{0,6}not\s{0,6}require.*", "", res_txt_jobstr, flags=re.I|re.S)
				res_txt_jobstr = re.sub(r"does\s{0,6}not\s{0,6}require.*", "", res_txt_jobstr, flags=re.I|re.S)
				res_txt_jobstr = re.sub(r"This\s{0,6}work\s{0,6}.*", "", res_txt_jobstr, flags=re.S)
				res_txt_jobstr = re.sub(r"\(.*?\)", " ", res_txt_jobstr)
				res_txt_jobstr = re.sub(r"\[.*?\]", " ", res_txt_jobstr)
				res_txt_jobstr = ' '.join(res_txt_jobstr.split()).lower()
				res_txt_jobstr = re.sub("^as an ?|^as ?a ?", "", res_txt_jobstr)
				res_txt_jobstr = re.sub("^an ?|^a ?", "", res_txt_jobstr)
				res_txt_jobstr = re.sub("\.$", "", res_txt_jobstr)
				res_txt_job_list = iecc.calc_s4jobscanperf(res_txt_jobstr)
				# TIP: calc_s4jobscanperf() returns a semicolon divided list of jobs
				res_txt_job_list_len = len(res_txt_job_list.split('; '))
				s4unstructured.append({"s4txt":tc.slight_cleaner_findings(res.group()), "s4ver":"1", "s4actgen":"U", "s4jobscanperf":res_txt_job_list, "s4jobscanperfct":res_txt_job_list_len, "s4txtsrc":"0", "s4versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# Step 4 FIT Unable Language:
			step4finditer2 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Prior\s{0,6}to\s{0,6}attaining\s{0,6}age\s{0,6}22[,\s]{0,4}the\s{0,6}claimant|Since.{1,25}the\s{0,6}claimant|At\s{0,6}all\s{0,6}times\s{0,6}relevant\s{0,6}to\s{0,6}this\s{0,6}decision[,\s]{0,4}the\s{0,6}claimant|Through\s{0,6}the\s{0,6}date\s{0,6}last\s{0,6}insured[,\s]{0,4}the\s{0,6}claimant|The\s{0,6}claimant)(\s{0,6}has\s{0,6}been\s{0,6}|\s{0,6}was\s{0,6}|\s{0,6}is\s{0,6})(unable\s{0,6}|to\s{0,6}perform\s{0,6}any\s{0,6}past\s{0,6}relevant\s{0,6}work)(.*)", decisionfindingsltd, re.I|re.M)
			for res in step4finditer2:
				s4unstructured.append({"s4txt":tc.slight_cleaner_findings(res.group()), "s4ver":"2", "s4actgen":"U", "s4jobscanperf":"U", "s4jobscanperfct":"U", "s4txtsrc":"0", "s4versrc":"0", "loc_st":res.start(), "loc_end":res.end()})

			# Step 4 FIT No PRW:
			step4finditer3 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(The\s{0,6}claimant|Claimant)\s{0,6}has\s{0,6}no\s{0,6}past\s{0,6}relevant\s{0,6}work", decisionfindingsltd, re.I|re.M)
			for res in step4finditer3:
				s4unstructured.append({"s4txt":tc.slight_cleaner_findings(res.group()), "s4ver":"3", "s4actgen":"U", "s4jobscanperf":"U", "s4jobscanperfct":"U", "s4txtsrc":"0", "s4versrc":"0", "loc_st":res.start(), "loc_end":res.end()})
		except Exception:
			logger.exception('EXCEPTION')

		# Education Level Parser:
		try:
			edstring = "U"
			# Education string FIT search 1:
			edsearchcomp1 = re.compile("claimant[^\.]{1,45}education.{1,150}communicate\s{0,6}in\s{0,6}English", re.S|re.I)
			edsearch1 = re.search(edsearchcomp1, decisionfindingsltd)
			if edsearch1:
				edstring = edsearch1.group()
			# Education string FIT search 2:
			edsearchcomp2 = re.compile("claimant[^\.]{1,45}illiterate.{1,150}communicate\s{0,6}in\s{0,6}English", re.S|re.I)
			edsearch2 = re.search(edsearchcomp2, decisionfindingsltd)
			if edsearch2:
				edstring = edsearch2.group()
			# If FIT edstring found, search for education level cited within it:
			if edstring != "U":
				ed2 = re.search(r"high\s{0,6}school", edstring, re.I)
				ed2a = re.search(r"did\s{0,6}not\s{0,6}complete\s{0,6}high\s{0,6}school|has\s{0,6}not\s{0,6}completed\s{0,6}high\s{0,6}school|never\s{0,6}completed\s{0,6}high\s{0,6}school", edstring, re.I)
				ed3 = re.search(r"limited", edstring, re.I)
				ed4 = re.search(r"marginal", edstring, re.I)
				ed5 = re.search(r"illiterate", edstring, re.I)
				ed6 = re.search("unable\s{0,6}to\s{0,6}communicate|not\s{0,6}able\s{0,6}to\s{0,6}communicate|cannot\s{0,6}communicate", edstring, re.I)
				ed7 = re.search(r"The\s{0,6}claimant\s{0,6}is\s{0,6}not\s{0,6}able\s{0,6}to\s{0,6}communicate\s{0,6}in\s{0,6}English[,\s]{0,6}and\s{0,6}is\s{0,6}considered\s{0,6}in\s{0,6}the\s{0,6}same\s{0,6}way\s{0,6}as\s{0,6}an\s{0,6}individual\s{0,6}who\s{0,6}is\s{0,6}illiterate\s{0,6}in\s{0,6}English\s{0,6}\(20\s{0,6}C\.? ?F\.? ?R\.? ?", decisionfindingsltd, re.I)
				if bool(ed2):
					if bool(ed2a) is False:
						edunstructured.append("H")
				if bool(ed3):
					edunstructured.append("L")
				if bool(ed4):
					edunstructured.append("M")
				if bool(ed5):
					edunstructured.append("I")
				if bool(ed6):
					edunstructured.append("I")
				if bool(ed7):
					edunstructured.append("I")
				# Convert list entries to non-duplicate 'unstructured' list values:
				if len(edunstructured) > 1:
					edunstructured = list(set(edunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# Claimant DOB Parser:
		# TODO: Accuracy for this 'as is' is high,
		# but in future hew to FIT language more closely.
		try:
			dobsearch1 = re.search(r"(born\s{0,6}on|born)(\s{0,6})((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d {0,2}\d {0,2}\d {0,2}\d)", decisionfindingsltd, re.I|re.S)
			if bool(dobsearch1) is True:
				dobresult1 = dobsearch1.group(3)
				dobresult1 = dobresult1.strip()
				dobresult1 = dh.parse_date_tostr(dobresult1)
				dobunstructured.append(dobresult1)
		except Exception:
			logger.exception('EXCEPTION')

		# Transferrable Skills Verdict Parser:
		try:
			txskillssearch1 = re.search(r"Transferability\s{0,6}of\s{0,6}job\s{0,6}skills\s{0,6}is\s{0,6}not\s{0,6}an\s{0,6}issue\s{0,6}(in\s{0,6}this\s{0,6}case|)\s{0,6}because\s{0,6}the\s{0,6}claimant\s{0,6}does\s{0,6}not\s{0,6}have\s{0,6}past\s{0,6}relevant\s{0,6}work", decisionfindingsltd, re.I)
			if bool(txskillssearch1):
				txskillsverdictunstructured.append("3")
			txskillssearch2 = re.search(r"Transferability\s{0,6}of\s{0,6}job\s{0,6}skills\s{0,6}is\s{0,6}not\s{0,6}an\s{0,6}issue\s{0,6}(in\s{0,6}this\s{0,6}case|)\s{0,6}because\s{0,6}the\s{0,6}claimant['si\s]{0,6}past\s{0,6}relevant\s{0,6}work\s{0,6}is\s{0,6}unskilled", decisionfindingsltd, re.I)
			if bool(txskillssearch2):
				txskillsverdictunstructured.append("3")
			txskillssearch3 = re.search(r"The\s{0,6}claimant['si\s]{0,6}acquired\s{0,6}job\s{0,6}skills\s{0,6}do\s{0,6}not\s{0,6}transfer\s{0,6}to\s{0,6}other\s{0,6}occupations\s{0,6}within\s{0,6}the\s{0,6}residual\s{0,6}functional\s{0,6}capacity\s{0,6}defined\s{0,6}above", decisionfindingsltd, re.I)
			if bool(txskillssearch3):
				txskillsverdictunstructured.append("2")
			txskillssearch4 = re.search(r"Transferability\s{0,6}of\s{0,6}job\s{0,6}skills\s{0,6}is\s{0,6}not\s{0,6}material\s{0,6}to\s{0,6}the\s{0,6}determination\s{0,6}of\s{0,6}disability\s{0,6}due\s{0,6}to\s{0,6}the\s{0,6}claimant['si\s]{0,6}age", decisionfindingsltd, re.I)
			if bool(txskillssearch4):
				txskillsverdictunstructured.append("3")
			txskillssearch5 = re.search(r"Transferability\s{0,6}of\s{0,6}job\s{0,6}skills\s{0,6}is\s{0,6}not\s{0,6}material\s{0,6}to\s{0,6}the\s{0,6}determination\s{0,6}of\s{0,6}disability\s{0,6}because\s{0,6}using\s{0,6}the\s{0,6}Medical-Vocational\s{0,6}Rules\s{0,6}as\s{0,6}a\s{0,6}framework\s{0,6}supports\s{0,6}a\s{0,6}finding\s{0,6}that\s{0,6}the\s{0,6}claimant\s{0,6}is\s{0,6}\"not\s{0,6}disabled,\"\s{0,6}whether\s{0,6}or\s{0,6}not\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}transferable\s{0,6}job\s{0,6}skills", decisionfindingsltd, re.I)
			if bool(txskillssearch5):
				txskillsverdictunstructured.append("3")
			txskillssearch6 = re.search(r"Transferability\s{0,6}of\s{0,6}job\s{0,6}skills\s{0,6}is\s{0,6}not\s{0,6}material\s{0,6}to\s{0,6}the\s{0,6}determination\s{0,6}of\s{0,6}disability\s{0,6}because\s{0,6}applying\s{0,6}the\s{0,6}Medical-Vocational\s{0,6}Rules\s{0,6}directly\s{0,6}supports\s{0,6}a\s{0,6}finding\s{0,6}of\s{0,6}\"not\s{0,6}disabled,\"\s{0,6}whether\s{0,6}or\s{0,6}not\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}transferable\s{0,6}job\s{0,6}skills", decisionfindingsltd, re.I)
			if bool(txskillssearch6):
				txskillsverdictunstructured.append("3")
			txskillssearch7 = re.search(r"The\s{0,6}claimant\s{0,6}has\s{0,6}acquired\s{0,6}work\s{0,6}skills\s{0,6}from\s{0,6}past\s{0,6}relevant\s{0,6}work", decisionfindingsltd, re.I)
			if bool(txskillssearch7):
				txskillsverdictunstructured.append("1")
			# Convert list entries to non-duplicate 'unstructured' list values:
			if len(txskillsverdictunstructured) > 1:
				txskillsverdictunstructured = list(set(txskillsverdictunstructured))
		except Exception:
			logger.exception('EXCEPTION')

		# Step 5 Verdict/Text Parser:
		try:
			# Step 5 UNFAV FIT Jobs Exist Standard:
			s5finditer1 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})(Prior\s{0,6}to\s{0,6}attaining\s{0,6}age\s{0,6}22[,\s]{0,6}considering|Since.{5,25}[,\s]{0,6}considering|Through\s{0,6}the\s{0,6}date\s{0,6}last\s{0,6}insured[,\s]{0,6}considering|Considering)\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}there\s{0,6}(were\s{0,6}jobs\s{0,6}that\s{0,6}existed|are\s{0,6}jobs\s{0,6}that\s{0,6}exist)\s{0,6}in\s{0,6}significant\s{0,6}numbers\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy\s{0,6}that\s{0,6}the\s{0,6}claimant\s{0,6}(could\s{0,6}have\s{0,6}performed|can\s{0,6}perform)", decisionfindingsltd, re.I|re.S|re.M)
			for res in s5finditer1:
				res_txt = res.group()
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"1", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 UNFAV FIT Jobs Exist Tx Skills:
			s5finditer2 = re.finditer(r"(\d\.\s{1,3}|\d\d\.\s{1,3})Considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}the\s{0,6}claimant\s{0,6}(has|had)\s{0,6}acquired\s{0,6}work\s{0,6}skills\s{0,6}from\s{0,6}past\s{0,6}relevant\s{0,6}work\s{0,6}that\s{0,6}(were|are)\s{0,6}transferable\s{0,6}to\s{0,6}other\s{0,6}occupations\s{0,6}with\s{0,6}jobs\s{0,6}existing\s{0,6}in\s{0,6}significant\s{0,6}numbers\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy", decisionfindingsltd, re.I|re.M|re.S)
			for res in s5finditer2:
				res_txt = res.group()
				res_st = res.start()
				res_end = res.end()
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"1", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 UNFAV FIT Alternative Finding Jobs Exist Standard 1:
			s5finditer3 = re.finditer(r"(Although\s{0,6}the\s{0,6}claimant\s{0,6}is\s{0,6}capable\s{0,6}of\s{0,6}performing\s*(his|her|)\s{0,6}past\s{0,6}relevant\s{0,6}work[,\s]{0,6}there\s{0,6}are\s*(also)\s{0,6}other\s{0,6}jobs\s{0,6}existing\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy\s{0,6}(that|)\s{0,6}(she|he)\s{0,6}is\s{0,6}also\s{0,6}able\s{0,6}to\s{0,6}perform)(.*)", decisionfindingsltd, re.S|re.I|re.M)
			for res in s5finditer3:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"2", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 UNFAV FIT Alternative Finding Jobs Exist Standard 2:
			s5finditer4 = re.finditer(r"(In\s{0,6}the\s{0,6}alternative[,\s]{0,6}considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}\s{0,6}there\s{0,6}(were\s{0,6}other\s{0,6}jobs\s{0,6}that\s{0,6}existed|are\s{0,6}other\s{0,6}jobs\s{0,6}that\s{0,6}exist))(.*)", decisionfindingsltd, re.S|re.I|re.M)
			for res in s5finditer4:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"2", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 UNFAV FIT Alternative Finding Jobs Exist Tx Skills:
			s5finditer5 = re.finditer(r"(In\s{0,6}the\s{0,6}alternative[,\s]{0,6}considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}the\s{0,6}claimant\s{0,6}(had|has)\s{0,6}also\s{0,6}acquired\s{0,6}work\s{0,6}skills\s{0,6}from\s{0,6}past\s{0,6}relevant\s{0,6}work\s{0,6}that\s{0,6}(were|are)\s{0,6}transferable\s{0,6}to\s{0,6}other\s{0,6}occupations\s{0,6}with\s{0,6}jobs\s{0,6}existing)(.*)", decisionfindingsltd, re.M|re.S|re.I)
			for res in s5finditer5:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"2", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 FFAV FIT No Jobs Standard:
			s5finditer6 = re.finditer(r"((\d\.\s{1,3}|\d\d\.\s{1,3})Considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}there\s{0,6}are\s{0,6}no\s{0,6}jobs\s{0,6}that\s{0,6}exist\s{0,6}in\s{0,6}significant\s{0,6}numbers\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy\s{0,6}that\s{0,6}the\s{0,6}claimant\s{0,6}can\s{0,6}perform)(.*)", decisionfindingsltd, re.S|re.I|re.M)
			for res in s5finditer6:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"3", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 T16 Child->Adult FIT No Jobs:
			s5finditer7 = re.finditer(r"((\d\.\s{1,3}|\d\d\.\s{1,3})Considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}there\s{0,6}are\s{0,6}no\s{0,6}jobs\s{0,6}that\s{0,6}exist\s{0,6}in\s{0,6}significant\s{0,6}numbers\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy\s{0,6}that\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}been\s{0,6}able\s{0,6}to\s{0,6}perform\s{0,6}since\s{0,6}attaining\s{0,6}age\s{0,6}18)(.*)", decisionfindingsltd, re.S|re.I|re.M)
			for res in s5finditer7:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"3", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

			# Step 5 T16 Child->Adult FIT Jobs Exist:
			s5finditer8 = re.finditer("((\d\.\s{1,3}|\d\d\.\s{1,3})Since\s{0,6}attaining\s{0,6}age\s{0,6}18[,\s]{0,6}considering\s{0,6}the\s{0,6}claimant['si\s]{0,6}age[,\s]{0,6}education[,\s]{0,6}work\s{0,6}experience[,\s]{0,6}and\s{0,6}residual\s{0,6}functional\s{0,6}capacity[,\s]{0,6}jobs\s{0,6}have\s{0,6}existed\s{0,6}in\s{0,6}significant\s{0,6}numbers\s{0,6}in\s{0,6}the\s{0,6}national\s{0,6}economy\s{0,6}that\s{0,6}the\s{0,6}claimant\s{0,6}has\s{0,6}been\s{0,6}able\s{0,6}to\s{0,6}perform)(.*)", decisionfindingsltd, re.S|re.I|re.M)
			for res in s5finditer8:
				res_txt = res.group(1)
				res_st = res.start()
				res_end = res_st + len(res_txt)
				s5unstructured.append({"s5txt":tc.slight_cleaner_findings(res_txt), "s5ver":"1", "s5txtsrc":"0", "s5versrc":"0", "s5fwkdir":"U", "loc_st":res_st, "loc_end":res_end})

		except Exception:
			logger.exception('EXCEPTION')

		### 'SECOND TIER' SEP/FINDINGS DATA PARSING ###

		# UNIVERSAL TODO: Evaluate the effect of stemming on supervised classifier
		# datasets.  Likely will not be terribly material due to the frequency of
		# training observations, but worth exploring:
		# E.g.
		# from nltk.stem.porter import PorterStemmer
		# porter = PorterStemmer()
		# porter.stem("functional") --> 'function'

		# Create all finding heading tuple lists
		# from most to least strict:
		# Findings tuple list from 'decisionfindingsltd':
		# ('4. This is finding heading text...', 25, 55)
		# NOTE: You presently only query second tier and third tier findings lists
		# in cases where the first tier returns *zero* results.  But what if a second
		# finding heading is lurking?  There is certainly a need to balance comprehensiveness
		# with reduction of false positives.  One mitigator would be to add code that would
		# recognize when what's been identified is the same as something from another
		# findings list source.  More realistically, it probably will work out most times
		# to simply stop after one tier if there's even 1 result, as it still leaves the door
		# open for 2+ results within that tier, and a match within 1 tier is likely to produce
		# any other additional matches, as the ALJs/OCR are likely to consistently 'present' the
		# finding heading text.
		findingstuplist = []
		findingfinditer1 = re.finditer(r"^\d\. {1,3}[A-Z]{1}.*", decisionfindingsltd, re.M)
		for res in findingfinditer1:
			findingstuplist.append((res.group(), res.start(), res.end()))
		findingfinditer2 = re.finditer(r"^(1|2)\d\. {1,3}[A-Z]{1}.*", decisionfindingsltd, re.M)
		for res in findingfinditer2:
			findingstuplist.append((res.group(), res.start(), res.end()))

		# Findings tuple list from space-normalized sentence list:
		findingssenttuplist = []
		for sent in decisionfindingsltd_sentlist:
			sent = sent.strip()
			if re.search(r"^\d\. {1,3}[A-Z]{1}", sent) or re.search(r"^(1|2)\d\. {1,3}[A-Z]{1}", sent):
				flsent_restup = iecc.extract_tgt_sent_ind(sent, decisionfindingsltd)
				if flsent_restup:
					findingssenttuplist.append((sent, flsent_restup[0], flsent_restup[1]))

		# (DEPRECATED 08042017 - returns far more 'non-finding' strings than 'finding' strings)
		# 'Expanded' findings tuple list that does not require
		# finding heading numeric to appear at beginning of line:
		expandedfindingstuplist = []
		expfindingfinditer1 = re.finditer(r"(\.\s*)(\d\. {1,3}[A-Z]{1}[a-z]{1}.*)", decisionfindingsltd, re.M)
		for res in expfindingfinditer1:
			expandedfindingstuplist.append((res.group(), res.start(), res.end()))
		expfindingfinditer2 = re.finditer(r"(\.\s*)((1|2)\d\. {1,3}[A-Z]{1}[a-z]{1}.*)", decisionfindingsltd, re.M)
		for res in expfindingfinditer2:
			expandedfindingstuplist.append((res.group(), res.start(), res.end()))

		# Second Tier Step 1 SGA Verdict/Text/Start Date/End Date Parser:
		try:
			# If 1+ FIT results, keep these:
			if s1sgaunstructured:
				s1sgachecked = s1sgaunstructured
			# Else, conduct ML analysis:
			else:

				# Step 1 SGA finding heading two-tier ML classifier:
				def s1sga_clf_tuplist(input_tuplist):
					'''Perform Step 1 SGA finding
					heading ML classification on an input
					list of tuples containing finding heading
					text.

					Args:
						input_tuplist {list}: A list where the
							each tup[0] value = an item of
							finding heading text.
					Returns:
						resdictlist {list}: A list of dictionaries
							formatted like values in 's1sgaunstructured'
							or 's1sgachecked' (mirroring s1sga child table
							columns).
					Raises:
						N/A (returns empty list if exception).'''
					try:
						resdictlist = []
						s1sgamlfindingslist = []
						for tup in input_tuplist:
							tup_txt = tup[0]
							tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
							tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
							s1sgamlfindingslist.append(tup_txt)
						s1sgamlfindingslist_array = np.array(s1sgamlfindingslist)
						s1sgamlfindingslist_vectorized = iedl.s1sga_id_vectorizer.transform(s1sgamlfindingslist_array)

						# Classify which are Step 1 finding headings:
						s1sgaml_poslist = []
						for i in range(len(s1sgamlfindingslist_array)):
							itemres = iedl.s1sga_id_clf.predict(s1sgamlfindingslist_vectorized[i])
							if 1 in itemres:
								s1sgaml_poslist.append(i)

						# Classify type of each Step 1 finding:
						if s1sgaml_poslist:
							s1sgaml_pos_tuplist = [input_tuplist[i] for i in s1sgaml_poslist]
							s1sgaml_pos_txtlist = [s1sgamlfindingslist_array[i] for i in s1sgaml_poslist]
							s1sgaml_pos_txtlist_array = np.array(s1sgaml_pos_txtlist)
							s1sgaml_pos_txtlist_vectorized = iedl.s1sga_type_vectorizer.transform(s1sgaml_pos_txtlist_array)
							s1sgaml_verlist = []
							for i in range(len(s1sgaml_pos_txtlist_array)):
								itemres = iedl.s1sga_type_clf.predict(s1sgaml_pos_txtlist_vectorized[i])
								# TIP: Transforming classifier output to its
								# corresponding 's1sgaver' value:
								if 1 in itemres:
									s1sgaml_verlist.append('1')
								elif 2 in itemres:
									s1sgaml_verlist.append('4')
								elif 3 in itemres:
									s1sgaml_verlist.append('3')
								elif 4 in itemres:
									s1sgaml_verlist.append('2')
							s1sgaml_pos_tuplist_zip = zip(s1sgaml_pos_tuplist, s1sgaml_verlist)
							# In: [(('2. The claimant engaged in earnings equaling substantial gainful activity
							# since May 1, 2006, the alleged onset date (20 CFR 404.1571 et seq., and 416.971 et seq.).', 45, 70), '4')]
							# Out: {'s1sgatxt':'U', 's1sgaver':'U', 's1sgatype':'U', 's1sga_startdt':'U', 's1sga_enddt':'U', 's1sgatxtsrc':'U', 's1sgaversrc':'U'}
							for tup in s1sgaml_pos_tuplist_zip:
								resdictlist.append({'s1sgatxt':tup[0][0], 's1sgaver':tup[1], 's1sgatype':'U', 's1sga_startdt':'U', 's1sga_enddt':'U', 's1sgatxtsrc':'3', 's1sgaversrc':'3', 'loc_st':tup[0][1], 'loc_end':tup[0][2]})

						return resdictlist
					except Exception:
						logger.exception('EXCEPTION')
						return []

				# First, try parsing 'findingstuplist':
				if findingstuplist:
					findinglist_resdictlist = s1sga_clf_tuplist(findingstuplist)
					if findinglist_resdictlist:
						for resdict in findinglist_resdictlist:
							s1sgachecked.append(resdict)
				# If still no values, try sentence-tokenized version
				# of 'findingstuplist':

				if not s1sgachecked:
					if findingssenttuplist:
						findinglist_resdictlist = s1sga_clf_tuplist(findingssenttuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s1sgachecked.append(resdict)
				# If still no values, try one last time with
				# 'expandedfindingslist':
				if not s1sgachecked:
					if expandedfindingstuplist:
						findinglist_resdictlist = s1sga_clf_tuplist(expandedfindingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s1sgachecked.append(resdict)

		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Step 2 MDI Verdict/Text Parser:
		try:
			if s2unstructured:
				s2checked = s2unstructured
			else:
				# Step 2 finding heading two-tier ML classifier:
				def s2_clf_tuplist(input_tuplist):
					'''Perform Step 2 finding
					heading ML classification on an input
					list of tuples containing finding heading
					text.

					Args:
						input_tuplist {list}: A list where the
							each tup[0] value = an item of
							finding heading text.
					Returns:
						resdictlist {list}: A list of dictionaries
							formatted like values in 's2unstructured'
							or 's2checked' (mirroring s2 child table
							columns).
					Raises:
						N/A (returns empty list if exception).'''
					try:
						resdictlist = []
						s2mlfindingslist = []
						for tup in input_tuplist:
							tup_txt = tup[0]
							tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
							tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
							s2mlfindingslist.append(tup_txt)
						s2mlfindingslist_array = np.array(s2mlfindingslist)
						s2mlfindingslist_vectorized = iedl.s2_id_vectorizer.transform(s2mlfindingslist_array)

						# Classify which are Step 2 finding headings:
						s2ml_poslist = []
						for i in range(len(s2mlfindingslist_array)):
							itemres = iedl.s2_id_clf.predict(s2mlfindingslist_vectorized[i])
							if 1 in itemres:
								s2ml_poslist.append(i)

						# Classify type of each Step 2 finding:
						if s2ml_poslist:
							s2ml_pos_tuplist = [input_tuplist[i] for i in s2ml_poslist]
							s2ml_pos_txtlist = [s2mlfindingslist_array[i] for i in s2ml_poslist]
							s2ml_pos_txtlist_array = np.array(s2ml_pos_txtlist)
							s2ml_pos_txtlist_vectorized = iedl.s2_type_vectorizer.transform(s2ml_pos_txtlist_array)
							s2ml_verlist = []
							for i in range(len(s2ml_pos_txtlist_array)):
								itemres = iedl.s2_type_clf.predict(s2ml_pos_txtlist_vectorized[i])
								# TIP: Transforming classifier output to its
								# corresponding 's2ver' value:
								if 1 in itemres:
									s2ml_verlist.append('1')
								elif 2 in itemres:
									s2ml_verlist.append('2')
								elif 3 in itemres:
									s2ml_verlist.append('3')

							s2ml_pos_tuplist_zip = zip(s2ml_pos_tuplist, s2ml_verlist)
							for tup in s2ml_pos_tuplist_zip:
								resdictlist.append({'s2txt':tup[0][0], 's2ver':tup[1], 's2txtsrc':'3', 's2versrc':'3', 'loc_st':tup[0][1], 'loc_end':tup[0][2]})

						return resdictlist
					except Exception:
						logger.exception('EXCEPTION')
						return []

				# First, try parsing 'findingstuplist':
				if findingstuplist:
					findinglist_resdictlist = s2_clf_tuplist(findingstuplist)
					if findinglist_resdictlist:
						for resdict in findinglist_resdictlist:
							s2checked.append(resdict)
				# If still no values, try sentence-tokenized version
				# of 'findingstuplist':
				if not s2checked:
					if findingssenttuplist:
						findinglist_resdictlist = s2_clf_tuplist(findingssenttuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s2checked.append(resdict)
				# If still no values, try one last time with
				# 'expandedfindingslist':
				if not s2checked:
					if expandedfindingstuplist:
						findinglist_resdictlist = s2_clf_tuplist(expandedfindingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s2checked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Step 3 'Meets/Equals' Verdict/Text/Listing # Parser:
		try:
			if s3mtequnstructured:
				s3mteqchecked = s3mtequnstructured
			else:

				# Step 3 'meets/equals' two-tier ML classifier:
				def s3mteq_clf_tuplist(input_tuplist):
					'''Perform Step 3 meets/equals finding
					heading ML classification on an input
					list of tuples containing finding heading
					text.

					Args:
						input_tuplist {list}: A list where the
							each tup[0] value = an item of
							finding heading text.
					Returns:
						resdictlist {list}: A list of dictionaries
							formatted like values in 's3mtequnstructured'
							or 's3mteqchecked' (mirroring s3mteq child table
							columns).
					Raises:
						N/A (returns empty list if exception).'''
					try:
						resdictlist = []
						s3mteqmlfindingslist = []
						for tup in input_tuplist:
							tup_txt = tup[0]
							tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
							tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
							s3mteqmlfindingslist.append(tup_txt)
						s3mteqmlfindingslist_array = np.array(s3mteqmlfindingslist)
						s3mteqmlfindingslist_vectorized = iedl.s3mteq_id_vectorizer.transform(s3mteqmlfindingslist_array)

						# Classify which are Step 3 meets/equals finding headings:
						s3mteqml_poslist = []
						for i in range(len(s3mteqmlfindingslist_array)):
							itemres = iedl.s3mteq_id_clf.predict(s3mteqmlfindingslist_vectorized[i])
							if 1 in itemres:
								s3mteqml_poslist.append(i)

						# Classify type of each Step 3 meets/equals finding:
						if s3mteqml_poslist:
							s3mteqml_pos_tuplist = [input_tuplist[i] for i in s3mteqml_poslist]
							s3mteqml_pos_txtlist = [s3mteqmlfindingslist_array[i] for i in s3mteqml_poslist]
							s3mteqml_pos_txtlist_array = np.array(s3mteqml_pos_txtlist)
							s3mteqml_pos_txtlist_vectorized = iedl.s3mteq_type_vectorizer.transform(s3mteqml_pos_txtlist_array)
							s3mteqml_verlist = []
							for i in range(len(s3mteqml_pos_txtlist_array)):
								itemres = iedl.s3mteq_type_clf.predict(s3mteqml_pos_txtlist_vectorized[i])
								# TIP: Transforming classifier output to its
								# corresponding 's3mteqver' value:
								if 1 in itemres:
									s3mteqml_verlist.append('1')
								elif 2 in itemres:
									s3mteqml_verlist.append('2')

							# Generate resdict entries:
							s3mteqml_pos_tuplist_zip = zip(s3mteqml_pos_tuplist, s3mteqml_verlist)
							for tup in s3mteqml_pos_tuplist_zip:
								if tup[1] == '1':
									resdictlist.append({'s3mteqtxt':tup[0][0], 's3mteqver':tup[1], 's3mteqtxtsrc':'3', 's3mteqversrc':'3', 's3mteqlistnum':'U', 'loc_st':tup[0][1], 'loc_end':tup[0][2], 's3parbadl':'U', 's3parbsf':'U', 's3parbcpp':'U', 's3parbdecomp':'U'})
								elif tup[1] == '2':
									mteq_res_ver = iecc.parse_mteq(tup[0][0])
									lnum_txt = tup[0][0]
									# TODO: Implement greater cleaning of 'lnum_txt':
									lnum_txt = re.sub(r"\(20\s{0,6}C\.? ?F\.? ?R\.? ?", " ", lnum_txt, flags=re.I)
									lnum_reslist = iecc.parse_lnum(lnum_txt)
									resdictlist.append({'s3mteqtxt':tup[0][0], 's3mteqver':mteq_res_ver, 's3mteqtxtsrc':'3', 's3mteqversrc':'3', 's3mteqlistnum':'; '.join(lnum_reslist), 'loc_st':tup[0][1], 'loc_end':tup[0][2], 's3parbadl':'U', 's3parbsf':'U', 's3parbcpp':'U', 's3parbdecomp':'U'})

						return resdictlist
					except Exception:
						logger.exception('EXCEPTION')
						return []

				# First, try parsing 'findingstuplist':
				if findingstuplist:
					findinglist_resdictlist = s3mteq_clf_tuplist(findingstuplist)
					if findinglist_resdictlist:
						for resdict in findinglist_resdictlist:
							s3mteqchecked.append(resdict)
				# If still no values, try sentence-tokenized version
				# of 'findingstuplist':
				if not s3mteqchecked:
					if findingssenttuplist:
						findinglist_resdictlist = s3mteq_clf_tuplist(findingssenttuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s3mteqchecked.append(resdict)
				# If still no values, try one last time with
				# 'expandedfindingslist':
				if not s3mteqchecked:
					if expandedfindingstuplist:
						findinglist_resdictlist = s3mteq_clf_tuplist(expandedfindingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s3mteqchecked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Step 3 'Functionally Equals' Verdict/Text Parser:
		try:
			if s3fequnstructured:
				s3feqchecked = s3fequnstructured
			else:

				# Step 3 'functionally equals' two-tier ML classifier:
				def s3feq_clf_tuplist(input_tuplist):
					'''Perform Step 3 functionally equals finding
					heading ML classification on an input
					list of tuples containing finding heading
					text.

					Args:
						input_tuplist {list}: A list where the
							each tup[0] value = an item of
							finding heading text.
					Returns:
						resdictlist {list}: A list of dictionaries
							formatted like values in 's3fequnstructured'
							or 's3feqchecked' (mirroring s3feq child table
							columns).
					Raises:
						N/A (returns empty list if exception).'''
					try:
						resdictlist = []
						s3feqmlfindingslist = []
						for tup in input_tuplist:
							tup_txt = tup[0]
							tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
							tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
							s3feqmlfindingslist.append(tup_txt)
						s3feqmlfindingslist_array = np.array(s3feqmlfindingslist)
						s3feqmlfindingslist_vectorized = iedl.s3feq_id_vectorizer.transform(s3feqmlfindingslist_array)

						# Classify which are Step 3 functionally equals finding headings:
						s3feqml_poslist = []
						for i in range(len(s3feqmlfindingslist_array)):
							itemres = iedl.s3feq_id_clf.predict(s3feqmlfindingslist_vectorized[i])
							if 1 in itemres:
								s3feqml_poslist.append(i)

						# Classify type of each Step 3 functionally equals finding:
						if s3feqml_poslist:
							s3feqml_pos_tuplist = [input_tuplist[i] for i in s3feqml_poslist]
							s3feqml_pos_txtlist = [s3feqmlfindingslist_array[i] for i in s3feqml_poslist]
							s3feqml_pos_txtlist_array = np.array(s3feqml_pos_txtlist)
							s3feqml_pos_txtlist_vectorized = iedl.s3feq_type_vectorizer.transform(s3feqml_pos_txtlist_array)
							s3feqml_verlist = []
							for i in range(len(s3feqml_pos_txtlist_array)):
								itemres = iedl.s3feq_type_clf.predict(s3feqml_pos_txtlist_vectorized[i])
								# TIP: Transforming classifier output to its
								# corresponding 's3feqver' value:
								if 1 in itemres:
									s3feqml_verlist.append('1')
								elif 2 in itemres:
									s3feqml_verlist.append('2')

							s3feqml_pos_tuplist_zip = zip(s3feqml_pos_tuplist, s3feqml_verlist)
							for tup in s3feqml_pos_tuplist_zip:
								fe_rating_resdict = iecc.s3fe_rating_parser(tup[0][2], decisionfindingsltd)
								tupresdict = {'s3feqtxt':tup[0][0], 's3feqver':tup[1], 's3feqtxtsrc':'3', 's3feqversrc':'3', 'loc_st':tup[0][1], 'loc_end':tup[0][2]}
								for k,v in fe_rating_resdict.iteritems():
									tupresdict[k] = v
								resdictlist.append(tupresdict)

							return resdictlist
					except Exception:
						logging.exception('EXCEPTION')
						return []

				# First, try parsing 'findingstuplist':
				if findingstuplist:
					findinglist_resdictlist = s3feq_clf_tuplist(findingstuplist)
					if findinglist_resdictlist:
						for resdict in findinglist_resdictlist:
							s3feqchecked.append(resdict)
				# If still no values, try sentence-tokenized version
				# of 'findingstuplist':
				if not s3feqchecked:
					if findingssenttuplist:
						findinglist_resdictlist = s3feq_clf_tuplist(findingssenttuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s3feqchecked.append(resdict)
				# If still no values, try one last time with
				# 'expandedfindingslist':
				if not s3feqchecked:
					if expandedfindingstuplist:
						findinglist_resdictlist = s3feq_clf_tuplist(expandedfindingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s3feqchecked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier RFC Text Parser:
		try:
			# PRECURSOR STEP:  Sometimes FIT-based results will erroneously
			# capture non-RFC text because anchoring FIT language is pushed
			# down until after RFC rationale.  To guard against this, remove
			# any 'rfcunstructured' result in excess of 2000 characters
			# (anecdotal study shows that less than 2% of RFCs are of this length):
			rfcunstructured = [subd for subd in rfcunstructured if len(subd['rfctxt']) < 2000]

			if rfcunstructured:
				rfcchecked = rfcunstructured
			else:

				# RFC text ML logical prechecks:
				rfclogicallyabsentverdict = "U"
				if '1' in disptypechecked or '2' in disptypechecked:
					if s1sgachecked and bool(len(s1sgachecked) == len([d for d in s1sgachecked if d['s1sgaver'] == '3'])):
						rfclogicallyabsentverdict = "Y"
					if s2checked and bool(len(s2checked) == len([d for d in s2checked if d['s2ver'] in ['2', '3']])) and not s3mteqchecked:
						rfclogicallyabsentverdict = "Y"
				if claimtypechecked == "T16 SSI Child":
					rfclogicallyabsentverdict = "Y"
				if rfclogicallyabsentverdict == "U":

					# (1) Classify all sentences in 'decisionfindingsltd_sentlist':
					# TIP: Tabling 'predprob' usage for now.  I don't see it used below
					# so clearly not crucial.
					rfcmldecsentlist = []
					for sent in decisionfindingsltd_sentlist:
						sent = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", sent, flags=re.I)
						sent = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", sent, flags=re.I)
						rfcmldecsentlist.append(sent)
					rfcmldecsentlist_array = np.array(rfcmldecsentlist)
					rfcmldecsentlist_vectorized = iedl.rfc_vectorizer.transform(rfcmldecsentlist_array)

					rfcmldecsent_pred_tupdict = {}
					for i in range(len(rfcmldecsentlist_array)):
						pred_res = iedl.rfc_clf.predict(rfcmldecsentlist_vectorized[i])
						if 1 in pred_res:
							rfcmldecsent_pred_tupdict[i] = (1, rfcmldecsentlist_array[i])
						else:
							rfcmldecsent_pred_tupdict[i] = (0, rfcmldecsentlist_array[i])

					# Progress through findings list entities:

					# RFC finding heading ML classifier:
					def rfc_clf_tuplist(input_tuplist):
						'''Perform RFC finding heading ML classification
						on an input list of tuples containing finding heading
						text.

						Args:
							input_tuplist {list}: A list where the
								each tup[0] value = an item of
								finding heading text.
						Returns:
							resdictlist {list}: A list of dictionaries
								formatted like values in 'rfcunstructured'
								or 'rfcchecked' (mirroring rfc child table
								columns).
						Raises:
							N/A (returns empty list if exception).'''
						try:
							resdictlist = []
							rfcmlfindingslist = []
							for tup in input_tuplist:
								tup_txt = tup[0]
								tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
								tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
								rfcmlfindingslist.append(tup_txt)
							rfcmlfindingslist_array = np.array(rfcmlfindingslist)
							rfcmlfindingslist_vectorized = iedl.rfc_vectorizer.transform(rfcmlfindingslist_array)

							# Classify which are RFC finding headings:
							rfcml_poslist = []
							for i in range(len(rfcmlfindingslist_array)):
								itemres = iedl.rfc_clf.predict(rfcmlfindingslist_vectorized[i])
								if 1 in itemres:
									rfcml_poslist.append(i)

							# Return positive matches as *preliminary* dictionaries (still
							# need to build on the 'rfctxt' entries):
							if rfcml_poslist:
								rfcml_pos_tuplist = [input_tuplist[i] for i in rfcml_poslist]
								for tup in rfcml_pos_tuplist:
									resdictlist.append({'rfctxt':tup[0], 'rfctxtsrc':'3', 'loc_st':tup[1], 'loc_end':tup[2]})
								return resdictlist
						except Exception:
							logger.exception('EXCEPTION')
							return []

					# RFC finding heading 'building' ML classifier:
					def rfc_clf_build(input_resdict_list):
						'''Build upon an ML-classified RFC finding
						heading to capture remaining 'RFC' sentences
						in finding heading.

						Args:
							input_resdict {list}: A list of 1+ dicts
							formatted like values in 'rfcunstructured' or
							'rfcchecked' where dict['rfctxt'] = the
							ML-classified finding heading text snippet.
						Returns:
							rebuilt_resdict_list {list}: A list of 1+ dicts
								formatted like values in 'rfcunstructured'
								or 'rfcchecked' (mirroring rfc child table
								columns), including a built upon 'rfctxt'
								value.
						Raises:
							N/A (returns input_resdict_list values
							if exception occurs).'''
						try:
							rebuilt_resdict_list = []
							for resdict in input_resdict_list:
								# Slice 'findingstuplist' version decision
								# text version from end of finding target
								# onward:
								decisiontxt_slice = decisionfindingsltd[resdict['loc_end']:]
								decisiontxt_slice_sentlist = nlp_helper.sentence_splitter(decisiontxt_slice)

								# Tokenize, then classify each sentence:
								rfcmldecsentlist = []
								for sent in decisiontxt_slice_sentlist:
									sent = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", sent, flags=re.I)
									sent = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", sent, flags=re.I)
									rfcmldecsentlist.append(sent)
								rfcmldecsentlist_array = np.array(rfcmldecsentlist)
								rfcmldecsentlist_vectorized = iedl.rfc_vectorizer.transform(rfcmldecsentlist_array)

								rfcmldecsent_pred_tuplist = []
								for i in range(len(rfcmldecsentlist_array)):
									pred_res = iedl.rfc_clf.predict(rfcmldecsentlist_vectorized[i])
									if 1 in pred_res:
										rfcmldecsent_pred_tuplist.append((1, i))
									else:
										rfcmldecsent_pred_tuplist.append((0, i))

								# Build from first sentence until there's a meaningful break in the sequence:
								# TIP: Presently, 'meaningful break' is defined as two sequential negative
								# classifications (compensation for footnote/definitional text).  If this causes
								# accuracy issues, reduce to one negative classification.
								rfctxt_build_list = []
								if rfcmldecsent_pred_tuplist:
									for tupnum, tup in enumerate(rfcmldecsent_pred_tuplist):
										if tup[0] == 1:
											rfctxt_build_list.append(rfcmldecsentlist_array[tup[1]])
										else:
											try:
												if rfcmldecsent_pred_tuplist[tupnum+1][0] == 1:
													continue
												else:
													break
											except KeyError:
												break

								# Reassign resdict['rfctxt'] with newly built RFC text value.
								if rfctxt_build_list:
									rfctxt_final_build = resdict['rfctxt'] + " " + " ".join(rfctxt_build_list)
									resdict['rfctxt'] = rfctxt_final_build

									# Append result to rebuilt_resdict_list:
									rebuilt_resdict_list.append(resdict)
								else:
									rebuilt_resdict_list.append(resdict)

							# Return 'rebuilt_resdict_list':
							return rebuilt_resdict_list

						except Exception:
							logger.exception('EXCEPTION')
							return input_resdict_list

					# First, try parsing 'findingstuplist':
					if findingstuplist:
						findinglist_resdictlist = rfc_clf_tuplist(findingstuplist)
						# If results, build them:
						if findinglist_resdictlist:
							findinglist_resdictlist_built = rfc_clf_build(findinglist_resdictlist)
							for resdict in findinglist_resdictlist_built:
								rfcchecked.append(resdict)

					# TEMPORARY FILTERS: There is some non-RFC FIT language that is highly similar
					# to RFC language that must be filtered out of RFC results.  We could add more instances to
					# the CLF's training set ultimately, but for now, manually filter out precise matches:
					rfcchecked = [d for d in rfcchecked if bool(re.search(r"^\.? ?\d\. ?Physical functions such as|^\.? ?\d\. ?Capacities for seeing|^\.? ?\d\. ?Understanding, ?carrying out|^\.? ?\d\. ?Use of judgment|^\.? ?\d\. ?Responding appropriately|^\.? ?\d\. ?Dealing with changes", d['rfctxt'], re.I)) is False]
					rfcchecked = [d for d in rfcchecked if len(d['rfctxt']) < 2000]
					rfcchecked = [d for d in rfcchecked if bool(re.search(r'FINDINGS ?OF ?FACT', d['rfctxt'])) is False]

					# If still no values, try sentence-tokenized version
					# of 'findingstuplist':
					if not rfcchecked:
						if findingssenttuplist:
							findinglist_resdictlist = rfc_clf_tuplist(findingssenttuplist)
							# If results, build them:
							if findinglist_resdictlist:
								findinglist_resdictlist_built = rfc_clf_build(findinglist_resdictlist)
								for resdict in findinglist_resdictlist_built:
									rfcchecked.append(resdict)

					# TEMPORARY FILTERS: There is some non-RFC FIT language that is highly similar
					# to RFC language that must be filtered out of RFC results.  We could add more instances to
					# the CLF's training set ultimately, but for now, manually filter out precise matches:
					rfcchecked = [d for d in rfcchecked if bool(re.search(r"^\.? ?\d\. ?Physical functions such as|^\.? ?\d\. ?Capacities for seeing|^\.? ?\d\. ?Understanding, ?carrying out|^\.? ?\d\. ?Use of judgment|^\.? ?\d\. ?Responding appropriately|^\.? ?\d\. ?Dealing with changes", d['rfctxt'], re.I)) is False]
					rfcchecked = [d for d in rfcchecked if len(d['rfctxt']) < 2000]
					rfcchecked = [d for d in rfcchecked if bool(re.search(r'FINDINGS ?OF ?FACT', d['rfctxt'])) is False]

					# If still no values, try one last time with
					# 'expandedfindingslist':
					if not rfcchecked:
						if expandedfindingstuplist:
							findinglist_resdictlist = rfc_clf_tuplist(expandedfindingstuplist)
							# If results, build them:
							if findinglist_resdictlist:
								findinglist_resdictlist_built = rfc_clf_build(findinglist_resdictlist)
								for resdict in findinglist_resdictlist_built:
									rfcchecked.append(resdict)

					# TEMPORARY FILTERS: There is some non-RFC FIT language that is highly similar
					# to RFC language that must be filtered out of RFC results.  We could add more instances to
					# the CLF's training set ultimately, but for now, manually filter out precise matches:
					rfcchecked = [d for d in rfcchecked if bool(re.search(r"^\.? ?\d\. ?Physical functions such as|^\.? ?\d\. ?Capacities for seeing|^\.? ?\d\. ?Understanding, ?carrying out|^\.? ?\d\. ?Use of judgment|^\.? ?\d\. ?Responding appropriately|^\.? ?\d\. ?Dealing with changes", d['rfctxt'], re.I)) is False]
					rfcchecked = [d for d in rfcchecked if len(d['rfctxt']) < 2000]
					rfcchecked = [d for d in rfcchecked if bool(re.search(r'FINDINGS ?OF ?FACT', d['rfctxt'])) is False]

		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Step 4 Verdict Parser:
		try:
			if s4unstructured:
				s4checked = s4unstructured
			else:
				# Step 4 text ML logical prechecks:
				# OPENQ: Remove?  If your ML is strong, at least in first tier,
				# removing this to enable parsing that could reveal quality issues
				# insofar as decision shouldn't have both a 'full period of SGA' and
				# an RFC finding (unless 2+ PAIs...).
				s4logicallyabsentverdict = "U"
				if '1' in disptypechecked or '2' in disptypechecked:
					if s1sgachecked and bool(len(s1sgachecked) == len([d for d in s1sgachecked if d['s1sgaver'] == '3'])):
						s4logicallyabsentverdict = "Y"
				if claimtypechecked == "T16 SSI Child":
					s4logicallyabsentverdict = "Y"
				if s4logicallyabsentverdict == "U":

					# Step 4 two-tier ML classifier:
					def s4_clf_tuplist(input_tuplist):
						'''Perform Step 4 finding
						heading ML classification on an input
						list of tuples containing finding heading
						text.

						Args:
							input_tuplist {list}: A list where the
								each tup[0] value = an item of
								finding heading text.
						Returns:
							resdictlist {list}: A list of dictionaries
								formatted like values in 's4unstructured'
								or 's4checked' (mirroring s4 child table
								columns).
						Raises:
							N/A (returns empty list if exception).'''
						try:
							resdictlist = []
							s4mlfindingslist = []
							for tup in input_tuplist:
								tup_txt = tup[0]
								tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
								tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
								s4mlfindingslist.append(tup_txt)
							s4mlfindingslist_array = np.array(s4mlfindingslist)
							s4mlfindingslist_vectorized = iedl.s4_id_vectorizer.transform(s4mlfindingslist_array)

							# Classify which are Step 4 finding headings:
							s4ml_poslist = []
							for i in range(len(s4mlfindingslist_array)):
								itemres = iedl.s4_id_clf.predict(s4mlfindingslist_vectorized[i])
								if 1 in itemres:
									s4ml_poslist.append(i)

							# Classify type of each Step 4 finding:
							if s4ml_poslist:
								s4ml_pos_tuplist = [input_tuplist[i] for i in s4ml_poslist]
								s4ml_pos_txtlist = [s4mlfindingslist_array[i] for i in s4ml_poslist]
								s4ml_pos_txtlist_array = np.array(s4ml_pos_txtlist)
								s4ml_pos_txtlist_vectorized = iedl.s4_type_vectorizer.transform(s4ml_pos_txtlist_array)
								s4ml_verlist = []
								for i in range(len(s4ml_pos_txtlist_array)):
									itemres = iedl.s4_type_clf.predict(s4ml_pos_txtlist_vectorized[i])
									# TIP: Transforming classifier output to its
									# corresponding 's4ver' value:
									if 1 in itemres:
										s4ml_verlist.append('1')
									elif 2 in itemres:
										s4ml_verlist.append('2')
									elif 3 in itemres:
										s4ml_verlist.append('3')
									elif 4 in itemres:
										s4ml_verlist.append('4')

								s4ml_pos_tuplist_zip = zip(s4ml_pos_tuplist, s4ml_verlist)
								for tup in s4ml_pos_tuplist_zip:
									if tup[1] != '1':
										resdictlist.append({'s4txt':tup[0][0], 's4ver':tup[1], 's4actgen':'U', 's4jobscanperf':'U', 's4jobscanperfct':'U', 's4txtsrc':'3', 's4versrc':'3', 'loc_st':tup[0][1], 'loc_end':tup[0][2]})
									elif tup[1] == '1':
										res_txt_jobstr = tup[0][0]
										res_txt_jobstr = re.sub(r"This\s{0,6}work\s{0,6}does\s{0,6}not\s{0,6}require.*", "", res_txt_jobstr, flags=re.I|re.S)
										res_txt_jobstr = re.sub(r"does\s{0,6}not\s{0,6}require.*", "", res_txt_jobstr, flags=re.I|re.S)
										res_txt_jobstr = re.sub(r"This\s{0,6}work\s{0,6}.*", "", res_txt_jobstr, flags=re.S)
										res_txt_jobstr = re.sub(r"\(.*?\)", " ", res_txt_jobstr)
										res_txt_jobstr = re.sub(r"\[.*?\]", " ", res_txt_jobstr)
										res_txt_jobstr = ' '.join(res_txt_jobstr.split()).lower()
										res_txt_jobstr = re.sub("^as an ?|^as ?a ?", "", res_txt_jobstr)
										res_txt_jobstr = re.sub("^an ?|^a ?", "", res_txt_jobstr)
										res_txt_jobstr = re.sub("\.$", "", res_txt_jobstr)
										# TIP: calc_s4jobscanperf() returns a semicolon divided list of jobs.
										res_txt_job_list = iecc.calc_s4jobscanperf(res_txt_jobstr)
										res_txt_job_list_len = len(res_txt_job_list.split('; '))
										resdictlist.append({'s4txt':tup[0][0], 's4ver':tup[1], 's4actgen':'U', 's4jobscanperf':res_txt_job_list, 's4jobscanperfct':res_txt_job_list_len, 's4txtsrc':'3', 's4versrc':'3', 'loc_st':tup[0][1], 'loc_end':tup[0][2]})
							return resdictlist
						except Exception:
							logger.exception('EXCEPTION')
							return []

					# First, try parsing 'findingstuplist':
					if findingstuplist:
						findinglist_resdictlist = s4_clf_tuplist(findingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s4checked.append(resdict)
					# If still no values, try sentence-tokenized version
					# of 'findingstuplist':
					if not s4checked:
						if findingssenttuplist:
							findinglist_resdictlist = s4_clf_tuplist(findingssenttuplist)
							if findinglist_resdictlist:
								for resdict in findinglist_resdictlist:
									s4checked.append(resdict)
					# If still no values, try one last time with
					# 'expandedfindingslist':
					if not s4checked:
						if expandedfindingstuplist:
							findinglist_resdictlist = s4_clf_tuplist(expandedfindingstuplist)
							if findinglist_resdictlist:
								for resdict in findinglist_resdictlist:
									s4checked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Education Level Parser:
		# TIP: Can output two values for contexts such as 'the claimant has a high
		# school education but is functionally illiterate' -> 'H; I'.
		try:
			if edunstructured:
				# 1 FIT Result:
				if len(edunstructured) == 1:
					edchecked = edunstructured[0]
					edcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				if len(edunstructured) > 1:
					edchecked = str("; ".join(edunstructured))
					edcheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier DOB Parser:
		try:
			if dobunstructured:
				# 1 FIT Result:
				dobchecked = dobunstructured[0]
				dobchecked = dh.parse_date_tostr(dobchecked)
				dobcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1: [N/A for this data point]
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Transferrable Skills Verdict Parser:
		# TODO: Add ML classifier for transferrable skills verdict parsing.
		try:
			if txskillsverdictunstructured:
				# 1 FIT Result:
				if len(txskillsverdictunstructured) == 1:
					txskillsverdictchecked = txskillsverdictunstructured[0]
					txskillsverdictcheckedsrc = "0"
				# 2+ FIT Results Where Should Be 1:
				if len(txskillsverdictunstructured) > 1:
					txskillsverdictchecked = str("; ".join(txskillsverdictunstructured))
					txskillsverdictcheckedsrc = "2"
		except Exception:
			logger.exception('EXCEPTION')

		# Second Tier Step 5 Verdict/Text Parser:
		try:
			if s5unstructured:
				s5checked = s5unstructured
			else:
				# Step 5 text ML logical prechecks:
				# OPENQ: Remove?  If your ML is strong, at least in first tier,
				# removing this to enable parsing that could reveal quality issues
				# insofar as decision shouldn't have both a 'full period of SGA' and
				# an RFC finding (unless 2+ PAIs...).
				s5logicallyabsentverdict = "U"
				if '1' in disptypechecked or '2' in disptypechecked:
					if s1sgachecked and bool(len(s1sgachecked) == len([d for d in s1sgachecked if d['s1sgaver'] == '3'])):
						s5logicallyabsentverdict = "Y"
				if claimtypechecked == "T16 SSI Child":
					s5logicallyabsentverdict = "Y"
				if s5logicallyabsentverdict == "U":

					# Step 5 two-tier ML classifier:
					# TODO: Add method to look for and classify alternative
					# Step 5 findings.
					def s5_clf_tuplist(input_tuplist):
						'''Perform Step 5 finding
						heading ML classification on an input
						list of tuples containing finding heading
						text.

						Args:
							input_tuplist {list}: A list where the
								each tup[0] value = an item of
								finding heading text.
						Returns:
							resdictlist {list}: A list of dictionaries
								formatted like values in 's5unstructured'
								or 's5checked' (mirroring s5 child table
								columns).
						Raises:
							N/A (returns empty list if exception).'''
						try:
							resdictlist = []
							s5mlfindingslist = []
							for tup in input_tuplist:
								tup_txt = tup[0]
								tup_txt = re.sub(r"((january|february|march|april|may|june|july|august|september|october|november|december)\s{0,6}\d{1,2},\s{0,6}\d\d\d\d)", "DATE", tup_txt, flags=re.I)
								tup_txt = re.sub(r"\s+(\d\d|\d)\s+years\s+old", " NUM years old", tup_txt, flags=re.I)
								s5mlfindingslist.append(tup_txt)
							s5mlfindingslist_array = np.array(s5mlfindingslist)
							s5mlfindingslist_vectorized = iedl.s5_id_vectorizer.transform(s5mlfindingslist_array)

							# Classify which are Step 5 finding headings:
							s5ml_poslist = []
							for i in range(len(s5mlfindingslist_array)):
								itemres = iedl.s5_id_clf.predict(s5mlfindingslist_vectorized[i])
								itemres2 = iedl.s5_id_clf.predict_proba(s5mlfindingslist_vectorized[i])
								if 1 in itemres:
									s5ml_poslist.append(i)

							# Classify type of each Step 5 finding:
							if s5ml_poslist:
								s5ml_pos_tuplist = [input_tuplist[i] for i in s5ml_poslist]
								s5ml_pos_txtlist = [s5mlfindingslist_array[i] for i in s5ml_poslist]
								s5ml_pos_txtlist_array = np.array(s5ml_pos_txtlist)
								s5ml_pos_txtlist_vectorized = iedl.s5_type_vectorizer.transform(s5ml_pos_txtlist_array)
								s5ml_verlist = []
								for i in range(len(s5ml_pos_txtlist_array)):
									itemres = iedl.s5_type_clf.predict(s5ml_pos_txtlist_vectorized[i])
									# TIP: Transforming classifier output to its
									# corresponding 's5ver' value:
									if 1 in itemres:
										s5ml_verlist.append('1')
									elif 2 in itemres:
										s5ml_verlist.append('3')

								s5ml_pos_tuplist_zip = zip(s5ml_pos_tuplist, s5ml_verlist)
								for tup in s5ml_pos_tuplist_zip:
									resdictlist.append({'s5txt':tup[0][0], 's5ver':tup[1], 's5txtsrc':'3', 's5versrc':'3', 's5fwkdir':'U', 'loc_st':tup[0][1], 'loc_end':tup[0][2]})

							return resdictlist
						except Exception:
							logger.exception('EXCEPTION')
							return []

					# First, try parsing 'findingstuplist':
					if findingstuplist:
						findinglist_resdictlist = s5_clf_tuplist(findingstuplist)
						if findinglist_resdictlist:
							for resdict in findinglist_resdictlist:
								s5checked.append(resdict)
					# If still no values, try sentence-tokenized version
					# of 'findingstuplist':
					if not s5checked:
						if findingssenttuplist:
							findinglist_resdictlist = s5_clf_tuplist(findingssenttuplist)
							if findinglist_resdictlist:
								for resdict in findinglist_resdictlist:
									s5checked.append(resdict)
					# If still no values, try one last time with
					# 'expandedfindingslist':
					if not s5checked:
						if expandedfindingstuplist:
							findinglist_resdictlist = s5_clf_tuplist(expandedfindingstuplist)
							if findinglist_resdictlist:
								for resdict in findinglist_resdictlist:
									s5checked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		### 'FINAL TIER' SEP/FINDINGS DATA PARSING ###

		# Identify boundaries of each 'body text' segment
		# that follows each finding heading entity dict:

		# Create container of all finding heading entity dictionaries
		# sorted according to their index location in the decision:
		# TIP: Using starting index for sorting (more reliable).
		fhent_dictlist = s1sgachecked + s2checked + s3mteqchecked + s3feqchecked + rfcchecked + s4checked + s5checked
		fhent_dictlist_sorted = sorted(fhent_dictlist, key=lambda x:x['loc_st'])

		# Calculate body text boundary and output into tuple where
		# k = finding heading ent dict start value and v = the
		# body text end value (a.k.a. the start value of the next
		# finding heading entity):
		fhent_bound_resdict = {}
		for i, subd in enumerate(fhent_dictlist_sorted):
			try:
				if i == len(fhent_dictlist_sorted)-1:
					break
				else:
					i_this_start = subd['loc_st']
					i_next_start = fhent_dictlist_sorted[i+1]['loc_st']
					fhent_bound_resdict[i_this_start] = i_next_start
			except IndexError:
				logger.exception('EXCEPTION')

		# Ok, so start values are reliable.  And all this is doing is saying
		# 'here's the location of the start of the next finding heading', so this
		# should work well.  You can use the same reliable 'start' value, which
		# should be unique, to re-associate these with their dictionary values:
		for subd in s1sgachecked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in s2checked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in s3mteqchecked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in s3feqchecked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in rfcchecked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in s4checked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]
		for subd in s5checked:
			subd['body_loc_end'] = np.nan
			if subd['loc_st'] in fhent_bound_resdict.keys():
				subd['body_loc_end'] = fhent_bound_resdict[subd['loc_st']]

		# 'claimdisp' Child Table Entry Parsing:
		try:
			if claimtypechecked:
				# TIP: 'claimtypechecked' example:
				# 'T2 DIB; T16 SSI'
				claimtypechecked_split = claimtypechecked.split('; ')
				if len(claimtypechecked_split) == 1:
					resdict = {}
					resdict['claimtype'] = claimtypechecked_split[0]
					dofchecked_split = dofchecked.split('; ')
					if len(dofchecked_split) == 1:
						dof = dofchecked_split[0]
						dof = re.sub(r"\(.*", "", dof)
						dof = dof.strip()
						resdict['dof'] = dof
					else:
						resdict['dof'] = 'U'
					disptypechecked_split = disptypechecked.split('; ')
					if len(disptypechecked_split) == 1:
						resdict['disptype'] = disptypechecked_split[0]
					else:
						resdict['disptype'] = 'U'
					claimdispchecked.append(resdict)
				elif len(claimtypechecked_split) > 1:
					for claimtype in claimtypechecked_split:
						resdict = {}
						resdict['claimtype'] = claimtype
						resdict['dof'] = 'U'
						# TIP: 'dofchecked' example:
						# '09/26/2012 (T2 DIB); 08/31/2012 (T16 SSI)'
						dofchecked_split = dofchecked.split('; ')
						for dof in dofchecked_split:
							if claimtype in dof:
								dof = re.sub(r"\(.*", "", dof)
								dof = dof.strip()
								resdict['dof'] = dof
						resdict['disptype'] = 'U'
						disptypechecked_split = disptypechecked.split('; ')
						# TIP: Should not have 2 disptype values:
						if len(disptypechecked_split) != 1:
							resdict['disptype'] = 'U'
						else:
							disptype = disptypechecked_split[0]
							if disptype in ['2','4','6']:
								if 'T2' in claimtype:
									resdict['disptype'] = '7'
								else:
									resdict['disptype'] = disptype
							else:
								resdict['disptype'] = disptype
						claimdispchecked.append(resdict)
		except Exception:
			logger.exception('EXCEPTION')

		# Step 1 SGA Type Reference Parsing:
		# TODO: Ensure child table 's1sgatype' data length permits multiple values
		# and is a 'varchar' type.
		try:
			for subd in s1sgachecked:
				# Results container:
				s1sgatype_reslist = []
				# Get body text using index locations:
				if isinstance(subd['loc_end'], int):
					if np.isnan(subd['body_loc_end']):
						end_loc = len(decisionfindingsltd)-1
					else:
						end_loc = subd['body_loc_end']
					decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]
					# FIT SGA type:
					s1sgatypesearch1 = re.search(r"The\s{0,6}claimant\s{0,6}worked\s{0,6}after\s{0,6}the\s{0,6}(application\s{0,6}date[,\s]{0,6}|alleged\s{0,6}disability\s{0,6}onset\s{0,6}date[,\s]{0,6}|established\s{0,6}disability\s{0,6}onset\s{0,6}date[,\s]{0,6})but\s{0,6}this\s{0,6}work\s{0,6}activity\s{0,6}did\s{0,6}not\s{0,6}rise\s{0,6}to\s{0,6}the\s{0,6}level\s{0,6}of\s{0,6}substantial\s{0,6}gainful\s{0,6}activity", decisionfindingsltd_snip, re.I)
					s1sgatypesearch2 = re.search(r"The\s{0,6}claimant\s{0,6}worked\s{0,6}after\s{0,6}the\s{0,6}(application\s{0,6}date|alleged\s{0,6}disability\s{0,6}onset\s{0,6}date||established\s{0,6}disability\s{0,6}onset\s{0,6}date\s{0,6})[;,\s]{0,6}however[,\s]{0,6}this\s{0,6}work\s{0,6}was\s{0,6}an\s{0,6}unsuccessful\s{0,6}work\s{0,6}attempt", decisionfindingsltd_snip, re.I)
					s1sgatypesearch3 = re.search(r"The\s{0,6}claimant\s{0,6}worked\s{0,6}after\s{0,6}the\s{0,6}established\s{0,6}onset\s{0,6}date[,\s]{0,6}but\s{0,6}this\s{0,6}work\s{0,6}activity\s{0,6}is\s{0,6}part\s{0,6}of\s{0,6}the\s{0,6}claimant['s\s]{0,6}trial\s{0,6}work\s{0,6}period", decisionfindingsltd_snip, re.I)
					if bool(s1sgatypesearch1):
						s1sgatype_reslist.append("1")
					if bool(s1sgatypesearch2):
						s1sgatype_reslist.append("2")
					if bool(s1sgatypesearch3):
						s1sgatype_reslist.append("3")
					# If no exact FIT results, perform looser searches:
					if not s1sgatype_reslist:
						s1sgatypesearch1looser = re.search(r"not\s{0,6}rise\s{0,6}to\s{0,6}the\s{0,6}level\s{0,6}of\s{0,6}(substantial\s{0,6}gainful\s{0,6}activity|SGA)|not\s{0,6}rise\s{0,6}to\s{0,6}(substantial\s{0,6}gainful\s{0,6}activity|SGA)|was\s{0,6}not\s{0,6}(substantial\s{0,6}gainful\s{0,6}activity|SGA)", decisionfindingsltd_snip, re.I)
						s1sgatypesearch2looser = re.search(r"(?<!not an )(?<!not a )unsuccessful\s{0,6}work\s{0,6}attempt", decisionfindingsltd_snip, re.I)
						s1sgatypesearch3looser = re.search(r"(?<!not an )(?<!not a )trial\s{0,6}work\s{0,6}period", decisionfindingsltd_snip, re.I)
						if bool(s1sgatypesearch1looser):
							s1sgatype_reslist.append("1")
						if bool(s1sgatypesearch2looser):
							s1sgatype_reslist.append("2")
						if bool(s1sgatypesearch3looser):
							s1sgatype_reslist.append("3")

				# Memorialize results into 's1sgachecked' dict:
				if s1sgatype_reslist:
					subd['s1sgatype'] = '; '.join(s1sgatype_reslist)
				else:
					subd['s1sgatype'] = 'U'
		except Exception:
			logger.exception('EXCEPTION')
			if s1sgachecked:
				for d in s1sgachecked:
					d.update((k, 'E') for k, v in d.iteritems() if k == 's1sgatype')

		# (TEMPORARILY DEPRECATING) Step 2 Non-Severe Mental MDI Par. B Ratings
		# NOTE: There are higher priority data points than this. Ensuring completion
		# of those before tackling these.

		# Step 3 Severe MDI Par. B Ratings:
		# TIP: For each 's3' child observation, a given
		# Par. B data point may contain multiple values
		# separated by semicolons?  Or more likely the
		# descriptive language was falsely ID'd as a
		# rating finding.
		try:
			for subd in s3mteqchecked:

				# Results container:
				# Ex: 'adl':[('1', 5, 25), ('2', 50, 75)]
				parb_resdict = defaultdict(list)

				# Get body text using index locations:
				if isinstance(subd['loc_end'], int):
					if np.isnan(subd['body_loc_end']):
						end_loc = len(decisionfindingsltd)-1
					else:
						end_loc = subd['body_loc_end']
					decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]

					# Normalize spacing:
					decisionfindingsltd_snip = tc.normalize_spacing(decisionfindingsltd_snip)

					# Remove FIT Par. B non-finding language:
					decisionfindingsltd_snip = re.sub(r"(resulting|must ?result) ?in ?at ?least ?(two|2) ?of ?the ?following:[^\.]{4,20}(restrictions?|difficulties|difficulty|limitations?|limits?) ?(of|in) ?activities ?of ?daily ?living(;|,)[^\.]{4,20}(restrictions?|difficulties|difficulty|limitations?|limits?) ?in ?(maintaining)? social ?functioning(;|,)[^\.]{4,20}(restrictions?|difficulties|difficulty|limitations?|limits?) ?in ?(maintaining)? concentration, ?persistence, ?(and/or|and|or) ?pace(;|,) ?or[^\.]{4,25}episodes ?of ?decompensation", " ", decisionfindingsltd_snip, flags=re.I)
					decisionfindingsltd_snip = re.sub(r"A[^\.]{4,20}(restriction|difficulty|limitation|limit) ?means ?more ?than ?.{0,3}moderate.{0,3} ?but ?less ?than ?.{0,3}extreme", " ", decisionfindingsltd_snip, flags=re.I)
					decisionfindingsltd_snip = re.sub(r"[^\.]{4,15}episodes ?of ?decompensation,? ?each ?of ?extended ?duration,? ?means ?(three|3) ?episodes ?within ?(one|1) ?year", " ", decisionfindingsltd_snip, flags=re.I)
					decisionfindingsltd_snip = re.sub(r"Because.{2,25}mental ?impairments? ?(does|did|do) ?not ?cause ?at ?least ?(two|2)[^\.]{4,20}(restrictions?|difficulties|limitations?|limits?) ?or ?(one|1)[^\.]{4,20}(restriction|limitation|difficulty) ?and[^\.]{4,20}episodes ?of ?decompensation", " ", decisionfindingsltd_snip, flags=re.I)

					# Split remaining text into sentences, then split on semicolons:
					# TIP: Presently, the latest DFRs do not indicate that any FIT Par. B
					# finding language would be split across separate sentences; rather,
					# splits across sentences only appear in Step 2 non-severe Par. B rating
					# language.  Thus this approach.
					decisionfindingsltd_snip_sents = nlp_helper.sentence_splitter(decisionfindingsltd_snip)
					decisionfindingsltd_snip_sents_2 = []
					for sent in decisionfindingsltd_snip_sents:
						sent_split = re.split(r";", sent)
						for split in sent_split:
							decisionfindingsltd_snip_sents_2.append(split)

					# Function to parse all 'findall' results below:
					parbvaluedict = {"NO":"1", "MILD":"2", "MODERATE":"3", "MARKED":"4", "EXTREME":"5", "ONE TO TWO":"2", "THREE":"3", "FOUR":"4", "FOUR OR MORE":"4"}
					parbvaluedictkeys = parbvaluedict.keys()
					def parse_parb_result_fit(catnm, rating_str, fullsent, start_ix, end_ix):
						'''Parse a snippet of text for a Par. B rating
						and value.

						Args:
							catnm {str}: Par. B category name.
							rating_str {str}: The snippet of text
								containing the Par. B rating.
							fullsent {str}: The full snippet.
							start_ix {int}: Starting index from
								within decision text.
							end_ix {int}: Ending index from
								within decision text.
						Returns:
							N/A (adds directly to 'parb_resdict').
						Raises:
							N/A'''
						try:

							# Retrieve 'actual' full sentence:
							fullsentreslist = []
							sent_orig = fullsent
							sent_orig_re = sent_orig.replace("'", "")
							sent_orig_re = re.escape(sent_orig_re)
							sent_orig_re = sent_orig_re.replace(" ", " ?")
							for sent in decisionfindingsltd_snip_sents_2:
								if bool(re.search(sent_orig_re, sent, re.I)):
									fullsentreslist.append(sent)

							# If 1 and only 1 target result retrieve,
							# continue:
							if len(fullsentreslist) == 1:
								if catnm in ['adl', 'sf', 'cpp']:
									# TIP: Check for opinion verbage:
									if bool(re.search(r"\bopines?|\bopined|testified", fullsent, re.I)) is False:
										# TIP: Check for non-finding/definitional language:
										if bool(re.search(r"To ?satisfy|\bmust result in\b|(?<!which )means\b|(did|do) ?not ?cause ?at ?least (two|2)|\bmet ?if\b|\bat ?least ?(two|2) ?of ?the ?following", fullsent, re.I)) is False:
											res = rating_str
											res = res.upper()
											res = res.strip()
											if res in parbvaluedictkeys:
												parbvalue = parbvaluedict[res]
												if catnm == 'adl':
													parb_resdict['s3parbadl'].append(parbvalue)
												elif catnm == 'sf':
													parb_resdict['s3parbsf'].append(parbvalue)
												elif catnm == 'cpp':
													parb_resdict['s3parbcpp'].append(parbvalue)
								else:
									if bool(re.search(r"\bopines?|\bopined|testified", fullsent, re.I)) is False:
										res = rating_str
										res = re.sub(r"\b0\b", " no ", res, flags=re.I)
										res = re.sub(r"\b1\b", " one ", res, flags=re.I)
										res = re.sub(r"\b2\b", " two ", res, flags=re.I)
										res = re.sub(r"\b3\b", " three ", res, flags=re.I)
										res = re.sub(r"\b4\b", " four ", res, flags=re.I)
										res = tc.normalize_spacing(res)
										res = re.sub(r" one ?- ?two ", " one to two ", res, flags=re.I)
										res = tc.normalize_spacing(res)
										res = res.upper()
										if res in parbvaluedictkeys:
											parbvalue = parbvaluedict[res]
											parb_resdict['s3parbdecomp'].append(parbvalue)
						except Exception:
							logger.exception('EXCEPTION')

					# Search for FIT Par. B category/rating language:

					# UNFAV 'severe' FIT Par. B language:
					# DFR, eBB Release 6.0 (2015)
					severeadl_finditer2 = re.finditer(r"In ?activities ?of ?daily ?living,? ?the ?claimant ?(has ?had|had|has) ?(no ?more ?than)? ?.{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits)", decisionfindingsltd_snip, re.I)
					for res in severeadl_finditer2:
						parse_parb_result_fit('adl', res.group(3), res.group(), res.start(), res.end())
					severesf_finditer2 = re.finditer(r"In ?social ?functioning,? ?the ?claimant ?(has ?had|had|has) ?(no ?more ?than)? ?.{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits)", decisionfindingsltd_snip, re.I)
					for res in severesf_finditer2:
						parse_parb_result_fit('sf', res.group(3), res.group(), res.start(), res.end())
					severecpp_finditer2 = re.finditer(r"With ?regard ?to ?concentration,? ?persistence ?or ?pace,? ?the ?claimant ?(has ?had|had|has) ?(no ?more ?than)? ?.{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits)", decisionfindingsltd_snip, re.I)
					for res in severecpp_finditer2:
						parse_parb_result_fit('cpp', res.group(3), res.group(), res.start(), res.end())
					severedecomp_finditer2 = re.finditer(r"As ?for ?episodes ?of ?decompensation,? ?the ?claimant ?(had|has) ?experienced ?(no ?more ?than)? ?.{0,3}(no|one ?to ?two|three|1 ?\- ?2|3|1 ?to ?2|four ?or ?more|4 ?or ?more).{0,3} ?episodes ?of ?decompensation", decisionfindingsltd_snip, re.I)
					for res in severedecomp_finditer2:
						parse_parb_result_fit('decomp', res.group(3), res.group(), res.start(), res.end())

					# FFAV 'severe' FIT Par. B language parsing:
					# TIP: FIT separates these via commas!
					# DFR, eBB Release 6.0 (2015)
					ffav_parb_finditer1 = re.finditer(r"impairments? ?causes?:? ?.{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits) ?in ?activities ?of ?daily ?living,?;? .{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits) ?in ?(maintaining)? ?social functioning, .{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} (difficulties|difficulty|restrictions?|limitations?|limits) ?in ?(maintaining)? ?concentration, persistence,? (and/or|and|or) pace,? and ?.{0,3}(no|one ?to ?two|three|1 ?\- ?2|3|1 ?to ?2|four ?or ?more|4 ?or ?more).{0,3} ?episodes? ?of ?decompensation", decisionfindingsltd_snip, re.I)
					for res in ffav_parb_finditer1:
						parse_parb_result_fit('adl', res.group(1), res.group(), res.start(), res.end())
						parse_parb_result_fit('sf', res.group(3), res.group(), res.start(), res.end())
						parse_parb_result_fit('cpp', res.group(6), res.group(), res.start(), res.end())
						parse_parb_result_fit('decomp', res.group(10), res.group(), res.start(), res.end())

					ffav_parb_finditer2 = re.finditer(r"Appendix ?1: ?(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits) ?in ?activities ?of ?daily ?living,?;? .{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} ?(difficulties|difficulty|restrictions?|limitations?|limits) ?in ?(maintaining)? ?social functioning, .{0,3}(\bno\b|mild|moderate|marked|extreme).{0,3} (difficulties|difficulty|restrictions?|limitations?|limits) ?in ?(maintaining)? ?concentration, persistence,? (and/or|and|or) pace,? and ?.{0,3}(no|one ?to ?two|three|1 ?\- ?2|3|1 ?to ?2|four ?or ?more|4 ?or ?more).{0,3} ?episodes? ?of ?decompensation", decisionfindingsltd_snip, re.I)
					for res in ffav_parb_finditer2:
						parse_parb_result_fit('adl', res.group(1), res.group(), res.start(), res.end())
						parse_parb_result_fit('sf', res.group(3), res.group(), res.start(), res.end())
						parse_parb_result_fit('cpp', res.group(6), res.group(), res.start(), res.end())
						parse_parb_result_fit('decomp', res.group(10), res.group(), res.start(), res.end())

					# If no results, perform looser non-FIT search:
					# TODO: This will only catch simple, single category-per-full-sentence,
					# entities.  It will NOT catch 2+ sentence rating findings, nor will
					# it catch comma-separated-same-sentence-contained ratings.
					if len(subd['s3parbadl']) == 0 or len(subd['s3parbsf']) == 0 or len(subd['s3parbcpp']) == 0 or len(subd['s3parbdecomp']) == 0:

						# Define rating REGEX patterns with cursory negation detection:
						no_re = r"\bnot ?have\b|\bhas ?no\b|\bis ?without\b|\bno ?(lim[a-z]+|restr[a-z]+)|failed ?to ?establish(?! more)(?! any more)"
						mild_re = r"(?<! not )(?<! no )(?<! without )(?<! absent )(?<! free of )(mildly\b|mild\b)"
						mod_re = r"(?<! not )(?<! no )(?<! without )(?<! absent )(?<! free of )(moderately\b|moderate\b)"
						marked_re = r"(?<! not )(?<! no )(?<! without )(?<! absent )(?<! free of )(markedly\b|marked\b)"
						extreme_re = r"(?<! not )(?<! no )(?<! without )(?<! absent )(?<! free of )(extremely\b|extreme\b)"

						for sent in decisionfindingsltd_snip_sents_2:

							# Cursory filtering out of opinion and non-finding/definitional language:
							if bool(re.search(r"\bopines?|\bopined|testified", sent, re.I)) is False:
								if bool(re.search(r"To ?satisfy|\bmust result in\b|(?<!which )means\b|(did|do) ?not ?cause ?at ?least (two|2)|\bmet ?if\b|\bat ?least ?(two|2) ?of ?the ?following", sent, re.I)) is False:

									# Search for any and all category ratings in the sentence:
									matchlist = []
									adlfinditer1 = re.finditer(r"activities ?of ?daily ?living", sent, re.I)
									for res in adlfinditer1:
										matchlist.append((sent, res.start(), res.end(), 'adl'))
									cppfinditer1 = re.finditer(r"concentration,? ?persistence", sent, re.I)
									for res in cppfinditer1:
										matchlist.append((sent, res.start(), res.end(), 'cpp'))
									sffinditer1 = re.finditer(r"\bsocial ?functioning\b", sent, re.I)
									for res in sffinditer1:
										matchlist.append((sent, res.start(), res.end(), 'sf'))
									decompfinditer1 = re.finditer(r"\bepisodes ?of ?decomp[a-z]+", sent, re.I)
									for res in decompfinditer1:
										matchlist.append((sent, res.start(), res.end(), 'decomp'))

									# If ONLY ONE match, proceed:
									if len(matchlist) == 1:
										rating_res_list = []
										for tup in [('NO', item.start(), item.end()) for item in re.finditer(no_re, matchlist[0][0], re.I)]:
											rating_res_list.append(tup)
										for tup in [('MILD', item.start(), item.end()) for item in re.finditer(mild_re, matchlist[0][0], re.I)]:
											rating_res_list.append(tup)
										for tup in [('MODERATE', item.start(), item.end()) for item in re.finditer(mod_re, matchlist[0][0], re.I)]:
											rating_res_list.append(tup)
										for tup in [('MARKED', item.start(), item.end()) for item in re.finditer(marked_re, matchlist[0][0], re.I)]:
											rating_res_list.append(tup)
										for tup in [('EXTREME', item.start(), item.end()) for item in re.finditer(extreme_re, matchlist[0][0], re.I)]:
											rating_res_list.append(tup)

										# If ONLY ONE rating item found, proceed:
										# TODO: Does not yet capture decomp numerics.
										if len(rating_res_list) == 1:
											if matchlist[3] == 'adl' and subd['s3parbadl'] == 'U':
												parb_resdict['s3parbadl'].append(parbvaluedict[rating_res_list[0]])
											elif matchlist[3] == 'sf' and subd['s3parbsf'] == 'U':
												parb_resdict['s3parbsf'].append(parbvaluedict[rating_res_list[0]])
											elif matchlist[3] == 'cpp' and subd['s3parbcpp'] == 'U':
												parb_resdict['s3parbcpp'].append(parbvaluedict[rating_res_list[0]])
											elif matchlist[3] == 'decomp' and subd['s3parbdecomp'] == 'U':
												parb_resdict['s3parbdecomp'].append(parbvaluedict[rating_res_list[0]])

				# Parse parb_resdict:
				for k,v in parb_resdict.iteritems():
					if v:
						subd[k] = '; '.join(list(set(v)))

		except Exception:
			logger.exception('EXCEPTION')
			if s3mteqchecked:
				for d in s3mteqchecked:
					d.update((k, 'E') for k, v in d.iteritems() if k == 's3parbadl')
					d.update((k, 'E') for k, v in d.iteritems() if k == 's3parbsf')
					d.update((k, 'E') for k, v in d.iteritems() if k == 's3parbcpp')
					d.update((k, 'E') for k, v in d.iteritems() if k == 's3parbdecomp')

		# Step 4 'Actually/Generally' Parsing:
		try:
			for i, subd in enumerate(s4checked):

				# Only proceed if 's4ver' == 'can perform PRW':
				if subd['s4ver'] == '1':
					# Get body text using index locations:
					if isinstance(subd['loc_end'], int):
						if np.isnan(subd['body_loc_end']):
							end_loc = len(decisionfindingsltd)-1
						else:
							end_loc = subd['body_loc_end']
						decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]
						# Parse:
						s4actuallygenerallyver = s4actgenclassifier.classify(decisionfindingsltd_snip)
						# Memorialize result into 's4checked' dict:
						subd['s4actgen'] = s4actuallygenerallyver
		except Exception:
			logger.exception('EXCEPTION')
			if s4checked:
				for d in s4checked:
					d.update((k, 'E') for k, v in d.iteritems() if k == 's4actgen')

		# Step 4 DOT Parsing:
		# {'s4dotnum': '111222333', 's4dotloc':'U'}
		try:
			for i, subd in enumerate(s4checked):

				# Results container:
				reslist = []
				s4dotfindingcheckedlist = []
				s4dotbodycheckedlist = []

				# Parse DOT #s:
				# Finding heading text parsing:
				s4txt = subd['s4txt']
				s4txt = tc.remove_whitespace(s4txt)
				if s4txt not in ['U','P','E','']:
					dotfindall1_reslist = []
					for restup in re.findall(r"([0-9l\.\-]{2}|[0-9l]{1})?([0-9l]{3}\.?[0-9l]{3}\-?[0-9l]{3})([0-9l\.\-]{2}|[0-9l]{1})?", s4txt):
						if restup[0] == '' and restup[2] == '':
							dotres = restup[1].replace('l', '1')
							dotfindall1_reslist.append(dotres)
					dotfindall1_reslist = list(set(dotfindall1_reslist))

					if dotfindall1_reslist:
						dotreslist = ["".join([x for x in dotstring if x in "0123456789"]) for dotstring in dotfindall1_reslist]
						# TIP: Ensure no SSN somehow remained within the Step 4 text snippet this evaluates:
						# WARNING: This mechanism will NOT remove SSN if it isn't found.  Before using these DOT # for IQ,
						# you'll need to try again to remove SSN values using 'CLMT_SSN'.
						ssncheckedlist = ssnchecked.split('; ')
						ssnxrefcheckedlist = ssnxrefchecked.split('; ')
						s4dotfindingcheckedlist = [dotres for dotres in dotreslist if len(dotres) == 9 and dotres not in ssncheckedlist and dotres not in ssnxrefcheckedlist]

					# Get body text using index locations:
					if isinstance(subd['loc_end'], int):
						if np.isnan(subd['body_loc_end']):
							end_loc = len(decisionfindingsltd)-1
						else:
							end_loc = subd['body_loc_end']
						decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]
						# Remove trailing language:
						decisionfindingsltd_snip = re.sub(r"\bDECISION.*", "", decisionfindingsltd_snip, flags=re.S)
						decisionfindingsltd_snip = re.sub(r"\bLIST ?OF ?EXHIBITS.*", "", decisionfindingsltd_snip, flags=re.S)
						# Remove 'stock' margin text:
						decisionfindingsltd_snip = tc.remove_see_next_page(decisionfindingsltd_snip)
						# Remove whitespace (not needed for this parsing task):
						decisionfindingsltd_snip = tc.remove_whitespace(decisionfindingsltd_snip)

						# Locate/parse DOT #'s present:
						dotfindall2_reslist = []
						for restup in re.findall(r"([0-9l\.\-]{2}|[0-9l]{1})?([0-9l]{3}\.?[0-9l]{3}\-?[0-9l]{3})([0-9l\.\-]{2}|[0-9l]{1})?", decisionfindingsltd_snip):
							if restup[0] == '' and restup[2] == '':
								dotres = restup[1].replace('l', '1')
								dotfindall2_reslist.append(dotres)

						dotfindall2_reslist = list(set(dotfindall2_reslist))
						if dotfindall2_reslist:
							dotreslist = ["".join([x for x in dotstring if x in "0123456789"]) for dotstring in dotfindall2_reslist]
							ssncheckedlist = ssnchecked.split('; ')
							ssnxrefcheckedlist = ssnxrefchecked.split('; ')
							s4dotbodycheckedlist = [dotres2 for dotres2 in dotreslist if len(dotres2) == 9 and dotres2 not in ssncheckedlist and dotres2 not in ssnxrefcheckedlist]

					# Convert results containers to child table-friendly entries:
					for dot in s4dotfindingcheckedlist:
						s4dotchecked.append({'s4dotnum':dot, 's4dotloc':'F', 'S4_ORD_NUM':i})
					for dot in s4dotbodycheckedlist:
						s4dotchecked.append({'s4dotnum':dot, 's4dotloc':'B', 'S4_ORD_NUM':i})

		except Exception:
			logger.exception('EXCEPTION')

		# Step 5 MVR/'fwkdir' Parsing:
		try:
			for i, subd in enumerate(s5checked):

				if isinstance(subd['loc_end'], int):
					if np.isnan(subd['body_loc_end']):
						end_loc = len(decisionfindingsltd)-1
					else:
						end_loc = subd['body_loc_end']

					# Get body text using index locations:
					decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]
					# Remove trailing language:
					decisionfindingsltd_snip = re.sub(r"\bDECISION.*", "", decisionfindingsltd_snip, flags=re.S)
					decisionfindingsltd_snip = re.sub(r"LIST\s+OF\s+EXHIBITS.*", "", decisionfindingsltd_snip, flags=re.S)
					# Remove generic FIT language containing non-decision specific MVR # references:
					decisionfindingsltd_snip = re.sub(r"If\s{0,}the\s{0,}claimant\s{0,}(had|has)\s{0,}solely\s{0,}nonexertional\s{0,}limitations,\s{0,}(Medical-Vocational Rule|Rule|section)\s{0,}204\.00", "", decisionfindingsltd_snip, flags=re.I)
					decisionfindingsltd_snip = re.sub(r"section\s{0,}2\s{0,2}0\s{0,2}4\s{0,2}\.\s{0,1}0\s{0,2}0 ?([a-z\-\'\"\(\)]+ ){0,10}(provides|specifies|indicates)", "", decisionfindingsltd_snip, flags=re.I)
					# Remove 'stock' margin text:
					decisionfindingsltd_snip = tc.remove_see_next_page(decisionfindingsltd_snip)

					# Results container:
					mvr_reslist = []
					s5mvrunstructured = []
					s5mvrlookuperrlist = []
					s5frameworkordirectedverdictunstructured = []
					# parb_resdict = defaultdict(list)

					mvrlist = ["201.01", "201.02", "201.03", "201.04", "201.05", "201.06", "201.07", "201.08", "201.09", "201.10", "201.11", "201.12", "201.13", "201.14", "201.15", "201.16", "201.17", "201.18", "201.19", "201.20", "201.21", "201.22", "201.23", "201.24", "201.25", "201.26", "201.27", "201.28", "201.29", "202.01", "202.02", "202.03", "202.04", "202.05", "202.06", "202.07", "202.08", "202.09", "202.10", "202.11", "202.12", "202.13", "202.14", "202.15", "202.16", "202.17", "202.18", "202.19", "202.20", "202.21", "202.22", "203.01", "203.02", "203.03", "203.04", "203.05", "203.06", "203.07", "203.08", "203.09", "203.10", "203.11", "203.12", "203.13", "203.14", "203.15", "203.16", "203.17", "203.18", "203.19", "203.20", "203.21", "203.22", "203.23", "203.24", "203.25", "203.26", "203.27", "203.28", "203.29", "203.30", "203.31", "204.00"]

					# FIT searches:
					mvrfindall1 = re.findall(r"""
					(would\s{0,6}(therefore|thus|)\s{0,6}be\s{0,6}directed\s{0,6}by\s{0,6}(Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?))
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall1:
						s5frameworkordirectedverdictunstructured.append("2")
						for res in mvrfindall1:
							mvr_reslist.append("".join(str(res[4]).split()))
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))

					mvrfindall2 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6}is\s{0,6}(therefore|thus|)\s{0,6}directed\s{0,6}by\s{0,6})
					(Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?)
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall2:
						s5frameworkordirectedverdictunstructured.append("2")
						for res in mvrfindall2:
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))
							mvr_reslist.append("".join(str(res[16]).split()))

					mvrfindall3 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6}is\s{0,6}(therefore|thus|)\s{0,6}appropriate\s{0,6}under\s{0,6}the\s{0,6}framework\s{0,6}of\s{0,6})
					(Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?)
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall3:
						s5frameworkordirectedverdictunstructured.append("1")
						for res in mvrfindall3:
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))
							mvr_reslist.append("".join(str(res[16]).split()))

					mvrfindall4 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6}is\s{0,6}(therefore|thus|)\s{0,6}reached\s{0,6}by\s{0,6}direct\s{0,6}application\s{0,6}of\s{0,6})
					(Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?)
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall4:
						s5frameworkordirectedverdictunstructured.append("2")
						for res in mvrfindall4:
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))
							mvr_reslist.append("".join(str(res[16]).split()))

					mvrfindall5 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6}would\s{0,6}(therefore|thus|)\s{0,6}be\s{0,6}directed\s{0,6}by\s{0,6})
					(Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?)
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall5:
						s5frameworkordirectedverdictunstructured.append("2")
						for res in mvrfindall5:
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))
							mvr_reslist.append("".join(str(res[16]).split()))

					mvrfindall6 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6}is\s{0,6}(therefore|thus|)\s{0,6}appropriate\s{0,6}under\s{0,6}the\s{0,6}framework\s{0,6}of\s{0,6})
					(sections?|Medical-Vocational\s{0,6}Rules?|Medical\s{0,6}Vocational\s{0,6}Rules?|M\.?V\.?R\.?s?|Rules?)
					(\s{0,6})
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1}|204)
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					(\s{0,6},?\s{0,6}and\s{0,6}|\s{0,6};?\s{0,6}and\s{0,6}|\s{0,6},?\s{0,6}or\s{0,6}|\s{0,6};?\s{0,6}or\s{0,6}|\s{0,6};\s{0,6}|\s{0,6},\s{0,6}|\s{0,6})?
					(\d\s{0,1}\d\s{0,1}\d\s{0,1}\.?-?\s{0,1}\d\s{0,1}\d\s{0,1})?
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall6:
						s5frameworkordirectedverdictunstructured.append("1")
						for res in mvrfindall6:
							mvr_reslist.append("".join(str(res[6]).split()))
							mvr_reslist.append("".join(str(res[8]).split()))
							mvr_reslist.append("".join(str(res[10]).split()))
							mvr_reslist.append("".join(str(res[12]).split()))
							mvr_reslist.append("".join(str(res[14]).split()))
							mvr_reslist.append("".join(str(res[16]).split()))

					mvrfindall7 = re.findall(r"""
					(a\s{0,6}finding\s{0,6}of\s{0,6}(\"not\s{0,6}disabled\"|\'not\s{0,6}disabled\'|not\s{0,6}disabled|\"disabled\"|\'disabled\'|disabled|disability))
					(\s{0,6})
					(is\s{0,6}(therefore|thus|)\s{0,6}appropriate\s{0,6}under\s{0,6}the\s{0,6}framework\s{0,6}of\s{0,6}the\s{0,6}above)
					""", decisionfindingsltd_snip, re.I|re.S|re.M|re.X)
					if mvrfindall7:
						s5frameworkordirectedverdictunstructured.append("1")

					# Non-FIT searches:
					mvrfinditer1 = re.finditer(r"([^\d]|^)201(\.|\-)[012][0-9]([^\d]|$)|([^\d]|^)202(\.|\-)[012][0-9]([^\d]|$)|([^\d]|^)203(\.|\-)[0123][0-9]([^\d]|$)", decisionfindingsltd_snip)
					mvrfinditer1 = [res.group().strip() for res in mvrfinditer1]
					for res in mvrfinditer1:
						mvr_reslist.append(res)

					# Convert MVR entries into non-duplicate, cleaned values and place
					# in appropriate bins:
					if len(mvr_reslist) >= 1:
						mvr_reslist_clean = [it.replace("-", ".") for it in mvr_reslist]
						mvr_reslist_clean = [it.strip() for it in mvr_reslist_clean]
						mvr_reslist_clean = [str(it[:3] + "." + it[3:5]) if bool(re.search(r"\b\d\d\d\d\d\b", it)) else it for it in mvr_reslist_clean]
						mvr_reslist_clean = [it + ".00" if it == "204" else it for it in mvr_reslist_clean]
						mvr_reslist_clean = [it for it in mvr_reslist_clean if it != ""]
						mvr_reslist_clean = [' '.join(it.split()) for it in mvr_reslist_clean]
						mvr_reslist_clean = [re.sub(r".*(\d\d\d\.\d\d).*", r"\1", it) for it in mvr_reslist_clean if bool(re.search(r"\d\d\d", it))]

						for res in mvr_reslist_clean:
							foundver = 0
							for mvr in mvrlist:
								if mvr in res:
									s5mvrunstructured.append(mvr)
									foundver = 1
									break
							if foundver == 0:
								if len([m for m in ['201', '202', '203', '204', '201.0', '202.0', '203.0', '204.0', '201.00', '202.00', '203.00', '204.00'] if m == res.strip()]) == 0:
									s5mvrlookuperrlist.append(res)
						s5mvrunstructured = list(set(s5mvrunstructured))
						s5mvrlookuperrlist = list(set(s5mvrlookuperrlist))

					# Parse results:
					if len(s5frameworkordirectedverdictunstructured) > 1:
						s5frameworkordirectedverdictunstructured = list(set(s5frameworkordirectedverdictunstructured))

					# Convert results containers to child table-friendly entries:
					for mvr in s5mvrlookuperrlist:
						s5mvrlookuperrchecked.append({'s5mvr':mvr, 'S5_ORD_NUM':i})
					for mvr in s5mvrunstructured:
						s5mvrchecked.append({'s5mvr':mvr, 's5mvrsrc':'0', 'S5_ORD_NUM':i})

					if s5frameworkordirectedverdictunstructured:
						s5frameworkordirectedverdictchecked = '; '.join(s5frameworkordirectedverdictunstructured)
						subd['s5fwkdir'] = s5frameworkordirectedverdictchecked
		except Exception:
			logger.exception('EXCEPTION')

		# Step 5 DOT Parsing:
		# {'s5dotnum': '111222333'}
		try:
			for i, subd in enumerate(s5checked):

				if isinstance(subd['loc_end'], int):
					if np.isnan(subd['body_loc_end']):
						end_loc = len(decisionfindingsltd)-1
					else:
						end_loc = subd['body_loc_end']

					# Results container:
					s5dotcheckedlist = []
					# parb_resdict = defaultdict(list)

					# Get body text using index locations:
					decisionfindingsltd_snip = decisionfindingsltd[subd['loc_end']:end_loc]

					# Remove trailing language:
					decisionfindingsltd_snip = re.sub(r"\bDECISION.*", "", decisionfindingsltd_snip, flags=re.S)
					decisionfindingsltd_snip = re.sub(r"\bLIST ?OF ?EXHIBITS.*", "", decisionfindingsltd_snip, flags=re.S)
					# Remove 'stock' margin text:
					decisionfindingsltd_snip = tc.remove_see_next_page(decisionfindingsltd_snip)
					# Remove whitespace (not needed for this parsing task):
					decisionfindingsltd_snip = tc.remove_whitespace(decisionfindingsltd_snip)

					# Locate/parse DOT #'s present:
					dotfindall1_reslist = []
					for restup in re.findall(r"([0-9l\.\-]{2}|[0-9l]{1})?([0-9l]{3}\.?[0-9l]{3}\-?[0-9l]{3})([0-9l\.\-]{2}|[0-9l]{1})?", decisionfindingsltd_snip):
						if restup[0] == '' and restup[2] == '':
							dotres = restup[1].replace('l', '1')
							dotfindall1_reslist.append(dotres)
					if dotfindall1_reslist:
						dotreslist = ["".join([x for x in dotstring if x in "0123456789"]) for dotstring in dotfindall1_reslist]
						ssncheckedlist = ssnchecked.split('; ')
						ssnxrefcheckedlist = ssnxrefchecked.split('; ')
						s5dotcheckedlist = [dot for dot in dotreslist if len(dot) == 9 and dot not in ssncheckedlist and dot not in ssnxrefcheckedlist]

					# Convert results containers to child table-friendly entries:
					for dot in s5dotcheckedlist:
						s5dotchecked.append({'s5dotnum':dot, 'S5_ORD_NUM':i})

		except Exception:
			logger.exception('EXCEPTION')

		# NERSA (Named Entity Recognition - Source Algorithm):
		# OPENQ: *MOVE* NERSA to enable it to leverage additional structured
		# data during its parsing? There are valid arguments for keeping
		# ME names in the results.
		# TODO: Create lists of (full and last) name strings that clearly aren't
		# claimant medical sources (e.g. ME / CE name data) to pass to
		# NERSA_MED.
		try:
			srcnmchecked = nlp_helper.nersa_med(decisionfindingsltd, [])
		except Exception:
			logger.exception('EXCEPTION')

		# Write the decision's data to the decision data dictionary:

		# 'dspn_doc':
		decisiondatadict['ssn'] = str(ssnchecked)
		decisiondatadict['ssnxref'] = str(ssnxrefchecked)
		decisiondatadict['clnmadd'] = str(clnmaddchecked)
		decisiondatadict['clnm'] = str(clnmchecked)
		decisiondatadict['clzip'] = str(clzipchecked)
		decisiondatadict['repnmadd'] = str(repnmaddchecked)
		decisiondatadict['repnm'] = str(repnmchecked)
		decisiondatadict['repzip'] = str(repzipchecked)
		decisiondatadict['adjudicator'] = str(adjudicatorchecked)
		decisiondatadict['daamat'] = str(daamatchecked)
		decisiondatadict['dof'] = str(dofchecked)
		decisiondatadict['aod'] = str(aodchecked)
		decisiondatadict['aodamendver'] = str(aodamendverchecked)
		decisiondatadict['dli'] = str(dlichecked)
		decisiondatadict['did'] = str(didchecked)
		decisiondatadict['mip'] = str(mipchecked)
		decisiondatadict['merefbg'] = str(merefbgchecked)
		decisiondatadict['merefbody'] = str(merefbodychecked)
		decisiondatadict['verefbg'] = str(verefbgchecked)
		decisiondatadict['verefbody'] = str(verefbodychecked)
		decisiondatadict['venm'] = str(venmchecked)
		decisiondatadict['otrref'] = str(otrrefchecked)
		decisiondatadict['ssnsrc'] = str(ssncheckedsrc)
		decisiondatadict['ssnxrefsrc'] = str(ssnxrefcheckedsrc)
		decisiondatadict['clnmaddsrc'] = str(clnmaddcheckedsrc)
		decisiondatadict['clnmsrc'] = str(clnmcheckedsrc)
		decisiondatadict['clzipsrc'] = str(clzipcheckedsrc)
		decisiondatadict['repnmaddsrc'] = str(repnmaddcheckedsrc)
		decisiondatadict['repnmsrc'] = str(repnmcheckedsrc)
		decisiondatadict['repzipsrc'] = str(repzipcheckedsrc)
		decisiondatadict['adjudicatorsrc'] = str(adjudicatorcheckedsrc)
		decisiondatadict['daamatsrc'] = str(daamatcheckedsrc)
		decisiondatadict['aodsrc'] = str(aodcheckedsrc)
		decisiondatadict['aodamendversrc'] = str(aodamendvercheckedsrc)
		decisiondatadict['dlisrc'] = str(dlicheckedsrc)
		decisiondatadict['didsrc'] = str(didcheckedsrc)
		decisiondatadict['mipsrc'] = str(mipcheckedsrc)
		decisiondatadict['edver'] = str(edchecked)
		decisiondatadict['dob'] = str(dobchecked)
		decisiondatadict['txskillsver'] = str(txskillsverdictchecked)
		decisiondatadict['edversrc'] = str(edcheckedsrc)
		decisiondatadict['dobsrc'] = str(dobcheckedsrc)
		decisiondatadict['txskillsversrc'] = str(txskillsverdictcheckedsrc)
		if s5mvrlookuperrchecked:
			decisiondatadict['s5mvrlookuperr'] = s5mvrlookuperrchecked
		else:
			decisiondatadict['s5mvrlookuperr'] = []

		# Child tables:
		for i, subdict in enumerate(claimdispchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['claimdisp'][i] = subdict

		for i,subdict in enumerate(s1sgachecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s1sga'][i] = subdict

		for i,subdict in enumerate(s2checked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s2'][i] = subdict

		for i,subdict in enumerate(s3mteqchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s3mteq'][i] = subdict

		for i,subdict in enumerate(s3feqchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s3feq'][i] = subdict

		for i,subdict in enumerate(rfcchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['rfc'][i] = subdict

		for i,subdict in enumerate(s4checked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s4'][i] = subdict

		for i,subdict in enumerate(s4dotchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s4dot'][i] = subdict

		for i,subdict in enumerate(s5checked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s5'][i] = subdict

		for i,subdict in enumerate(s5dotchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['s5dot'][i] = subdict

		for i,subdict in enumerate(s5mvrchecked):
			subdict['ORD_NUM'] = i
			decisiondatadict['mvr'][i] = subdict

		for i,nm in enumerate(srcnmchecked):
			decisiondatadict['srcnm'][i] = nm

		return decisiondatadict, decisionfindingsltd

	except Exception:
		logger.exception('EXCEPTION')
		decisiondatadict = {k:'E' for k,v in decisiondatadict.iteritems()}
		for k,v in decisiondatadict.iteritems():
			if k in ['claimdisp', 's1sga', 's2', 's3mteq', 's3feq', 'rfc', 's4', 's4dot', 's5', 's5dot', 'mvr', 'srcnm']:
				decisiondatadict[k] = {}
		return decisiondatadict, "E"

# Testing function:
def testprep(inputfp):
	with open(inputfp, 'r') as input:
		inputread = input.read()
		res = insightextract(inputread)
		return res

# Testing/multiprocessing:
if __name__ == '__main__':


	def databasetest():

		# Set default values:
		test_dict = 'U'
		test_decision = 'U'

		# Set test UID values:

		# MVR 204.00 OVER-GUESSING DOCU_CTL_ID:
		test_decid_list = ["A1001001A15A22B53035F76499", "A1001001A15E11B33401G56532", "A1001001A15A30B11313I05415", "A1001001A15F02B42859E74474", "A1001001A15I09B45843G10135"]

		# DAA MATERIALITY TEST:
		test_decid_list = ['A1001001A15G13B35834F59114']

		for decid in test_decid_list:

			# Retrieve decision text:
			decisionfilesdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../input/decisionfiles"))
			decid_fn = decid + '.txt'
			decid_fp = os.path.join(decisionfilesdir, decid_fn)
			with open (decid_fp, 'r') as decid_file:
				decision = decid_file.read()

				#Run IE:
				res_tup = insightextract(decision)

				# Save readable version of result dictionary to file and open file:
				test_res_fn = 'IFS_IE_TEST_' + decid + '.txt'
				with open(os.path.join(testdir, test_res_fn), 'w') as res_file:
					for k,v in res_tup[0].iteritems():
						resstr = "%s: %s" % (str(k), str(v))
						res_file.write(resstr)
						res_file.write('\n')
				os.startfile(os.path.join(testdir, test_res_fn))

	print 'starting database test...'
	databasetest()


	def mptest():
		decisiondir = "D:\\NLP_INPUT\\2014DECISIONS"
		os.chdir("D:\\NLP_INPUT\\2014DECISIONS")
		testfplist = [os.path.join(decisiondir, fn) for fn in os.listdir(os.getcwd()) if fn.endswith('txt')]
		random.shuffle(testfplist)
		testfplist = testfplist[:50000]


		# Start the multiprocess:
		start = timeit.default_timer()
		batch_mp_process_ct = 'U'
		if batch_mp_process_ct == 'U':
			cpu_count = multiprocessing.cpu_count()
			batch_mp_process_ct = int(round(cpu_count*float(0.7)))
		pool = multiprocessing.Pool(processes=batch_mp_process_ct)
		results = pool.map_async(testprep, testfplist)
		resdict_list = results.get()
		pool.close()
		pool.join()
		stop = timeit.default_timer()
		print "INSIGHT IE - TIME TO COMPLETE: " + str(stop-start)
		print "RES LEN: %s" % str(len(resdict_list))

		resdict_list = [tup[0] for tup in resdict_list]
		resdf = pandas.DataFrame(resdict_list)
		resdf.to_csv("D:/temp/TEST_05022017.csv")

	# mptest()
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	
	

