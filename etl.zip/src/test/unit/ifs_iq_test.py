# INSIGHT QUALITY UNIT TESTS
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 12.23.2016
#
# SUMMARY: 
# This module consists of a suite of tools designed to extract, normalize,
# and otherwise parse date strings and datetime objects.
# 
# To simply convert a date present in text to a 'normalized' INSIGHT string
# format, the following workflow is required:
# (1) parse_date_tostr(date_string)
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os.path
import sys
import logging
import re
import datetime
import unittest
import numpy as np
from dateutil.relativedelta import *
from dateutil import parser

# Set directories:
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)
import ifs_iq as iq

# Disable all logging during testing:
# TIP: Disabling does not persist beyond test execution.
for k,v in logging.Logger.manager.loggerDict.iteritems():
	logging.disable(logging.CRITICAL)


# Create unittest class:
class Test(unittest.TestCase):
	
	# def setUp(self):
	
	# TIP: Not testing parse_date() as it is a helper function used only
	# by parse_date_tostr().
		
	def test_mvrlookuperr_calc(self):
		self.assertEqual(iq.mvrlookuperr_calc({'s5mvrlookuperr':'U'}), ('U', 'U'))
		self.assertEqual(iq.mvrlookuperr_calc({'s5mvrlookuperr':'E'}), ('E', 'E'))
		self.assertEqual(iq.mvrlookuperr_calc({}), ('E', 'E'))
		self.assertEqual(iq.mvrlookuperr_calc({'s5mvrlookuperr':'202.40'}), ('1', '202.40'))
	
	def test_s2txtonlysx_calc(self):
		self.assertEqual(iq.mvrlookuperr_calc({'s2':{0:{'ORD_NUM': 1, 's2txt': '5. From June 2010 to the present, the claimant has the following severe impairments: back pain (20 CFR 404.1520(c) and 416.920(c)).  ', 'body_end_loc': 1824, 's2txtsrc': '3', 'loc_tup': (1285, 1418), 's2ver': '1', 's2versrc': '3'}}}), ('1', [{'S2_ORD_NUM':0, 'SX_ENT':'BACK PAIN'}]))
		

	# def tearDown(self):

# Run:
if __name__=='__main__':
	unittest.main(exit=False)