"""Common FX Unit Test"""

import unittest
import pytest
import setup_config
import common_fx as cfx

#Common FX Unit Test Class

class TestCommonFx(object):

    @pytest.mark.parametrize( "data, expected", [
        ([1,2,[3,4],(5,6),7], [1, 2, 3, 4, 5, 6, 7]),
        (['A', {'Z':100}, 2, [3,-4],(5,'C'),7], ['A', 'Z', 2, 3, -4, 5, 'C', 7]),
        ([-7,-6,[-5,-4],(-3,-2),-1], [-7, -6, -5, -4, -3, -2, -1]),
    ])

    def test_flatten_irreg1(self, data, expected):
        input = cfx.flatten_irreg(data)
        assert list(input) == expected

    def test_flatten_irreg2(self):
        input = cfx.flatten_irreg([1,2,[3,4],(5,6),7])
        assert list(input) != [1, 2, 3, 5, 6, 7]

    def test_flatten_irreg_type(self):
        input = cfx.flatten_irreg([1,2,[3,4],(5,6),7])
        assert type(list(input)) == list   