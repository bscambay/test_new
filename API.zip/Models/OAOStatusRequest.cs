﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INSIGHT_Request.Models
{
    public class OAOStatusRequest
    {
        public string cossn { get; set; } = "";
        public string wrkunitofcuid { get; set; } = "";
        public string ocd { get; set; } = "";

    }
}