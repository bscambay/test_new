﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INSIGHT_Request.Models
{
    public class Claimant
    {
        [JsonProperty("folderNumber")]
        public int FLDR_NUM { get; set; } = 0;
        [JsonProperty("caseNumber")]
        public int CASE_NUM { get; set; } = 0;
        [JsonProperty("cossn")]
        public string COSSN { get; set; } = "";
        [JsonProperty("ocd")]
        public string JURIS_OCD { get; set; } = "";

        [JsonProperty("caseLevel")]
        public string ADJULVL_CD { get; set; } = "";

        [JsonProperty("clientFirstName")]
        public string FNM_UCASE { get; set; } = "";
        [JsonProperty("clientLastName")]
        public string LNM_UCASE { get; set; } = "";
        [JsonProperty("clientMiddleName")]
        public string MNM_UCASE { get; set; } = "";
        [JsonProperty("clientDOB")]
        public string DOB { get; set; } = "";
        //ALLGN
        //2017-06-21 Added
        [JsonProperty("clientAOD")]
        public string AOD { get; set; } = "";

        //ALLGN STOP_WRK_DT
        //2017-06-21 Added
        [JsonProperty("clientSWD")]
        public string STOP_WRK_DATE { get; set; } = "";

        [JsonProperty("clientGender")]
        public string SEX { get; set; } = "";

        [JsonProperty("clientAddress")]
        public string ADDR { get; set; } = "";

        [JsonProperty("clientHeight")]
        public string HT_INCH { get; set; } = "";
        [JsonProperty("clientWeight")]
        public string WT_OUNCES { get; set; } = "";
        [JsonProperty("caseAllegations")]
        public string ALLGN_DESC { get; set; } = "";
        [JsonProperty("caseReceiptDate")]
        public string CASE_ESTB_DT { get; set; } = "";
        [JsonProperty("caseAssignedDate")]
        public string MOST_RCNT_FLG_DT { get; set; } = "";
    }
}