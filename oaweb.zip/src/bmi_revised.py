# INSIGHT COMMON CALCULATIONS:
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# Contains functions that perform miscellaneous/common calculation tasks
# required by INSIGHT modules.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

# Import modules:
import logging
import os.path
import re

import pandas

import date_helper as dh

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, 'data')

# Set up logging as child:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load datasets:
bmi_male_2_20_df = pandas.read_csv(os.path.join(datadir, 'bmi_male_2_20.csv'))
bmi_female_2_20_df = pandas.read_csv(os.path.join(datadir, 'bmi_female_2_20.csv'))
male_0_2_imperial_df = pandas.read_csv(os.path.join(datadir, 'male_0_2_imperial.csv'))
female_0_2_imperial_df = pandas.read_csv(os.path.join(datadir, 'female_0_2_imperial.csv'))


# Parse weight instance BMI and/or percentile:
def parse_weight(sex_input_str, htin_input_str, wtlb_input_str, age_input_str, dob_str, enddt_str):
    '''Calculate and interpret weight-related information based on input height/weight/sex/age
    information.  Capable of handling adults, children, and infants.

    Args:
        sex_input_str {str}: Claimant sex, either 'M' (male) or 'F' (female).
        htin_input_str {str}: Claimant height, in inches.
        wtlb_input_str {str}: Claimant weight, in pounds.
        age_input_str {str}: Claimant age, formatted as '#-y-#-mo', i.e. the output
            format of 'date_helper.calc_age()'.
        dob_str {str}: Claimant date of birth. Accepts variety of formats
            (whatever 'parse_date_todatetime_struct()' can handle).
        enddt_str {str}: A terminal date used to calculate a target claimant
            age. Accepts variety of formats (whatever 'parse_date_todatetime_struct()'
            can handle).
    Returns:
        A dictionary containing in part the following values:
        bmi {str}: A number indicating the BMI given the input
            values.
        interp_var {str}: A variable value representing a
            weight interpretation, e.g. 'UW2'.
        interp_str {str}: A string, possibly including embedded
            HTML, summarizing the weight interpretation and what
            inputs it was based upon (e.g. 'Underweight (BMI = %s
            for height [%s in] & weight [%s lb]))'.
    Raises:
        N/A (returns dictionary containing 'E' values if Exception).
    '''
    try:
        # Check arguments:
        if not isinstance(sex_input_str, str):
            logger.critical('not isinstance(sex_input_str, str)')
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - sex_input_str - type passed = %s' % type(
                sex_input_str)
            res_dict = {'sex':'E', 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str, 'dob':dob_str,
                        'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if sex_input_str.upper() not in ['M', 'F', 'U']:
            logger.critical("sex_input_str.upper() not in ['M', 'F', 'U']")
            errstr = 'bmi_revised.parse_weight() - Argument Value Error - sex_input_str = %s' % sex_input_str
            res_dict = {'sex':'E', 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str, 'dob':dob_str,
                        'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not isinstance(htin_input_str, str):
            logger.critical("not isinstance(htin_input_str, str)")
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - htin_input_str - type passed = %s' % type(
                htin_input_str)
            #TODO Fix this syntax error in the next line for 'age': v where v doesnt exist
            res_dict = {'sex':sex_input_str, 'htin':'E', 'wtlb':wtlb_input_str, 'age':'v', 'dob':dob_str,
                        'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not isinstance(wtlb_input_str, str):
            logger.critical("isinstance(wtlb_input_str, str)")
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - wtlb_input_str - type passed = %s' % type(
                wtlb_input_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':'E', 'age':age_input_str, 'dob':dob_str,
                        'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not isinstance(age_input_str, str):
            logger.critical("isinstance(age_input_str, str)")
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - age_input_str - type passed = %s' % type(
                age_input_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':'E', 'dob':dob_str,
                        'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not isinstance(dob_str, str):
            logger.critical("isinstance(dob_str, str)")
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - dob_str - type passed = %s' % type(dob_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str,
                        'dob':'E', 'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not isinstance(enddt_str, str):
            logger.critical("isinstance(enddt_str, str)")
            errstr = 'bmi_revised.parse_weight() - Argument Type Error - enddt_str - type passed = %s' % type(
                enddt_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str,
                        'dob':dob_str, 'enddt':'E', 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not htin_input_str[0].isdigit():
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str,
                        'dob':dob_str, 'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict
        if not wtlb_input_str[0].isdigit():
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_input_str,
                        'dob':dob_str, 'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict

        # Normalize arguments:
        sex_input_str = sex_input_str.upper()

        # Parse age or date inputs (if both input, age still controls):
        if age_input_str in ['U', 'P', 'E']:
            if dob_str == 'U' or enddt_str == 'U':
                errstr = 'bmi_revised.parse_weight() - No age or date value passed'
                logger.critical(errstr)
                #TODO Fix this syntax error in the next line for 'age': age_parsed where age_parsed doesnt exist
                res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':'age_parsed',
                            'dob':dob_str, 'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
                return res_dict
            else:
                age_parsed = dh.calc_age(dob_str, enddt_str)
        else:
            age_parsed = age_input_str

        # Parse weight instance:
        if age_parsed == 'E':
            logger.critical("age_parsed == 'E'")
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_parsed,
                        'dob':dob_str, 'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
            return res_dict

        age_yr = int(age_parsed.split('-y-')[0])
        if age_yr >= 18:
            bmi_res = calc_bmi(htin_input_str, wtlb_input_str)
            interp_res_tup = interp_bmi_adult(bmi_res, htin_input_str, wtlb_input_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_parsed,
                        'dob':dob_str, 'enddt':enddt_str}
            res_dict['bmi'] = bmi_res
            res_dict['interp_var'] = interp_res_tup[0]
            res_dict['interp_str'] = interp_res_tup[1]
            return res_dict
        elif 18 > age_yr >= 2:
            bmi_res = calc_bmi(htin_input_str, wtlb_input_str)
            interp_res_tup = interp_bmi_child_2_18(age_parsed, sex_input_str, bmi_res)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_parsed,
                        'dob':dob_str, 'enddt':enddt_str}
            res_dict['bmi'] = bmi_res
            res_dict['interp_var'] = interp_res_tup[0]
            res_dict['interp_str'] = interp_res_tup[1]
            return res_dict
        # TIP: No need to call separate 'interpreter' fx here, as there's no 'BMI'
        # output for this age group (the only output is the interpretation of the
        # weight input).
        else:
            interp_res_tup = interp_bmi_child_0_2(sex_input_str, htin_input_str, wtlb_input_str)
            res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_parsed,
                        'dob':dob_str, 'enddt':enddt_str}
            res_dict['bmi'] = 'U'
            res_dict['interp_var'] = interp_res_tup[0]
            res_dict['interp_str'] = interp_res_tup[1]
            return res_dict
    except Exception, x:
        logger.exception('EXCEPTION')
        res_dict = {'sex':sex_input_str, 'htin':htin_input_str, 'wtlb':wtlb_input_str, 'age':age_parsed, 'dob':dob_str,
                    'enddt':enddt_str, 'bmi':'E', 'interp_var':'E', 'interp_str':'E'}
        return res_dict


# Interpret BMI value for an individual 18+:
def interp_bmi_adult(bmi_input_str, htin_input_str, wtlb_input_str):
    try:

        # Check argument:
        if not isinstance(bmi_input_str, str):
            errstr = 'bmi_revised.interp_bmi_adult() - Argument Type Error - bmi_input_str - type passed = %s' % type(
                bmi_input_str)
            return ('E', 'E')

        if bmi_input_str == 'U':
            bmi_interp_var = 'U'
            bmiverdictstr = """<span class="sso" style="color:purple; " id="bmiresultclaimant">Not Available (No Height/Weight Data for This Case)</span>"""
            return (bmi_interp_var, bmiverdictstr)
        elif bmi_input_str == 'E':
            bmi_interp_var = 'E'
            bmiverdictstr = """<span class="sso" style="color:purple; " id="bmiresultclaimant">Not Available (No Height/Weight Data for This Case)</span>"""
            return (bmi_interp_var, bmiverdictstr)
        else:
            bmi_input_str_float = float(bmi_input_str.strip())
            if bmi_input_str_float < 17.5:
                bmi_interp_var = 'UW1'
                bmi_interp_str = 'Underweight - Possible <a style=\"color:#ce0000; \" href=\"https://www.ssa.gov/disability/professionals/bluebook/5.00-Digestive-Adult.htm#5_08\" target=\"blank\">5.08</a> Meets/Equals BMI Level (BMI = %s for height [%s in] & weight [%s lb])' % (
                    bmi_input_str, htin_input_str, wtlb_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif 17.5 <= bmi_input_str_float <= 18.5:
                bmi_interp_var = 'UW2'
                bmi_interp_str = 'Underweight (BMI = %s for height [%s in] & weight [%s lb])' % (
                    bmi_input_str, htin_input_str, wtlb_input_str)
                bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif 18.5 <= bmi_input_str_float <= 24.999:
                bmi_interp_var = 'NML'
                bmi_interp_str = 'Normal (BMI = %s for height [%s in] & weight [%s lb])' % (
                    bmi_input_str, htin_input_str, wtlb_input_str)
                bmi_interp_html_str = "<span style=\"color:green; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif 24.999 <= bmi_input_str_float <= 29.999:
                bmi_interp_var = 'OW'
                bmi_interp_str = 'Overweight (BMI = %s for height [%s in] & weight [%s lb])' % (
                    bmi_input_str, htin_input_str, wtlb_input_str)
                bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            else:
                bmi_interp_var = 'OB'
                bmi_interp_str = 'Obese (BMI = %s for height [%s in] & weight [%s lb])' % (
                    bmi_input_str, htin_input_str, wtlb_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
    except Exception:
        logger.exception('EXCEPTION')
        return ('E', 'E')


# Interpret BMI value for an individual 2-18:
def interp_bmi_child_2_18(age_input_str, sex_input_str, bmi_input_str):
    try:
        # Check arguments:
        if isinstance(age_input_str, str) is False or bool(re.search(r'^\d+\-y\-\d+\-m$', age_input_str)) is False:
            errstr = 'bmi_revised.interp_bmi_child_2_18() - argument check error for age_input_str value %s' % str(
                age_input_str)
            logger.critical(errstr)
            return ('E', 'E')
        if isinstance(sex_input_str, str) is False or sex_input_str.upper() not in ['M', 'F']:
            return ('E', 'E')
        if not isinstance(bmi_input_str, str):
            errstr = 'bmi_revised.interp_bmi_child_2_18() - Argument Type Error - bmi_input_str - type passed = %s' % type(
                bmi_input_str)
            logger.critical(errstr)
            return ('E', 'E')

        # Normalize arguments:
        sex_input_str = sex_input_str.upper()

        # Calculate age in months as a float:
        age_yr = int(age_input_str.split("-y")[0])
        age_mo = int(age_input_str.split("-y-")[1].split('-m')[0])
        age_in_mo = float((age_yr * 12) + age_mo)

        # Convert bmi_input_str to float:
        bmi = float(bmi_input_str)

        # Parse sex-appropriate BMI interpretive dataset to
        # locate nearest age value <= 'age_in_mo':
        if sex_input_str == 'M':
            bmi_male_2_20_df_age_mo_list = bmi_male_2_20_df['age_mo'].tolist()
            bmi_male_2_20_df_age_mo_list_slice = [v for v in bmi_male_2_20_df_age_mo_list if v <= age_in_mo]
            bmi_male_2_20_df_age_mo_list_slice_min = min(bmi_male_2_20_df_age_mo_list_slice,
                                                         key=lambda x: abs(x - age_in_mo))
            bmi_male_2_20_df_age_mo_list_slice_min_df = bmi_male_2_20_df.loc[
                bmi_male_2_20_df['age_mo'] == bmi_male_2_20_df_age_mo_list_slice_min]
            if len(bmi_male_2_20_df_age_mo_list_slice_min_df) == 1:
                min_dict = bmi_male_2_20_df_age_mo_list_slice_min_df.iloc[0].to_dict()
                if bmi < min_dict['3']:
                    if age_yr == 2:
                        bmi_interp_var = 'UW1A'
                        bmi_interp_str = 'Underweight (BMI of %s < ~3rd percentile for age [%s] & sex [%s]) - may meet Listings 100.05, 105.08B and/or 106.08' % (
                            bmi_input_str, age_input_str, sex_input_str)
                        bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                        return (bmi_interp_var, bmi_interp_html_str)
                    else:
                        bmi_interp_var = 'UW1B'
                        bmi_interp_str = 'Underweight (BMI of %s < ~3rd percentile for age [%s] & sex [%s]) - may meet Listings 105.08B and/or 106.08' % (
                            bmi_input_str, age_input_str, sex_input_str)
                        bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                        return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['5'] > bmi >= min_dict['3']:
                    bmi_interp_var = 'UW2'
                    bmi_interp_str = 'Underweight (BMI of %s >= ~3rd percentile but < 5th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['85'] > bmi >= min_dict['5']:
                    bmi_interp_var = 'NML'
                    bmi_interp_str = 'Normal (BMI of %s >= 5th percentile but < 85th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:green; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['95'] > bmi >= min_dict['85']:
                    bmi_interp_var = 'OW'
                    bmi_interp_str = 'Overweight (BMI of %s >= 85th percentile but < 95th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif bmi >= min_dict['95']:
                    bmi_interp_var = 'OB'
                    bmi_interp_str = 'Obese (BMI of %s >= 95th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                else:
                    return ('E', 'E')
            else:
                return ('E', 'E')
        else:
            bmi_female_2_20_df_age_mo_list = bmi_female_2_20_df['age_mo'].tolist()
            bmi_female_2_20_df_age_mo_list_slice = [v for v in bmi_female_2_20_df_age_mo_list if v <= age_in_mo]
            bmi_female_2_20_df_age_mo_list_slice_min = min(bmi_female_2_20_df_age_mo_list_slice,
                                                           key=lambda x: abs(x - age_in_mo))
            bmi_female_2_20_df_age_mo_list_slice_min_df = bmi_female_2_20_df.loc[
                bmi_female_2_20_df['age_mo'] == bmi_female_2_20_df_age_mo_list_slice_min]
            if len(bmi_female_2_20_df_age_mo_list_slice_min_df) == 1:
                min_dict = bmi_female_2_20_df_age_mo_list_slice_min_df.iloc[0].to_dict()
                if bmi < min_dict['3']:
                    if age_yr == 2:
                        bmi_interp_var = 'UW1A'
                        bmi_interp_str = 'Underweight (BMI of %s < 3rd percentile for age [%s] & sex [%s]) - may meet Listings 100.05, 105.08B and/or 106.08' % (
                            bmi_input_str, age_input_str, sex_input_str)
                        bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                        return (bmi_interp_var, bmi_interp_html_str)
                    else:
                        bmi_interp_var = 'UW1B'
                        bmi_interp_str = 'Underweight (BMI of %s < 3rd percentile for age [%s] & sex [%s]) - may meet Listings 105.08B and/or 106.08' % (
                            bmi_input_str, age_input_str, sex_input_str)
                        bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                        return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['5'] > bmi >= min_dict['3']:
                    bmi_interp_var = 'UW2'
                    bmi_interp_str = 'Underweight (BMI of %s >= 3rd percentile but < 5th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['85'] > bmi >= min_dict['5']:
                    bmi_interp_var = 'NML'
                    bmi_interp_str = 'Normal (BMI of %s >= 5th percentile but < 85th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:green; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif min_dict['95'] > bmi >= min_dict['85']:
                    bmi_interp_var = 'OW'
                    bmi_interp_str = 'Overweight (BMI of %s >= 85th percentile but < 95th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                elif bmi >= min_dict['95']:
                    bmi_interp_var = 'OB'
                    bmi_interp_str = 'Obese (BMI of %s >= 95th percentile for age [%s] & sex [%s])' % (
                        bmi_input_str, age_input_str, sex_input_str)
                    bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                    return (bmi_interp_var, bmi_interp_html_str)
                else:
                    return ('E', 'E')
            else:
                return ('E', 'E')

    except Exception:
        logger.exception('EXCEPTION')
        return ('E', 'E')


# Interpret weight value for an individual 0-2:
def interp_bmi_child_0_2(sex_input_str, htin_input_str, wtlb_input_str):
    '''Calculate/interpret child BMI for use in evaluating obesity,
    malnutrition, etc., for children ages 0-2.

    Interprets child weight using imperial height (in), weight (lb), and sex
    ['m' or 'f']. Returns weight as well as an 'interpretation' of the
    percentile range the weight falls within as a string.  The interpretation
    is based on CDC datasets.  Age value passed (INSIGHT format, i.e. '##-y-##-mo')
    is used to confirm claimant status in 0-2 age range.

    Args:
        age_input_str {str}: Claimant's age as an INSIGHT-formatted
            string (i.e. '##-y-##-mo').
        sex_input_str {str}: Claimant's sex ['m'=male; 'f'=female].
        htin_input_str {str}: Height in inches as a string (e.g. '10'
            or '10.53').
        wtlb_input_str {str}: Weight in pounds as a string (e.g. '67'
            or '67.343').
    Returns:
        List where index 0 = a float type value equaling
        the claimant's weight (or 'E' if error) and index 1 = a string
        conveying the interpretation of that weight value (or 'E' if error).
    Raises:
        N/A (returns 'E' if exception occurs).
    '''
    try:

        # Check types:
        if isinstance(sex_input_str, str) is False or sex_input_str.upper() not in ['M', 'F']:
            return ('E', 'E')
        if isinstance(htin_input_str, str) is False or bool(htin_input_str[0].isdigit()) is False:
            return ('E', 'E')
        if isinstance(wtlb_input_str, str) is False or bool(wtlb_input_str[0].isdigit()) is False:
            return ('E', 'E')

        # Normalize arguments:
        sex_input_str = sex_input_str.upper()

        # Parse sex-appropriate weight interpretive dataset to
        # locate nearest 'len_in' value <= 'htin_input_str':
        # TIP: Interpretation of weight for children ages 0-2
        # requires a precise calculation using TWO 'nearest
        # bordering' height values.  If htin_input_float value
        # passed > 40.74805 or < 17.716545 in, then
        # 2 'nearest border' height values cannot be present
        # and we cannot calculate BMI (e.g. if a 1.9 yo CL 60 in
        # in length with a weight of 50 lb is measured, it's not
        # clear they should be obese, which is what would be the
        # conclusion if using the highest '40 in height' observation
        # in the CDC data).
        htin_input_float = float(htin_input_str)
        wtlb_input_float = float(wtlb_input_str)
        if htin_input_float < 17.716545 or htin_input_float > 40.74805:
            return ('U', 'U')

        # Interpret weight based on sex:
        if sex_input_str == 'M':

            # Find 'nearest border' higher/lower observations to calculate precise
            # weight percentile thresholds:
            male_0_2_imperial_df_len_in_list = male_0_2_imperial_df['len_in'].tolist()
            male_0_2_imperial_df_len_in_list_slice_lessthan = [v for v in male_0_2_imperial_df_len_in_list if
                                                               v <= htin_input_float]
            male_0_2_imperial_df_len_in_list_slice_greaterthan = [v for v in male_0_2_imperial_df_len_in_list if
                                                                  v >= htin_input_float]
            male_0_2_imperial_df_len_in_list_slice_min_lessthan = min(male_0_2_imperial_df_len_in_list_slice_lessthan,
                                                                      key=lambda x: abs(x - htin_input_float))
            male_0_2_imperial_df_len_in_list_slice_min_greaterthan = min(
                male_0_2_imperial_df_len_in_list_slice_greaterthan, key=lambda x: abs(x - htin_input_float))

            # Using weight percentile threshold ratio, recalculate height-appropriate weight percentile values given claimant's htin_input_float
            # then classify claimant's wtlb_input_float given recalculated height-appropriate weight percentile values:
            min_dict_lessthan = {}
            min_dict_greaterthan = {}
            min_dict_lessthan = male_0_2_imperial_df.loc[
                male_0_2_imperial_df['len_in'] == male_0_2_imperial_df_len_in_list_slice_min_lessthan]
            min_dict_lessthan = min_dict_lessthan.iloc[0].to_dict()
            min_dict_greaterthan = male_0_2_imperial_df.loc[
                male_0_2_imperial_df['len_in'] == male_0_2_imperial_df_len_in_list_slice_min_greaterthan]
            min_dict_greaterthan = min_dict_greaterthan.iloc[0].to_dict()

            if not min_dict_lessthan or not min_dict_greaterthan:
                return ('E', 'E')

            # Recalculate height-appropriate weight percentile values:
            min_dict_recalculated = {}
            for col in ['3', '5', '10', '25', '50', '75', '90', '95', '97']:
                min_dict_lessthan_wtval = min_dict_lessthan[col]
                min_dict_greaterthan_wtval = min_dict_greaterthan[col]
                min_dict_lessthan_htval = min_dict_lessthan['len_in']
                min_dict_greaterthan_htval = min_dict_greaterthan['len_in']
                htval_diff = min_dict_greaterthan_htval - min_dict_lessthan_htval
                wtval_diff = min_dict_greaterthan_wtval - min_dict_lessthan_wtval
                wtval_diff_100th = wtval_diff / 100
                htval_diff_100th = htval_diff / 100
                htin_input_float_diff = htin_input_float - min_dict_lessthan_htval
                htin_input_float_diff_appliedratio = htin_input_float_diff / htval_diff_100th
                added_wtlb = htin_input_float_diff_appliedratio * wtval_diff_100th
                min_dict_greaterthan_wtval_recalc = min_dict_lessthan_wtval + added_wtlb
                min_dict_recalculated[col] = min_dict_greaterthan_wtval_recalc

            # Interpret using recalculated values:
            # TODO - IN DEVELOPMENT - FOLLOWING IS PLACEHOLDER:
            # NOTE: If claimant's weight is between 3rd and 5th percentile, I'd output an 'interp_str' value
            # that notes that the claimant is 'very close to threshold where claimant would meet Listing 100.05' or
            # something of that nature.
            if wtlb_input_float < min_dict_recalculated['3']:
                bmi_interp_var = 'UW1'
                bmi_interp_str = 'Underweight (weight < 3rd percentile for weight [%s], height [%s], and sex [%s]) - may meet Listings 105.08B and/or 106.08' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif min_dict_recalculated['5'] > wtlb_input_float >= min_dict_recalculated['3']:
                bmi_interp_var = 'UW2'
                bmi_interp_str = 'Underweight (weight >= 3rd percentile but < 5th percentile for weight [%s], height [%s], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif min_dict_recalculated['95'] > wtlb_input_float >= min_dict_recalculated['5']:
                bmi_interp_var = 'NML'
                bmi_interp_str = 'Normal (weight >= 5th percentile but < 95th percentile for weight [%s], height [%s], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:green; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif wtlb_input_float >= min_dict_recalculated['95']:
                bmi_interp_var = 'OB'
                bmi_interp_str = 'Obese (weight >= 95th percentile for weight [%s lb], height [%s in], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            else:
                return ('E', 'E')
        else:

            # Find 'nearest border' higher/lower observations to calculate precise
            # weight percentile thresholds:
            female_0_2_imperial_df_len_in_list = female_0_2_imperial_df['len_in'].tolist()
            female_0_2_imperial_df_len_in_list_slice_lessthan = [v for v in female_0_2_imperial_df_len_in_list if
                                                                 v <= htin_input_float]
            female_0_2_imperial_df_len_in_list_slice_greaterthan = [v for v in female_0_2_imperial_df_len_in_list if
                                                                    v >= htin_input_float]
            female_0_2_imperial_df_len_in_list_slice_min_lessthan = min(
                female_0_2_imperial_df_len_in_list_slice_lessthan, key=lambda x: abs(x - htin_input_float))
            female_0_2_imperial_df_len_in_list_slice_min_greaterthan = min(
                female_0_2_imperial_df_len_in_list_slice_greaterthan, key=lambda x: abs(x - htin_input_float))

            # Using weight percentile threshold ratio, recalculate height-appropriate weight percentile values given claimant's htin_input_float
            # then classify claimant's wtlb_input_float given recalculated height-appropriate weight percentile values:
            min_dict_lessthan = {}
            min_dict_greaterthan = {}
            min_dict_lessthan = female_0_2_imperial_df.loc[
                female_0_2_imperial_df['len_in'] == female_0_2_imperial_df_len_in_list_slice_min_lessthan]
            min_dict_lessthan = min_dict_lessthan.iloc[0].to_dict()
            min_dict_greaterthan = female_0_2_imperial_df.loc[
                female_0_2_imperial_df['len_in'] == female_0_2_imperial_df_len_in_list_slice_min_greaterthan]
            min_dict_greaterthan = min_dict_greaterthan.iloc[0].to_dict()

            if not min_dict_lessthan or not min_dict_greaterthan:
                return ('E', 'E')

            # Recalculate height-appropriate weight percentile values:
            min_dict_recalculated = {}
            for col in ['3', '5', '10', '25', '50', '75', '90', '95', '97']:
                min_dict_lessthan_wtval = min_dict_lessthan[col]
                min_dict_greaterthan_wtval = min_dict_greaterthan[col]
                min_dict_lessthan_htval = min_dict_lessthan['len_in']
                min_dict_greaterthan_htval = min_dict_greaterthan['len_in']
                htval_diff = min_dict_greaterthan_htval - min_dict_lessthan_htval
                wtval_diff = min_dict_greaterthan_wtval - min_dict_lessthan_wtval
                wtval_diff_100th = wtval_diff / 100
                htval_diff_100th = htval_diff / 100
                htin_input_float_diff = htin_input_float - min_dict_lessthan_htval
                htin_input_float_diff_appliedratio = htin_input_float_diff / htval_diff_100th
                added_wtlb = htin_input_float_diff_appliedratio * wtval_diff_100th
                min_dict_greaterthan_wtval_recalc = min_dict_lessthan_wtval + added_wtlb
                min_dict_recalculated[col] = min_dict_greaterthan_wtval_recalc

            # Interpret using recalculated values:
            # TODO - IN DEVELOPMENT - FOLLOWING IS PLACEHOLDER:
            # NOTE: If claimant's weight is between 3rd and 5th percentile, I'd output an 'interp_str' value
            # that notes that the claimant is 'very close to threshold where claimant would meet Listing 100.05' or
            # something of that nature.
            if wtlb_input_float < min_dict_recalculated['3']:
                bmi_interp_var = 'UW1'
                bmi_interp_str = 'Underweight (weight < 3rd percentile for weight [%s], height [%s], and sex [%s]) - may meet Listings 105.08B and/or 106.08' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif min_dict_recalculated['5'] > wtlb_input_float >= min_dict_recalculated['3']:
                bmi_interp_var = 'UW2'
                bmi_interp_str = 'Underweight (weight >= 3rd percentile but < 5th percentile for weight [%s], height [%s], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:purple; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif min_dict_recalculated['95'] > wtlb_input_float >= min_dict_recalculated['5']:
                bmi_interp_var = 'NML'
                bmi_interp_str = 'Normal (weight >= 5th percentile but < 95th percentile for weight [%s], height [%s], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:green; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            elif wtlb_input_float >= min_dict_recalculated['95']:
                bmi_interp_var = 'OB'
                bmi_interp_str = 'Obese (weight >= 95th percentile for weight [%s lb], height [%s in], and sex [%s])' % (
                    wtlb_input_str, htin_input_str, sex_input_str)
                bmi_interp_html_str = "<span style=\"color:#ce0000; \"> " + bmi_interp_str + "</span>"
                return (bmi_interp_var, bmi_interp_html_str)
            else:
                return ('E', 'E')

    except Exception, x:
        logger.exception('EXCEPTION')
        return ('E', 'E')


# Calculate BMI (ages 2+):
def calc_bmi(htin_input_str, wtlb_input_str):
    '''Calculate BMI for individuals ages 2+.

    Arguments:
        htin_input_str {str}: Height in inches as a string (e.g. '10'
            or '10.53').
        wtlb_input_str {str}: Weight in pounds as a string (e.g. '67'
            or '67.343').
    Returns:
        bmi_rounded {str}: A BMI value, rounded to the third decimal place.
    '''
    try:
        # Check arguments:
        if not isinstance(wtlb_input_str, str):
            return 'E'
        if not isinstance(htin_input_str, str):
            return 'E'
        if not wtlb_input_str[0].isdigit():
            return 'E'
        if not htin_input_str[0].isdigit():
            return 'E'
        # Convert to floats & calcualte BMI:
        wtlb_input_float = float(wtlb_input_str)
        htin_input_float = float(htin_input_str)
        bmi = (wtlb_input_float / (htin_input_float ** 2)) * 703
        bmi_rounded = round(bmi, 3)
        return str(bmi_rounded)
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'
