﻿using System.IO;
using System.Web;

namespace INSIGHT_RequestTests
{
    public static class UnitTestHelper
    {
        /// <summary>
        /// Sets the HTTP context with a valid simulated request
        /// </summary>
        /// <param name="host">Host.</param>
        /// <param name="application">Application.</param>
        public static void SetHttpContextWithSimulatedRequest(string host, string url)
        {
            string appVirtualDir = "/";
            string appPhysicalDir = @"";

            string page = string.Empty;
            TextWriter output = null;

            SimulatedHttpRequest workerRequest = new SimulatedHttpRequest(appVirtualDir, appPhysicalDir, page, url, output, host);
            HttpContext.Current = new HttpContext(workerRequest);
        }
    }
}