﻿using log4net;
using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace INSIGHT_Request.Util
{
    public static class Utils
    {

        private static ILog logger = log4net.LogManager.GetLogger(typeof(Utils));
        /// <summary>
        /// Extension Method to correct issues in JSON
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        /// 

        public static string ToValueOrEmpty(this String str)
        {
            string s = str;
            if (string.IsNullOrWhiteSpace(s))
            {
                s = "";
            }
            return s;
        }
        public static string ToShortDate(this String str)
        {
            String s = str;
            if (string.IsNullOrWhiteSpace(s))
            {
                return "";
            }
            DateTime dt = new DateTime();
            DateTime.TryParse(s, out dt);
            s = dt.ToString("yyyy-MM-dd");
            return s;
        }

        public static string ToDmaDocumentChannel(string btchSrc,string srcDocuDspn = "",string ssasgnSite = "",string ssasgnVendorName = "",string rqstId = "")
        {
            string s = btchSrc.Trim();
            if (btchSrc.ToUpper() == "VENDOR" && ssasgnVendorName.ToUpper() == "EME") { return "ERE"; }
            if (btchSrc.ToUpper() == "VENDOR" && ssasgnVendorName.ToUpper() == "ACS") { return "VENDOR_SCAN"; }
            //
            if (btchSrc.ToUpper() == "OUTSOURCE" && ssasgnVendorName.ToUpper() == "HP") { return "HEALTHPORT"; }
            if (btchSrc.ToUpper() == "FAX") { return "FAX"; }
            if (btchSrc.ToUpper() == "SCAN") { return "ON_SITE_SCAN"; }
            if (btchSrc.ToUpper() == "" && ssasgnVendorName.ToUpper() == "")
            {
                if(rqstId.Contains("HIT"))
                return "HIT";
            }
            return s;
        }


        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethod()
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);

            return sf.GetMethod().Name + ":" + sf.GetFileName() + ":" + sf.GetFileLineNumber().ToString();
        }

        public static string ExtractValue(DataSet ds, string tableName, string lookupValue)
        {
            try
            {
                foreach (DataRow dR in ds.Tables[tableName].Rows)
                {
                    if (dR["HOST_VALUE"].ToString() ==lookupValue)
                    {
                        return dR["HOST_SETTING"].ToString().Trim();
                    }
                }

                return "";
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:" + x.StackTrace);
                return "";
            }
        }

        public static string GetQueryFromResource(string resname)
        {
            try
            {
                string result = string.Empty;
                var assembly = Assembly.GetExecutingAssembly();
                var resourceName = resname;

                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                using (StreamReader reader = new StreamReader(stream))
                {
                    result = reader.ReadToEnd();
                }

                return result;
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:" + x.StackTrace);
                return "";
            }
        }
    }
}