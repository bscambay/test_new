﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INSIGHT_Request.Models
{
    public class ClaimantRequest
    {
        public string folderNumber { get; set; } = "";
        public string caseNumber { get; set; } = "";

    }
}