export class CourseService {
    getCourses() {
        return ["Course1", "Course2", "Course3"];
    }
}