﻿using INSIGHT_Request.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace INSIGHT_Request.Util
{
    //regex replace for parmeters
    public static class StringExtensions
    {
        public static string SafeReplace(this string input, string find, string replace, bool matchWholeWord)
        {
            var pattern = Regex.Escape(find);
            if (Regex.IsMatch(find, @"^\w"))
                pattern = @"\b" + pattern;
            if (Regex.IsMatch(find, @"\w$"))
                pattern = pattern + @"\b";
            //string value = Regex.Escape(find);
            string textToFind = matchWholeWord ? string.Format(pattern, find) : find;
            input = Regex.Replace(input, textToFind, replace);
            //return input.Replace(find,replace);
            return input;
        }
    }
    //OdbcCommand
    public class OdbcSql
    {
        public enum sqlDataTypes
        {
            OString,
            ONumeric,
            ODate,
            OConst,
            OStringArray,
            ONumericArray
        }
        
        public OdbcSqlParameters OdbcSqlParameters { get; set; } = new OdbcSqlParameters();

        public string Sql { get; set; } = "";

        
        public OdbcSql()
        {

        }
        public OdbcSql(string sql)
        {

        }
        public string Prepare()
        {
            foreach (OdbcSqlParameter p in OdbcSqlParameters.Parameters)
            {
                switch (p.type)
                {
                    case sqlDataTypes.OString:
                        this.Sql = this.Sql.SafeReplace(p.name, "'" + p.value + "'",true);
                        break;
                    case sqlDataTypes.ONumeric:
                        this.Sql = this.Sql.SafeReplace(p.name, p.value,true);
                        break;
                    case sqlDataTypes.ODate:
                        this.Sql = this.Sql.SafeReplace(p.name, "'" + p.value + "'", true);
                        break;
                    case sqlDataTypes.OConst:
                        this.Sql = this.Sql.SafeReplace(p.name, "" + p.value + "", true);
                        break;
                    
                    default:
                        this.Sql = this.Sql.SafeReplace(p.name, "'" + p.value + "'", true);
                        break;
                }
                
            }

            return this.Sql;
        }
        
        public OdbcSqlParameters ListParameters()
        {
            OdbcSqlParameters temp = new OdbcSqlParameters();

            return temp;
        }
    }
    public class OdbcSqlParameter
    {
        public string name { get; set; }
        public string value { get; set; }
        public OdbcSql.sqlDataTypes type { get; set; }
        public OdbcSqlParameter()
        {

        }
        public OdbcSqlParameter(string name, string value, OdbcSql.sqlDataTypes type = OdbcSql.sqlDataTypes.OString )
        {
            this.name = name;
            this.value = value;
            this.type = type;
        }
    }
    public class OdbcSqlParameters
    {
        public List<OdbcSqlParameter> Parameters { get; } = new List<OdbcSqlParameter>();
        public OdbcSqlParameters()
        {

        }
        public OdbcSqlParameters(List<OdbcSqlParameter> list)
        {

        }
        public void Clear()
        {
            Parameters.Clear();
        }
        public void AddParameter(string name, string value, OdbcSql.sqlDataTypes type = OdbcSql.sqlDataTypes.OString)
        {
            this.Parameters.Add(new OdbcSqlParameter { name = name, value = value, type = type });
        }
        public void AddArrayParameter(string name, string[] value, OdbcSql.sqlDataTypes type = OdbcSql.sqlDataTypes.OStringArray)
        {
            string arr = "";
            foreach(string t in value)
            {
                arr += "'" + t + "',";
            }
            arr = arr.Substring(0, arr.Length - 1);
            this.Parameters.Add(new OdbcSqlParameter { name = name, value = arr, type = type });
        }
        private void AddParameters(List<OdbcSqlParameter> list)
        {
            foreach (OdbcSqlParameter p in list)
            {
                this.Parameters.Add(p);
            }
        }
    }
}
