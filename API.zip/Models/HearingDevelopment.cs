﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class HearingDevelopment
    {
        [JsonProperty("expertId")]
        public string EXPERT_UID { get; set; } = "";
        [JsonProperty("developmentSource")]
        public string DEV_SRC_CD { get; set; } = "";
        [JsonProperty("developmentGroup")]
        public string DEV_GRP { get; set; } = "";
        [JsonProperty("acknowledgementRecievedDate")]
        public string ACKT_RCVDT { get; set; } = "";
        [JsonProperty("insertTimestamp")]
        public string INSRT_TS { get; set; } = "";
        [JsonProperty("expertType")]
        public string EXPERT_TYP { get; set; } = "";
        [JsonProperty("title")]
        public string TITLE { get; set; } = "";
        [JsonProperty("firstName")]
        public string FNM { get; set; } = "";
        [JsonProperty("middleName")]
        public string MNM { get; set; } = "";
        [JsonProperty("lastName")]
        public string LNM { get; set; } = "";
        [JsonProperty("suffix")]
        public string SFX { get; set; } = "";
    }
}
