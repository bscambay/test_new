"""Text Cleaner Unit Test"""

import unittest
import pytest
import setup_config
import text_cleaner as cleaner



#Test Cleaner Unit Test Class

class TestTextCleaner(object):
    @pytest.mark.skip(reason="Skip this due to functionality issue")
    @pytest.mark.parametrize(
        "error, correction", [
            (r"claimant\ws", "claimant's"),
            (r"doctor\ws", "doctor's"),
            (r"widow\ws", "widow's"),
        ])
    def test_correct_common_spelling_errors_regex(self, error, correction):
        text = cleaner.correct_common_spelling_errors(error)
        assert text == correction

    @pytest.mark.parametrize(
        "error, correction", [
            ("Fullv Favorable", "Fully Favorable"),
            ("ffparagraph", "paragraph"),
            ("activityii", "activity"),
        ])
    def test_correct_common_spelling_errors(self, error, correction):
        text = cleaner.correct_common_spelling_errors(error)
        assert text == correction

    @pytest.mark.skip(reason="Skip this due to functionality issue")
    @pytest.mark.parametrize("input, expected", [
        ("O12-O|-1234", "012011234"),
        ("O45-|2-850O", "045128500")
    ])     
    def test_final_spelling_corrections(self, input, expected):
        text = cleaner.final_spelling_corrections(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("123. 456", "123.456"),
        ("789. 111", "789.111")
    ])     
    def test_remove_num_whitespace(self, input, expected):   
        text = cleaner.remove_num_whitespace(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("A B C D E", "ABCDE"),
        ("1 2 3 4 5", "12345")
    ])
    def test_remove_whitespace(self, input, expected):   
        text = cleaner.remove_whitespace(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("A   B C D    E", "A B C D E"), 
        ("1 2   3    4   5", "1 2 3 4 5") 
    ])
    def test_normalize_spacing(self, input, expected):    
        text = cleaner.normalize_spacing(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("ain't", "am not"),
        ("mustn't", "must not")
    ])
    def test_expand_contractions(self, input, expected):
        text = cleaner.expand_contractions(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("ABCDE", "_ABCDE_"),
        ("12345", "_12345_")
    ])
    def test_normalize_with_underscores(self, input, expected):  
        text = cleaner.normalize_with_underscores(input)
        assert text == expected

    @pytest.mark.parametrize("input, expected", [
        ("A, B, C, D, E", "E D C B A"),
        ("1, 2, 3, 4, 5", "5 4 3 2 1")
    ])
    def test_invert_around_comma(self, input, expected):
        text = cleaner.invert_around_comma(input)
        assert text == expected