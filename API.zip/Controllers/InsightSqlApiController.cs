﻿using INSIGHT_Request.Models;
using INSIGHT_Request.SSL;
using INSIGHT_Request.Util;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web.Http;

namespace INSIGHT_Request.Controllers
{
    public class InsightSqlApiController : ApiController
    {
        private static ILog logger = log4net.LogManager.GetLogger(typeof(InsightUserController));
        private Dictionary<string, string> routeParameterValues = new Dictionary<string, string>();
        private string ocd = string.Empty;
        private string hofc_wrk_unit_uid = string.Empty;
        private string searchssn = string.Empty;
        private string searchResultJSON = string.Empty;
        private string iv_user = string.Empty;        
        private string certIssuer = string.Empty;
        private string certSubject = string.Empty;

        /// <summary>
        /// Retrieves the Expert Data from the tables MHAODS.HRGEXP, MHAODS.DEVLPH and MHAODS.OPTLEXP 
        /// </summary>
        /// <returns>A json representation of the query results.</returns>
        [HttpGet]
        [Route("insight-request/insightsqlapi/structdata/medexpertdata")]

        public HttpResponseMessage casefromfolder()
        {                    
            try
            {
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));
                searchResultJSON = WWData.CaseDetailsFromFolder();

                return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON);                               
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }
            
        }


        /// <summary>
        /// Returns a merged data set comprised of the following db2 tables:
        ///     MHAODS.PACAR
        ///     MHAODS.WRKUNH
        ///     MHALCOPY.WRKUNH
        ///     MHAODS.ARCHWKUT
        ///     MHAODS.CLMINFO
        ///     MHAODS.DISPNH
        ///     MEDIB.CASE
        ///     MIDIB.CASE
        /// </summary>
        /// <returns>A json representation of the data set.</returns>
        [HttpGet]
        [Route("insight-request/insightsqlapi/structdata/merged-case-data")]

        public HttpResponseMessage GetMergedCaseData()
        {
            string searchResultJSON = string.Empty;

            try
            {
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));
                searchResultJSON = WWData.GetMergedCaseData();

                return Request.CreateResponse(HttpStatusCode.OK, searchResultJSON);
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }

        /// <summary>
        /// ETL endpoint for ARPS - support call from external applications
        /// Uses SSL
        /// </summary>
        /// <returns>Logs the call and returns success.</returns>

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("insight-request/insightsqlapi/structdata/etltrigger")]
        [RequireHttps]

        public HttpResponseMessage arpsetldatarequest([FromBody] ArpsRouteParameters rqst)
        {
                        
            try
            {
                logger.Info("ARPS triggered ETL call with parameters.....");
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));
                
                ///Get client certificate
                X509Certificate2 cert = Request.GetClientCertificate();

                //Capture client certificate details
                if (cert != null)
                {
                    certIssuer = cert.Issuer;
                    certSubject = cert.Subject;

                    logger.Info(string.Format("Certificate Details.....{0}, {1}", certIssuer, certSubject));
                }

                StringBuilder errorText = new StringBuilder();
                GetHeaderRouteParameters();
                GetBodyRouteParameters(rqst);


                if (routeParameterValues.TryGetValue("iv_user", out iv_user))
                {
                    if (iv_user == null)
                        errorText.Append("Missing IV_USER parameter");
                }

                if (routeParameterValues.TryGetValue("ocd", out ocd))
                {
                    if(ocd == null)
                        errorText.Append(" /// Missing OCD parameter");
                }

                if (routeParameterValues.TryGetValue("hofc_wrk_unit_uid", out hofc_wrk_unit_uid))
                {
                    if(hofc_wrk_unit_uid == null)
                        errorText.Append(" /// Missing HOFC_WRK_UNIT_UID parameter");
                }

                if (routeParameterValues.TryGetValue("searchssn", out searchssn))
                {
                    if(searchssn == null)
                        errorText.Append(" /// Missing SEARCHSSN parameter");
                }
                    
                
                if (errorText.Length > 0)
                {
                    logger.Error(errorText.ToString());
                    return Request.CreateResponse(HttpStatusCode.OK, errorText.ToString());
                }
               
                logger.Info(string.Format("ARPS triggered ETL call with parameters.....{0}, {1}, {2}, User: {3}", ocd, hofc_wrk_unit_uid, searchssn, iv_user));
                return Request.CreateResponse(HttpStatusCode.OK, "It worked");
                
                                
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("insight-request/insightsqlapi/structdata/etltrg")]
        [RequireHttps]

        public HttpResponseMessage arpstrg()
        {                      
            try
            {                                
                logger.Info("ARPS triggered SSL ETL call.....");
                logger.Info(string.Format("Invoking method.....: {0}", Utils.GetCurrentMethod()));                

                return Request.CreateResponse(HttpStatusCode.OK, "ETL trigger called successfully");
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }

        private void GetHeaderRouteParameters()
        {
            try
            {
                //Get Route Parameter values
                //from request Header for iv_user              
                HttpRequestMessage requestMsg = Request;
                var headers = requestMsg.Headers;

                if (headers.Contains("iv_user"))
                {                    
                    routeParameterValues.Add("iv_user", iv_user = headers.GetValues("iv_user").First());

                    logger.Info(string.Format("Header Parameter iv_user found {0}", iv_user));
                }
                else
                {
                    routeParameterValues.Add("iv_user", null);
                }

            }
            catch (KeyNotFoundException kx)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }

        private void GetBodyRouteParameters(ArpsRouteParameters rparms)
        {
            try
            {
                //Get Route Parameter values
                //from request Body for SSN, HOFC_WRK_UNIT_UID, OCD
                if (rparms != null)
                {                    
                    if (!routeParameterValues.ContainsKey("ocd"))
                    {
                        if (rparms.ocd.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter ocd: {0}", rparms.ocd));
                            routeParameterValues.Add("ocd", rparms.ocd);
                        }
                        else
                        {
                            routeParameterValues.Add("ocd", null);
                        }
                    }
                    
                    if (!routeParameterValues.ContainsKey("hofc_wrk_unit_uid"))
                    {
                        if (rparms.hofc_wrk_unit_uid.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter hofc_wrk_unit_uid: {0}", rparms.hofc_wrk_unit_uid));
                            routeParameterValues.Add("hofc_wrk_unit_uid", rparms.hofc_wrk_unit_uid);
                        }
                        else
                        {
                            routeParameterValues.Add("hofc_wrk_unit_uid", null);
                        }
                    }
                    if (!routeParameterValues.ContainsKey("searchssn"))
                    {
                        if (rparms.searchssn.Length > 0)
                        {
                            logger.Info(string.Format("Body Parameter searchssn: {0}", rparms.searchssn));
                            routeParameterValues.Add("searchssn", rparms.searchssn);
                        }
                        else
                        {
                            routeParameterValues.Add("searchssn", null);
                        }
                    }
                }

            }
            catch (KeyNotFoundException kx)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", kx.ToString(), Environment.NewLine, kx.StackTrace));
            }
            catch (Exception x)
            {
                logger.Error(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
                throw new Exception(string.Format("Error Details:-> {0} //// {1} {2}", x.ToString(), Environment.NewLine, x.StackTrace));
            }

        }

    }
}
