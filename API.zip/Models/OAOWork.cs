﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class OAOWork
    {
        [JsonProperty("OAOWorkListing")]
        public List<OAOClaimant_O> OAOWorkListing { get; set; } = new List<OAOClaimant_O>();
        public List<OAOFolderDocument> OAOFolderDocuments { get; set; } = new List<OAOFolderDocument>();
        public string rid { get; set; } = "-1";

    }
}
