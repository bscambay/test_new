﻿
using INSIGHT_Request.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using INSIGHT_Request.Util;
using System.Diagnostics;
using INSIGHT_Request;
using System.Web;
using log4net;

namespace INSIGHT_Request.Controllers
{
    public class MHAController : ApiController
    {
        ILog logger = log4net.LogManager.GetLogger(typeof(MHAController));
        [HttpPost]
        [ActionName("HC")]
        public HttpResponseMessage HC([FromBody] HearingClaimantRequest rqst)
        {
            try
            {
                byte[] b = System.Convert.FromBase64String(rqst.decisionText);
                rqst.decisionText = System.Text.Encoding.Default.GetString(b);
            }
            catch (Exception ex)
            {

                logger.ErrorFormat("Error converting base64 text \n{0}",ex.Message + ex.StackTrace);
            }
            
            
            HearingClaimantRequest c = rqst;

            DataSet ds = new DataSet();
            //TEST SET
            
            //
            ds = WWData.HearingClaimant(c.cossn, ds);
            logger.DebugFormat("Hearing Insight for Claimant {0}", c.cossn);
            logger.DebugFormat("Hearing Insight Requesting User {0}", c.pin);
            HearingWork ccl = new HearingWork();
            foreach (DataRow r in ds.Tables["STRUCT_HODISP"].Rows)
            {
                HearingClaimant_O cc = new HearingClaimant_O();
                cc.CASE_GRP_CD = r["CASE_GRP_CD"].ToString();
                cc.CLMT_DECD_SW = r["CLMT_DECD_SW"].ToString();
                cc.CLMT_DOB = Utils.ToShortDate(r["CLMT_DOB"].ToString().Trim());

                cc.SEX = r["SEX"].ToString(); 
                cc.HT_INCH = r["HT_INCH"].ToString();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString();

                cc.CLMT_NM25 = r["CLMT_NM25"].ToString();
                cc.CLMT_SSN = r["CLMT_SSN"].ToString();
                cc.CLMT_ST = r["CLMT_ST"].ToString();
                cc.CLM_TYP = r["CLM_TYP"].ToString();
                cc.CLM_UID = r["CLM_UID"].ToString();
                cc.CRITL_CASE_CTGY_SW = r["CRITL_CASE_CTGY_SW"].ToString();
                cc.DIRE_NEED_SW = r["DIRE_NEED_SW"].ToString();
                cc.DLI = Utils.ToShortDate(r["DLI"].ToString().Trim());
                cc.EDIB_CD = r["EDIB_CD"].ToString();

                cc.EFLDR_NUM = r["EFLDR_NUM"].ToString();
                cc.HEDULVL_CD = r["HEDULVL_CD"].ToString();
                cc.HOFC_WRK_UNIT_UID = r["HOFC_WRK_UNIT_UID"].ToString();
                cc.HRG_ISU_CD = r["HRG_ISU_CD"].ToString();
                cc.HRG_TYP = r["HRG_TYP"].ToString();

                cc.OHA_DAA_CD = r["OHA_DAA_CD"].ToString();
                cc.PTNTLY_HOMCDL_SW = r["PTNTLY_HOMCDL_SW"].ToString();
                cc.REP_UID = r["REP_UID"].ToString();
                cc.SUICIDL_SW = r["SUICIDL_SW"].ToString();
                cc.T16_APP_DT = Utils.ToShortDate(r["T16_APP_DT"].ToString().Trim());
                cc.T16_PFLG_DT = Utils.ToShortDate(r["T16_PFLG_DT"].ToString().Trim());
                cc.T2_APP_DT = Utils.ToShortDate(r["T2_APP_DT"].ToString().Trim());
                cc.T2_PFLG_DT = Utils.ToShortDate(r["T2_PFLG_DT"].ToString().Trim());

                cc.TRML_ILLNESS_SW = r["TRML_ILLNESS_SW"].ToString();
                cc.WG_ERNR_SSN = r["WG_ERNR_SSN"].ToString();
                //should put the expert and devl inside this class
                ds = WWData.HearingExpert(cc.HOFC_WRK_UNIT_UID, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP"].Rows)
                {
                    HearingExpert he = new HearingExpert();
                    he.ATTNDD_SW = hr["ATTNDD_SW"].ToString();
                    he.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    he.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    he.FNM = hr["FNM"].ToString();
                    he.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    he.LNM = hr["LNM"].ToString();
                    he.MED_SPCLY_CD = hr["MED_SPCLY_CD"].ToString();
                    he.MNM = hr["MNM"].ToString();
                    he.SCHD_SW = hr["SCHD_SW"].ToString();
                    he.SFX = hr["SFX"].ToString();
                    he.TITLE = hr["TITLE"].ToString();
                    cc.HearingExpert.Add(he);
                }
                ds = WWData.HearingDevelopment(cc.HOFC_WRK_UNIT_UID, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP"].Rows)
                {
                    HearingDevelopment hd = new HearingDevelopment();
                    hd.ACKT_RCVDT = Utils.ToShortDate(hr["ACKT_RCVDT"].ToString());
                    hd.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    hd.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    hd.FNM = hr["FNM"].ToString();
                    hd.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    hd.LNM = hr["LNM"].ToString();
                    hd.DEV_GRP = hr["DEV_GRP"].ToString();
                    hd.MNM = hr["MNM"].ToString();
                    hd.DEV_SRC_CD = hr["DEV_SRC_CD"].ToString();
                    hd.SFX = hr["SFX"].ToString();
                    hd.TITLE = hr["TITLE"].ToString();
                    cc.HearingDevelopment.Add(hd);
                }

                


                ccl.HearingWorkListing.Add(cc);
                

            }
            //moved prior to documents because inserts are done programtically based on the ds name
            string strPin = HttpContext.Current.User.Identity.Name;
            logger.Debug("Current User: " + strPin);

            

            HearingWork suc = WWData.AddInsightRequest(ds, rqst.cossn, rqst.decisionText, ccl,c.pin);
            logger.DebugFormat("AddInsightRequest: {0}", suc);
            //hearingdocuments
            //if (suc.HearingWorkListing.Count > 0)
            //{
            //    ds = WWData.HearingDocuments(suc.HearingWorkListing[0].EFLDR_NUM, ds);
            //    foreach (DataRow doc in ds.Tables["STRUCT_FOLDER_DOCUMENTS"].Rows)
            //    {
            //        HearingFolderDocument hfd = new HearingFolderDocument();
            //        hfd.CASE_NUM = doc["CASE_NUM"].ToString();
            //        hfd.DMA_NOTES = doc["DMA_NOTES"].ToString();
            //        hfd.DMA_RCPT_TS = Utils.ToShortDate(doc["DMA_RCPT_TS"].ToString());
            //        hfd.DOCU_CD = doc["DOCU_CD"].ToString();
            //        hfd.DOCU_CTL_ID = doc["DOCU_CTL_ID"].ToString();
            //        hfd.FLDR_NUM = doc["FLDR_NUM"].ToString();
            //        hfd.MDF_CD = doc["MDF_CD"].ToString();
            //        hfd.OCD = doc["OCD"].ToString();
            //        hfd.TRTMNT_SRC_NM = doc["TRTMNT_SRC_NM"].ToString();
            //        suc.HearingFolderDocuments.Add(hfd);
            //    }
            //}

            HttpResponseMessage response = new HttpResponseMessage();
            if (rqst.displayJson)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc);
            }
            else
            {
                if(suc.rid == "-1")
                {
                    response = Request.CreateResponse(HttpStatusCode.InternalServerError, "A DB Error has occured: " + suc.rid);
                }
                else
                {
                    response = Request.CreateResponse(HttpStatusCode.OK, suc.rid);
                }
                
            }

            logger.DebugFormat("INSIGHT Request has been created for RID = {0} ",suc.rid);
            return response;


        }
        [HttpPost]
        [ActionName("HC-data")]
        public HttpResponseMessage HC_Data([FromBody] HearingClaimantRequest rqst)
        {
            byte[] b = System.Convert.FromBase64String(rqst.decisionText);
            rqst.decisionText = System.Text.Encoding.Default.GetString(b);
            HearingClaimantRequest c = rqst;

            DataSet ds = new DataSet();
            //TEST SET

            //
            ds = WWData.HearingClaimant(c.cossn, ds);

            HearingWork ccl = new HearingWork();
            foreach (DataRow r in ds.Tables["STRUCT_HODISP"].Rows)
            {
                HearingClaimant_O cc = new HearingClaimant_O();
                cc.CASE_GRP_CD = r["CASE_GRP_CD"].ToString();
                cc.CLMT_DECD_SW = r["CLMT_DECD_SW"].ToString();
                cc.CLMT_DOB = Utils.ToShortDate(r["CLMT_DOB"].ToString().Trim());

                cc.SEX = r["SEX"].ToString();
                cc.HT_INCH = r["HT_INCH"].ToString();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString();

                cc.CLMT_NM25 = r["CLMT_NM25"].ToString();
                cc.CLMT_SSN = r["CLMT_SSN"].ToString();
                cc.CLMT_ST = r["CLMT_ST"].ToString();
                cc.CLM_TYP = r["CLM_TYP"].ToString();
                cc.CLM_UID = r["CLM_UID"].ToString();
                cc.CRITL_CASE_CTGY_SW = r["CRITL_CASE_CTGY_SW"].ToString();
                cc.DIRE_NEED_SW = r["DIRE_NEED_SW"].ToString();
                cc.DLI = Utils.ToShortDate(r["DLI"].ToString().Trim());
                cc.EDIB_CD = r["EDIB_CD"].ToString();

                cc.EFLDR_NUM = r["EFLDR_NUM"].ToString();
                cc.HEDULVL_CD = r["HEDULVL_CD"].ToString();
                cc.HOFC_WRK_UNIT_UID = r["HOFC_WRK_UNIT_UID"].ToString();
                cc.HRG_ISU_CD = r["HRG_ISU_CD"].ToString();
                cc.HRG_TYP = r["HRG_TYP"].ToString();

                cc.OHA_DAA_CD = r["OHA_DAA_CD"].ToString();
                cc.PTNTLY_HOMCDL_SW = r["PTNTLY_HOMCDL_SW"].ToString();
                cc.REP_UID = r["REP_UID"].ToString();
                cc.SUICIDL_SW = r["SUICIDL_SW"].ToString();
                cc.T16_APP_DT = Utils.ToShortDate(r["T16_APP_DT"].ToString().Trim());
                cc.T16_PFLG_DT = Utils.ToShortDate(r["T16_PFLG_DT"].ToString().Trim());
                cc.T2_APP_DT = Utils.ToShortDate(r["T2_APP_DT"].ToString().Trim());
                cc.T2_PFLG_DT = Utils.ToShortDate(r["T2_PFLG_DT"].ToString().Trim());

                cc.TRML_ILLNESS_SW = r["TRML_ILLNESS_SW"].ToString();
                cc.WG_ERNR_SSN = r["WG_ERNR_SSN"].ToString();
                //should put the expert and devl inside this class
                ds = WWData.HearingExpert(cc.HOFC_WRK_UNIT_UID, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP"].Rows)
                {
                    HearingExpert he = new HearingExpert();
                    he.ATTNDD_SW = hr["ATTNDD_SW"].ToString();
                    he.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    he.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    he.FNM = hr["FNM"].ToString();
                    he.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    he.LNM = hr["LNM"].ToString();
                    he.MED_SPCLY_CD = hr["MED_SPCLY_CD"].ToString();
                    he.MNM = hr["MNM"].ToString();
                    he.SCHD_SW = hr["SCHD_SW"].ToString();
                    he.SFX = hr["SFX"].ToString();
                    he.TITLE = hr["TITLE"].ToString();
                    cc.HearingExpert.Add(he);
                }
                ds = WWData.HearingDevelopment(cc.HOFC_WRK_UNIT_UID, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP"].Rows)
                {
                    HearingDevelopment hd = new HearingDevelopment();
                    hd.ACKT_RCVDT = Utils.ToShortDate(hr["ACKT_RCVDT"].ToString());
                    hd.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    hd.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    hd.FNM = hr["FNM"].ToString();
                    hd.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    hd.LNM = hr["LNM"].ToString();
                    hd.DEV_GRP = hr["DEV_GRP"].ToString();
                    hd.MNM = hr["MNM"].ToString();
                    hd.DEV_SRC_CD = hr["DEV_SRC_CD"].ToString();
                    hd.SFX = hr["SFX"].ToString();
                    hd.TITLE = hr["TITLE"].ToString();
                    cc.HearingDevelopment.Add(hd);
                }




                ccl.HearingWorkListing.Add(cc);


            }
            //moved prior to documents because inserts are done programtically based on the ds name
            //HearingWork suc = WWData.AddInsightRequest(ds, rqst.cossn, rqst.decisionText, ccl);
            HearingWork suc = ccl;
            //HearingDocuments
            if (suc.HearingWorkListing.Count > 0)
            {
                ds = WWData.HearingDocuments(suc.HearingWorkListing[0].EFLDR_NUM, ds);
                foreach (DataRow doc in ds.Tables["STRUCT_FOLDER_DOCUMENTS"].Rows)
                {
                    HearingFolderDocument hfd = new HearingFolderDocument();
                    hfd.CASE_NUM = doc["CASE_NUM"].ToString();
                    hfd.DMA_NOTES = doc["DMA_NOTES"].ToString();
                    hfd.DMA_RCPT_TS = Utils.ToShortDate(doc["DMA_RCPT_TS"].ToString());
                    hfd.DOCU_CD = doc["DOCU_CD"].ToString();
                    hfd.DOCU_CTL_ID = doc["DOCU_CTL_ID"].ToString();
                    hfd.FLDR_NUM = doc["FLDR_NUM"].ToString();
                    hfd.MDF_CD = doc["MDF_CD"].ToString();
                    hfd.OCD = doc["OCD"].ToString();
                    hfd.TRTMNT_SRC_NM = doc["TRTMNT_SRC_NM"].ToString();
                    suc.HearingFolderDocuments.Add(hfd);
                }
            }

            HttpResponseMessage response = new HttpResponseMessage();
            if (rqst.displayJson)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc.rid);
            }

            return response;


        }

    }
}
