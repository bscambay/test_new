# INSIGHT DATABASE ACTIONS - BATCH PROCESSING VERSION
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# SUMMARY:
# Contains functions to perform common database actions required for
# INSIGHT batch processing operations, such as adding/updating decision 
# text observation data.
#
# NOTE: Due to SQL Express storage constraints, I will NOT be inserting
# decisional text strings into 'NLPMain' when inserting batch-generated
# observations.	 Beyond technical considerations, this is possible because 
# decision text is not needed to generate HTML for IFS OAO calls.  If we
# want to 'update' batch-generated observations, we'll simply use
# 'batch.py' again to reopen each decision string text file for
# reprocessing.
#
# FUTURE: Would be better to store decision string in database rather than
# local copies (at least for accessibility/security reasons; speed-wise it is
# a detraction).
#
# DATE LAST UPDATED: 
# 01.04.2017
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# ==============================================================================

# Import modules:
import sys
import os
import datetime
import os.path
import logging
import pandas
import traceback
import pyodbc
import json
import numpy as np
import database_actions as ifsda
import config as cfg

# Import config_sec:
# secdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../../sec"))
# sys.path.insert(0, secdir)
import config_sec as cfg_sec

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


def convert_ord_num(x):
    if isinstance(x, long):
        return int(x)
    elif isinstance(x, float) and bool(np.isnan(x)) is False:
        return int(x)
    else:
        return x


# Function to return SQL Server database connection
_connection_SQLNLP = None


def get_sql_db_connect():
    global _connection_SQLNLP
    if _connection_SQLNLP is None:
        # Connect to INSIGHT DB:
        _connection_SQLNLP = sql_connect()
    else:
        try:
            cursor = _connection_SQLNLP.cursor()
        except Exception as e:
            if e.__class__ == pyodbc.ProgrammingError:
                # Connect to INSIGHT DB:
                _connection_SQLNLP = sql_connect()
    return _connection_SQLNLP


def sql_connect(sqlconnection=None):
    try:
        # Connect to INSIGHT DB:
        ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (
            cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
        sqlconnection = pyodbc.connect(ifs_db_cnxn_str)

    except Exception as e:
        logger.exception('EXCEPTION: ' + str(e))

    return sqlconnection


# Insert usage data into 'usagelog' table:
# DEPRECATION WARNING 06292017 - Duplicative of bottle_oao.py function.
def insert_usagelog(reqid, nm, inputs, response):
    try:
        # Check arguments:
        if not reqid.isdigit():
            logger.critical('database_actions_batch.insert_usagelog() - non-digit REQID:')
            logger.critical(reqid)
            return 'E'
        if not isinstance(nm, str):
            logger.critical('database_actions_batch.insert_usagelog() - non-str nm:')
            logger.critical(nm)
            return 'E'
        if not isinstance(inputs, str):
            logger.critical('database_actions_batch.insert_usagelog() - non-str inputs:')
            logger.critical(inputs)
            return 'E'
        if not isinstance(response, str):
            logger.critical('database_actions_batch.insert_usagelog() - non-str response:')
            logger.critical(response)
            return 'E'
        # Connect to INSIGHT DB and insert values:
        ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (
            cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
        connection_SQLNLP = pyodbc.connect(ifs_db_cnxn_str)
        cursor_SQLNLP = connection_SQLNLP.cursor()
        col_names = [row[3] for row in cursor_SQLNLP.columns(table='usagelog')]
        col_names = [c for c in col_names if c != 'insert_ts']
        sql = "INSERT into usagelog (%s) values (%s)" % (','.join(col_names), ','.join(['?'] * len(col_names)))
        cursor_SQLNLP.execute(sql, [reqid, nm, inputs, response])
        # Commit changes/close connection:
        connection_SQLNLP.commit()
        cursor_SQLNLP.close()
        del cursor_SQLNLP
        connection_SQLNLP.close()
        return '1'
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Insert IFS OAO ETL batch of observation data into
# IFS DB (schema 2):
def insert_schema2(input_df, input_df_exp, unique_uid_cn):
    '''
    INSERT newly generated OAO ETL data into
    INSIGHT DB.

    NOTE: Every 'input_df' obs will have a
    DOCU_CTL_ID value.
    '''
    try:
        # Connect to INSIGHT DB:
        ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (
            cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
        connection_SQLNLP = pyodbc.connect(ifs_db_cnxn_str)
        cursor_SQLNLP = connection_SQLNLP.cursor()

        # (TABLED - ifs_batch.py already filters out DOCU_CTL_ID values that are already
        # in the INSIGHT DB before running INSIGHT and before this insert action would occur)

        # Insert data into dspn_doc:

        # Verify data to be written matches 'dspn_doc' shape:
        col_names = [row[3] for row in cursor_SQLNLP.columns(table='dspn_doc')]
        col_names = [c for c in col_names if c not in ['REQID']]
        dspn_doc_subdf = input_df[[cn for cn in col_names if cn in input_df.columns.tolist()]]
        dspn_doc_subdf.drop_duplicates(subset='DOCU_CTL_ID', keep='first', inplace=True)
        if len(set(col_names).symmetric_difference(set(dspn_doc_subdf.columns.tolist()))) != 0:
            logger.critical(
                'ifs_database_actions_batch.insert_schema2() - dspn_doc shape does not match input data shape')
            raise Exception

        dspn_doc_lol = dspn_doc_subdf.values.tolist()
        # TEMPORARY - fill in missing column names:
        missing_params_len = len(col_names) - len(dspn_doc_lol[0])
        # Convert all Longs and non-NaN floats to ints, then convert
        # all values to strings:
        dspn_doc_lol_fnl = []
        for sublist in dspn_doc_lol:
            new_sublist = []
            for item in sublist:
                item = convert_ord_num(item)
                new_sublist.append(str(item))
            sublist_fnl = new_sublist + [''] * missing_params_len
            dspn_doc_lol_fnl.append(new_sublist)
        # Insert into DB:
        sql = "INSERT into dspn_doc (%s) values (%s)" % (','.join(col_names), ','.join(['?'] * len(col_names)))
        for i, sublist in enumerate(dspn_doc_lol_fnl):
            try:
                subtuple = tuple(sublist)
                cursor_SQLNLP.execute(sql, subtuple)
            except Exception:
                logger.critical(str(sublist))
                logger.critical(str(sql))
                logger.exception('EXCEPTION')

        # Retrieve generated REQID values and merge them into
        # input_df:
        docu_ctl_id_list = dspn_doc_subdf['DOCU_CTL_ID'].tolist()
        col_names = ['DOCU_CTL_ID', 'REQID']
        sql = "SELECT DOCU_CTL_ID, REQID from dspn_doc WHERE DOCU_CTL_ID IN (%s)" % ','.join(
            ['?'] * len(docu_ctl_id_list))
        cursor_SQLNLP.execute(sql, docu_ctl_id_list)
        restuplist = cursor_SQLNLP.fetchall()
        reqid_resdict = {tup[0]: tup[1] for tup in restuplist}
        input_df['REQID'] = input_df['DOCU_CTL_ID'].map(reqid_resdict)
        input_df_hofc_reqid_dict = dict(zip(input_df['HOFC_WRK_UNIT_UID'], input_df['REQID']))
        input_df_exp['REQID'] = input_df_exp['HOFC_WRK_UNIT_UID'].map(input_df_hofc_reqid_dict)
        input_df = input_df.dropna(subset=['REQID'])
        input_df_exp = input_df_exp.dropna(subset=['REQID'])

        # Insert child table data by REQID using same basic steps as
        # dspn_doc insert:
        child_subdf = input_df.drop_duplicates(subset='DOCU_CTL_ID', keep='first')
        for tbl_nm in cfg.ifs_database_tblnm_list_s2_nonstruct_child:

            # Add REQID value to child observations:
            def expand_child(row, child_tgt_cn):
                # Quality '_val' values = list of dicts:
                if child_tgt_cn == 'quality':
                    qdictlist = []
                    reqid = row['REQID']
                    for cn in [c for c in input_df.columns.tolist() if '_val' in c]:
                        child_tgt_dictlist = row[cn]
                        for d in [dict(item, REQID=reqid) for item in child_tgt_dictlist]:
                            qdictlist.append(d)
                    return qdictlist
                # Source name values = dict:
                elif child_tgt_cn == 'srcnm':
                    child_tgt_dict = row[child_tgt_cn]
                    srcnmdictlist = []
                    for k, v in child_tgt_dict.iteritems():
                        srcnmdict = {}
                        srcnmdict['ORD_NUM'] = str(k)
                        srcnmdict['srcnm'] = v
                        srcnmdictlist.append(srcnmdict)
                    reqid = row['REQID']
                    srcnmdictlist = [dict(item, REQID=reqid) for item in srcnmdictlist]
                    return srcnmdictlist
                #
                else:
                    # Retrieve child_tgt_cn value (dict):
                    child_tgt_dict = row[child_tgt_cn]
                    # Get child_tgt_cn value's values (list of dicts):
                    child_tgt_dict_values = child_tgt_dict.values()
                    # Add REQID to each child obs dict:
                    reqid = row['REQID']
                    child_tgt_dict_values = [dict(item, REQID=reqid) for item in child_tgt_dict_values]
                    # Return list of child obs dict that each
                    # include the row[3]s REQID value:
                    return child_tgt_dict_values

            res_ser = child_subdf.apply(lambda row: expand_child(row, tbl_nm), axis=1)

            # Convert from list of sublists (each sublist containing
            # a child obs dict) to a list of child obs dicts:
            res_lol = res_ser.values.tolist()
            res_dictlist = [sd for sl in res_lol for sd in sl]
            if res_dictlist:
                res_df = pandas.DataFrame(res_dictlist)

                # Filter res_df to only its columns that are in the child table, then INSERT:
                col_names = [row[3] for row in cursor_SQLNLP.columns(table=tbl_nm)]
                res_df_slice = res_df[[cn for cn in col_names if cn in res_df.columns.tolist()]]
                res_df_slice_lol = res_df_slice.values.tolist()
                missing_params_len = len(col_names) - len(res_df_slice_lol[0])
                res_df_slice_lol_fnl = []
                for sublist in res_df_slice_lol:
                    new_sublist = []
                    for item in sublist:
                        item = convert_ord_num(item)
                        if isinstance(item, float):
                            if np.isnan(item):
                                new_sublist.append(None)
                            else:
                                new_sublist.append(str(item))
                        else:
                            new_sublist.append(str(item))
                    sublist_fnl = new_sublist + [None] * missing_params_len
                    res_df_slice_lol_fnl.append(sublist_fnl)
                # Insert:
                sql = '''INSERT into %s(%s) values(%s)''' % (
                    tbl_nm, ','.join(col_names), ','.join(['?'] * len(col_names)))
                for i, sublist in enumerate(res_df_slice_lol_fnl):
                    if sublist:
                        try:
                            subtuple = tuple(sublist)
                            cursor_SQLNLP.execute(sql, subtuple)
                        except Exception:
                            logger.critical(str(sublist))
                            logger.critical(str(sql))
                            logger.exception('EXCEPTION')

        # Insert structured data:
        for tbl_nm in cfg.ifs_database_tblnm_list_s2_struct:
            if tbl_nm == 'struct_hodisp':
                struct_hodisp_df = input_df.drop_duplicates(subset='HOFC_WRK_UNIT_UID', keep='first')
                col_names = [row[3] for row in cursor_SQLNLP.columns(table='struct_hodisp')]
                struct_hodisp_df_slice = struct_hodisp_df[
                    [cn for cn in col_names if cn in struct_hodisp_df.columns.tolist()]]
                struct_hodisp_df_slice_lol = struct_hodisp_df_slice.values.tolist()
                missing_params_len = len(col_names) - len(struct_hodisp_df_slice_lol[0])
                struct_hodisp_df_slice_lol_fnl = []
                for sublist in struct_hodisp_df_slice_lol:
                    new_sublist = []
                    for item in sublist:
                        item = convert_ord_num(item)
                        new_sublist.append(str(item))
                    sublist_fnl = new_sublist + [None] * missing_params_len
                    struct_hodisp_df_slice_lol_fnl.append(sublist_fnl)
                sql = "INSERT into %s (%s) values (%s)" % (
                    tbl_nm, ','.join(col_names), ','.join(['?'] * len(col_names)))
                for i, sublist in enumerate(struct_hodisp_df_slice_lol_fnl):
                    try:
                        cursor_SQLNLP.execute(sql, sublist)
                    except Exception:
                        logger.critical(str(sublist))
                        logger.critical(str(sql))
                        logger.exception('EXCEPTION')
            elif tbl_nm == 'struct_oao':
                struct_oao_df = input_df.drop_duplicates(subset='hofc_wrk_unit_AC', keep='first')
                col_names = [row[3] for row in cursor_SQLNLP.columns(table='struct_oao')]
                struct_oao_df_slice = struct_oao_df[[cn for cn in col_names if cn in struct_oao_df.columns.tolist()]]
                struct_oao_df_slice_lol = struct_oao_df_slice.values.tolist()
                missing_params_len = len(col_names) - len(struct_oao_df_slice_lol[0])
                struct_oao_df_slice_lol_fnl = []
                for sublist in struct_oao_df_slice_lol:
                    new_sublist = []
                    for item in sublist:
                        item = convert_ord_num(item)
                        new_sublist.append(str(item))
                    sublist_fnl = new_sublist + [None] * missing_params_len
                    struct_oao_df_slice_lol_fnl.append(sublist_fnl)
                sql = "INSERT into %s (%s) values (%s)" % (
                    tbl_nm, ','.join(col_names), ','.join(['?'] * len(col_names)))
                for i, sublist in enumerate(struct_oao_df_slice_lol_fnl):
                    try:
                        cursor_SQLNLP.execute(sql, sublist)
                    except Exception:
                        logger.critical(str(sublist))
                        logger.critical(str(sql))
                        logger.exception('EXCEPTION')
            elif tbl_nm == 'struct_exp':
                col_names = [row[3] for row in cursor_SQLNLP.columns(table='struct_exp')]
                input_df_exp_slice = input_df_exp[[cn for cn in col_names if cn in input_df_exp.columns.tolist()]]
                input_df_exp_slice_lol = input_df_exp_slice.values.tolist()
                missing_params_len = len(col_names) - len(input_df_exp_slice_lol[0])
                input_df_exp_slice_lol_fnl = []
                for sublist in input_df_exp_slice_lol:
                    new_sublist = []
                    for item in sublist:
                        item = convert_ord_num(item)
                        new_sublist.append(str(item))
                    sublist_fnl = new_sublist + [None] * missing_params_len
                    input_df_exp_slice_lol_fnl.append(sublist_fnl)
                if input_df_exp_slice_lol_fnl:
                    sql = "INSERT into %s (%s) values (%s)" % (
                        tbl_nm, ','.join(col_names), ','.join(['?'] * len(col_names)))
                    for i, sublist in enumerate(input_df_exp_slice_lol_fnl):
                        try:
                            cursor_SQLNLP.execute(sql, sublist)
                        except Exception:
                            logger.critical(str(sublist))
                            logger.critical(str(sql))
                            logger.exception('EXCEPTION')

        # Commit changes/close connection:
        connection_SQLNLP.commit()
        cursor_SQLNLP.close()
        del cursor_SQLNLP
        connection_SQLNLP.close()

        return '1'

    except Exception:
        logger.exception('EXCEPTION')
        cursor_SQLNLP.close()
        del cursor_SQLNLP
        connection_SQLNLP.close()
        return 'E'


# Insert IFS OAO ETL batch of observation data into
# IFS DB (schema 2):
def insert_failed_schema2(input_df, reason):
    """
    INSERT newly generated OAO failed ETL data into
    INSIGHT DB.
    """
    connection_SQLNLP = None
    cursor_SQLNLP = None

    try:
        # Connect to INSIGHT DB:
        connection_SQLNLP = get_sql_db_connect()
        cursor_SQLNLP = connection_SQLNLP.cursor()

        col_names = [row[3] for row in cursor_SQLNLP.columns(table='failed_struct_oao')]
        col_names = [c for c in col_names if c not in ['ID', 'INSRT_TS']]
        decid_nondownloaded_df = input_df[[cn for cn in col_names if cn in input_df.columns.tolist()]]
        decid_nondownloaded_df.drop_duplicates(subset=['hofc_wrk_unit_AC', 'DOCU_CTL_ID'], keep='first', inplace=True)

        table_doc_lol = decid_nondownloaded_df.values.tolist()

        # Convert all Longs and non-NaN floats to ints, then convert
        # all values to strings:
        table_doc_lol_fnl = []
        for sublist in table_doc_lol:
            new_sublist = []
            for item in sublist:
                item = convert_ord_num(item)
                new_sublist.append(str(item))
            # Add reason
            new_sublist.append(reason)
            table_doc_lol_fnl.append(new_sublist)

        # Insert into DB:
        sql = "INSERT into failed_struct_oao (%s) values (%s)" % (','.join(col_names), ','.join(['?'] * len(col_names)))
        for i, sublist in enumerate(table_doc_lol_fnl):
            try:
                subtuple = tuple(sublist)
                cursor_SQLNLP.execute(sql, subtuple)
            except Exception as ex:
                logger.critical(str(sublist))
                logger.critical(str(sql))
                logger.exception('EXCEPTION: ' + str(ex))

        # Commit changes/close connection:
        connection_SQLNLP.commit()
        cursor_SQLNLP.close()
        del cursor_SQLNLP
        connection_SQLNLP.close()

        return '1'

    except Exception as ex:
        logger.exception('EXCEPTION: ' + str(ex))
        if cursor_SQLNLP:
            cursor_SQLNLP.close()
            del cursor_SQLNLP
        if connection_SQLNLP:
            connection_SQLNLP.close()
        return 'E'
