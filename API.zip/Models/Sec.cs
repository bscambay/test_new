﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class Sec
    {
        public string uid { get; set; } = "";
        public string pwd { get; set; } = "";

    }
}
