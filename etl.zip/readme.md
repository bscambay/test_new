# Insight ETL

## Setup

1. Start out by cloning this repository:
    ```
    cd c:\ws\repos
    git clone ssh://git@stash.ba.ssa.gov/ins/insight_etl.git
    cd insight_etl
    ```
1. Install dependancies
    ```
    robocopy \\s1ff600\resources c:\ProgramData\Pip pip.ini /NFL /NDL /s
    pip install -r requires.txt
    ```
## Testing
Note:
    Tox will take a while to run upon first invocation.  Tox run a second time runs much faster because it keeps track of virtualenv details and will not recreate or re-install dependencies.
```
pip install tox
```
* unit test
    ```
    tox -e test-scripts
    ```
* code coverage
    ```
    tox -e cov-report
    ```
* lint
    ```
    tox -e lint
    ```
* run all
    ```
    tox or tox -v
    ```

## Running
1. Rename src/sample_config_sec.py to src/config_sec.py
1. Update config_sec.py
    * Set your PIN and password in the __MIDIB database connection__ section
    * Update the __IFS database connection__ section to point to your local database
1. Open command prompt and run `python src\batch.py`
