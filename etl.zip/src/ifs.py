# INSIGHT FULL SUITE
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 02.16.2017
# 
# SUMMARY:
# IFS is a proof of concept application designed to perform 'cradle to grave' 
# parsing of draft or finalized hearing decision text to
# generate structured data about its content (findings, etc.) and quality,
# which then may be utilized to generate an INSIGHT Web App report page
# conveying that quality data to an end user adjudicator, decision writer,
# etc., and providing a series of helpful widgets, such as a field office
# SSO code lookup tool.
#
# IFS-HL is designed to interface with a C# Word Add-In.
#
# IFS-OAO is designed to interface with an ODAR-OESSI-DITI created web app.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has not
# yet been formally validated and whose documentation is not yet fully formed.
# =============================================================================

# Import modules:
import os
import os.path
import logging
import time
import ie as ie
import ie_common_calcs as iecc
import iq as iq
import rfcparser as rfcparser
import common_calcs as cc
import database_actions as ifsda
import umls_extract as umls_extract
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
inputdir = os.path.join(insightdir, "Input/Input")
processingdir = os.path.join(insightdir, "Input/Processing")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Define IFS-OAO extraction/analysis/report generation workflow function:
def runsuite_batch(input_dict, tgt_uid_colnm):
    """Runs INSIGHT script version tailored for batch processing,
	a task designed to facilitate production of data for OAO
	uses of INSIGHT on already-issued hearing decisions.
	
	Args:
		input_dict: {dictionary} A dictionary containing at least
			a target UID value (used to name the decision files that
			will be retrieved by this function)) but also potentially 
			other UID values associated with a decision observation.
		tgt_uid_colnm {str} The target UID column name that is used
			in runsuite_batch to select the appropriate decision text
			file by its file name (which consists of the UID value).
	Returns:
		A dictionary containing INSIGHT data.
	Raises:
		TypeError: Arguments passed are not appropriate type.
	"""
    try:

        # Retrieve decision text:
        tgt_uid_nm_val = input_dict[tgt_uid_colnm]
        tgt_uid_nm_val_fn = tgt_uid_nm_val.strip() + '.txt'
        decisionfiledir = cfg.batch_decisionfiles_dir
        with open(os.path.join(decisionfiledir, tgt_uid_nm_val_fn), 'r') as tgt_uid_nm_val_file:
            tgt_uid_nm_val_fileread = tgt_uid_nm_val_file.read()

            # Run INSIGHT modules:
            insight_dict = {}
            insight_dict = dict(insight_dict.items() + input_dict.items())

            # INSIGHT Extract:
            ie_dict, insight_text = ie.insightextract(tgt_uid_nm_val_fileread)
            insight_dict = dict(insight_dict.items() + ie_dict.items())

            # RFC Parsing:
            if insight_dict['rfc']:
                rfc_parsed_dictlist = []
                for subd in insight_dict['rfc'].values():
                    # Collect rfcparser-generated values:
                    rfcparser_resdict = rfcparser.rfcparser(subd['rfctxt'])
                    subd_parsed = dict(subd.items() + rfcparser_resdict.items())
                    rfcexlvl_parsed = iecc.rfcexlvlparser(subd_parsed)
                    subd_parsed['rfcexlvl_parsed'] = rfcexlvl_parsed
                    rfc_parsed_dictlist.append(subd_parsed)
                for i, subd in enumerate(rfc_parsed_dictlist):
                    insight_dict['rfc'][i] = subd

            # Circuit parsing from 'clnmadd':
            # OPENQ: Why not collect this within ie.py?
            insight_dict['circuit'] = iecc.circuitparser(insight_dict['clnmadd'])

            # Circuit parsing from 'ARCHWKUT.CLMT_ST':
            insight_dict['CIRCUIT_STRUCT'] = iecc.circuitparser_struct(insight_dict['CLMT_ST'])

            # Claimant age & PAI calculations:
            insight_dict['STRUCT_AGEREL_PAISTART'], insight_dict['STRUCT_AGEREL_PAISTART_SRC'], insight_dict[
                'paistart'] = cc.calc_struct_agerel_paistart(insight_dict)
            insight_dict['STRUCT_AGEREL_PAIEND'], insight_dict['STRUCT_AGEREL_PAIEND_SRC'], insight_dict[
                'paiend'] = cc.calc_struct_agerel_paiend(insight_dict)
            insight_dict['STRUCT_AGE_DID'] = cc.calc_struct_agerel_did(insight_dict)

            # Extract UMLS data from s2.s2txt values into a dict of dicts:
            claimtype_merged = 'U'
            if insight_dict['CLAIMDISP_STRUCT']:
                claimtype_merged = [subd['CLM_TYP'] for subd in insight_dict['CLAIMDISP_STRUCT']]
                claimtype_merged = [c for c in claimtype_merged if c != 'U']

            insight_dict['mdi'] = {}
            if insight_dict['s2']:
                umls_resdictlist = []
                for k, subd in insight_dict['s2'].iteritems():
                    umls_insight_dict = dict({'claimtype': claimtype_merged, 'paistart': insight_dict['paistart'],
                                              'paiend': insight_dict['paiend']}.items() + subd.items())
                    umls_obs_resdictlist = umls_extract.extract_umls_data_insight_tgt(umls_insight_dict, 's2txt')
                    if umls_obs_resdictlist:
                        for resd in umls_obs_resdictlist:
                            resd['S2_ORD_NUM'] = subd['ORD_NUM']
                            umls_resdictlist.append(resd)
                for i, subd in enumerate(umls_resdictlist):
                    subd['ORD_NUM'] = i
                    insight_dict['mdi'][i] = subd

            # INSIGHT Quality:
            iq_dict = iq.run(iq_input_dict=insight_dict, iq_decision_str=insight_text)
            insight_dict = dict(insight_dict.items() + iq_dict.items())

            # Remove input values EXCEPT for DOCU_CTL_ID and pre-processor-created
            # case entity values to prevent '_x,_y' duplication on merge action in batch.py:
            input_dict_keys_filtered = [k for k in input_dict.keys() if
                                        k not in ['DOCU_CTL_ID', 'CLAIMDISP_STRUCT', 'EXP']]
            insight_dict = {k: v for k, v in insight_dict.iteritems() if k not in input_dict_keys_filtered}

            return insight_dict

    except Exception:
        logger.exception('EXCEPTION')
        raise
