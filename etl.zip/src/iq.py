# INSIGHT HEARING DECISION QUALITY ANALYSIS ALGORITHM (INSIGHT Quality)
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 11.02.2016
#
# SUMMARY: 
# This script is designed to analyze the quality of individual
# hearing decision texts based on INSIGHT Extract data, existing
# structured data related to the claimant/claim at issue in the
# decision text, and the decisional text itself.
#
# INPUT: 
# (1) A dictionary containing INSIGHT Extract data for a single
# hearing decision text string; 
# (2) The hearing decision text string associated with the passed
# dictionary.)
#
# OUTPUT:
# A dictionary containing INSIGHT quality data for the passed hearing
# decision text string.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import sys
import re
import os.path
import logging
import ast
import numpy as np
from collections import defaultdict
from nltk import pos_tag
import bmi_revised as bmi
import iq_data_loader as iqdl
import iq_common_calcs as iqcc
import nlp_helper
import regex_strings as rs
import its_sklearn_classifier as its
import text_cleaner as tc
import database_actions as ifsda
import config as cfg
import date_helper as dh
import common_fx as cfx
import umls_analyzer as ua

# Import config_sec:
import config_sec as cfg_sec

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")
testdir = os.path.join(insightdir, "test/functional")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Function to ICD9 from UMLS Explorer results:
def gathericd9_v2(input_dict):
	try:
		allicd9 = []
		icd9_keys = [key for key in input_dict.keys() if '_ICD9' in key]
		if icd9_keys:
			for key in icd9_keys:
				icd9val = input_dict[key]
				# OPENQ/TODO: What ARE unknown ICD9 values? Are they even
				# presently generated? If not, modify that script to
				# output a 'U' value where no results are found in
				# 'ICD_V8':
				if icd9val != 'U':
					for res in icd9val.split('; '):
						allicd9.append(res)
		return allicd9
	except Exception:
		logger.exception('EXCEPTION')
		raise


# Function to retrieve all target values from
# target container (schema 2 compliant):
def gather_container_tgt(input_dict, tgt_key, tgt_nm, tgt_ord_num, tgt_ord_num_subnm, tgt_ord_num_subval):
	'''Gather target values from all tgt_key observations
	in an INSIGHT observation dictionary.

	Args:
		input_dict {dict}: An INSIGHT observation
			dict containing an 'mdi' key.
		tgt_key {str}: The INSIGHT observation dict
			key value to target.
		tgt_nm {str}: The INSIGHT observation dict
			key value to target within the tgt_key
			values.
		tgt_ord_num {str}: The target ORD_NUM value to
			use to filter results.  If 'U', will not
			apply filter.
		tgt_ord_num_subnm {str}: The target ORD_NUM sub-name
			to target using the value present in 'tgt_ord_nm', e.g.
			'S4_ORD_NUM'. If 'U', will not apply filter.
		tgt_ord_num_subval {int}: The target ORD_NUM sub-name
			value to target using the value present in 'tgt_ord_nm'.
			If 'U', will not apply filter.
	Returns:
		cui_list {list}: A list of unique 'CUI'
			values contained in the 'mdi'
			observations.
	Raises:
		N/A (returns empty list if exception).
	'''
	try:
		if tgt_ord_num == 'U':
			if tgt_ord_num_subnm == 'U':
				tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key].values()]
			else:
				tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key].values() if d[tgt_ord_num_subnm] == tgt_ord_num_subval]
		else:
			if tgt_ord_num_subnm == 'U':
				tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key].values() if d['ORD_NUM'] == tgt_ord_num]
			else:
				tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key].values() if d['ORD_NUM'] == tgt_ord_num and d[tgt_ord_num_subnm] == tgt_ord_num_subval]
		tgt_list = cfx.flatten_irreg(tgt_lol)
		tgt_list = list(tgt_list)
		tgt_list = list(set(tgt_list))
		return tgt_list
	except Exception:
		logger.exception('EXCEPTION')
		return []


# Function to retrieve
# CUI from UMLS Explorer/'mdi' results:
def gathercui_v2(input_dict, input_ord_num):
	'''Gather CUI from all 'mdi' observations
	in an INSIGHT observation dictionary for
	a given 'mdi.ORD_NUM' value.

	Args:
		input_dict {dict}: An INSIGHT observation
			dict containing an 'mdi' key.
		input_ord_num {int}: An 'mdi' observation
			'ORD_NUM' value that filters which
			CUI to return.
	Returns:
		cui_list {list}: A list of unique 'CUI'
			values contained in the 'mdi'
			observations.
	Raises:
		N/A (returns empty list if exception).
	'''
	try:
		cui_lol = [d['CUI'] for d in input_dict['mdi'].values() if d['ORD_NUM'] == input_ord_num]
		cui_list = cfx.flatten_irreg(cui_lol)
		cui_list = list(cui_list)
		cui_list = list(set(cui_list))
		return cui_list
	except Exception:
		logger.exception('EXCEPTION')
		return []


# (DEPRECATION WARNING 05102017 - See
# 'gathercui_v2()') Function to retrieve
# CUI from UMLS Explorer results:
def gathercui(input_dict):
	try:
		allcui = []
		cui_keys = [key for key in input_dict.keys() if '_CUI' in key]
		if cui_keys:
			for key in cui_keys:
				cuival = input_dict[key]
				# TIP: All retrieved values are strings.  _CUI values
				# can be either a single CUI (e.g. 'C0131313') or a
				# string representation of a list of CUI strings (e.g.
				# "['C2332322', 'C2332322']").
				if cuival not in ['U', 'P', 'E', '']:
					if '[' in cuival:
						cuival_list = ast.literal_eval(cuival)
						for cuistr in cuival_list:
							allcui.append(cuistr)
					else:
						allcui.append(cuival)
		return allcui
	except Exception:
		logger.exception('EXCEPTION')
		raise


# (DEPRECATION WARNING - 05.19.2017 - see below) Gather semantically related CUI:
# WARNING: As presently set up, you CANNOT reliably use 'get_related_cui'/CUI semantic relations
# in this flag; rather, you must use it as a preliminary measure, then manually filter the results.
# Why? Because get_related_cui() brought up results like 'abnormal EMG' (which goes to ANY muscle system)
# *and* 'abnormal EMG' is classified as a TYP 'Finding', so you can't really filter out there either.
# COULD try filtering on disease, but honestly, wouldn't you rather have MORE (many 'Finding' are good)
# rather than limit yourself?
# UPDATE: Results get better if you filter out ['Finding', 'Therapeutic or Preventive Procedure'], but
# still leaves undesirable CUIs for strings like 'C0031117' - _DISORDER_OF_PERIPHERAL_NERVOUS_SYSTEM_.
# Continue to refine UMLS semantic relation filtering as started in 'sandbox_01032017.ipynb', but for
# now you must use a whitelist.
# UPDATE: Other source of this issue may be in how you developed this semantic relation table.  Research
# updates to that (e.g. why does 'peripheral nervous disorder' come up for CTS?  Too broad!)
# UPDATE: See 'manual curation' parsing strategy in 'sandbox_01032017.ipynb'.
def get_related_cui(cui):
	'''Retrieve all semantically related CUIs (if any) from
	cui_semrel dataset.

	WARNING 03282017: At least some semantic relations contained here are NOT
	ideal for your desired uses of this dataset.  For example:
	'obesity' (C0028754) brings up a semrel of 'coronary artery disease' (C1956346)
	along with its more reasonable semrels such as 'corpulence'.  Use ONLY after
	manually checking the target's semrels for the time being.

	Argument:
		A string containing a single CUI.
	Returns:
		Empty list or list of 1+ semantically related CUIs
		as strings.]
	Raises:
		N/A (may legitimately be no results; no need to log
		such cases).
	'''
	# NEW (10.13.2016):
	try:
		cui_semrel_res = str(iqdl.cui_semrel_dict[cui])
		if cui_semrel_res in ['', '[]']:
			return []
		return cui_semrel_res
	except KeyError:
		return []



# (X) Step 1 'No SGA' Verdict + No Step 1 Body Text vs. PAI Annualized
# SGA Conflict Flag:
# TODO: Update to take advantage of structured date values to compensate
# for INSIGHT-derived absences.
def s1sgavsseqy_calc(row, decision_txt):
	'''Detects whether 's1sgaver' value of 'no period of SGA'
	is or is not consistent with SEQY annual earnings data.
	'''
	try:

		# If S1 SGA verdict of 'no SGA' present...
		if row['s1sgaver'] == '1':

			# If body text between S1 SGA finding and S2 SGA finding, don't parse.	Otherwise, if no body text or can't determine, parse:
			s1sgatxt = row['s1sgatxt']
			s2txt = row['s2txt']

			if s1sgatxt not in ['U', 'P', 'E', ''] and s2txt not in ['U', 'P', 'E', '']:

				s1sgabodytextver = "U"
				try:
					# Normalize decision text's spacing:
					decision = " ".join(decision_txt.split())

					# Determine if Step 1 finding has (substantive) body text:
					s1sgatxt = s1sgatxt.replace("'", "")
					s1sgatxt = re.escape(s1sgatxt)
					s1sgatxt = s1sgatxt.replace(" ", " ?")
					s2txt = s2txt.replace("'", "")
					s2txt = re.escape(s2txt)
					s2txt = s2txt.replace(" ", " ?")
					bodytxtpattern = s1sgatxt + ".*?" + s2txt
					bodytxtsearch = re.search(bodytxtpattern, decision, re.S)
					if bool(bodytxtsearch):
						bodytxtres = bodytxtsearch.group()
						bodytxtres = re.sub(s1sgatxt, "", bodytxtres)
						bodytxtres = re.sub(s2txt, "", bodytxtres)
						bodytxtres = re.sub(r"\s{0,6}See\s{0,6}Next\s{0,6}Page.{5,300}Page\s{0,6}\d{1,2}\s{0,6}of\s{0,6}\d{1,2}", " ", bodytxtres, flags=re.I)
						bodytxtres = " ".join(bodytxtres.split())
						bodytxtreswordct = re.findall("[A-Za-z]+", bodytxtres)
						if len(bodytxtreswordct) > 10:
							s1sgabodytextver = 1
				except Exception:
					return "E"


				if s1sgabodytextver != 1:

					# Check that you have what you need to calculate the PAI years (claimtype; AOD; DOF; DID; DLI)
					# TODO: Remove this code, create new 'functionalized' version of its parsing, and run it on all decisions to create 'pai' data column value.
					claimtype = row['claimtype_merged']
					claimtype_merged = [subd['CLM_TYP'] for subd in row['CLAIMDISP_STRUCT']]
					claimtype_merged = [c for c in claimtype_merged if c != 'U']
					if claimtype not in ['U', 'P', 'E', '']:

						aod = row['aod']
						dof = row['dof']
						did = row['did']
						dli = row['dli']

						# (1) If claimtype == *solely* a T16 adult, child, or adult/child claim, calculate PAI from DOF -> DID:
						# NOTE: For T16 Age 18 Redetermination claims, the PAI begins with the date the CL was found no longer disabled.  However, Age 18 claim decisions are immaterial for Step 1-related checks, as they DO NOT MAKE STEP 1 SGA FINDINGS! ("The first step is to apply the rule used for individuals who are engaging in substantial gainful activity (20 CFR 416.920(b)). However, this step is not used for redetermining disability at age 18 (20 CFR 416.987(b)).")
						# NOTE 2: For T2 CDB claims, the PAI begins with the later of the AOD *or* the year the CL attained age 18.
						if claimtype == 'T16 SSI' or claimtype == 'T16 SSI Child' or claimtype == 'T16 SSI Child+Adult':  # OPENQ: Do any other claim types have no AOD significance?

							if dof not in ['U', 'P', 'E', ''] and did not in ['U', 'P', 'E', '']:

								dofyear = 'U'
								didyear = 'U'
								aodyear = 'U'

								dofyearlist = re.findall(r'\d\d\d\d', dof)	# TIP: DOF will either be formatted as '##/##/####', '##/##/#### (claimtype)', or '##/##/#### (claimtype); ##/##/#### (claimtype); etc.'  Hence focus on year string.
								if dofyearlist:
									dofyear = int(min(list(set([int(item) for item in dofyearlist])))) # TIP: Retrieves the *earliest* year present in 'dof' as an INTEGER.

								# OPENQ/TODO: This presumes there will only be ONE DID value.
								if row['didsrc'] != '2':
									didyearsearch = re.search(r'\d\d\d\d', did)
									if bool(didyearsearch):
										didyear = int(didyearsearch.group())

								# Check if there's an AOD value present whose year is AFTER the DOF year (e.g. amended AODs).  If so, reassign 'dofyear' as the AOD's year:
								aod = row['aod']
								aodyearlist = re.findall(r'\d\d\d\d', aod)
								if aodyearlist:
									aodyear = max(list(set([int(item) for item in aodyearlist])))  # TIP: Retrieves latest year (necessary?)
									if int(dofyear) >= int(aodyear):
										pass
									elif int(aodyear) > int(dofyear):
										dofyear = int(aodyear)

								# If you have a dofyear and didyear, begin paiyearlist calculation:
								if dofyear != 'U' and didyear != 'U':
									dofyearexcluded = dofyear + 1
									didyearexcluded = didyear - 1

									paiyearlist = []
									if dofyearexcluded == didyearexcluded:	# TIP: This means there is a full, nonexcluded PAI year that's the same from each end, e.g. 2010 DOF, 2012 DID, 2011 same year result.
										paiyearlist.append(str(dofyearexcluded))
									else:
										paiyearct = didyearexcluded - dofyearexcluded  # TIP: This means there is at least 1 full, nonexcluded PAI year that is NOT the same at each end, e.g. 2009 DOF -> 2010, 2012 DID -> 2011.
										if paiyearct >= 1:
											while dofyearexcluded != didyear:
												paiyearlist.append(str(dofyearexcluded))
												dofyearexcluded += 1

									if paiyearlist:

										# Quickly attempt to ascertian via Step 2 finding whether 'blindness' is in play, thereby modifying what is 'SGA':
										blindnessinplay = 0

										# Gather All ICD 9 Entries From Individual MDI Values:
										allicd9 = gathericd9_v2(row)

										if len([item for item in allicd9 if item.startswith("369")]) >= 1:
											blindnessinplay = 1

										sga_blind_dict = {'2003': '1330', '1997': '1000', '1986': '650', '1987': '680', '1984': '580', '1985': '610', '1982': '500', '1983': '550', '1980': '417', '1981': '459', '1988': '700', '1989': '740', '2015': '1820', '2014': '1800', '2016': '1820', '2011': '1640', '2010': '1640', '2013': '1740', '2012': '1690', '2005': '1380', '1991': '810', '1990': '780', '1993': '880', '1992': '850', '1995': '940', '1994': '930', '1979': '375', '1978': '334', '1977': '240', '1976': '230', '1975': '200', '1996': '960', '2002': '1300', '1999': '1110', '2000': '1170', '2001': '1240', '2006': '1450', '2007': '1500', '2004': '1350', '1998': '1050', '2008': '1570', '2009': '1640'}
										sga_nonblind_dict = {'2003': '800', '1997': '500', '1986': '300', '1987': '300', '1984': '300', '1985': '300', '1982': '300', '1983': '300', '1980': '300', '1981': '300', '1988': '300', '1989': '300', '2015': '1090', '2014': '1070', '2016': '1130', '2011': '1000', '2010': '1000', '2013': '1040', '2012': '1010', '2005': '830', '1991': '500', '1990': '500', '1993': '500', '1992': '500', '1995': '500', '1994': '500', '1979': '280', '1978': '260', '1977': '240', '1976': '230', '1975': '200', '1996': '500', '2002': '780', '1999': '700', '2000': '700', '2001': '740', '2006': '860', '2007': '900', '2004': '810', '1998': '500', '2008': '940', '2009': '980'}

										# Check whether SEQY earnings for each year of the PAI are above the annualized SGA amount for that year:
										flagresults = []

										for year in paiyearlist:
											try:
												struct = row[year]
												if struct not in ['0', '']:
													struct = int(float(struct))
													# If blindness in play:
													if blindnessinplay == 1:
														if struct > int(sga_blind_dict[year]*12):
															flagresults.append(year)
													# If blindness NOT in play:
													else:
														if struct > int(sga_nonblind_dict[year]*12):
															flagresults.append(year)
											except KeyError:
												logger.exception('EXCEPTION')
												return "E"

										# If any such PAI year's SEQY earnings ARE above annualized SGA, return a list of those years as the flag result (you can reassemble how much CL earned and what the annualized SGA amount is in the report generation tool):

										if flagresults:
											return str(flagresults)
										else:
											return "0"

									# No year values in 'paiyearlist'; return 'P'.
									else:

										return "P"

								# No DOF and DID year values; return 'P'.
								else:
									return "P"
							# No DOF and/or DID; return 'P'.
							else:

								return "P"


						elif claimtype == 'T2 DIB':


							if (dof not in ['U', 'P', 'E', ''] or aod not in ['U', 'P', 'E', '']) and did not in ['U', 'P', 'E', ''] and dli not in ['U', 'P', 'E', '']:


								aodyear = 'U'
								dofyear = 'U'
								didyear = 'U'
								dliyear = 'U'

								paididyearchecked = 'U'
								paididmonthchecked = 'U'
								paididdaychecked = 'U'
								paidlidaychecked = 'U'
								paidlimonthchecked = 'U'
								paidliyearchecked = 'U'

								remotedliverdictchecked = "0"

								paididyearsearch1 = re.search("\d {0,2}\d {0,2}\d {0,2}\d", did)
								if paididyearsearch1:
									paididyear1 = paididyearsearch1.group()
									paididyear1 = "".join(paididyear1.split())
									paididyearchecked = int(paididyear1)
								paididmonthsearch1 = re.search("\A\d\d", did)
								if paididmonthsearch1:
									paididmonth1 = paididmonthsearch1.group()
									paididmonthchecked = int(paididmonth1)
								paididdaysearch1 = re.search("/\d\d/", did)
								if paididdaysearch1:
									paididday1 = paididdaysearch1.group()
									paididday2 = re.sub("\A/", "", paididday1)
									paididday3 = re.sub("/\Z", "", paididday2)
									paididdaychecked = int(paididday3)

								paidliyearsearch1 = re.search("\d {0,2}\d {0,2}\d {0,2}\d", dli)
								if paidliyearsearch1:
									paidliyear1 = paidliyearsearch1.group()
									paidliyear1 = "".join(paidliyear1.split())
									paidliyearchecked = int(paidliyear1)
								paidlimonthsearch1 = re.search("\A\d\d", dli)
								if paidlimonthsearch1:
									paidlimonth1 = paidlimonthsearch1.group()
									paidlimonthchecked = int(paidlimonth1)
								paidlidaysearch1 = re.search("/\d\d/", dli)
								if paidlidaysearch1:
									paidliday1 = paidlidaysearch1.group()
									paidliday2 = re.sub("\A/", "", paidliday1)
									paidliday3 = re.sub("/\Z", "", paidliday2)
									paidlidaychecked = int(paidliday3)

								# Comparing DID to DLI:
								if (paididyearchecked != "U") and (paidliyearchecked != "U"):
									if paidliyearchecked < paididyearchecked:
										remotedliverdictchecked = "1"
									elif paidliyearchecked > paididyearchecked:
										remotedliverdictchecked = "0"
									elif paidliyearchecked == paididyearchecked:
										if (paididmonthchecked != "U") and (paidlimonthchecked != "U"):
											if paidlimonthchecked < paididmonthchecked:
												remotedliverdictchecked = "1"
											elif paidlimonthchecked > paididmonthchecked:
												remotedliverdictchecked = "0"
											elif paidlimonthchecked == paididmonthchecked:
												if (paididdaychecked != "U") and (paidlidaychecked != "U"):
													if paidlidaychecked < paididdaychecked:
														remotedliverdictchecked = "1"
													elif paidlidaychecked > paididdaychecked:
														remotedliverdictchecked = "0"

								# If remote DLI, use that year to calculate PAI:
								if remotedliverdictchecked == "1":
									didyear = int(paidliyearchecked)
								else:
									didyear = int(paididyearchecked)


								# If AOD before DOF, use AOD; if AOD after DOF, use AOD.  Basically use AOD, then use DOF as backup:

								if aod not in ['U', 'P', 'E', '']:
									aodyearsearch = re.search(r"\d\d\d\d", aod)
									if bool(aodyearsearch):
										dofyear = int(aodyearsearch.group())

								if dofyear == 'U':
									if dof not in ['U', 'P', 'E', '']:
										yearsearch = re.search(r"\d\d\d\d", dof)
										if bool(yearsearch):
											dofyear = int(yearsearch.group())


								# 3) Use rest of script below to calculate PAI and compare earnings.
								if dofyear != 'U' and didyear != 'U':



									dofyearexcluded = dofyear + 1
									didyearexcluded = didyear - 1

									paiyearlist = []
									if dofyearexcluded == didyearexcluded:	# TIP: This means there is a full, nonexcluded PAI year that's the same from each end, e.g. 2010 DOF, 2012 DID, 2011 same year result.
										paiyearlist.append(str(dofyearexcluded))
									else:
										paiyearct = didyearexcluded - dofyearexcluded  # TIP: This means there is at least 1 full, nonexcluded PAI year that is NOT the same at each end, e.g. 2009 DOF -> 2010, 2012 DID -> 2011.
										if paiyearct >= 1:
											while dofyearexcluded != didyear:
												paiyearlist.append(str(dofyearexcluded))
												dofyearexcluded += 1

									if paiyearlist:


										# Quickly attempt to ascertian via Step 2 finding whether 'blindness' is in play, thereby modifying what is 'SGA':
										blindnessinplay = 0

										# Gather All ICD 9 Entries From Individual MDI Values:
										allicd9 = gathericd9_v2(row)

										if len([item for item in allicd9 if item.startswith("369")]) >= 1:
											blindnessinplay = 1

										sga_blind_dict = {'2003': '1330', '1997': '1000', '1986': '650', '1987': '680', '1984': '580', '1985': '610', '1982': '500', '1983': '550', '1980': '417', '1981': '459', '1988': '700', '1989': '740', '2015': '1820', '2014': '1800', '2016': '1820', '2011': '1640', '2010': '1640', '2013': '1740', '2012': '1690', '2005': '1380', '1991': '810', '1990': '780', '1993': '880', '1992': '850', '1995': '940', '1994': '930', '1979': '375', '1978': '334', '1977': '240', '1976': '230', '1975': '200', '1996': '960', '2002': '1300', '1999': '1110', '2000': '1170', '2001': '1240', '2006': '1450', '2007': '1500', '2004': '1350', '1998': '1050', '2008': '1570', '2009': '1640'}
										sga_nonblind_dict = {'2003': '800', '1997': '500', '1986': '300', '1987': '300', '1984': '300', '1985': '300', '1982': '300', '1983': '300', '1980': '300', '1981': '300', '1988': '300', '1989': '300', '2015': '1090', '2014': '1070', '2016': '1130', '2011': '1000', '2010': '1000', '2013': '1040', '2012': '1010', '2005': '830', '1991': '500', '1990': '500', '1993': '500', '1992': '500', '1995': '500', '1994': '500', '1979': '280', '1978': '260', '1977': '240', '1976': '230', '1975': '200', '1996': '500', '2002': '780', '1999': '700', '2000': '700', '2001': '740', '2006': '860', '2007': '900', '2004': '810', '1998': '500', '2008': '940', '2009': '980'}

										# Check whether SEQY earnings for each year of the PAI are above the annualized SGA amount for that year:
										flagresults = []
										for year in paiyearlist:
											try:
												struct = row[year]
												if struct not in ['0', '']:
													struct = int(float(struct))


													# If blindness in play:
													if blindnessinplay == 1:
														if struct > int(int(sga_blind_dict[year])*12):
															flagresults.append(year)
													# If blindness NOT in play:
													else:
														if struct > int(int(sga_nonblind_dict[year])*12):
															flagresults.append(year)
											except KeyError:
												pass

										# If any such PAI year's SEQY earnings ARE above annualized SGA, return a list of those years as the flag result (you can reassemble how much CL earned and what the annualized SGA amount is in the report generation tool):

										if flagresults:
											return str(flagresults)
										else:
											return "0"

									# No year values in 'paiyearlist'; return 'P'.
									else:

										return "P"

								# No DOF and DID year values; return 'P'.
								else:

									return "P"
							# Don't have the data values to parse this; return 'P'.
							else:
								"T2 REQUIRED VALUES MISSING:"
								return "P"


						# Claim type is not solely T16, not solely T2 (probably concurrent) - parse from ideally the AOD, or the DOF as a backup:
						else:

							if (dof not in ['U', 'P', 'E', ''] or aod not in ['U', 'P', 'E', '']) and did not in ['U', 'P', 'E', '']:	# TIP: Only *need* the DOF or the AOD, ideally AOD; but don't want this to fail if the AOD is missing (high miss rate I believe).

								aodyear = 'U'
								dofyear = 'U'
								didyear = 'U'

								dofyearlist = re.findall(r'\d\d\d\d', dof)
								if dofyearlist:
									dofyear = int(min(list(set([int(item) for item in dofyearlist]))))	# TIP: Retrieves the *earliest* year present in 'dof' as an INTEGER.

								didyearsearch = re.search(r'\d\d\d\d', did)
								if bool(didyearsearch):
									didyear = int(didyearsearch.group())

								# Not REQUIRED (low risk of false flag), but see if you can extract the AOD; if so, see if its year is AFTER the DOF year (think amended AODs).	 If so, use the AOD year.
								aod = row['aod']
								aodyearlist = re.findall(r'\d\d\d\d', aod)
								if aodyearlist:
									aodyear = max(list(set([int(item) for item in aodyearlist])))
									if int(dofyear) >= int(aodyear):
										pass
									elif int(aodyear) > int(dofyear):
										dofyear = int(aodyear)


								# If you have a 'dofyear' and didyear, begin paiyearlist calculation:
								if dofyear != 'U' and didyear != 'U':
									dofyearexcluded = dofyear + 1
									didyearexcluded = didyear - 1

									paiyearlist = []
									if dofyearexcluded == didyearexcluded:	# TIP: This means there is a full, nonexcluded PAI year that's the same from each end, e.g. 2010 DOF, 2012 DID, 2011 same year result.
										paiyearlist.append(str(dofyearexcluded))
									else:
										paiyearct = didyearexcluded - dofyearexcluded  # TIP: This means there is at least 1 full, nonexcluded PAI year that is NOT the same at each end, e.g. 2009 DOF -> 2010, 2012 DID -> 2011.
										if paiyearct >= 1:
											while dofyearexcluded != didyear:
												paiyearlist.append(str(dofyearexcluded))
												dofyearexcluded += 1

									if paiyearlist:

										# Quickly attempt to ascertian via Step 2 finding whether 'blindness' is in play, thereby modifying what is 'SGA':
										blindnessinplay = 0

										# Gather All ICD 9 Entries From Individual MDI Values:
										allicd9 = gathericd9_v2(row)

										if len([item for item in allicd9 if item.startswith("369")]) >= 1:
											blindnessinplay = 1

										sga_blind_dict = {'2003': '1330', '1997': '1000', '1986': '650', '1987': '680', '1984': '580', '1985': '610', '1982': '500', '1983': '550', '1980': '417', '1981': '459', '1988': '700', '1989': '740', '2015': '1820', '2014': '1800', '2016': '1820', '2011': '1640', '2010': '1640', '2013': '1740', '2012': '1690', '2005': '1380', '1991': '810', '1990': '780', '1993': '880', '1992': '850', '1995': '940', '1994': '930', '1979': '375', '1978': '334', '1977': '240', '1976': '230', '1975': '200', '1996': '960', '2002': '1300', '1999': '1110', '2000': '1170', '2001': '1240', '2006': '1450', '2007': '1500', '2004': '1350', '1998': '1050', '2008': '1570', '2009': '1640'}
										sga_nonblind_dict = {'2003': '800', '1997': '500', '1986': '300', '1987': '300', '1984': '300', '1985': '300', '1982': '300', '1983': '300', '1980': '300', '1981': '300', '1988': '300', '1989': '300', '2015': '1090', '2014': '1070', '2016': '1130', '2011': '1000', '2010': '1000', '2013': '1040', '2012': '1010', '2005': '830', '1991': '500', '1990': '500', '1993': '500', '1992': '500', '1995': '500', '1994': '500', '1979': '280', '1978': '260', '1977': '240', '1976': '230', '1975': '200', '1996': '500', '2002': '780', '1999': '700', '2000': '700', '2001': '740', '2006': '860', '2007': '900', '2004': '810', '1998': '500', '2008': '940', '2009': '980'}

										# Check whether SEQY earnings for each year of the PAI are above the annualized SGA amount for that year:
										flagresults = []

										for year in paiyearlist:
											try:
												struct = row[year]
												if struct not in ['0', '']:
													struct = int(float(struct))
													# If blindness in play:
													if blindnessinplay == 1:
														if struct > int(sga_blind_dict[year]*12):
															flagresults.append(year)
													# If blindness NOT in play:
													else:
														if struct > int(sga_nonblind_dict[year]*12):
															flagresults.append(year)
											except KeyError:
												pass

										# If any such PAI year's SEQY earnings ARE above annualized SGA, return a list of those years as the flag result (you can reassemble how much CL earned and what the annualized SGA amount is in the report generation tool):

										if flagresults:
											return str(flagresults)
										else:
											return "0"

									# No year values in 'paiyearlist'; return 'P'.
									else:

										return "P"

								# No DOF and DID year values; return 'P':
								else:

									return "P"
							# Required values missing; return 'P':
							else:
								return "P"
					# No claimtype is present; return 'P':
					else:
						return "P"
				# Body rationale text IS present; return 'P':
				else:
					return "P"
			# Required value is missing; return 'P':
			else:
				return "P"
		# No s1sgaver value of '1' (i.e. no SGA verdict); return 'P'.
		else:
			return "P"
	# Broadest scope exception occurred; return 'E':
	except Exception:
		logger.exception('EXCEPTION')
		return "E1"


# (X) Step 1 'SGA' Verdict But No Step 1 Body Text Flag:
# DEVELOPMENT: Certain 'sgatxt' values go to the SECOND portion of a finding,
# so this flag will erroneously 'miss' where the Step 1 rationale begins.
# You'll need to refactor IE to capture both portions of the finding, then
# if both captured, search the area between the two results.
def s1sgaver234nortl_ver_calc(row, decision_txt):
	'''Detects whether a Step 1 SGA finding that the claimant
	has enegaged in SGA is or is not supported by rationale body text.
	'''
	try:

		# If 's1sgaver' does NOT indicate some period of SGA found, return 'P'; else, proceed:
		# TIP: Remember that
		if row['s1sgaver'] not in ['2', '3', '4']:
			return 'P'
		else:

			# Determine whether Step 1 body text rationale is or isn't present:
			s1sgatxt = row['s1sgatxt']
			s2txt = row['s2txt']

			if s1sgatxt in ['U', 'P', 'E', ''] or s2txt in ['U', 'P', 'E', '']:
				return 'P'
			else:
				s1sgabodytextver = 'U'
				decision = " ".join(decision_txt.split())
				decision = decision.lower()
				s1sgatxt = s1sgatxt.replace("'", "")
				s1sgatxt = re.escape(s1sgatxt)
				s1sgatxt = s1sgatxt.replace(" ", " ?")
				s2txt = s2txt.replace("'", "")
				s2txt = re.escape(s2txt)
				s2txt = s2txt.replace(" ", " ?")
				bodytxtpattern = s1sgatxt + ".*?" + s2txt
				bodytxtsearch = re.search(bodytxtpattern, decision, re.S)
				if bool(bodytxtsearch):
					bodytxtres = bodytxtsearch.group()
					bodytxtres = re.sub(s1sgatxt, "", bodytxtres)
					bodytxtres = re.sub(s2txt, "", bodytxtres)
					bodytxtres = re.sub(r"\s{0,6}See\s{0,6}Next\s{0,6}Page.{5,300}Page\s{0,6}\d{1,2}\s{0,6}of\s{0,6}\d{1,2}", " ", bodytxtres)
					bodytxtres = " ".join(bodytxtres.split())
					bodytxtreswordct = re.findall("[A-Za-z]+", bodytxtres)
					if len(bodytxtreswordct) > 10:
						s1sgabodytextver = 1

					if s1sgabodytextver != 1:
						return '1'
					else:
						return '0'
				else:
					return 'P'
	except Exception:
		logger.exception('EXCEPTION')
		return "E"


# (X) Step 2 'SX-as-MDI' and 'Uncertain' Language Flags:
# TODO: Revise these parsers to take advantage of ULMS type SYMPTOM for
#  's2txtsxver' types like IDEA OR CONCEPT (possible) and QUALITATIVE
# CONCEPT (suspected) for 's2txtuncertain' PLUS a whitelist of type
#  FINDINGS such as 'history of'.
def s2txtquality_calc(input_dict):
	'''Checks for 'symptom-as-MDI' and 'uncertain' language
	quality issues in Step 2 finding heading text.
	'''
	try:
		if not input_dict['s2']:
			return 'U', [], 'U', []

		flag_s2txtsxasmdi_resdictlist = []
		flag_s2txtuncertain_resdictlist = []
		for k,v in input_dict['s2'].iteritems():

			flag_s2txtsxver = 'U'
			flag_s2txtuncertainver = 'U'
			flag_s2txtsxval = []
			flag_s2txtuncertainval = []

			# PREFACE (b) Get s2ver, s2txt values:
			s2ver = v['s2ver']
			s2versrc = v['s2versrc']
			s2txt = v['s2txt']
			s2txtsrc = v['s2txtsrc']

			# (x) If s2ver != 1 or 2 (i.e. a finding the CL has MDIs, either severe or non-severe), then logically there's no MDI language to parse; return Ps:
			# (x) If s2txt == ['U', 'P', 'E', ''], then logically there's no MDI language to parse; return Ps:
			if s2ver not in ['1', '2'] or s2txt in ['U', 'P', 'E', '']:
				flag_s2txtsxasmdi_resdictlist.append({'nm':'flag_s2txtsxasmdi_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				flag_s2txtuncertain_resdictlist.append({'nm':'flag_s2txtuncertain_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			# (x) Else, then we logically must have an 'MDI' Step 2 finding AND Step 2 finding text to parse; proceed:
			else:

				# Clean s2txt:
				s2txt = s2txt.lower()
				s2txt = " ".join(s2txt.split())

				# If FIT-sourced s2txt, clean using s2txt_cleaner:
				if s2txtsrc == '0':
					s2txt = nlp_helper.s2txt_cleaner_fit(s2txt)
				# Else more fuzzily remove any non-MDI FIT-like
				# program/generic language (TIP: Including inapplicable
				# Step 2 FIT language options in case they slip through
				# via erroneous classification):
				else:
					s2txt = nlp_helper.s2txt_cleaner_nonfit(s2txt)

				# (3) Remove FIT-like/programmatic language not related to MDIs or SXs:
				# OPENQ/TODO: Check whether these 'nonlist' entities adequately remove things like CFR references.	If so, fine.  But if not, you have pretty decent newly reviewed CFR removal scripts in the latest version of RFC LoL/FA Parser you should move here.
				for item in iqdl.nonlist:
					s2txt = re.sub(item, " ", s2txt, flags=re.I)
				s2txt = " ".join(s2txt.split())

				# (4) Split the text into SS's using highly reliable splitting rules:
				# TODO: Overlaps with splitting conducted in rfcparser.py; take best practices from there and consider functionalizing if overlap present.

				# (4)(a) SPLIT by full sentences:
				s2txtsplit1 = nlp_helper.sentence_splitter(s2txt)

				# Define splitting function that optionally adds split target back
				# to resulting split strings (except for last string):
				# TODO: Add to nlp_helper.
				def ss_split(input_list, split_tgt, keep_split_tgt):
					res_list = []
					for ss in input_list:
						input_split = re.split(split_tgt, ss)
						if keep_split_tgt is False:
							for res in input_split:
								res_list.append(res)
						else:
							if len(input_split) == 0:
								res_list.append(input_split[0])
							else:
								split_ct = 0
								while split_ct != (len(input_split) - 1):
									input_split_plus_delim = input_split[split_ct] + str(split_tgt)
									res_list.append(input_split_plus_delim)
									split_ct += 1
								res_list.append(input_split[-1])
					return res_list

				# (4)(b) SPLIT by colons:
				s2txtsplit2 = ss_split(s2txtsplit1, r": ", True)

				# (4)(c) SPLIT by semicolons:
				s2txtsplit3 = ss_split(s2txtsplit2, r"; ", True)

				# (4)(d) SPLIT by 'never-part-of-list' conjunction terms (NOTE: These conjunction were selected after study):
				# TIP: 's2txtsplit4' represents the final SS splits containing unaltered SS text.  Pulling from this SS list when storing SS's deemed to contain SX/UNCERT language.
				s2txtsplit4 = ss_split(s2txtsplit3, r"\bbut\b|\byet\b|, ?while(?= \w+)|, ?however(?= \w+)|, ?whereas(?= \w+)|, ?except(?= \w+)|, ?with ?the ?exception", True)

				# (5) Complete categorical substitutions/deletions for each SS:

				# (5)(a) Substitute all 'diseaselist' entries for 'MDI_ENT' (OPTIONAL: Above could be model code for new 'individualdiseaseslist' parsing - see S2_QUALITY_PARSER_12292015.py):
				s2txtsplit5 = []
				for ss in s2txtsplit4:
					newss = ss
					for diseaseentry in iqdl.diseaselist:
							if bool(re.search(diseaseentry, newss, re.I)):
								newss = re.sub(diseaseentry, " MDI_ENT ", newss, flags=re.I)
					newss = " ".join(newss.split())
					s2txtsplit5.append(newss)

				# (5)(b) Substitute all 'symptom' phrases for 'SX_ENT':
				# TODO: DEBUG THIS.  ESSENTIALLY THE ISSUE IS THAT YOU CORRECTED
				# FOR INSTANCES WHERE 2 SYMPTOM ITEMS IN A SS BY APPENDING INDIVIDUAL
				# SX WORDS STRAIGHT TO SX_ENT_BY_SS.  BUT THAT CREATED FAULTS FOR 1 SX
				# INSTANCES.  YOU NEED TO FIGURE OUT HOW TO GET THIS TO WORK IN BOTH 1 AND
				# 2 SX SS CASES.
				s2txtsplit6 = []
				sx_ent_by_ss = []
				for ss in s2txtsplit5:
					sxent_reslist = []
					for item in iqdl.sxlist:
						sxent_finditer = re.finditer(item, ss, re.I)
						for item in sxent_finditer:
							sxent_reslist.append(item.group())
							ss = re.sub(item.group(), " SX_ENT ", ss, count=1)
					if len(sxent_reslist) == 1:
						sx_ent_by_ss.append(sxent_reslist)
					else:
						sx_ent_by_ss.append([", ".join(sxent_reslist)])
					ss = " ".join(ss.split())
					s2txtsplit6.append(ss)

				# (5)(c) Substitute all 'uncertain' phrases for 'UNCERT_ENT':
				s2txtsplit7 = []
				uncert_ent_by_ss_sx = []
				for ss in s2txtsplit6:
					uncertainent_reslist = []
					for item in iqdl.uncertainlist:
						uncertainent_finditer = re.finditer(item, ss, re.I)
						for item in uncertainent_finditer:
							uncertainent_reslist.append(item.group())
							ss = re.sub(item.group(), " UNCERT_ENT ", ss, count=1)
					if len(uncertainent_reslist) == 1:
						uncert_ent_by_ss_sx.append(uncertainent_reslist)
					else:
						uncert_ent_by_ss_sx.append([", ".join(uncertainent_reslist)])
					ss = " ".join(ss.split())
					s2txtsplit7.append(ss)

				s2txtsplit7_uncert = []
				uncert_ent_by_ss = []
				for ss in s2txtsplit6:
					uncertainent_reslist = []
					for item in iqdl.uncertainlist:
						uncertainent_finditer = re.finditer(item, ss, re.I)
						for item in uncertainent_finditer:
							uncertainent_reslist.append(item.group())
							ss = re.sub(item.group(), " UNCERT_ENT ", ss, count=1)
					if len(uncertainent_reslist) == 1:
						uncert_ent_by_ss.append(uncertainent_reslist)
					else:
						uncert_ent_by_ss.append([", ".join(uncertainent_reslist)])
					ss = " ".join(ss.split())
					s2txtsplit7_uncert.append(ss)

				# (5)(d) Substitute all 'associative' phrases for 'ASSOC_ENT':
				s2txtsplit8 = []
				for ss in s2txtsplit7:
					for item in iqdl.assocphraselist:
						ss = re.sub(item, " ASSOC_ENT ", ss, flags=re.I)
					ss = " ".join(ss.split())
					s2txtsplit8.append(ss)

				s2txtsplit8_uncertain = []
				for ss in s2txtsplit7_uncert:
					for item in iqdl.assocphraselist2:
						ss = re.sub(item, " ASSOC_ENT ", ss, flags=re.I)
					ss = " ".join(ss.split())
					s2txtsplit8_uncertain.append(ss)

				# (6) Perform final deletions (now that you've completed critical substitutions from the unmodified text):

				# (6)(a) Delete all 'body system' phrases:
				s2txtsplit9 = []
				for ss in s2txtsplit8:
					for item in iqdl.bodysystemlist:
						ss = re.sub(item, " ", ss, flags=re.I)
					ss = " ".join(ss.split())
					s2txtsplit9.append(ss)

				s2txtsplit9_uncertain = []
				for ss in s2txtsplit8_uncertain:
					for item in iqdl.bodysystemlist:
						ss = re.sub(item, " ", ss, flags=re.I)
					ss = " ".join(ss.split())
					s2txtsplit9_uncertain.append(ss)


				# (6)(b)  Delete all parentheticals/bracket clauses that do not contain any 'MDI_ENT', 'SX_ENT', and 'ASSOC_ENT':
				s2txtsplit10 = []
				for ss in s2txtsplit9:

					allenclosed = []
					parenfindall = re.findall(r"\(.*?\)", ss)
					if parenfindall:
						for item in parenfindall:
							allenclosed.append(item)
					bracketfindall = re.findall(r"\[.*?\]", ss)
					if bracketfindall:
						for item in bracketfindall:
							allenclosed.append(item)

					for res in allenclosed:
						if not any(x for x in ["MDI_ENT", "SX_ENT", "ASSOC_ENT"] if x in res):
							ss = ss.replace(res, "", 1)

					# Now remove all remaining parenthetical/bracket characters (TIP: Regardless of whether the clause/its words were or weren't removed, you don't need these characters):
					ss = ss.replace("(", " ")
					ss = ss.replace(")", " ")
					ss = ss.replace("[", " ")
					ss = ss.replace("]", " ")
					ss = " ".join(ss.split())
					s2txtsplit10.append(ss)

				s2txtsplit10_uncertain = []
				for ss in s2txtsplit9_uncertain:

					allenclosed = []
					parenfindall = re.findall(r"\(.*?\)", ss)
					if parenfindall:
						for item in parenfindall:
							allenclosed.append(item)
					bracketfindall = re.findall(r"\[.*?\]", ss)
					if bracketfindall:
						for item in bracketfindall:
							allenclosed.append(item)

					for res in allenclosed:
						if not any(x for x in ["MDI_ENT", "SX_ENT", "ASSOC_ENT"] if x in res):
							ss = ss.replace(res, "", 1)

					# Now remove all remaining parenthetical/bracket characters (TIP: Regardless of whether the clause/its words were or weren't removed, you don't need these characters):
					ss = ss.replace("(", " ")
					ss = ss.replace(")", " ")
					ss = ss.replace("[", " ")
					ss = ss.replace("]", " ")
					ss = " ".join(ss.split())
					s2txtsplit10_uncertain.append(ss)

				# (7) Now parse each SS for SX language:

				# (7)(b) Begin parsing loop:
				ss_sx_ct = 0  # TIP: Used to track which SS we're talking about.  TODO: Deprecate in favor of 'enumerate' calls.
				ss_uncertain_ct = 0	 # TIP: Used to track which SS we're talking about.	 TODO: Deprecate in favor of 'enumerate' calls.
				try:

					# (7)(b)(1): SX_ENT PARSING:
					for ss in s2txtsplit10:
						ssjoined = "".join(ss)	# TIP: Used in several locations below.
						ss = ss.split()
						sx_ent_ct = len([token for token in ss if token == 'SX_ENT'])
						mdi_ent_ct = len([token for token in ss if token == 'MDI_ENT'])
						assoc_ent_ct = len([token for token in ss if token == 'ASSOC_ENT'])
						uncert_ent_ct = len([token for token in ss if token == 'UNCERT_ENT'])

						# (7)(b)(1) SX_ENT PARSING:

						# If 0 SX_ENT, skip this SS:
						if sx_ent_ct == 0:
							ss_sx_ct += 1

						# Elif 1 SX_ENT, continue:
						elif sx_ent_ct == 1:

							# If 0 MDI_ENT, continue:
							if mdi_ent_ct == 0:
								# If 0 ASSOC_ENT, continue:
								if assoc_ent_ct == 0:
									# If the 1 SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.	 Do not flag such cases as symptom language:
									sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
									if len(sx_ent_indices) == 1:
										if int(sx_ent_indices[0]) == (len(ss) - 1):
											flag_s2txtsxver = "1"
											res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
											flag_s2txtsxval.append(res)
											ss_sx_ct += 1
										else:
											indofwordaftersxent = int(sx_ent_indices[0]) + 1
											if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
												flag_s2txtsxver = "1"
												try:
													res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
													flag_s2txtsxval.append(res)
													ss_sx_ct += 1
												except Exception:
													pass
											else:
												ss_sx_ct += 1
									else:
										ss_sx_ct += 1

								# Else if 1+ ASSOC_ENT, then via abductive reasoning, my educated guess is that the 1+ ASSOC_ENT likely do relate to the SX_ENT (as I can't say that it relates to any untagged words present, which may just be filler words or a longer statement of the SX).
								# OPENQ: If the pattern was "SX_ENT + untagged_word + untagged_word + "," + CC + untagged_word + ASSOC_ENT"
								else:
									ss_sx_ct += 1

							# Else if 1+ MDI_ENT, continue:
							else:
								# If 0 ASSOC_ENT, proceed (RATIONALE: Since you don't perform 'concept' relational checks (e.g. 'DDD, back pain' are related and arguably make 'back pain' OK), if there are 0 ASSOC_ENT connecting the MDI to the SX, what does it matter if both are present?)
								if assoc_ent_ct == 0:
									# If the 1 SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.	 Do not flag such cases as symptom language:
									sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
									if len(sx_ent_indices) == 1:
										if int(sx_ent_indices[0]) == (len(ss) - 1):
											flag_s2txtsxver = "1"
											try:
												res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
												flag_s2txtsxval.append(res)
												ss_sx_ct += 1
											except Exception:
												pass
										else:
											indofwordaftersxent = int(sx_ent_indices[0]) + 1
											if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
												flag_s2txtsxver = "1"
												try:
													res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
													flag_s2txtsxval.append(res)
													ss_sx_ct += 1
												except Exception:
													pass
											else:
												ss_sx_ct += 1
									else:
										ss_sx_ct += 1

								# If 1+ ASSOC_ENT, then you have exactly 1 SX_ENT, 1+ MDI_ENT, and 1+ ASSOC_ENT.  Begin parsing:
								else:

									# (a) Determine if all the ASSOC_ENT are before or after the SX_ENT, then parse accordingly (if both before AND after, you can't parse):
									assoc_ent_indexlist = [i for i, token in enumerate(ss) if token == 'ASSOC_ENT']

									# (a)(1) If ALL ASSOC_ENT *follow* the SX_ENT, parse:
									if all(ss.index('SX_ENT') < item for item in assoc_ent_indexlist):

										# If SX_ENT is followed by a ',' and an MDI_ENT before ANY ASSOC_ENT, you can be reasonably confident that ASSOC_ENT isn't related to the SX_ENT:
										ssregex1 = re.search(r"SX_ENT(?:(?!ASSOC_ENT).)*?,(?:(?!ASSOC_ENT).)*?MDI_ENT", ssjoined)
										if bool(ssregex1):
											# If the 1 SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.	 Do not flag such cases as symptom language:
											sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
											if len(sx_ent_indices) == 1:
												if int(sx_ent_indices[0]) == (len(ss) - 1):
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
													except Exception:
														pass
												else:
													indofwordaftersxent = int(sx_ent_indices[0]) + 1
													if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
														flag_s2txtsxver = "1"
														try:
															res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
															flag_s2txtsxval.append(res)
															ss_sx_ct += 1
														except Exception:
															pass
													else:
														ss_sx_ct += 1
											else:
												ss_sx_ct += 1
										else:
											ss_sx_ct += 1

									else:

										# (a)(2) If ALL ASSOC_ENT *precede* the SX_ENT, parse:
										if all(ss.index('SX_ENT') > item for item in assoc_ent_indexlist):

											# If SX_ENT is preceded by an MDI_ENT with *no* intervening ASSOC_ENT, you can be reasonably confident that the ASSOC_ENT isn't related to the SX_ENT:
											ssregex2 = re.search(r"MDI_ENT(?:(?!MDI_ENT).)*?SX_ENT", ssjoined)
											if bool(ssregex2):
												ssgroup1 = ssregex2.group()
												if "ASSOC_ENT" not in ssgroup1:
													# If the 1 SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.	 Do not flag such cases as symptom language:
													sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
													if len(sx_ent_indices) == 1:
														if int(sx_ent_indices[0]) == (len(ss) - 1):
															flag_s2txtsxver = "1"
															try:
																res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
																flag_s2txtsxval.append(res)
																ss_sx_ct += 1
															except Exception:
																pass
														else:
															indofwordaftersxent = int(sx_ent_indices[0]) + 1
															if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
																flag_s2txtsxver = "1"
																try:
																	res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
																	flag_s2txtsxval.append(res)
																	ss_sx_ct += 1
																except Exception:
																	pass
															else:
																ss_sx_ct += 1
													else:
														ss_sx_ct += 1
												else:
													ss_sx_ct += 1
											else:
												ss_sx_ct += 1

										# (a)(3) Else, because ASSOC_ENT logically must be before AND after SX_ENT, skip this SS:
										else:
											ss_sx_ct += 1


						# Elif > 1 SX_ENT, basically the ASSOC_ENT parsing rules change, continue:
						else:

							# If 0 MDI_ENT, continue:
							if mdi_ent_ct == 0:
								# If 0 ASSOC_ENT, then you've got a winner!
								if assoc_ent_ct == 0:
									# If the 2+ SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.  Do not flag such cases as symptom language:
									sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
									if len(sx_ent_indices) >= 2:
										for i, ind in enumerate(sx_ent_indices):
											if int(ind) == (len(ss) - 1):
												flag_s2txtsxver = "1"
												try:
													res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
													flag_s2txtsxval.append(res)
												except Exception:
													pass
											else:
												indofwordaftersxent = int(ind) + 1
												if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
													except Exception:
														pass
										ss_sx_ct += 1
									else:
										ss_sx_ct += 1

								# Elif 1 ASSOC_ENT, you MAY be able to parse it out. First and only idea so far: if pattern is "SX_ENT ASSOC_ENT SX_ENT", then the SX are flag-worthy b/c that pattern negates the 1 instance of ASSOC_ENT.
								# TODO: Add exceptions - one idea, if the pattern is "SX_ENT + ASSOC_ENT + untagged token + untagged token + ',' + SX_ENT", etc. etc.
								elif assoc_ent_ct == 1:
									if "SX_ENTASSOC_ENTSX_ENT" in ssjoined:
										# If the 2+ SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.  Do not flag such cases as symptom language:
										sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
										if len(sx_ent_indices) >= 2:
											for i, ind in enumerate(sx_ent_indices):
												if int(ind) == (len(ss) - 1):
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
													except Exception:
														pass
												else:
													indofwordaftersxent = int(ind) + 1
													if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
														flag_s2txtsxver = "1"
														try:
															res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
															flag_s2txtsxval.append(res)
														except Exception:
															pass
											ss_sx_ct += 1
										else:
											ss_sx_ct += 1
									else:
										ss_sx_ct += 1
								# Else if 2+ ASSOC_ENT, the parsing becomes highly complex. Disregard SS for now:
								# OPENQ: Could include parsing here that said 'for however many # of ASSOC_ENT are present, if SX_ENT border each, then you're ok'.
								else:
									ss_sx_ct += 1

							# Else if 1+ MDI_ENT, it's likely a long, comma-separated string of MDIs and the SX.  See if you can split it:
							elif mdi_ent_ct >= 1:
								# If 0 ASSOC_ENT, proceed (RATIONALE: Since you don't perform 'concept' relational checks (e.g. 'DDD, back pain' are related and arguably make 'back pain' OK), if there are 0 ASSOC_ENT connecting the MDI to the SX, what does it matter if both are present?)
								if assoc_ent_ct == 0:
									# If the 2+ SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.  Do not flag such cases as symptom language:
									sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
									if len(sx_ent_indices) >= 2:
										for i, ind in enumerate(sx_ent_indices):
											if int(ind) == (len(ss) - 1):
												flag_s2txtsxver = "1"
												try:
													res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
													flag_s2txtsxval.append(res)
												except Exception:
													pass

											else:
												indofwordaftersxent = int(ind) + 1
												if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
													except Exception:
														pass
										ss_sx_ct += 1
									else:
										ss_sx_ct += 1
								# Else if 1+ ASSOC_ENT, see if you can negate the ASSOC_ENT via bordering SX_ENT similar to above.	Then, under same logic as above, it doesn't matter if there are MDI_ENT present.
								elif assoc_ent_ct == 1:
									if "SX_ENTASSOC_ENTSX_ENT" in ssjoined:
										# If the 2+ SX_ENT is followed by an MDI-like classifier (e.g. 'left arm pain disorder'), then while the SX_ENT lang is present, it's not exactly accurate to classify it as a pure "SX" as much as it is a non-recognized MDI term.  Do not flag such cases as symptom language:
										sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
										if len(sx_ent_indices) >= 2:
											for i, ind in enumerate(sx_ent_indices):
												if int(ind) == (len(ss) - 1):
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
													except Exception:
														pass
												else:
													indofwordaftersxent = int(ind) + 1
													if bool(re.search(r"disorder|syndrome|condition", ss[indofwordaftersxent], re.I)) is False:
														flag_s2txtsxver = "1"
														try:
															res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
															flag_s2txtsxval.append(res)
														except Exception:
															pass
										else:
											ss_sx_ct += 1
									else:
										sx_ent_indices = [i for i, j in enumerate(ss) if j == 'SX_ENT']
										for i, ind in enumerate(sx_ent_indices):
											if ss[ind-1] == ",":
												if ss[ind+1] == ",":
													flag_s2txtsxver = "1"
													try:
														res = str("LANG='" + sx_ent_by_ss[ss_sx_ct][0] + "', TEXT='" + s2txtsplit4[ss_sx_ct] + "'")
														flag_s2txtsxval.append(res)
														ss_sx_ct += 1
													except Exception:
														pass
								# Else if 2+ ASSOC_ENT, the parsing becomes highly complex. Disregard SS for now:
								# OPENQ: Could include parsing here that said 'for however many # of ASSOC_ENT are present, if SX_ENT border each, then you're ok'.
								else:
									ss_sx_ct += 1


					# (7)(b)(2) UNCERT_ENT PARSING:
					for ss in s2txtsplit10_uncertain:

						# Calculate base values:
						ssjoined = "".join(ss)	# TIP: Used in several locations below.
						ss = ss.split()
						sx_ent_ct = len([token for token in ss if token == 'SX_ENT'])
						mdi_ent_ct = len([token for token in ss if token == 'MDI_ENT'])
						assoc_ent_ct = len([token for token in ss if token == 'ASSOC_ENT'])
						uncert_ent_ct = len([token for token in ss if token == 'UNCERT_ENT'])

						# If 0 UNCERT_ENT, skip this SS:
						if uncert_ent_ct == 0:
							ss_uncertain_ct += 1

						# Else if 1 UNCERT_ENT, proceed:
						elif uncert_ent_ct == 1:

							# If 0 MDI_ENT, it's probably a "HX of [procedure/status/etc.]" phrase, and logically that's all you CAN parse for since you otherwise *require* an MDI_ENT to be beside the UNCERT_ENT. So proceed with re: to "HX of":
							# NOTE: The # of ASSOC_ENT in this context is irrelevant!  Reason being you have no clear MDI_ENT to tie to the UNCERT_ENT via the ASSOC_ENT anyway, so even if the UNCERT_ENT does appear expository, the question is 'expository to what?'  At this fork, I side on raising a flag, particularly for "HX of" language.
							if mdi_ent_ct == 0:
								if bool(re.search(r"\bhistory ?of\b", str(s2txtsplit4[ss_uncertain_ct]))):
									flag_s2txtuncertainver = "1"
									resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
									flag_s2txtuncertainval.append(resstr)
									ss_uncertain_ct += 1
								else:
									ss_uncertain_ct += 1

							# Else if 1+ MDI_ENT, proceed with more complex parsing (including checking for possible negation of the 1 UNCERT_ENT as expository):
							else:
								# DEVELOPMENT (12.30.2016):
								temptrigger = 1
								if temptrigger == 1:

									# 0 ASSOC_ENT, only check if 'status-post' is the 'uncertain' term.  If so, then 'status-post' could be used as an associative term rather than
									# as a (presently classified) uncertain term:
									if assoc_ent_ct == 0:
										# If status post the UNCERT_ENT at issue, see if the status post is 'declarative' (e.g. starts the SS and thus is logically followed by the MDI_ENT present, and thus is really uncertainty language) or if
										# it is 'associative' (e.g. follows an MDI_ENT and thus, given prior efforts to divide SSs, is more likely to be used as associative language such as 'DDD status post surgery'):
										if bool(re.search(r"\bstatus ?post\b|\bstatus/post\b|\bs/p\b|\bsp\b|\bs p\b|\bstatus-post\b", uncert_ent_by_ss[ss_uncertain_ct][0], re.I)):
											status_post_regex_1 = re.search(r"^UNCERT_ENT", ssjoined)
											if bool(status_post_regex_1):
												resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
												flag_s2txtuncertainval.append(resstr)
												ss_uncertain_ct += 1
											else:
												ss_uncertain_ct += 1
										else:
											flag_s2txtuncertainver = "1"
											resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
											flag_s2txtuncertainval.append(resstr)
											ss_uncertain_ct += 1

									# 1 ASSOC_ENT, you have 1 UNCERT_ENT, 1 ASSOC_ENT, and 1+ MDI_ENT.	Check for 'negation as expository' sequence:
									elif assoc_ent_ct == 1:

										# "HX OF" + WORD + WORD + ',' + (NON-CC WORD|MDI_ENT|SX_ENT){1,} + ASSOC_ENT! (basically, cases where the "HX OF" phrase appears first, then after it appears there's a comma, then right aftar the comma there is another 'noun-like' entity so that the probaility the "HX of" phrase is connected all the way to the ASSOC_ENT is small b/c this appears to be a list:
										assoc_regex_1 = re.search(r"UNCERT_ENT(?:(?!ASSOC_ENT).)*?, (?:(?!ASSOC_ENT).)*?\w+ .*ASSOC_ENT", ssjoined)
										if bool(assoc_regex_1):
											flag_s2txtuncertainver = "1"
											resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
											flag_s2txtuncertainval.append(resstr)
											ss_uncertain_ct += 1

										# ... ASSOC_ENT + WORD + ',' + (NON-CC WORD){0,} + "HX OF" (basically, cases where the ASSOC_ENT is separated by any word and a ',', which is followed by no connecting CC's (and|as well as|etc.) before the UNCERT_ENT:
										assoc_regex_2 = re.search(r"ASSOC_ENT.*? \w+ ? ? ?,(?:(?!(\band\b|\bas ?well ?as\b|\bin ?addition ?to\b)).)*?UNCERT_ENT(.*)", ssjoined)
										if bool(assoc_regex_2):
											assoc_regex_2_res = assoc_regex_2.group()
											# Check that the UNCERT_ENT doesn't appear to be part of some long list tied back to the ASSOC_ENT:
											assoc_regex_2_res = assoc_regex_2_res.split("UNCERT_ENT")[1]
											if bool(re.search(r", ?(\band\b|\bas well as\b)", assoc_regex_2_res, re.I)) is False:
												flag_s2txtuncertainver = "1"
												resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
												flag_s2txtuncertainval.append(resstr)

										ss_uncertain_ct += 1

									# 2+ ASSOC_ENT, 1+ MDI_ENT, and only 1 UNCERT_ENT, the probability that the UNCERT_ENT is negated as expository goes up. Pattern parsing becomes more complex as you can see by the additional steps added below:
									else:

										# "HX OF" + WORD + WORD + ',' + (NON-CC WORD|MDI_ENT|SX_ENT){1,} + ASSOC_ENT! (basically, cases where the "HX OF" phrase appears before any ASSOC_ENT, followed by a comma, then right aftar the comma there is another 'noun-like' entity so that the probaility the "HX of" phrase is connected all the way to the ASSOC_ENT is small b/c this appears to be a list:
										assoc_regex_1 = re.search(r"^.*UNCERT_ENT(?:(?!ASSOC_ENT).)*?, (?:(?!ASSOC_ENT).)*?\w+ .*ASSOC_ENT", ssjoined)
										if bool(assoc_regex_1):
											assoc_regex_1_res = assoc_regex_1.group()
											# Check that no other ASSOC_ENT appear proximally close / related to the "HX OF" before it:
											pre_UNCERT_ENT = assoc_regex_1_res.split("UNCERT_ENT")[0]
											if "ASSOC_ENT" in pre_UNCERT_ENT:
												if bool(re.search(r"ASSOC_ENT (?:(?!ASSOC_ENT).)*?\w+(?:(?!(and|as ?well ?as)).)*", pre_UNCERT_ENT)):
													flag_s2txtuncertainver = "1"
													resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
													flag_s2txtuncertainval.append(resstr)
											else:
												flag_s2txtuncertainver = "1"
												resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
												flag_s2txtuncertainval.append(resstr)

										# ... ASSOC_ENT + WORD + ',' + (NON-CC WORD){0,} + "HX OF" (basically, cases where the ASSOC_ENT is separated by any word and a ',', which is followed by no connecting CC's (and|as well as|etc.) before the UNCERT_ENT:
										assoc_regex_2 = re.search(r"ASSOC_ENT.*? \w+ ? ? ?,(?:(?!(ASSOC_ENT|\band\b|\bas ?well ?as\b|\bin ?addition ?to\b)).)*?UNCERT_ENT(.*)", ssjoined)
										if bool(assoc_regex_2):
											assoc_regex_2_res = assoc_regex_2.group()
											# Check that the UNCERT_ENT doesn't appear to be part of some long list tied back to the ASSOC_ENT *and* that no ASSOC_ENT immediately follows the UNCERT_ENT:
											assoc_regex_2_res = assoc_regex_2_res.split("UNCERT_ENT")[1]
											if bool(re.search(r", ?(\band\b|\bas well as\b)", assoc_regex_2_res, re.I)) is False:
												if bool(re.search(r"[\w ]*?ASSOC_ENT", assoc_regex_2_res)) is False:
													flag_s2txtuncertainver = "1"
													resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
													flag_s2txtuncertainval.append(resstr)

										ss_uncertain_ct += 1


								# (b) Parse all other values for the 1 UNCERT_ENT:
								else:

									if "UNCERT_ENTMDI_ENT" in ssjoined:

										# 0 ASSOC_ENT, great!
										if assoc_ent_ct == 0:
											flag_s2txtuncertainver = "1"
											resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
											flag_s2txtuncertainval.append(resstr)
											ss_uncertain_ct += 1

										# 1 ASSOC_ENT, you have 1 UNCERT_ENT, 1 ASSOC_ENT, and 1+ MDI_ENT.	Check for 'negation as expository' sequence:
										elif assoc_ent_ct == 1:

											# "UNCERT_ENT MDI_ENT" + WORD + WORD + ',' + (NON-CC WORD|MDI_ENT|SX_ENT){1,} + ASSOC_ENT! (basically, cases where the "HX OF" phrase appears first, then after it appears there's a comma, then right aftar the comma there is another 'noun-like' entity so that the probaility the "HX of" phrase is connected all the way to the ASSOC_ENT is small b/c this appears to be a list:
											assoc_regex_1 = re.search(r"UNCERT_ENT(?:(?!ASSOC_ENT).)*?, (?:(?!ASSOC_ENT).)*?\w+ .*ASSOC_ENT", ssjoined)
											if bool(assoc_regex_1):
												flag_s2txtuncertainver = "1"
												resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
												flag_s2txtuncertainval.append(resstr)

											# ... ASSOC_ENT + WORD + ',' + (NON-CC WORD){0,} + "UNCERT_ENT MDI_ENT" (basically, cases where the ASSOC_ENT is separated by any word and a ',', which is followed by no connecting CC's (and|as well as|etc.) before the UNCERT_ENT:
											assoc_regex_2 = re.search(r"ASSOC_ENT.*? \w+ ? ? ?,(?:(?!(\band\b|\bas ?well ?as\b|\bin ?addition ?to\b)).)*?UNCERT_ENT(.*)", ssjoined)
											if bool(assoc_regex_2):
												assoc_regex_2_res = assoc_regex_2.group()
												# Check that the UNCERT_ENT doesn't appear to be part of some long list tied back to the ASSOC_ENT:
												assoc_regex_2_res = assoc_regex_2_res.split("UNCERT_ENT")[1]
												if bool(re.search(r", ?(\band\b|\bas well as\b)", assoc_regex_2_res, re.I)) is False:
													flag_s2txtuncertainver = "1"
													resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
													flag_s2txtuncertainval.append(resstr)
											ss_uncertain_ct += 1


										# 2+ ASSOC_ENT, 1+ MDI_ENT, and only 1 UNCERT_ENT, the probability that the UNCERT_ENT is negated as expository goes up. Pattern parsing becomes more complex as you can see by the additional steps added below:
										else:

											# "UNCERT_ENT MDI_ENT" + WORD + WORD + ',' + (NON-CC WORD|MDI_ENT|SX_ENT){1,} + ASSOC_ENT! (basically, cases where the "HX OF" phrase appears first, then after it appears there's a comma, then right aftar the comma there is another 'noun-like' entity so that the probaility the "HX of" phrase is connected all the way to the ASSOC_ENT is small b/c this appears to be a list:
											assoc_regex_1 = re.search(r"^.*UNCERT_ENT(?:(?!ASSOC_ENT).)*?, (?:(?!ASSOC_ENT).)*?\w+ .*ASSOC_ENT", ssjoined)
											if bool(assoc_regex_1):
												assoc_regex_1_res = assoc_regex_1.group()
												# Check that no other ASSOC_ENT appear proximally close / related to the "HX OF" before it:
												pre_UNCERT_ENT = assoc_regex_1_res.split("UNCERT_ENT")[0]
												if "ASSOC_ENT" in pre_UNCERT_ENT:
													if bool(re.search(r"ASSOC_ENT (?:(?!ASSOC_ENT).)*?\w+(?:(?!(and|as ?well ?as)).)*", pre_UNCERT_ENT)):
														flag_s2txtuncertainver = "1"
														resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
														flag_s2txtuncertainval.append(resstr)
												else:
													flag_s2txtuncertainver = "1"
													resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
													flag_s2txtuncertainval.append(resstr)

											# ... ASSOC_ENT + WORD + ',' + (NON-CC WORD){0,} + "UNCERT_ENT MDI_ENT" (basically, cases where the ASSOC_ENT is separated by any word and a ',', which is followed by no connecting CC's (and|as well as|etc.) before the UNCERT_ENT:
											assoc_regex_2 = re.search(r"ASSOC_ENT.*? \w+ ? ? ?,(?:(?!(ASSOC_ENT|\band\b|\bas ?well ?as\b|\bin ?addition ?to\b)).)*?UNCERT_ENT(.*)", ssjoined)
											if bool(assoc_regex_2):
												assoc_regex_2_res = assoc_regex_2.group()
												# Check that the UNCERT_ENT doesn't appear to be part of some long list tied back to the ASSOC_ENT *and* that no ASSOC_ENT immediately follows the UNCERT_ENT:
												assoc_regex_2_res = assoc_regex_2_res.split("UNCERT_ENT")[1]
												if bool(re.search(r", ?(\band\b|\bas well as\b)", assoc_regex_2_res, re.I)) is False:
													if bool(re.search(r"[\w ]*?ASSOC_ENT", assoc_regex_2_res)) is False:
														flag_s2txtuncertainver = "1"
														resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
														flag_s2txtuncertainval.append(resstr)
											ss_uncertain_ct += 1

									else:
										uncert_ent_indices = [i for i, j in enumerate(ss) if j == 'UNCERT_ENT']
										for i, ind in enumerate(uncert_ent_indices):
											if ss[ind-1] != "ASSOC_ENT":
												if ss[ind+1] == "ASSOC_ENT":
													flag_s2txtuncertainver = "1"
													resstr = str("LANG='") + str(uncert_ent_by_ss[ss_uncertain_ct][0]) + str("', TEXT='") + str(s2txtsplit4[ss_uncertain_ct] + "'")
													flag_s2txtuncertainval.append(resstr)
										ss_uncertain_ct += 1

						# Else if 2+ UNCERT_ENT, for the time being just assume the UNCERT_ENT aren't negated as expository:
						else:
							flag_s2txtuncertainver = "1"
							resstr = str("LANG='" + str(uncert_ent_by_ss[ss_uncertain_ct]).replace("[", "").replace("]", "") + "', TEXT='" + str(s2txtsplit4[ss_uncertain_ct]) + "'")
							flag_s2txtuncertainval.append(resstr)
							ss_uncertain_ct += 1

				except Exception:
					logger.exception('EXCEPTION')
					flag_s2txtsxver = "E"
					flag_s2txtuncertainver = "E"

				# Perform final parsing of 's2'-wise result:
				flag_s2txtsxasmdi_resdictlist.append({'nm':'flag_s2txtsxasmdi_val', 'ver':flag_s2txtsxver, 'val':' /// '.join(flag_s2txtsxval), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				flag_s2txtuncertain_resdictlist.append({'nm':'flag_s2txtuncertain_val', 'ver':flag_s2txtuncertainver, 'val':' /// '.join(flag_s2txtuncertainval), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Parse all results to output general verdict:
		flag_s2txtsxasmdi_ver = 'U'
		flag_s2txtsxasmdi_val = []
		flag_s2txtuncertain_ver = 'U'
		flag_s2txtuncertain_val = []

		if not flag_s2txtsxasmdi_resdictlist:
			logger.critical('iq.s2txtquality_calc.flag_s2txtsxasmdi_resdictlist empty!')
			flag_s2txtsxasmdi_ver = 'U'
		else:
			flag_s2txtsxasmdi_resdictlist_vervals = [subd['ver'] for subd in flag_s2txtsxasmdi_resdictlist]
			if '1' in flag_s2txtsxasmdi_resdictlist_vervals:
				flag_s2txtsxasmdi_ver = '1'
				flag_s2txtsxasmdi_val = [subd for subd in flag_s2txtsxasmdi_resdictlist if subd['ver'] == '1']
			else:
				if len(set(flag_s2txtsxasmdi_resdictlist_vervals)) == 1 and flag_s2txtsxasmdi_resdictlist_vervals[0] == '0':
					flag_s2txtsxasmdi_ver = '0'
				else:
					flag_s2txtsxasmdi_ver = 'U'

		if not flag_s2txtuncertain_resdictlist:
			logger.critical('iq.s2txtquality_calc.flag_s2txtuncertain_resdictlist empty!')
			flag_s2txtuncertain_ver = 'U'
		else:
			flag_s2txtuncertain_resdictlist_vervals = [subd['ver'] for subd in flag_s2txtuncertain_resdictlist]
			if '1' in flag_s2txtuncertain_resdictlist_vervals:
				flag_s2txtuncertain_ver = '1'
				flag_s2txtuncertain_val = [subd for subd in flag_s2txtuncertain_resdictlist if subd['ver'] == '1']
			else:
				if len(set(flag_s2txtuncertain_resdictlist_vervals)) == 1 and flag_s2txtuncertain_resdictlist_vervals[0] == '0':
					flag_s2txtuncertain_ver = '0'
				else:
					flag_s2txtuncertain_ver = 'U'

		return flag_s2txtsxasmdi_ver, flag_s2txtsxasmdi_val, flag_s2txtuncertain_ver, flag_s2txtuncertain_val

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', [], 'E', []


# (X) Step 2 'Severe MDI' Finding Consists ONLY of 'SX' and 'Uncertain'
# Language with NO Actual MDI Medical Terms Detected:
# TODO: Revise 'flagdata' to indicate that this does express that
# there are only symptoms with no MDIs, but that the 'no MDI' element
# will not permit procedures and injuries to qualify as MDIs for this
# analysis. Basically it could be reframed as "I don't see MDIs, only
# symptoms (always) and possibly some  procedures and events."
def s2txtonlysx_calc(input_dict):
	'''For each Step 2 MDI finding that the claimant has MDIs (severe
	or non-severe) present, evaluates whether the *only* MDI entity or
	entities cited are symptom entities (in this context, any references
	to procedures or injuries do not count as MDIs sufficient to preclude
	raising this flag.

	Args:
		input_dict {dict}: An INSIGHT observation dictionary.
	Returns:
		flag_s2txtonlysx_ver {str}: A verdict for this
			quality issue, where '0' = not detected and '1'
			= detected.
		flag_s2txtonlysx_val {list}: A value providing
			details on each such quality issue of this kind
			detected.
	Raises:
		N/A (returns 'E' values if Exception occurs).
	'''
	try:

		if not input_dict['s2']:
			return 'U', []

		flag_s2txtonlysx_resdictlist = []
		for k,v in input_dict['s2'].iteritems():

			sxent_reslist = []
			s2ver = v['s2ver']
			s2txtsrc = v['s2txtsrc']
			s2txt = v['s2txt']

			# If s2ver != 1 or 2 (i.e. a finding the CL has MDIs, either
			# severe or non-severe), then logically there's no MDI language
			# to parse; if s2txt == ['U', 'P', 'E', ''], then logically
			# there's no MDI language to parse:
			if s2ver not in ['1', '2'] or s2txt in ['U', 'P', 'E', '']:
				flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:

				# Normalize s2txt:
				s2txt = " ".join(s2txt.split())

				# (TEMPORARILY DISABLED PENDING UPDATE)
				# TODO: Update code to persist POS
				# tag data through the end of this algorithm
				# to enable more intelligent handling of
				# 'junk' remaining after the following
				# filters.
				# First, classify text's POS tags:
				# s2txt_pos_tuplist = pos_tag(s2txt.split())

				# If FIT-sourced s2txt, clean using s2txt_cleaner:
				if s2txtsrc == '0':
					s2txt = nlp_helper.s2txt_cleaner_fit(s2txt)
				# Else more fuzzily remove any non-MDI FIT-like
				# program/generic language:
				else:
					s2txt = nlp_helper.s2txt_cleaner_nonfit(s2txt)

				# Universally remove FIT-like program/generic language
				# at the term level:
				for item in iqdl.nonlist:
					s2txt = re.sub(item, " ", s2txt, flags=re.I)
				s2txt = tc.normalize_spacing(s2txt)

				# Search for and remove SX terms; if none found,
				# do not proceed:
				# NOTE: On further study, keep gatekeeping focus
				# on 1+ *SX* only rather than on 1+ SX, procedures,
				# or injury terms; the UMLS procedure and injury
				# TYP contents are broad and include many entities
				# that are quite MDI-like (e.g. 'ORBITAL ROOF
				# FRACTURE').
				umls_sx_restup = ua.extract_terms_s2txt_returntxt_sx(s2txt, s2txtsrc, '0')
				umls_sx_resdictlist = umls_sx_restup[0]
				if len(umls_sx_resdictlist) == 0:
					flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					sx_txt_list = [d['TXT'] for d in umls_sx_resdictlist]
					for sx in sx_txt_list:
						sxent_reslist.append(sx)
					s2txt = umls_sx_restup[1]

					# Now parse text for MDI terms using full UMLS:
					# If 0 results, proceed:
					# If 1+ non 'Sign or Symptom' type results,
					# pass (TIP: UMLS 'types_terms_list' does NOT
					# include body part or body system types, so it'
					# won't trigger a match in the face of 'back'
					# or 'shoulder')
					# If 1+ but all 'Sign or Symptom', proceed:
					umls_halt_ver = 0
					umls_restup = ua.extract_terms_s2txt_returntxt(s2txt, s2txtsrc, '0')
					umls_resdictlist = umls_restup[0]
					if len(umls_resdictlist) >= 1:
						typevallist = [d['TYP'] for d in umls_resdictlist]
						if len([l for l in typevallist if 'Sign or Symptom' in l]) == len(typevallist):
							pass
						else:
							typevallist_nonprocedure = [l for l in typevallist if bool('Therapeutic or Preventive Procedure'in l or 'Injury or Poisoning' in l) is False]
							if len(typevallist_nonprocedure) == 0 or len([l for l in typevallist_nonprocedure if 'Sign or Symptom' in l]) == len(typevallist_nonprocedure):
								pass
							else:
								umls_halt_ver = 1

					# If UMLS gate passed, proceed:
					if umls_halt_ver == 1:
						flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						s2txt = umls_restup[1]
						s2txt = s2txt.replace('_', ' ')
						s2txt = tc.normalize_spacing(s2txt)

						# Remove body part and other non-MDI terms:
						for item in iqdl.bodysystemlist:
							s2txt = re.sub(item, " ", s2txt, flags=re.I)

						# Remove uncertainty terms:
						for item in iqdl.uncertainlist:
							s2txt = re.sub(item, " ", s2txt, flags=re.I)

						# HEURISTIC:
						# UMLS extraction will not capture every MDI term present
						# (e.g. misspells, unusual or novel MDIs, etc.).  Thus, need
						# to create means to evaluate whether 'scraps' remaining are
						# or are not likely to be 1+ 'lurking' MDI.  Thus, heuristic:
						# If there are more than 2 2+ character words present, then
						# it is possible that parsing missed a valid MDI, which would
						# make this flag false.
						if len(sxent_reslist) != 0:
							word_ct_init_findall = re.findall(r"[a-z\-]{2,}", s2txt, re.I)
							if len(word_ct_init_findall) <= 1:
								flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'1', 'val':'; '.join(sxent_reslist), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
							else:

								# So we have some scraps.  Now we must make sense of it.
								# If ANY conjunction/associational term matches, that isn't necesarily
								# the end - could have been used between two symptom/injury/procedure
								# terms (e.g. "cervical pain associated with headaches" or "cervical
								# pain status-post 2005 C4-C5 fusion")

								# So why not try to ID and remove such phrasing. Also ID and remove
								# extremely low value stop words. If 1+ term still present
								# after removal, then that strongly suggests you have a possible MDI
								# still lurking around in the scraps:
								# Remove conjunctions:
								for conj in [r'AND', r'OR', r'BUT', r'YET', r'ALTHOUGH', r'AS WELL AS', r'AND / OR']:
									conjre = conj.replace(' ', ' ?')
									conjre = r'\b' + conj + r'\b'
									s2txt = re.sub(conjre, ' ', s2txt, flags=re.I)
								# Remove associational phrases:
								for item in iqdl.assocphraselist2:
									s2txt = re.sub(item, ' ', s2txt, flags=re.I)
								# Remove stopwords (except conjunctions):
								s2txt = nlp_helper.remove_stopwords(s2txt)
								# Count again:
								word_ct_fnl_findall = re.findall(r"[a-z\-]{2,}", s2txt, re.I)
								if len(word_ct_fnl_findall) == 0:
									flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'1', 'val':'; '.join(sxent_reslist), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
								else:
									flag_s2txtonlysx_resdictlist.append({'nm':'flag_s2txtonlysx_val', 'ver':'U', 'val':'; '.join(sxent_reslist), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})


		# Finalize results:
		if not flag_s2txtonlysx_resdictlist:
			logger.critical('iq.s2txtonlysx_calc.flag_s2txtonlysx_resdictlist empty!')
			return 'U', []
		else:
			flag_s2txtonlysx_resdictlist_vervals = [subd['ver'] for subd in flag_s2txtonlysx_resdictlist]
			if '1' in flag_s2txtonlysx_resdictlist_vervals:
				flag_s2txtonlysx_ver = '1'
				flag_s2txtonlysx_val = [subd for subd in flag_s2txtonlysx_resdictlist if subd['ver'] == '1']
				return flag_s2txtonlysx_ver, flag_s2txtonlysx_val
			else:
				if len(set(flag_s2txtonlysx_resdictlist_vervals)) == 1 and flag_s2txtonlysx_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception, x:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Claimant Self-Reported Height/Weight/Sex (As Reported Around Application Date
# in 3368 [Disability Report - Adult] And As Contained In MEDIB.CASE as 'HT_IN'
# and 'WT_LB' and 'SEX') And Age At DID (Calculated from 'CLMT_DOB' With An End
# Date Determined By Argument, But Either Today's Date Or PACAR 'FNL_DSPN_DT') Versus
# Weight-Related Impairment Reference Consistency Check:
# TIP: Capable of operating for ALL ages (infant to adult).
def s2mdi_selfwt_calc(input_dict, input_dec_str):
	try:

		if not input_dict['s2']:
			return 'U', []

		# Calculate BMI depending on CL age:
		# TIP: 'OB' will output for ANY age range if the case.
		wt_resdict = bmi.parse_weight(input_dict['SEX'], input_dict['HT_INCH'], input_dict['WT_LB'], input_dict['STRUCT_AGEREL_PAIEND'], input_dict['CLMT_DOB'], input_dict['FNL_DSPN_DT'])
		if wt_resdict['interp_var'] != 'OB':
			return 'U', []

		# Gather target CUI list centered on
		# CUI C0028754 (obesity):
		tgt_cui_list = list(set(iqdl.cui_rel_ntwk_dict['C0028754']['CUI'].tolist()))

		flag_s2mdi_selfwt_resdictlist = []
		for k,v in input_dict['s2'].iteritems():

			# Gather all CUI related to this ORD_NUM:
			allcui = gathercui_v2(input_dict, v['ORD_NUM'])

			# Evaluate CUI-wise consistency:
			if len([cui for cui in tgt_cui_list if cui in allcui]) != 0:
				flag_s2mdi_selfwt_resdictlist.append({'nm':'flag_s2mdi_selfwt_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# Perform manual search of 's2txt' and 's2' entity
				# body text for obesity references (conservative approach to cover both
				# severity findings and non-severe finding references):
				# TODO: Implement a more fuzzy string matching REGEX pattern or
				# other fuzzy match mechanism.
				if np.isnan(v['loc_end']) or np.isnan(v['body_loc_end']):
					flag_s2mdi_selfwt_resdictlist.append({'nm':'flag_s2mdi_selfwt_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					s2txt = v['s2txt']
					s2bodytxt = input_dec_str[v['loc_end']:v['body_loc_end']]
					manual_concept_regex_list = list(set(iqdl.cui_rel_ntwk_dict['C0028754']['STR'].tolist()))
					manual_concept_regex_list = [re.escape(s) for s in manual_concept_regex_list]
					manual_concept_regex_list = [r'\b' + s + r'\b' for s in manual_concept_regex_list]
					manual_concept_regex_list = [s.replace(' ', ' ?') for s in manual_concept_regex_list]
					manual_s2txt_concept_ver = 0
					for conceptre in manual_concept_regex_list:
						if bool(re.search(conceptre, s2txt, re.I)):
							manual_s2txt_concept_ver = 1
							break
						if bool(re.search(conceptre, s2bodytxt, re.I)):
							manual_s2txt_concept_ver = 1
							break

					if manual_s2txt_concept_ver == 0:
						flag_s2mdi_selfwt_resdictlist.append({'nm':'flag_s2mdi_selfwt_val', 'ver':'1', 'val':wt_resdict['interp_str'], 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s2mdi_selfwt_resdictlist.append({'nm':'flag_s2mdi_selfwt_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s2mdi_selfwt_resdictlist:
			logger.critical('iq.s2mdi_selfwt_calc.flag_s2mdi_selfwt_resdictlist empty!')
			return 'U', []
		else:
			flag_s2mdi_selfwt_resdictlist_vervals = [subd['ver'] for subd in flag_s2mdi_selfwt_resdictlist]
			if '1' in flag_s2mdi_selfwt_resdictlist_vervals:
				flag_s2mdi_selfwt_ver = '1'
				flag_s2mdi_selfwt_val = [subd for subd in flag_s2mdi_selfwt_resdictlist if subd['ver'] == '1']
				return flag_s2mdi_selfwt_ver, flag_s2mdi_selfwt_val
			else:
				if len(set(flag_s2mdi_selfwt_resdictlist_vervals)) == 1 and flag_s2mdi_selfwt_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) (TABLED 05252017) Step 2 Severe/Non-Severe Mental MDI Found, But Decision Text Contains
# No References (Whatsoever?) to Par. B Ratings/Language:
# WARNING: Not yet schema 2 compliant.
def s2mentalmdiparb_ver_calc(input_dict, decision_txt):
	try:
		s2ver = input_dict['s2ver'].split('; ')
		if not any(x for x in s2ver if x in ['1', '2']):
			return 'P'
		else:
			# TIP: If 's3parb' values have been assigned then deeming this
			# flag's issue to not be present - even though at this point
			# you haven't yet confirmed a mental MDI was found, given the
			# limitations of the UMLS -- think organic brain injuries being
			# classified as non-mental -- it is reasonable to return a '0'.
			s3parbvallist = []
			s3parbvallist.append(input_dict['s3parbadl'])
			s3parbvallist.append(input_dict['s3parbcpp'])
			s3parbvallist.append(input_dict['s3parbsf'])
			s3parbvallist.append(input_dict['s3parbdecomp'])
			if any(val for val in s3parbvallist if val not in ['U', 'P', 'E', '']):
				return '0'
			else:
				# Gather all MDI 'TYP' values:
				typ_vals = [input_dict[key].split('; ') for key in input_dict.keys() if '_TYP' in key]
				typ_vals = list(cfx.flatten_irreg(typ_vals))
				typ_vals = [typ for typ in typ_vals if typ not in ['U', 'P', 'E', '']]

				# If no 'TYP' values, return 'P'; else, proceed:
				if not typ_vals:
					return 'P'
				else:
					# If no 'TYP' is mental, return 'P'; else, proceed:
					if not any(typ for typ in typ_vals if typ == 'Mental or Behavioral Dysfunction'):
						return 'P'
					else:
						# Search for ANY non-FIT/non-stock references to Par. B ratings
						# in the findings section:
						# TIP: 'decision_txt' = 'decisionfindingsltd', so it is necessary
						# to normalize spacing.
						decision = " ".join(decision_txt.split())

						# Remove stock FIT 'non-finding' Par. B language:
						# TODO (01.13.2017): Check  latest DFRs to ensure this
						# covers all targeted language.
						# UNFAV:
						decision = re.sub(r"These ?(four|4) ?broad ?functional ?areas ?are ?known ?as ?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria", " ", decision, flags=re.I)
						decision = re.sub(r"In ?making ?this ?finding\, ?the ?undersigned ?has ?considered ?whether ?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria ?(were|are) ?satisfied", " ", decision, flags=re.I)
						decision = re.sub(r"To ?satisfy ?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria(,|) ?the ?mental ?(impairment/impairments|impairments|impairment) ?must ?result ?in ?at ?least ?(two|2) ?of ?the ?following\: ?marked ?restriction ?of ?activities ?of ?daily ?living\; ?marked ?difficulties ?in ?maintaining ?social ?functioning\; ?marked ?difficulties ?in ?maintaining ?concentration\, ?persistence\, ?or ?pace\; ?or ?repeated ?episodes ?of ?decompensation", " ", decision, flags=re.I)
						decision = re.sub(r"Because ?the ?claimant.?.?s ?mental ?impairments? (does|did|do) ?not ?cause ?at ?least ?(two|2) ?(\"|\'|)marked(\"|\'|) ?limitations ?or ?(one|1) ?(\"|\'|)marked(\"|\'|) ?limitation ?and ?(\"|\'|)repeated(\"|\'|) ?episodes ?of ?decompensation.?.?each ?of ?extended ?duration.?.?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria", " ", decision, flags=re.I)
						decision = re.sub(r"The ?limitations ?identified ?in ?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria ?are ?not ?a ?residual ?functional ?capacity ?assessment", " ", decision, flags=re.I)
						decision = re.sub(r"The ?mental ?residual ?functional ?capacity ?assessment ?used ?at ?steps ?(four|4) ?and ?(five|5) ?(of ?the ?sequential ?evaluation ?process|) ?requires ?a ?more ?detailed ?assessment ?by ?itemizing ?various ?functions ?contained ?in ?the ?broad ?categories ?found ?in ?paragraph ?B", " ", decision, flags=re.I)
						decision = re.sub(r"the ?following ?residual ?functional ?capacity ?assessment ?reflects ?the ?degree ?of ?limitation ?the ?undersigned ?has ?found ?in ?the ?(\"|\'|)paragraph ?B", " ", decision, flags=re.I)
						decision = re.sub(r"As ?for ?the ?(\"|\'|)paragraph ?B(\"|\'|) ?criteria\, ?they ?(were|are) ?not ?met ?because ?the ?claimant ?(did|does) ?not ?have ?a ?valid ?verbal, ?performance, ?or ?full.?scale", " ", decision, flags=re.I)
						decision = re.sub(r"Turning ?to ?the ?requirements ?in ?(\"|\'|)paragraph ?B(\"|\'|).?.?they ?(were|are) ?not ?met ?because ?the ?claimant ?(did|does) ?not ?have ?a ?valid ?verbal\, ?performance\, ?or ?full.?scale", " ", decision, flags=re.I)
						# FFAV: None.
						# WIDOW: None.
						# T16CHILDT16ADULT: None.

						# Search for any remaining Par. B language that could
						# be a finding, including pertinent CFRs, etc.:
						parb_lang_search = re.search(r"\bparagraph.{0,3}\bB\b|concentration.{0,3}persistence|social.{0,3}functioning|episode.{0,4}of.{0,3}decompensation|C.?F.?R.? ?404\.?1520a|C.?F.?R.? ?416\.?920a", decision, flags=re.I)
						if bool(parb_lang_search):
							return '1'
						else:
							return '0'
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'


# (X) Step 3 'Medically Equals' Finding vs. 1+ Reference to Medical Expert
# Evidence Consistency Flag:
# TIP: Rechecked and I am *certain* there is no stock FIT 'medical expert'
# language automatically generated in the SEP/body text of hearing decisions.
# TODO: Add functionality to check MIDIB CASEDOC table using FLDR_NUM value
# to check for DOCU_CD values indicating an ME supplied interrogatory responses
# or otherwise was requested/provided evidence.  Even better would be to see if
# any interrogatory response was exhibited and then use that to check for Exhibit #
# references.
def s3ver3nomeref_calc(input_dict, decision_txt):
	'''In Step 3 'medically equals' findings, detects whether there is r is not
	a reference to medical expert evidence, including references to medical
	expert last names (e.g. 'Dr. Smith' if 'Smith' is an ME name value associated
	with the case/decision).
	'''
	try:
		if not input_dict['s3mteq']:
			return 'U', []

		flag_s3ver3nomeref_resdictlist = []
		for k,v in input_dict['s3mteq'].iteritems():

			s3mteqver = v['s3mteqver']
			merefbody = input_dict['merefbody']

			if s3mteqver != '3':
				flag_s3ver3nomeref_resdictlist.append({'nm':'flag_s3ver3nomeref_val', 'ver':'U', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If 'merefbody' == '1', then ME language is present and
				# this quality check has been satisfied; return '0':
				if merefbody == '1':
					flag_s3ver3nomeref_resdictlist.append({'nm':'flag_s3ver3nomeref_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				# Else, proceed:
				else:
					# Obtain structured data on ME names who provided
					# evidence from struct_exp_devlph and struct_exp_hrgexp:
					# TIP: Example dict:
					# {'TITLE': 'DR.  ', 'FNM':'JOHN   ', 'MNM':'AARON     ', 'LNM':'SMITH   ', 'SFX':NULL}
					# If 0 structured ME names retrieved, you have nothing further
					# to check. Output '1':
					if not input_dict['EXP']:
						flag_s3ver3nomeref_resdictlist.append({'nm':'flag_s3ver3nomeref_val', 'ver':'E', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					# Else, proceed:
					else:

						# Normalize the decision text's spacing:
						decision = " ".join(decision_txt.split())

						# Search for the structured ME names (find last name instances, then
						# take 5 tokens prior and 2 after and look for other name element
						# matches):
						structmenamefound = 0
						for sndict in input_dict['EXP']:
							lnm = sndict['LNM']
							if lnm and lnm.strip() not in ['U', 'P', 'E', '']:

								# HEURISTIC: Search for last name, and if found, search for other ME
								# name components in the surrounding text:
								# OPENQ: Switch to making LNM enough in Step 3 rationale text, and LNM + 1
								# in other text?
								lnm = lnm.strip()
								lnm_re = re.escape(lnm)
								lnm_re = lnm_re.replace(" ", " ?")
								lnm_re = r"\b" + lnm_re
								lnm_finditer = re.finditer(lnm_re, decision, re.I)

								for res in lnm_finditer:
									res_snippet_raw = decision[res.start()-100:res.start()] + decision[res.end():res.end()+20]

									me_srch_list = [r"Dr\."]
									for dpt in ['FNM', 'TITLE']:
										dpt_v = sndict[dpt]
										if dpt_v and dpt_v.strip() not in ['U', 'P', 'E', '']:
											dpt_v = dpt_v.strip()
											dpt_v_re = re.escape(dpt_v)
											dpt_v_re = dpt_v_re.replace(" ", " ?")
											dpt_v_re = r"\b" + dpt_v_re
											me_srch_list.append(dpt_v_re)

									me_srch_ver = 0
									for re_str in me_srch_list:
										if bool(re.search(re_str, res_snippet_raw, re.I)):
											me_srch_ver == 1

									if me_srch_ver != 0:
										structmenamefound = 1

						if structmenamefound == 0:
							all_nm_list = []
							for sndict in input_dict['EXP']:
								nm_res_list = []
								for dpt in ['TITLE', 'FNM', 'MNM', 'LNM']:
									dpt_v = sndict[dpt]
									if dpt_v and dpt_v.strip() not in ['U', 'P', 'E', '']:
										nm_res_list.append(dpt_v.strip())
								if nm_res_list:
									all_nm_list.append(' '.join(nm_res_list))
							flag_s3ver3nomeref_resdictlist.append({'nm':'flag_s3ver3nomeref_val', 'ver':'1', 'val':'; '.join(all_nm_list), 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
						else:
							flag_s3ver3nomeref_resdictlist.append({'nm':'flag_s3ver3nomeref_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s3ver3nomeref_resdictlist:
			logger.critical('iq.s3ver3nomeref_calc.flag_s3ver3nomeref_resdictlist empty!')
			return 'U', []
		else:
			flag_s3ver3nomeref_resdictlist_vervals = [subd['ver'] for subd in flag_s3ver3nomeref_resdictlist]
			if '1' in flag_s3ver3nomeref_resdictlist_vervals:
				flag_s3ver3nomeref_ver = '1'
				flag_s3ver3nomeref_val = [subd for subd in flag_s3ver3nomeref_resdictlist if subd['ver'] == '1']
				return flag_s3ver3nomeref_ver, flag_s3ver3nomeref_val
			else:
				if len(set(flag_s3ver3nomeref_resdictlist_vervals)) == 1 and flag_s3ver3nomeref_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Severe Hand/Wrist-Affecting MDI / RFC Inconsistency Flag:
def rfcmdi_cts_calc(input_dict):
	try:
		if not input_dict['s2'] or not input_dict['rfc']:
			return 'U', []

		# Gather target CUI list centered on
		# CUI C0007286 (carpal tunnel syndrome) and
		# other hand/wrist-affecting diseases:
		tgt_cui_list = list(set(iqdl.cui_rel_ntwk_dict['C0007286']['CUI'].tolist()))

		flag_rfcmdi_cts_resdictlist = []
		for k,v in input_dict['s2'].iteritems():

			# Gather all CUI related to this ORD_NUM:
			allcui = gathercui_v2(input_dict, v['ORD_NUM'])

			# If no CUI-wise match, still look for manual match:
			tgt_str_list = []
			if len([cui for cui in tgt_cui_list if cui in allcui]) == 0:

				# Perform manual search of 's2txt' value for target concept:
				manual_s2txt_concept_ver = 0
				s2txt = v['s2txt']
				manual_concept_regex_list = list(set(iqdl.cui_rel_ntwk_dict['C0007286']['STR'].tolist()))
				manual_concept_regex_list = [re.escape(s) for s in manual_concept_regex_list]
				manual_concept_regex_list = [r'\b' + s + r'\b' for s in manual_concept_regex_list]
				manual_concept_regex_list = [s.replace(' ', ' ?') for s in manual_concept_regex_list]
				for conceptre in manual_concept_regex_list:
					conceptsearch = re.search(conceptre, s2txt, re.I)
					if bool(conceptsearch):
						tgt_str_list.append(conceptsearch.group())
						manual_s2txt_concept_ver = 1
						break
				if manual_s2txt_concept_ver == 0:
					flag_rfcmdi_cts_resdictlist.append({'nm':'flag_rfcmdi_cts_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					continue

			# Parse CUI matches (if any) to add to tgt_str_list:
			cuimatchlist = list(set([cm for cm in tgt_cui_list if cm in allcui]))
			for res in cuimatchlist:
				for mdi_k, mdi_subd in input_dict['mdi'].iteritems():
					if res in mdi_subd['CUI']:
						tgt_str_list.append(mdi_subd['TXT'])

			# Parse RFC(s) for corresponding limitations:
			# Locate all relevant RFC values for comparison:
			rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's2', v['ORD_NUM'], 'rfc', 'after')

			if not rfc_tgt_key_list:
				flag_rfcmdi_cts_resdictlist.append({'nm':'flag_rfcmdi_cts_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				rfc_concept_corr_ver_dict = {}
				for rfck, rfcv in input_dict['rfc'].iteritems():
					if rfck in rfc_tgt_key_list:

						if (rfcv['rfcfingerpresent'] != '1' and
							rfcv['rfcfingerlol'] == 'U' and
							rfcv['rfcfeelpresent'] != '1' and
							rfcv['rfcfeellol'] == 'U' and
							rfcv['rfchandlepresent'] != '1' and
							rfcv['rfchandlelol'] == 'U' and
							rfcv['rfcallmanipulativespresent'] != '1'
							):

							manual_cts_rfcfunction_ver = 0
							manual_cts_function_regex_list = [
								r"\bcarpal ?tuimel|\bcarpal.?tunnel|\bhand\b|\bfingers?|\bwrist|\b(handle|touch|manipulate|finger|feel|utilize|use) ?([a-z]+ ?)?(object|item|hand|controls|hand ?controls)",
								r"\bmedian ?nerve ?compression|\bcompress(ion|ed) ?(of ?the ?)?median ?nerve"
								r"\btyping\b|\btype ?on\b",
								r"\bkeyboard"]
							for regexpat in manual_cts_function_regex_list:
								if bool(re.search(regexpat, rfcv['rfctxt'], re.I)):
									manual_cts_rfcfunction_ver = 1
									break
							if manual_cts_rfcfunction_ver == 0:
								flag_rfcmdi_cts_resdictlist.append({'nm':'flag_rfcmdi_cts_val', 'ver':'1', 'val':'; '.join(tgt_str_list), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
							else:
								flag_rfcmdi_cts_resdictlist.append({'nm':'flag_rfcmdi_cts_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
						else:
							flag_rfcmdi_cts_resdictlist.append({'nm':'flag_rfcmdi_cts_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})

		# Finalize results:
		if not flag_rfcmdi_cts_resdictlist:
			logger.critical('iq.rfcmdi_cts_calc.flag_rfcmdi_cts_resdictlist empty!')
			return 'U', []
		else:
			flag_rfcmdi_cts_resdictlist_vervals = [subd['ver'] for subd in flag_rfcmdi_cts_resdictlist]
			if '1' in flag_rfcmdi_cts_resdictlist_vervals:
				flag_rfcmdi_cts_ver = '1'
				flag_rfcmdi_cts_val = [subd for subd in flag_rfcmdi_cts_resdictlist if subd['ver'] == '1']
				return flag_rfcmdi_cts_ver, flag_rfcmdi_cts_val
			else:
				if len(set(flag_rfcmdi_cts_resdictlist_vervals)) == 1 and flag_rfcmdi_cts_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Severe Visual MDI / RFC Inconsistency Flag:
def rfcmdi_blind_calc(input_dict):
	try:

		if not input_dict['s2'] or not input_dict['rfc']:
			return 'U', []

		# Gather target CUI list centered on
		# CUI C0456909 (blindness) and
		# other visual diseases:
		tgt_cui_list = list(set(iqdl.cui_rel_ntwk_dict['C0456909']['CUI'].tolist()))

		flag_rfcmdi_blind_resdictlist = []
		for k,v in input_dict['s2'].iteritems():

			# Gather all CUI related to this ORD_NUM:
			allcui = gathercui_v2(input_dict, v['ORD_NUM'])

			# If no CUI-wise match, look for manual match:
			tgt_str_list = []
			if len([cui for cui in tgt_cui_list if cui in allcui]) == 0:

				# Perform manual search of 's2txt' value for target concept:
				manual_s2txt_concept_ver = 0
				s2txt = v['s2txt']
				manual_concept_regex_list = list(set(iqdl.cui_rel_ntwk_dict['C0456909']['STR'].tolist()))
				manual_concept_regex_list = [re.escape(s) for s in manual_concept_regex_list]
				manual_concept_regex_list = [r'\b' + s + r'\b' for s in manual_concept_regex_list]
				manual_concept_regex_list = [s.replace(' ', ' ?') for s in manual_concept_regex_list]
				for conceptre in manual_concept_regex_list:
					conceptsearch = re.search(conceptre, s2txt, re.I)
					if bool(conceptsearch):
						tgt_str_list.append(conceptsearch.group())
						manual_s2txt_concept_ver = 1
						break
				if manual_s2txt_concept_ver == 0:
					flag_rfcmdi_blind_resdictlist.append({'nm':'flag_rfcmdi_blind_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					continue

			# Parse CUI matches (if any) to add to tgt_str_list:
			cuimatchlist = list(set([cm for cm in tgt_cui_list if cm in allcui]))
			for res in cuimatchlist:
				for mdi_k, mdi_subd in input_dict['mdi'].iteritems():
					if res in mdi_subd['CUI']:
						tgt_str_list.append(mdi_subd['TXT'])

			# Parse RFC for corresponding limitations:
			# Locate all relevant RFC values:
			rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's2', v['ORD_NUM'], 'rfc', 'after')

			if not rfc_tgt_key_list:
				flag_rfcmdi_blind_resdictlist.append({'nm':'flag_rfcmdi_blind_val', 'ver':'U', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				rfc_concept_corr_ver_dict = {}
				for rfck,rfcv in input_dict['rfc'].iteritems():
					if rfck in rfc_tgt_key_list:

						if (
							rfcv['rfcnearacuitypresent'] != '1' and
							rfcv['rfcnearacuitylol'] == 'U' and
							rfcv['rfcfaracuitypresent'] != '1' and
							rfcv['rfcfaracuitylol'] == 'U' and
							rfcv['rfcdepthperceptionpresent'] != '1' and
							rfcv['rfcdepthperceptionlol'] == 'U' and
							rfcv['rfcaccomodationpresent'] != '1' and
							rfcv['rfcaccomodationlol'] == 'U'
							):
							manual_blind_function_ver = 0
							rfctxt = rfcv['rfctxt']
							manual_blind_function_regex_list = [
								r"\bblindness\b|\bblinded\b|\bblind\b|\bvision\b|\bvisual\b|\beye.?sight\b|\beyesight\b|\beyes?\b|\boptic|\bsight\b|\bsee\b|\bacuity",
								r"\bsmall ?text|\bdriving\b|\bdrive\b|\bvehicles?",
								r"\bblurriness\b|\bblurry\b|\bdifficulty ?seeing|\bperception\b|\perceive ?object|\beyes\b",
								r"\bmyopia\b|\bmyopic\b|\bhyperopia\b|\bhyperopic\b|\bnear.{0,3}sight|\bfar.{0,3}sight",
								r"\b(visual|vision|eye.?sight|sight) ?(limitation|reduction|impairment)"
								r"\b(limited|low|restricted|reduced|reduction|compromised|impaired) ?([a-z]+ ){0,3}(visual|vision|eye.?sight|sight)"
								r"\bfine.print|\breading\b|\bread\b|\bscan|\bglancing\b|\bglance\b"]
							for regexpat in manual_blind_function_regex_list:
								if bool(re.search(regexpat, rfctxt, re.I)):
									manual_blind_function_ver = 1
									break
							if manual_blind_function_ver == 0:
								flag_rfcmdi_blind_resdictlist.append({'nm':'flag_rfcmdi_blind_val', 'ver':'1', 'val':'; '.join(tgt_str_list), 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
							else:
								flag_rfcmdi_blind_resdictlist.append({'nm':'flag_rfcmdi_blind_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
						else:
							flag_rfcmdi_blind_resdictlist.append({'nm':'flag_rfcmdi_blind_val', 'ver':'0', 'val':'U', 'cn1':'s2', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})

		# Finalize results:
		if not flag_rfcmdi_blind_resdictlist:
			logger.critical('iq.rfcmdi_blind_calc.flag_rfcmdi_blind_resdictlist empty!')
			return 'U', []
		else:
			flag_rfcmdi_blind_resdictlist_vervals = [subd['ver'] for subd in flag_rfcmdi_blind_resdictlist]
			if '1' in flag_rfcmdi_blind_resdictlist_vervals:
				flag_rfcmdi_blind_ver = '1'
				flag_rfcmdi_blind_val = [subd for subd in flag_rfcmdi_blind_resdictlist if subd['ver'] == '1']
				return flag_rfcmdi_blind_ver, flag_rfcmdi_blind_val
			else:
				if len(set(flag_rfcmdi_blind_resdictlist_vervals)) == 1 and flag_rfcmdi_blind_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Mod+ CPP/RFC Inconsistency Flag:
def rfcparb_cpp_calc(input_dict):
	try:
		if not input_dict['s3mteq'] or not input_dict['rfc']:
			return 'U', []

		flag_rfcparb_cpp_resdictlist = []
		for k,v in input_dict['s3mteq'].iteritems():

			if v['s3parbcpp'] not in ['4', '5'] and '3' not in v['s3parbcpp']:
				flag_rfcparb_cpp_resdictlist.append({'nm':'flag_rfcparb_cpp_val', 'ver':'U', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:

				# Locate all relevant RFC findings for comparison:
				rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's3mteq', v['ORD_NUM'], 'rfc', 'after')

				if not rfc_tgt_key_list:
					flag_rfcparb_cpp_resdictlist.append({'nm':'flag_rfcparb_cpp_val', 'ver':'U', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					for rfc_k,rfc_v in input_dict['rfc'].iteritems():
						if rfc_k in rfc_tgt_key_list:

							if rfc_v['rfcmentalcpppresent'] == '1':
								flag_rfcparb_cpp_resdictlist.append({'nm':'flag_rfcparb_cpp_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
							else:
								# Additionally search manually for CPP-related RFC language:
								# OPENQ: Is this really different from 'rfcmentalcpppresent' search coverage?
								rfctxt = rfc_v['rfctxt']
								rfc_parblol_clarifying_search1 = re.search(r"simple|routine|unskilled|not ?skilled|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|unskilled ?(work|tasks)|simple ?tasks|simple,? ?routine|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|specific-? ?vocational-? ?preparation|\bsvp\b|unskilled|(\blow|\blower|\bless|\breduced)-? ?stress|non-production|production-? ?pace|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfctxt, re.I)
								rfc_parblol_clarifying_search2 = re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfctxt, re.I)
								rfc_parblol_clarifying_search3 = re.search(r"production.?(rate|pace)|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfctxt, re.I)
								rfc_parblol_clarifying_search4 = re.search(r"unskilled|semi-?skilled|(no|not) ?detailed|step.?task", rfctxt, re.I)
								rfc_parblol_clarifying_search5 = re.search(r"chang\w* ?in ? \w* ?(workplace|work|setting|job|employment|task)|(workplace|work|setting|task|job) ?change", rfctxt, re.I)
								rfc_parblol_clarifying_search6 = re.search(r"\bsteps\b|\bstep\b|\brote\b|\bsimple\b|\bquota|\bpaced\b|\bpace\b|\bpersist|\bconcentrat|(\bnormal|\bregular) ?break", rfctxt, re.I)
								if bool(rfc_parblol_clarifying_search1) or bool(rfc_parblol_clarifying_search2) or bool(rfc_parblol_clarifying_search3) or bool(rfc_parblol_clarifying_search4) or bool(rfc_parblol_clarifying_search5) or bool(rfc_parblol_clarifying_search6):
									flag_rfcparb_cpp_resdictlist.append({'nm':'flag_rfcparb_cpp_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
								else:
									flag_rfcparb_cpp_resdictlist.append({'nm':'flag_rfcparb_cpp_val', 'ver':'1', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})

		# Finalize results:
		if not flag_rfcparb_cpp_resdictlist:
			logger.critical('iq.rfcparb_cpp_calc.flag_rfcparb_cpp_resdictlist empty!')
			return 'U', []
		else:
			flag_rfcparb_cpp_resdictlist_vervals = [subd['ver'] for subd in flag_rfcparb_cpp_resdictlist]
			if '1' in flag_rfcparb_cpp_resdictlist_vervals:
				flag_rfcparb_cpp_ver = '1'
				flag_rfcparb_cpp_val = [subd for subd in flag_rfcparb_cpp_resdictlist if subd['ver'] == '1']
				return flag_rfcparb_cpp_ver, flag_rfcparb_cpp_val
			else:
				if len(set(flag_rfcparb_cpp_resdictlist_vervals)) == 1 and flag_rfcparb_cpp_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Mod+ SF/RFC Inconsistency Flag:
def rfcparb_sf_calc(input_dict):
	try:

		if not input_dict['s3mteq'] or not input_dict['rfc']:
			return 'U', []

		flag_rfcparb_sf_resdictlist = []
		for k,v in input_dict['s3mteq'].iteritems():

			if v['s3parbsf'] not in ['4', '5'] and '3' not in v['s3parbsf']:
				flag_rfcparb_sf_resdictlist.append({'nm':'flag_rfcparb_sf_val', 'ver':'U', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:

				# Locate all relevant RFC findings for comparison:
				rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's3mteq', v['ORD_NUM'], 'rfc', 'after')

				if not rfc_tgt_key_list:
					flag_rfcparb_sf_resdictlist.append({'nm':'flag_rfcparb_sf_val', 'ver':'U', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					for rfc_k,rfc_v in input_dict['rfc'].iteritems():
						if rfc_k in rfc_tgt_key_list:

							if rfc_v['rfcmentalsfintanypresent'] == '1':
								flag_rfcparb_sf_resdictlist.append({'nm':'flag_rfcparb_sf_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
							else:
								# Search manually for sf-related RFC language:
								rfctxt = rfc_v['rfctxt']
								rfc_parblol_clarifying_search4 = re.search(r"\bgeneral ?public|public(!? speaking)|non-public|\bthe ?public\b", rfctxt, re.I)
								rfc_parblol_clarifying_search5 = re.search(r"\bsocial|interaction|interact ?with|public|co-workers|coworkers|colleagues|supervisor|superiors|non-confrontation|(objects|things) ?rather ?than ?people|object-focused|objects ?rather|social ?functioning|proximity( ?to ?| ?with ?)others|others|other ?people", rfctxt, re.I)
								rfc_parblol_clarifying_search6 = re.search(r"\bpeople|\bsupervision|\binterpersonal", rfctxt, re.I)
								if bool(rfc_parblol_clarifying_search4) or bool(rfc_parblol_clarifying_search5) or bool(rfc_parblol_clarifying_search6):
									flag_rfcparb_sf_resdictlist.append({'nm':'flag_rfcparb_sf_val', 'ver':'0', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
								else:
									flag_rfcparb_sf_resdictlist.append({'nm':'flag_rfcparb_sf_val', 'ver':'1', 'val':'U', 'cn1':'s3mteq', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})

		# Finalize results:
		if not flag_rfcparb_sf_resdictlist:
			logger.critical('iq.rfcparb_sf_calc.flag_rfcparb_sf_resdictlist empty!')
			return 'U', []
		else:
			flag_rfcparb_sf_resdictlist_vervals = [subd['ver'] for subd in flag_rfcparb_sf_resdictlist]
			if '1' in flag_rfcparb_sf_resdictlist_vervals:
				flag_rfcparb_sf_ver = '1'
				flag_rfcparb_sf_val = [subd for subd in flag_rfcparb_sf_resdictlist if subd['ver'] == '1']
				return flag_rfcparb_sf_ver, flag_rfcparb_sf_val
			else:
				if len(set(flag_rfcparb_sf_resdictlist_vervals)) == 1 and flag_rfcparb_sf_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) RFC Inability to Sustain Language Parser:
def rfcits_calc(input_dict):
	try:
		if not input_dict['rfc']:
			return 'U', []

		flag_rfcits_resdictlist = []
		for k,v in input_dict['rfc'].iteritems():

			rfctxt = v['rfctxt']
			its_results = its.classify(rfctxt)
			if len([tup for tup in its_results if tup[1] == 'y']) != 0:
				flag_its_val = ' /// '.join([tup[0] for tup in its_results if tup[1] == 'y'])
				flag_rfcits_resdictlist.append({'nm':'flag_rfcits_val', 'ver':'1', 'val':flag_its_val, 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				if len([tup for tup in its_results if tup[1] == 'E']) != 0:
					flag_rfcits_resdictlist.append({'nm':'flag_rfcits_val', 'ver':'E', 'val':'U', 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					flag_rfcits_resdictlist.append({'nm':'flag_rfcits_val', 'ver':'0', 'val':'U', 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_rfcits_resdictlist:
			logger.critical('iq.rfcits_calc.flag_rfcits_resdictlist empty!')
			return 'U', []
		else:
			flag_rfcits_resdictlist_vervals = [subd['ver'] for subd in flag_rfcits_resdictlist]
			if '1' in flag_rfcits_resdictlist_vervals:
				flag_rfcits_ver = '1'
				flag_rfcits_val = [subd for subd in flag_rfcits_resdictlist if subd['ver'] == '1']
				return flag_rfcits_ver, flag_rfcits_val
			else:
				if len(set(flag_rfcits_resdictlist_vervals)) == 1 and flag_rfcits_resdictlist_vervals[0] == '0':
					return '0', []
				elif len(set(flag_rfcits_resdictlist_vervals)) == 1 and flag_rfcits_resdictlist_vervals[0] == 'E':
					return 'E', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) RFC Logical Work Capacity Conflict Parser:
# TODO: Later nuance this parser to support parsing of
# 'unfavorable portion' of PFAVs.
def rfc_logicconflict_calc(input_dict):
	'''If unfavorable decision with 1+ RFCs,
	determines whether the content of the RFC
	contains individual exertional capacity levels
	that logically conflict with the Step 4 or 5
	finding that the claimant is capable of performing
	work.

	Args:
		input_dict {dict}
	Returns:
		flag_rfc_logicconflict_ver {str}
		flag_rfc_logicconflict_val {list}: A list of
			dicts where each dict = a discrete quality flag entity
			(typically related to a particular finding observation
			or cluster of observations).  Here, each dict's 'val'
			contains a semicolon-divided string of logic conflict
			type values (e.g. '1; 2', '1', etc.).
	Raises:
		N/A
	'''
	try:
		if not input_dict['rfc']:
			return 'U', []

		# Verify decision is unfavorable:
		# OPENQ: Use structured data for this?
		disptype_list = gather_container_tgt(input_dict, 'claimdisp', 'disptype', 'U', 'U', 'U')
		if len(disptype_list) != len([dtype for dtype in disptype_list if dtype in ['1', '2']]):
			return 'U', []

		flag_rfc_logicconflict_resdictlist = []
		for k,v in input_dict['rfc'].iteritems():

			logicconflict_reslist = []
			# (TEMPORARILY DISABLED PENDING FURTHER REFINEMENT 07/11/2017)
			# Scenario 1: Combined sit/stand/walk capacity < 8:
			# rfcsitlol_parsed = 'U'
			# rfcstandlol_parsed = 'U'
			# rfcwalklol_parsed = 'U'
			# rfcsitlol = v['rfcsitlol']
			# if rfcsitlol.isdigit():
				# rfcsitlol_parsed = int(rfcsitlol)
			# rfcstandlol = v['rfcstandlol']
			# if rfcstandlol.isdigit():
				# rfcstandlol_parsed = int(rfcstandlol)
				# rfcstandlol_parsed = int(rfcstandlol)
			# rfcwalklol = v['rfcwalklol']
			# if rfcwalklol.isdigit():
				# rfcwalklol_parsed = int(rfcwalklol)
			# if rfcsitlol_parsed != 'U' and rfcstandlol_parsed != 'U' and rfcwalklol_parsed != 'U':
				# if sum([rfcsitlol_parsed, rfcstandlol_parsed, rfcwalklol_parsed]) < 8:
					# logicconflict_reslist.append('1')

			# Scenario 2: Sedentary exertion + no stooping:
			rfcexlvl_parsed = v['rfcexlvl_parsed'].split('; ')
			if rfcexlvl_parsed and len(rfcexlvl_parsed) == len([exlvl for exlvl in rfcexlvl_parsed if exlvl == 'S']):
				rfcstooplol = v['rfcstooplol']
				if rfcstooplol == 'N':
					logicconflict_reslist.append('2')

			if not logicconflict_reslist:
				flag_rfc_logicconflict_resdictlist.append({'nm':'flag_rfc_logicconflict_val', 'ver':'0', 'val':'U', 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				flag_rfc_logicconflict_resdictlist.append({'nm':'flag_rfc_logicconflict_val', 'ver':'1', 'val':'; '.join(logicconflict_reslist), 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_rfc_logicconflict_resdictlist:
			logger.critical('iq.rfc_logicconflict_calc.flag_rfc_logicconflict_resdictlist empty!')
			return 'U', []
		else:
			flag_rfc_logicconflict_resdictlist_vervals = [subd['ver'] for subd in flag_rfc_logicconflict_resdictlist]
			if '1' in flag_rfc_logicconflict_resdictlist_vervals:
				flag_rfc_logicconflict_ver = '1'
				flag_rfc_logicconflict_val = [subd for subd in flag_rfc_logicconflict_resdictlist if subd['ver'] == '1']
				return flag_rfc_logicconflict_ver, flag_rfc_logicconflict_val
			else:
				if len(set(flag_rfc_logicconflict_resdictlist_vervals)) == 1 and flag_rfc_logicconflict_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) RFC Language Quality Flags:
# OPENQ: Why can't I migrate these to 'rfcparser'
# similar to the other RFC language quality checks?
def rfc_vague_calc(input_dict):
	try:
		if not input_dict['rfc']:
			return 'U', [], 'U', []

		flag_rfc_vague_gen_resdictlist = []
		flag_rfc_vague_fa_resdictlist = []
		for k,v in input_dict['rfc'].iteritems():

			rfc_vague_gen_reslist = []
			rfc_vague_fa_reslist = []

			rfctxt = v['rfctxt']
			rfclolfa = rfctxt

			# Remove FIT RFC introductory language chunks:
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(After ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that ?the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(The ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", "", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(After ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}through ?the ?date ?last ?insured[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(After ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}since ?attaining ?age ?18[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(After ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}the ?undersigned ?finds ?that[, ]{0,4}based ?on ?the ?current ?impairments[, ]{0,4}the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"(\d\d\. {1,}|\d\. {1,})(After ?careful ?consideration ?of ?the ?entire ?record[, ]{0,4}(the ?undersigned ?finds ?|I ?find ?)that ?the ?claimant ?(has ?had|has|had) ?the ?residual ?functional ?capacity)", " ", rfclolfa, flags=re.I)
			rfclolfa = rfclolfa.strip()

			# Remove FIT exertional language chunks:
			rfclolfa = re.sub(r"perform ?(sedentary|light|medium) ?work ?as ?defined ?in ?in ?(20 ?CFR ?|20 ?C\.F\.R\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\)) ?except", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"perform ?a ?full ?range ?of ?work ?at ?all ?exertional ?levels ?but ?with ?the ?following ?nonexertional ?limitations:", " ", rfclolfa, flags=re.I)
			rfclolfa = re.sub(r"perform ?the ?full ?range ?of(sedentary|light|medium) ?work ?as ?defined ?in ?(20 ?CFR ?|20 ?C\.F\.R\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\))", " ", rfclolfa, flags=re.I)
			rfclolfa = rfclolfa.strip()

			# Remove non-standard FIT exertional language:
			rfclolfa = re.sub(r"^.*as ?defined ?in ?(20 ?CFR ?|20 ?C\.F\.R\. ?)(404\.1567\((a|b|c)\) ?and ?416\.967\((a|b|c)\)|416.967\((a|b|c)\)|404.1567\((a|b|c)\))", " ", rfclolfa, flags=re.I|re.S)
			rfclolfa = re.sub(r"20 ?(c\.f\.\r.|cfr)", " ", rfclolfa, flags=re.I)
			rfclolfa = rfclolfa.strip()

			# Remove lingering FIT introductory/exertional language and trailing FIT language from ends of RFC:
			rfclolfa = re.sub(r"^to ?perform ?", " ", rfclolfa, flags=re.I)
			rfclolfa = rfclolfa.strip()
			rfclolfa = re.sub(r"^except ?", " ", rfclolfa, flags=re.I)
			rfclolfa = rfclolfa.strip()
			rfclolfa = re.sub(r"^(\.|,|:|;|\-)", " ", rfclolfa)
			rfclolfa = rfclolfa.strip()
			rfclolfa = re.sub(r"(In ?making ?this ?finding[, ]{0,4}(the ?undersigned ?has|I ?have) ?considered ?all ?symptoms ?and ?the ?extent).*", " ", rfclolfa, flags=re.I|re.S)
			rfclolfa = rfclolfa.strip()
			rfclolfa = re.sub(r"In ?making ?this ?finding.*", " ", rfclolfa, flags=re.I|re.S)
			rfclolfa = rfclolfa.strip()

			# Normalize/fix RFC text:

			# Normalize spacing and lower case:
			rfclolfa = " ".join(rfclolfa.split())
			rfclolfa = rfclolfa.lower()
			# Correct select quoting-as-letter issues:
			rfclolfa = re.sub(r"(limited|restricted|impeded|constrained|inhibited|limitations|restrictions)([a-z]{1,3})", r"\1", rfclolfa, flags=re.I)
			# Normalize spacing again:
			rfclolfa = " ".join(rfclolfa.split())

			# Split RFC text:

			# Split by full sentences:
			rfcsplit1 = nlp_helper.sentence_splitter(rfclolfa)
			# Split by colons (while re-adding the splitting colons):
			rfcsplit2 = []
			for ss in rfcsplit1:
				sssplit = ss.split(": ")
				if len(sssplit) > 1:
					sssplitcount = 0
					while sssplitcount != (len(sssplit) - 1):
						ssplusdelimiter = str(sssplit[sssplitcount]) + str(": ")
						rfcsplit2.append(ssplusdelimiter)
						sssplitcount += 1
					rfcsplit2.append(sssplit[-1])
				else:
					rfcsplit2.append(sssplit[0])
			# Split by semicolons (while re-adding the splitting semicolons):
			rfcsplit3 = []
			for ss in rfcsplit2:
				sssplit = ss.split("; ")
				if len(sssplit) > 1:
					sssplitcount = 0
					while sssplitcount != (len(sssplit) - 1):
						ssplusdelimiter = str(sssplit[sssplitcount]) + str("; ")
						rfcsplit3.append(ssplusdelimiter)
						sssplitcount += 1
					rfcsplit3.append(sssplit[-1])
				else:
					rfcsplit3.append(sssplit[0])
			# Split by 'never-part-of-list' conjunction terms:
			rfcsplit4 = []
			for ss in rfcsplit3:
				sssplit = re.split(r"\bbut\b|\byet\b|, ?while(?= \w+)|, ?however(?= \w+)|, ?whereas(?= \w+)|, ?except(?= \w+)|, ?with ?the ?exception|, ?only (?!occasional\w*)|, ?only (?!frequent\w*)|, ?only (?!constant\w*)|, ?only (?!concentrated\w*)|, ?only (?!moderate\w*)", ss)
				for item in sssplit:
					item = " ".join(item.split())
					rfcsplit4.append(item)

			# Parse RFC language by SS, looking for deficiencies:
			for ss in rfcsplit4:

				# Perform final normalization of each SS (remove complicating punctuation, normalize spacing/case, etc.):
				ss = ss.replace("\"", " ")
				ss = ss.replace("'", " ")
				ss = " ".join(ss.split())
				ss = ss.lower()
				ss = ss.strip()

				# Vague Language (General):
				rfc_equivocal_findall1 = re.findall(r"\bmight|\bpossibly|\bperhaps|\bconceivably|\bprobably|\blikely|\bmaybe|\bperchance|\bpotentially", ss, re.I)
				if rfc_equivocal_findall1:
					for tup in rfc_equivocal_findall1:
						tupmerged = "".join(tup)
						tupmerged = tupmerged.strip()
						tupmerged = "LANG=" + tupmerged
						res_str = tupmerged + ' / ' + 'TEXT=' + ss
						rfc_vague_gen_reslist.append(res_str)

				rfc_equivocal_findall2 = re.findall(r"(extent|if|when|where|if ?at ?all)( ?[A-Za-z0-9\'\"]+ [A-Za-z0-9\'\"]+ ?| ?[A-Za-z0-9\'\"]+ ?| ?)(possible|conceivable|workable|realizable|practical|practicable|available|convenient|feasible|handy|vacant|obtainable|procurable|serviceable|securable|at ?hand\b|free\b|accessible|performable|workable|within ?possibility)", ss)
				if rfc_equivocal_findall2:
					for tup in rfc_equivocal_findall2:
						tupmerged = "".join(tup)
						tupmerged = tupmerged.strip()
						tupmerged = "LANG=" + tupmerged
						res_str = tupmerged + ' / ' + 'TEXT=' + ss
						rfc_vague_gen_reslist.append(res_str)

				rfc_equivocal_findall3 = re.findall(r"(?<!to be as comfortable )(as)( ?)(possible|conceivable|workable|realizable|practical|practicable|available)", ss)
				if rfc_equivocal_findall3:
					for tup in rfc_equivocal_findall3:
						tupmerged = "".join(tup)
						tupmerged = tupmerged.strip()
						tupmerged = "LANG=" + tupmerged
						res_str = tupmerged + ' / ' + 'TEXT=' + ss
						rfc_vague_gen_reslist.append(res_str)

				# Vague 'Category' Reference Without Clarification:
				# 'Postural':
				rfc_vague_facategory_postural_findall1 = re.findall(r"\bposturally\b|\bposturals\b|\bpostural\b", ss)
				if rfc_vague_facategory_postural_findall1:
					rfcclimbpresent = v["rfcclimbpresent"]
					rfcclimbingobjectspresent = v['rfcclimbingobjectspresent']
					rfcbalancepresent = v["rfcbalancepresent"]
					rfcstooppresent = v["rfcstooppresent"]
					rfckneelpresent = v["rfckneelpresent"]
					rfccrouchpresent = v["rfccrouchpresent"]
					rfccrawlpresent = v["rfccrawlpresent"]
					if len([value for value in [rfcclimbpresent, rfcbalancepresent, rfcstooppresent, rfckneelpresent, rfccrouchpresent, rfccrawlpresent, rfcclimbingobjectspresent] if value == '1']) == 0:
						for tup in rfc_vague_facategory_postural_findall1:
							tupmerged = "".join(tup)
							tupmerged = tupmerged.strip()
							tupmerged = "LANG=" + tupmerged
							res_str = tupmerged + ' / ' + 'TEXT=' + ss
							rfc_vague_fa_reslist.append(res_str)
				# 'Manipulative':
				rfc_vague_facategory_manip_findall1 = re.findall(r"\bmanipulatives\b|\bmanipulative\b", ss)
				if rfc_vague_facategory_manip_findall1:
					rfchandlepresent = v["rfchandlepresent"]
					rfcfingerpresent = v["rfcfingerpresent"]
					rfcfeelpresent = v["rfcfeelpresent"]
					if len([value for value in [rfchandlepresent, rfcfingerpresent, rfcfeelpresent] if value == '1']) == 0:
						if bool(re.search(r"\bhands\w*|\bgrasp\w*|\bfinger\b|\bfingers\b|\bfingering\b|\bfingered\b|\bfine ?manipulat\w*|\bhandle\b|\bhandles\b|\bhandling\b|\bhandled\b|\bfeel\b|\bfeeling\b|\bgrip\b|\bgripping\b|\bmanual ?dexterity\b", rfclolfa)) is False:
							for tup in rfc_vague_facategory_manip_findall1:
								tupmerged = "".join(tup)
								tupmerged = tupmerged.strip()
								tupmerged = "LANG=" + tupmerged
								res_str = tupmerged + ' / ' + 'TEXT=' + ss
								rfc_vague_fa_reslist.append(res_str)
				# 'Visual':
				rfc_vague_facategory_visual_findall1 = re.findall(r"(?<!fine )(?<!near )(?<!far )(?<!near-)(?<!far-)\bsight\b|(?<!fine )(?<!near )(?<!far )(?<!near-)(?<!far-)(?<!binocular)(\bvisual\b|\bvisually\b)(?! accomodation)(?! field)", ss)
				if rfc_vague_facategory_visual_findall1:
					rfcnearacuitypresent = v["rfcnearacuitypresent"]
					rfcfaracuitypresent = v["rfcfaracuitypresent"]
					rfcdepthperceptionpresent = v["rfcdepthperceptionpresent"]
					rfcaccomodationpresent = v["rfcaccomodationpresent"]
					rfccolorvisionpresent = v["rfccolorvisionpresent"]
					rfcfieldofvisionpresent = v["rfcfieldofvisionpresent"]
					if len([value for value in [rfcnearacuitypresent, rfcfaracuitypresent, rfcdepthperceptionpresent, rfcaccomodationpresent, rfccolorvisionpresent, rfcfieldofvisionpresent] if value == '1']) == 0:
						for tup in rfc_vague_facategory_visual_findall1:
							tupmerged = "".join(tup)
							tupmerged = tupmerged.strip()
							tupmerged = "LANG=" + tupmerged
							res_str = tupmerged + ' / ' + 'TEXT=' + ss
							rfc_vague_fa_reslist.append(res_str)

			# Parse RFC-wise results:
			if not rfc_vague_gen_reslist:
				flag_rfc_vague_gen_resdictlist.append({'nm':'flag_rfc_vague_gen_val', 'ver':'0', 'val':'U', 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				flag_rfc_vague_gen_resdictlist.append({'nm':'flag_rfc_vague_gen_val', 'ver':'1', 'val':' /// '.join(rfc_vague_gen_reslist), 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			if not rfc_vague_fa_reslist:
				flag_rfc_vague_fa_resdictlist.append({'nm':'flag_rfc_vague_fa_val', 'ver':'0', 'val':'U', 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				flag_rfc_vague_fa_resdictlist.append({'nm':'flag_rfc_vague_fa_val', 'ver':'1', 'val':' /// '.join(rfc_vague_fa_reslist), 'cn1':'rfc', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})


		# Finalize results:
		flag_rfc_vague_gen_ver = 'U'
		flag_rfc_vague_gen_val = []
		flag_rfc_vague_fa_ver = 'U'
		flag_rfc_vague_fa_val = []

		if not flag_rfc_vague_gen_resdictlist:
			logger.critical('iq.rfc_vague_calc.flag_rfc_vague_gen_resdictlist empty!')
			flag_rfc_vague_gen_ver = 'U'
		else:
			flag_rfc_vague_gen_resdictlist_vervals = [subd['ver'] for subd in flag_rfc_vague_gen_resdictlist]
			if '1' in flag_rfc_vague_gen_resdictlist_vervals:
				flag_rfc_vague_gen_ver = '1'
				flag_rfc_vague_gen_val = [subd for subd in flag_rfc_vague_gen_resdictlist if subd['ver'] == '1']
			else:
				if len(set(flag_rfc_vague_gen_resdictlist_vervals)) == 1 and flag_rfc_vague_gen_resdictlist_vervals[0] == '0':
					flag_rfc_vague_gen_ver = '0'
				else:
					flag_rfc_vague_gen_ver = 'U'

		if not flag_rfc_vague_fa_resdictlist:
			logger.critical('iq.rfc_vague_calc.flag_rfc_vague_fa_resdictlist empty!')
			flag_rfc_vague_fa_ver = 'U'
		else:
			flag_rfc_vague_fa_resdictlist_vervals = [subd['ver'] for subd in flag_rfc_vague_fa_resdictlist]
			if '1' in flag_rfc_vague_fa_resdictlist_vervals:
				flag_rfc_vague_fa_ver = '1'
				flag_rfc_vague_fa_val = [subd for subd in flag_rfc_vague_fa_resdictlist if subd['ver'] == '1']
			else:
				if len(set(flag_rfc_vague_fa_resdictlist_vervals)) == 1 and flag_rfc_vague_fa_resdictlist_vervals[0] == '0':
					flag_rfc_vague_fa_ver = '0'
				else:
					flag_rfc_vague_fa_ver = 'U'

		return flag_rfc_vague_gen_ver, flag_rfc_vague_gen_val, flag_rfc_vague_fa_ver, flag_rfc_vague_fa_val

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', [], 'E', []


# (X) Step 4 'Can Perform PRW' Finding, But No 'Actually/Generally
# Performed' Subfinding Language Detected Flag:
def s4ver1s4actgenU_calc(input_dict, input_dec_str):
	try:
		if not input_dict['s4']:
			return 'U', []

		flag_s4ver1s4actgenu_resdictlist = []
		for k,v in input_dict['s4'].iteritems():

			if '1' not in v['s4ver']:
				flag_s4ver1s4actgenu_resdictlist.append({'nm':'flag_s4ver1s4actgenu_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# Examine body text for actual/general performance language:
				if not isinstance(v['loc_end'], int):
					flag_s4ver1s4actgenu_resdictlist.append({'nm':'flag_s4ver1s4actgenu_val', 'ver':'E', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					if isinstance(v['body_loc_end'], int):
						s4_body_txt = input_dec_str[v['loc_end']:v['body_loc_end']]
					else:
						s4_body_txt = input_dec_str[v['loc_end']:]
					actgenlangpresentver = 0
					s4actgen_regexlist = [rs.actually_words_regex, rs.performed_in_economy_regex, rs.generally_words_regex, r'\bactually\b', r'\bgenerally\b', r'\bcustomarily\b']
					for regex in s4actgen_regexlist:
						if bool(re.search(regex, s4_body_txt, re.I)):
							actgenlangpresentver = 1
							break

					if actgenlangpresentver == 1:
						flag_s4ver1s4actgenu_resdictlist.append({'nm':'flag_s4ver1s4actgenu_val', 'ver':'0', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s4ver1s4actgenu_resdictlist.append({'nm':'flag_s4ver1s4actgenu_val', 'ver':'1', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s4ver1s4actgenu_resdictlist:
			logger.critical('iq.s4ver1s4actgenU_calc.flag_s4ver1s4actgenu_resdictlist empty!')
			return 'U', []
		else:
			flag_s4ver1s4actgenu_resdictlist_vervals = [subd['ver'] for subd in flag_s4ver1s4actgenu_resdictlist]
			if '1' in flag_s4ver1s4actgenu_resdictlist_vervals:
				flag_s4ver1s4actgenu_ver = '1'
				flag_s4ver1s4actgenu_val = [subd for subd in flag_s4ver1s4actgenu_resdictlist if subd['ver'] == '1']
				return flag_s4ver1s4actgenu_ver, flag_s4ver1s4actgenu_val
			else:
				if len(set(flag_s4ver1s4actgenu_resdictlist_vervals)) == 1 and flag_s4ver1s4actgenu_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 4 DOT # Lookup Error Checker:
def s4dot_lookuperr_calc(input_dict):
	try:
		if not input_dict['s4'] or not input_dict['s4dot']:
			return 'U', []

		flag_s4dot_lookuperr_resdictlist = []
		for k,v in input_dict['s4'].iteritems():

			# Get all 's4dot.s4dotnum' values associated with this 'ORD_NUM':
			s4dot_list = gather_container_tgt(input_dict, 's4dot', 's4dotnum', 'U', 'S4_ORD_NUM', v['ORD_NUM'])
			# Remove claimant SSN values (and xref value) that may be erroneously
			# present (from margin text):
			s4dot_list = [dot for dot in s4dot_list if dot not in [input_dict['ssn'], input_dict['ssnxref']]]

			# If none, assign 'U':
			if not s4dot_list:
				flag_s4dot_lookuperr_resdictlist.append({'nm':'flag_s4dot_lookuperr_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				s4dot_lookuperr_reslist = []
				for dot in s4dot_list:
					lookuperr_res = iqcc.dotlookupcheck(dot)
					if not lookuperr_res:
						s4dot_lookuperr_reslist.append(dot)

				if not s4dot_lookuperr_reslist:
					flag_s4dot_lookuperr_resdictlist.append({'nm':'flag_s4dot_lookuperr_val', 'ver':'0', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					flag_s4dot_lookuperr_resdictlist.append({'nm':'flag_s4dot_lookuperr_val', 'ver':'1', 'val':'; '.join(s4dot_lookuperr_reslist), 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s4dot_lookuperr_resdictlist:
			logger.critical('iq.s4dot_lookuperr_calc.flag_s4dot_lookuperr_resdictlist empty!')
			return 'U', []
		else:
			flag_s4dot_lookuperr_resdictlist_vervals = [subd['ver'] for subd in flag_s4dot_lookuperr_resdictlist]
			if '1' in flag_s4dot_lookuperr_resdictlist_vervals:
				flag_s4dot_lookuperr_ver = '1'
				flag_s4dot_lookuperr_val = [subd for subd in flag_s4dot_lookuperr_resdictlist if subd['ver'] == '1']
				return flag_s4dot_lookuperr_ver, flag_s4dot_lookuperr_val
			else:
				if len(set(flag_s4dot_lookuperr_resdictlist_vervals)) == 1 and flag_s4dot_lookuperr_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 4 'Can Perform PRW' Finding Heading & Finding Text
# Past Work DOT # Job Requirements vs. RFC Flag Tool:
def s4dotrfc_calc(input_dict, input_dec_str):
	try:
		if not input_dict['rfc'] or not input_dict['s4'] or not input_dict['s4dot']:
			return 'U', []

		flag_s4dotrfc_resdictlist = []
		for k,v in input_dict['s4'].iteritems():

			if v['s4ver'] != '1':
				flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:

				# Locate all relevant RFC findings for comparison:
				rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's4', v['ORD_NUM'], 'rfc', 'before')
				if not rfc_tgt_key_list:
					flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Get all 's4dot.s4dotnum' values associated with this 'ORD_NUM':
					s4dot_list = gather_container_tgt(input_dict, 's4dot', 's4dotnum', 'U', 'S4_ORD_NUM', v['ORD_NUM'])
					# Remove claimant SSN values (and xref value) that may be erroneously
					# present (from margin text):
					s4dot_list = [dot for dot in s4dot_list if dot not in [input_dict['ssn'], input_dict['ssnxref']]]
					if not s4dot_list:
						flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						for rfc_k,rfc_v in input_dict['rfc'].iteritems():
							if rfc_v['ORD_NUM'] in rfc_tgt_key_list:
								# Analyze for RFC/DOT conflicts:
								# TIP: Ex. Output: {'111111111':'0', '222222222':'E': '333333333':['str', 'str']}.
								s4dotrfc_conflict_resdict = iqcc.dotvsrfc(rfc_v, s4dot_list)
								s4dotrfc_conflict_resdict_vals = s4dotrfc_conflict_resdict.values()
								if len([rv for rv in s4dotrfc_conflict_resdict_vals if isinstance(rv, list)]) != 0:
									s4dotrfc_conflict_posvaldict = {}
									for ck,cv in s4dotrfc_conflict_resdict.iteritems():
										if isinstance(cv, list):
											s4dotrfc_conflict_posvaldict[ck] = cv
									flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'1', 'val':str(s4dotrfc_conflict_posvaldict), 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
								else:
									if len(s4dotrfc_conflict_resdict_vals) == len([rd for rd in s4dotrfc_conflict_resdict_vals if rd == '0']):
										flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'0', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
									else:
										flag_s4dotrfc_resdictlist.append({'nm':'flag_s4dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s4', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})

		# Finalize results:
		if not flag_s4dotrfc_resdictlist:
			logger.critical('iq.s4dotrfc_calc.flag_s4dotrfc_resdictlist empty!')
			return 'U', []
		else:
			flag_s4dotrfc_resdictlist_vervals = [subd['ver'] for subd in flag_s4dotrfc_resdictlist]
			if '1' in flag_s4dotrfc_resdictlist_vervals:
				flag_s4dotrfc_conflict_ver = '1'
				flag_s4dotrfc_conflict_val = [s for s in flag_s4dotrfc_resdictlist if s['ver'] == '1']
				return flag_s4dotrfc_conflict_ver, flag_s4dotrfc_conflict_val
			else:
				if len(set(flag_s4dotrfc_resdictlist_vervals)) == 1 and flag_s4dotrfc_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR Lookup Error Flag:
def s5mvrlookuperr_calc(input_dict):
	try:
		# TIP: Ex. output: [{'s5mvr':'201.44', 'S5_ORD_NUM':0}, {'s5mvr':'202.38', 'S5_ORD_NUM':1}].
		if not input_dict['s5'] or not input_dict['s5mvrlookuperr']:
			return 'U', []

		flag_s5mvrlookuperr_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Gather all s5mvrlookuperr dict values associated with this 's5' instance:
			s5mvrlookuperr_list = [d for d in input_dict['s5mvrlookuperr'] if d['S5_ORD_NUM'] == v['ORD_NUM']]
			if not s5mvrlookuperr_list:
				flag_s5mvrlookuperr_resdictlist.append({'nm':'flag_s5mvrlookuperr_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				s5mvrlookuperr_valstr = '; '.join([d['s5mvr'] for d in input_dict['s5mvrlookuperr'] if d['S5_ORD_NUM'] == v['ORD_NUM']])
				flag_s5mvrlookuperr_resdictlist.append({'nm':'flag_s5mvrlookuperr_val', 'ver':'1', 'val':s5mvrlookuperr_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5mvrlookuperr_resdictlist:
			logger.critical('iq.s5mvrlookuperr_calc.flag_s5mvrlookuperr_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvrlookuperr_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvrlookuperr_resdictlist]
			if '1' in flag_s5mvrlookuperr_resdictlist_vervals:
				flag_s5mvrlookuperr_ver = '1'
				flag_s5mvrlookuperr_val = [subd for subd in flag_s5mvrlookuperr_resdictlist if subd['ver'] == '1']
				return flag_s5mvrlookuperr_ver, flag_s5mvrlookuperr_val
			else:
				if len(set(flag_s5mvrlookuperr_resdictlist_vervals)) == 1 and flag_s5mvrlookuperr_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR vs. RFC Ex. Lvl. Flag:
def s5mvrrfcexlvl_calc(input_dict):
	'''Compare Step 5 MVRs to RFC exertional level(s).
	'''
	try:
		if not input_dict['mvr'] or not input_dict['s5'] or not input_dict['rfc']:
			return 'U', []

		flag_s5mvrrfcexlvl_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				flag_s5mvrrfcexlvl_resdictlist_TEMP = []

				# Get all relevant RFCs:
				rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's5', v['ORD_NUM'], 'rfc', 'before')
				if not rfc_tgt_key_list:
					flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Compare 'rfcexlvl_parsed' value to MVR(s):
					for rfck,rfcv in input_dict['rfc'].iteritems():
						if rfcv['ORD_NUM'] in rfc_tgt_key_list:
							rfcexlvl_parsed = rfcv['rfcexlvl_parsed']
							if rfcexlvl_parsed in ['U', 'P', 'E', '']:
								flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
							else:
								rfc_exlvl_list = rfcexlvl_parsed.split('; ')
								mvrexlvl_dict = {}
								for mvr in s5mvr_list:
									if mvr not in ['201.00', '202.00', '203.00', '204.00']:
										mvrexlvl = iqdl.mvrdf.loc[mvr]['ex_lvl']
										mvrexlvl_dict[mvr] = mvrexlvl
								if not mvrexlvl_dict or len(mvrexlvl_dict) != len(s5mvr_list):
									flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
								else:
									# TIP: For this particular RFC and its exlvl's, is this RFC
									# consistent insofar as at least 1 of its exlvl's matches an
									# exlvl in this particular Step 5 finding's MVRs?
									rfcmvr_noconsistent_ver = 0
									mvrexlvl_dict_vallist = mvrexlvl_dict.values()
									if set(rfc_exlvl_list).isdisjoint(mvrexlvl_dict_vallist):
										flag_s5mvrrfcexlvl_resdictlist_TEMP.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'1', 'val':rfc_exlvl_list, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
									else:
										flag_s5mvrrfcexlvl_resdictlist_TEMP.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})

				# Now before adding this particular Step 5 conflict results to flag_s5mvrrfcexlvl_resdictlist,
				# you must confirm that ALL relevant RFC's exertional levels entirely conflict; otherwise you'll
				# have cases where RFC 1 = 'S' and RFC 2 = 'L', but this thing raises a false positive on RFC 2
				# because the only MVRs = 'S':
				if flag_s5mvrrfcexlvl_resdictlist_TEMP:
					if len([sd for sd in flag_s5mvrrfcexlvl_resdictlist_TEMP if sd['ver'] == '1']) == len(rfc_tgt_key_list):
						rfc_exlvl_list_combined = []
						for resd in flag_s5mvrrfcexlvl_resdictlist_TEMP:
							for exlvl in resd['val']:
								rfc_exlvl_list_combined.append(exlvl)
						s5mvrrfcexlvl_valstr = '%s vs %s' % (str(rfc_exlvl_list_combined), str(list(set(s5mvr_list))))
						flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'1', 'val':s5mvrrfcexlvl_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})
					else:
						flag_s5mvrrfcexlvl_resdictlist.append({'nm':'flag_s5mvrrfcexlvl_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfcv['ORD_NUM']})


		# Finalize results:
		if not flag_s5mvrrfcexlvl_resdictlist:
			logger.critical('iq.s5mvrrfcexlvl_calc.flag_s5mvrrfcexlvl_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvrrfcexlvl_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvrrfcexlvl_resdictlist]
			if '1' in flag_s5mvrrfcexlvl_resdictlist_vervals:
				flag_s5mvrrfcexlvl_ver = '1'
				flag_s5mvrrfcexlvl_val = [subd for subd in flag_s5mvrrfcexlvl_resdictlist if subd['ver'] == '1']
				return flag_s5mvrrfcexlvl_ver, flag_s5mvrrfcexlvl_val
			else:
				if len(set(flag_s5mvrrfcexlvl_resdictlist_vervals)) == 1 and flag_s5mvrrfcexlvl_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR vs. Age Throughout PAI Flag:
# OPENQ: What about weird MVRs like 201.00, 202.00, etc.? Does
# 'mvr' parsing take care to exclude those?
def s5mvragepai_calc(input_dict, decision_txt):
	try:
		if not input_dict['mvr'] or input_dict['STRUCT_AGEREL_PAISTART'] == 'E' or input_dict['STRUCT_AGEREL_PAIEND'] == 'E':
			return 'U', []

		flag_s5mvragepai_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvragepai_resdictlist.append({'nm':'flag_s5mvragepai_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If the MVR list consists *exclusively* of '204.00', then you have
				# nothing to crosscheck here as 204.00 is not associated with any
				# pre-defined age range:
				if len(list(set(s5mvr_list))) == 1 and s5mvr_list[0] == '204.00':
					flag_s5mvragepai_resdictlist.append({'nm':'flag_s5mvragepai_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Retrieve year values from the STRUCT values:
					struct_agerel_paistart = input_dict['STRUCT_AGEREL_PAISTART']
					struct_agerel_paiend = input_dict['STRUCT_AGEREL_PAIEND']
					struct_agerel_paistart_year = int(re.search(r"^\d+", struct_agerel_paistart).group())
					struct_agerel_paiend_year = int(re.search(r"^\d+", struct_agerel_paiend).group())

					# Get all MVR age range data as a list of age numbers UNLESS the MVR == '204.00',
					# as that value has no pre-defined age range; in that case, skip that MVR:
					mvrage1ultimate_errlist = []
					for mvr in s5mvr_list:
						if mvr != '204.00':
							mvr_age_range_min = int(iqdl.mvrdf.loc[mvr]['age_min'])
							mvr_age_range_max = int(iqdl.mvrdf.loc[mvr]['age_max'])
							if mvr_age_range_min > struct_agerel_paiend_year:
								# TIP: Search for borderline age application, which
								# would allow the ALJ to jump to the next age MVR:
								bodytxtsearch = re.search(r"\bborderline ?age\b|\bborderline ?situation\b|25501\.410|25015\.005|II-5-3-2|age ? categories ?(non-?mechanically|mechanically)|apply ?the ?age ?categories ?mechanically|mechanically ?apply ?age ?categories", decision_txt, re.I)
								if bool(bodytxtsearch) is False:
									mvrage1ultimate_errlist.append(mvr)
							if struct_agerel_paistart_year > mvr_age_range_max:
								mvrage1ultimate_errlist.append(mvr)
					if mvrage1ultimate_errlist:
						mvrage1ultimate_valstr = '; '.join(list(set(mvrage1ultimate_errlist)))
						flag_s5mvragepai_resdictlist.append({'nm':'flag_s5mvragepai_val', 'ver':'1', 'val':mvrage1ultimate_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s5mvragepai_resdictlist.append({'nm':'flag_s5mvragepai_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5mvragepai_resdictlist:
			logger.critical('iq.s5mvragepai_calc.flag_s5mvragepai_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvragepai_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvragepai_resdictlist]
			if '1' in flag_s5mvragepai_resdictlist_vervals:
				flag_s5mvragepai_ver = '1'
				flag_s5mvragepai_val = [subd for subd in flag_s5mvragepai_resdictlist if subd['ver'] == '1']
				return flag_s5mvragepai_ver, flag_s5mvragepai_val
			else:
				if len(set(flag_s5mvragepai_resdictlist_vervals)) == 1 and flag_s5mvragepai_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR 1+ = Age at End of PAI Flag:
def s5mvragepaiend_calc(input_dict, decision_txt):
	try:
		if not input_dict['mvr'] or input_dict['STRUCT_AGEREL_PAIEND'] == 'E':
			return 'U', []

		flag_s5mvragepaiend_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvragepaiend_resdictlist.append({'nm':'flag_s5mvragepaiend_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If the MVR list consists *exclusively* of '204.00', then you have
				# nothing to crosscheck here as 204.00 is not associated with any
				# pre-defined age range:
				if len(list(set(s5mvr_list))) == 1 and s5mvr_list[0] == '204.00':
					flag_s5mvragepaiend_resdictlist.append({'nm':'flag_s5mvragepaiend_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:

					# Pull earliest and latest year age year values from the STRUCT values:
					struct_agerel_paiend = input_dict['STRUCT_AGEREL_PAIEND']
					struct_agerel_paiend_year = int(re.search(r"^\d+", struct_agerel_paiend).group())

					# Compare PAIEND to MVR age ranges:
					mvr_ageatpai_val_list = []
					for mvr in s5mvr_list:
						if bool(mvr.startswith('204')) is False:
							mvr_age_range_min = int(iqdl.mvrdf.loc[mvr]['age_min'])
							mvr_age_range_max = int(iqdl.mvrdf.loc[mvr]['age_max'])
							if mvr_age_range_max >= struct_agerel_paiend_year >= mvr_age_range_min:
								pass
							else:
								bodytxtsearch = re.search(r"\bborderline ?age\b|\bborderline ?situation\b|25501\.410|25015\.005|II-5-3-2|age ? categories ?(non-?mechanically|mechanically)|apply ?the ?age ?categories ?mechanically|mechanically ?apply ?age ?categories", decision_txt, re.I)
								if bool(bodytxtsearch) is False:
									mvr_ageatpai_val_list.append(mvr)
									break
					if len(mvr_ageatpai_val_list) == len(s5mvr_list):
						s5mvragepaiend_valstr = '; '.join(s5mvr_list)
						flag_s5mvragepaiend_resdictlist.append({'nm':'flag_s5mvragepaiend_val', 'ver':'1', 'val':s5mvragepaiend_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s5mvragepaiend_resdictlist.append({'nm':'flag_s5mvragepaiend_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5mvragepaiend_resdictlist:
			logger.critical('iq.s5mvragepaiend_calc.flag_s5mvragepaiend_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvragepaiend_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvragepaiend_resdictlist]
			if '1' in flag_s5mvragepaiend_resdictlist_vervals:
				flag_s5mvragepaiend_ver = '1'
				flag_s5mvragepaiend_val = [subd for subd in flag_s5mvragepaiend_resdictlist if subd['ver'] == '1']
				return flag_s5mvragepaiend_ver, flag_s5mvragepaiend_val
			else:
				if len(set(flag_s5mvragepaiend_resdictlist_vervals)) == 1 and flag_s5mvragepaiend_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR vs. Education Finding:
def s5mvred_calc(input_dict):
	try:
		if not input_dict['mvr'] or input_dict['edver'] in ['U', 'P', 'E', '']:
			return 'U', []

		# Parse the 1 education level(s) found in 'edver':
		# TIP: If it's a multiple entry 'edver' value and high-accuracy "I" multiple entry value, use "I"
		# (as it typically goes to education level findings of "the claimant has X level of education but
		# is unable to communicate in English").
		edver = input_dict['edver'].split('; ')
		edver_ultimate_list = []
		if 'I' in edver:
			edver_ultimate_list.append('I')
		else:
			for ed in edver:
				edver_ultimate_list.append(ed)

		if not edver_ultimate_list:
			logger.critical('iq.s5mvred_calc.edver_ultimate_list empty!')
			return 'U', []

		flag_s5mvred_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvred_resdictlist.append({'nm':'flag_s5mvred_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If the MVR list consists *exclusively* of '204.00', then you have
				# nothing to crosscheck here as 204.00 is not associated with any
				# pre-defined age range:
				if len(list(set(s5mvr_list))) == 1 and s5mvr_list[0] == '204.00':
					flag_s5mvred_resdictlist.append({'nm':'flag_s5mvred_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Determine the ed level value(s) of each Step 5 MVR in 's5mvr_list' UNLESS
					# the MVR == '204.00', as that value has no pre-defined ed level (in that case, skip);
					# then, if ANY is inconsistent with all of the 'edver' values, add that MVR to
					# 'mvredultimate_errlist' and trigger flag:
					mvredultimate_errlist = []
					for mvr in s5mvr_list:
						if bool(mvr.startswith('204')) is False:
							# TIP: Returns a possibly semicolon-divided string.
							mvr_ed_list = iqdl.mvrdf.loc[mvr]['ed']
							mvr_ed_list = mvr_ed_list.split('; ')
							if set(edver_ultimate_list).isdisjoint(set(mvr_ed_list)):
								mvredultimate_errlist.append(mvr)

					if mvredultimate_errlist:
						mvredultimate_valstr = '; '.join(list(set(mvredultimate_errlist)))
						flag_s5mvred_resdictlist.append({'nm':'flag_s5mvred_val', 'ver':'1', 'val':mvredultimate_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s5mvred_resdictlist.append({'nm':'flag_s5mvred_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5mvred_resdictlist:
			logger.critical('iq.s5mvred_calc.flag_s5mvred_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvred_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvred_resdictlist]
			if '1' in flag_s5mvred_resdictlist_vervals:
				flag_s5mvred_ver = '1'
				flag_s5mvred_val = [subd for subd in flag_s5mvred_resdictlist if subd['ver'] == '1']
				return flag_s5mvred_ver, flag_s5mvred_val
			else:
				if len(set(flag_s5mvred_resdictlist_vervals)) == 1 and flag_s5mvred_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR vs. Transferability Finding:
def s5mvrtx_calc(input_dict):
	try:
		if not input_dict['mvr'] or input_dict['txskillsver'] not in ['1', '2']:
			return 'U', []

		txskillsver = input_dict['txskillsver']

		flag_s5mvrtx_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvrtx_resdictlist.append({'nm':'flag_s5mvrtx_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If the MVR list consists *exclusively* of '204.00', then you have
				# nothing to crosscheck here as 204.00 is not associated with any
				# pre-defined age range:
				if len(list(set(s5mvr_list))) == 1 and s5mvr_list[0] == '204.00':
					flag_s5mvrtx_resdictlist.append({'nm':'flag_s5mvrtx_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Extract the 'tx skills' value of each Step 5 MVR in 's5mvr_list' UNLESS the MVR == '204.00', as that
					# value has no pre-defined tx skills level, then if ANY is inconsistent with the 1 'txskillsver' value,
					# add that MVR to 'mvrtxultimate_errlist' and trigger flag:
					# TIP: If 'tx skills' deemed not material, then the MVR should never indicate the CL *has* tx skills
					# (as that would require a finding/rationale).
					mvrtxultimate_errlist = []
					for mvr in s5mvr_list:
						if bool(mvr.startswith('204')) is False:
							# TIP: Returns a single string value (either 'U', 'N', or 'Y').
							mvr_txskills = iqdl.mvrdf.loc[mvr]['txskills']
							if txskillsver == "1":
								if mvr_txskills != "Y":
									mvrtxultimate_errlist.append(mvr)
							elif txskillsver == "2":
								if mvr_txskills == "Y":
									mvrtxultimate_errlist.append(mvr)

					if mvrtxultimate_errlist:
						s5mvrtx_valstr = '; '.join(list(set(mvrtxultimate_errlist)))
						flag_s5mvrtx_resdictlist.append({'nm':'flag_s5mvrtx_val', 'ver':'1', 'val':s5mvrtx_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						flag_s5mvrtx_resdictlist.append({'nm':'flag_s5mvrtx_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5mvrtx_resdictlist:
			logger.critical('iq.s5mvrtx_calc.flag_s5mvrtx_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvrtx_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvrtx_resdictlist]
			if '1' in flag_s5mvrtx_resdictlist_vervals:
				flag_s5mvrtx_ver = '1'
				flag_s5mvrtx_val = [subd for subd in flag_s5mvrtx_resdictlist if subd['ver'] == '1']
				return flag_s5mvrtx_ver, flag_s5mvrtx_val
			else:
				if len(set(flag_s5mvrtx_resdictlist_vervals)) == 1 and flag_s5mvrtx_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 MVR vs. Step 4 'No PRW' Finding:
def s5mvrnoprw_calc(input_dict):
	try:
		if not input_dict['mvr'] or not input_dict['s4'] or not input_dict['s5']:
			return 'U', []

		flag_s5mvrnoprw_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5mvrnoprw_resdictlist.append({'nm':'flag_s5mvrnoprw_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# Get all relevant Step 4 findings:
				s4_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's5', v['ORD_NUM'], 's4', 'before')
				if not s4_tgt_key_list:
					flag_s5mvrnoprw_resdictlist.append({'nm':'flag_s5mvrnoprw_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Compare 's4' no PRW value to MVR(s):
					for s4k, s4v in input_dict['s4'].iteritems():
						if s4v['ORD_NUM'] in s4_tgt_key_list:
							if s4v['s4ver'] != '3':
								flag_s5mvrnoprw_resdictlist.append({'nm':'flag_s5mvrnoprw_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'s4', 'ORD_NUM2':s4v['ORD_NUM']})
							else:
								mvrpastwork_errlist = []
								for mvr in s5mvr_list:
									if mvr not in ['201.00', '202.00', '203.00', '204.00']:
										prev_work_list = iqdl.mvrdf.loc[mvr]['prevwork']
										prev_work_list = prev_work_list.split('; ')
										if 'N' not in prev_work_list:
											# TIP: There are certain MVRs that are 'best choices' because there is no MVR for the
											# exact vocational profile at issue.  These are MVRs 201.06, 201.14, and 201.21.  If
											# one of these MVRs is at issue, do not find its citation inconsistent with the Step 4
											# 'no PRW' finding as it was a 'best choice' scenario.
											# TIP2: Reducing to only 201.21; not sure where others came from.
											# if mvr not in ['201.06', '201.14', '201.21']:
											if mvr not in ['201.21']:
												mvrpastwork_errlist.append(mvr)
								if mvrpastwork_errlist:
									s5mvrnoprw_valstr = '; '.join(mvrpastwork_errlist)
									flag_s5mvrnoprw_resdictlist.append({'nm':'flag_s5mvrnoprw_val', 'ver':'1', 'val':s5mvrnoprw_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'s4', 'ORD_NUM2':s4v['ORD_NUM']})
								else:
									flag_s5mvrnoprw_resdictlist.append({'nm':'flag_s5mvrnoprw_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'s4', 'ORD_NUM2':s4v['ORD_NUM']})

		# Finalize results:
		if not flag_s5mvrnoprw_resdictlist:
			logger.critical('iq.s5mvrnoprw_calc.flag_s5mvrnoprw_resdictlist empty!')
			return 'U', []
		else:
			flag_s5mvrnoprw_resdictlist_vervals = [subd['ver'] for subd in flag_s5mvrnoprw_resdictlist]
			if '1' in flag_s5mvrnoprw_resdictlist_vervals:
				flag_s5mvrnoprw_ver = '1'
				flag_s5mvrnoprw_val = [subd for subd in flag_s5mvrnoprw_resdictlist if subd['ver'] == '1']
				return flag_s5mvrnoprw_ver, flag_s5mvrnoprw_val
			else:
				if len(set(flag_s5mvrnoprw_resdictlist_vervals)) == 1 and flag_s5mvrnoprw_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 Borderline Age Present Flag:
def s5bordage_calc(input_dict, input_dec_str):
	try:
		if not input_dict['mvr'] or not input_dict['claimdisp'] or input_dict['STRUCT_AGEREL_PAIEND'] == 'E':
			return 'U', []

		# If decision not an UNFAV variant, return 'P'; else, proceed:
		disptype_list = gather_container_tgt(input_dict, 'claimdisp', 'disptype', 'U', 'U', 'U')
		if '1' not in disptype_list and '2' not in disptype_list:
			return 'U', []

		flag_s5bordage_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all MVRs associated with this 's5' obs:
			s5mvr_list = gather_container_tgt(input_dict, 'mvr', 's5mvr', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
			if not s5mvr_list:
				flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# If the MVR list consists *exclusively* of '204.00', then you have
				# nothing to crosscheck here as 204.00 is not associated with any
				# pre-defined age range:
				if len(list(set(s5mvr_list))) == 1 and s5mvr_list[0] == '204.00':
					flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:

					borderlineagemvrdict = {'201.23': ['201.17'], '202.16': ['202.09'], '201.21': ['201.12', '201.14'], '202.13': ['202.04', '202.06'], '202.11': ['202.02'], '202.10': ['202.01'], '201.18': ['201.09'], '201.19': ['201.10'], '203.11': ['203.01'], '203.18': ['203.10']}
					borderlineagemvrdict_youngermvr = borderlineagemvrdict.keys()

					# Check if any 'younger' borderline age MVR is cited:
					# TIP: Even if they cite to MVRs covering multiple exertion
					# levels (say for a split ex lvl RFC) or cite to multiple
					# MVRs in the same exertion level (e.g. where they don't make
					# a definitive finding on the CL's education or PRW level), they
					# still cited to the borderline MVR and may need to deal with it).
					bordagemvrpresent = [mvr for mvr in s5mvr_list if mvr in borderlineagemvrdict_youngermvr]
					if not bordagemvrpresent:
						flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:

						# Parse STRUCT_AGEREL_PAIEND:
						struct_age_paiend = input_dict['STRUCT_AGEREL_PAIEND']
						age_year = int(re.search(r"^\d+", struct_age_paiend).group())
						age_mo = int(re.search(r"-(\d+)-", struct_age_paiend).group(1))
						age_mo_total = (age_year * 12) + age_mo

						# For each borderline age younger MVR, if the claimant's age at the end of
						# *any* claim's PAI is within 6 months of the upper boundary of that younger
						# MVR's age range, you have a borderline age scenario:
						bordage_mvrage_reslist = []
						for mvr in bordagemvrpresent:

							# Get total months in this younger MVR's max age:
							mvr_age_range_max = int(iqdl.mvrdf.loc[mvr]['age_max']) + 1
							mvr_age_range_max_months = mvr_age_range_max * 12
							# If difference between the younger MVR's max age and
							# the claimant's age at end of PAI is 6 months or less,
							# a borderline age scenario is present:
							if (mvr_age_range_max_months - age_mo_total) in range(0,7):
								bordage_mvrage_reslist.append(mvr)

						# If no indications of a borderline age scenario, return 'P'; else, proceed:
						if not bordage_mvrage_reslist:
							flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
						else:

							# Check decision text to see if the text contains
							# references to borderline age/regulatory cites
							# consistent with the scenario's presence:

							# Normalize spacing:
							decision = tc.normalize_spacing(input_dec_str)
							# Remove exhibits list:
							decision = re.sub(r"LIST ?OF ?EXHIBITS.*", "", decision)
							# Search for references to borderline age scenarios and/or borderline age regulatory citations.	 If present, consider them 'discussed', else raise flag:
							bodytxtsearch = re.search(r"\bborderline ?age\b|\bborderline ?situation\b|25501\.410|25015\.005|II-5-3-2|age ? categories ?(non-?mechanically|mechanically)|apply ?the ?age ?categories ?mechanically|mechanically ?apply ?age ?categories", decision, re.I)
							if bool(bodytxtsearch) is False:
								s5bordage_valstr = '; '.join(bordage_mvrage_reslist)
								flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'1', 'val':s5bordage_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
							else:
								flag_s5bordage_resdictlist.append({'nm':'flag_s5bordage_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		if not flag_s5bordage_resdictlist:
			logger.critical('iq.s5bordage_calc.flag_s5bordage_resdictlist empty!')
			return 'U', []
		else:
			flag_s5bordage_resdictlist_vervals = [subd['ver'] for subd in flag_s5bordage_resdictlist]
			if '1' in flag_s5bordage_resdictlist_vervals:
				flag_s5bordage_ver = '1'
				flag_s5bordage_val = [subd for subd in flag_s5bordage_resdictlist if subd['ver'] == '1']
				return flag_s5bordage_ver, flag_s5bordage_val
			else:
				if len(set(flag_s5bordage_resdictlist_vervals)) == 1 and flag_s5bordage_resdictlist_vervals[0] == '0':
					return '0', []
				else:
					return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) Step 5 DOT # Lookup Error Checker:
def s5dot_lookuperr_calc(input_dict):
	try:
		if not input_dict['s5'] or not input_dict['s5dot']:
			return 'U', []

		flag_s5dot_lookuperr_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			# Get all 's5dot.s5dotnum' values associated with this 'ORD_NUM':
			s5dot_list = gather_container_tgt(input_dict, 's5dot', 's5dotnum', 'U', 'S5_ORD_NUM', v['ORD_NUM'])

			# Remove claimant SSN values (and xref value) that may be erroneously
			# present (from margin text):
			s5dot_list = [dot for dot in s5dot_list if dot not in [input_dict['ssn'], input_dict['ssnxref']]]

			# If none, assign 'U':
			if not s5dot_list:
				flag_s5dot_lookuperr_resdictlist.append({'nm':'flag_s5dot_lookuperr_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				s5dot_lookuperr_reslist = []
				for dot in s5dot_list:
					lookuperr_res = iqcc.dotlookupcheck(dot)
					if not lookuperr_res:
						s5dot_lookuperr_reslist.append(dot)

				if not s5dot_lookuperr_reslist:
					flag_s5dot_lookuperr_resdictlist.append({'nm':'flag_s5dot_lookuperr_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					flag_s5dot_lookuperr_resdictlist.append({'nm':'flag_s5dot_lookuperr_val', 'ver':'1', 'val':'; '.join(s5dot_lookuperr_reslist), 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})

		# Finalize results:
		flag_s5dot_lookuperr_resdictlist_vervals = [subd['ver'] for subd in flag_s5dot_lookuperr_resdictlist]
		if '1' in flag_s5dot_lookuperr_resdictlist_vervals:
			flag_s5dot_lookuperr_ver = '1'
			flag_s5dot_lookuperr_val = [subd for subd in flag_s5dot_lookuperr_resdictlist if subd['ver'] == '1']
			return flag_s5dot_lookuperr_ver, flag_s5dot_lookuperr_val
		else:
			if len(set(flag_s5dot_lookuperr_resdictlist_vervals)) == 1 and flag_s5dot_lookuperr_resdictlist_vervals[0] == '0':
				return '0', []
			else:
				return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# (X) REVISED Step 5 DOT Job Requirements vs. RFC Flag Tool:
def s5dotrfc_calc(input_dict, input_dec_str):
	try:
		if not input_dict['rfc'] or not input_dict['s5'] or not input_dict['s5dot']:
			return 'U', []

		flag_s5dotrfc_resdictlist = []
		for k,v in input_dict['s5'].iteritems():

			if '1' not in v['s5ver'] and '2' not in v['s5ver']:
				flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
			else:
				# Locate all relevant RFC findings for comparison:
				rfc_tgt_key_list = iqcc.locate_relevant_finding_obs(input_dict, 's5', v['ORD_NUM'], 'rfc', 'before')
				if not rfc_tgt_key_list:
					flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
				else:
					# Get all 's5dot.s5dotnum' values associated with this 'ORD_NUM':
					s5dot_list = gather_container_tgt(input_dict, 's5dot', 's5dotnum', 'U', 'S5_ORD_NUM', v['ORD_NUM'])
					# Remove claimant SSN values (and xref value) that may be erroneously
					# present (from margin text):
					s5dot_list = [dot for dot in s5dot_list if dot not in [input_dict['ssn'], input_dict['ssnxref']]]

					if not s5dot_list:
						flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'U', 'ORD_NUM2':'U'})
					else:
						for rfc_k,rfc_v in input_dict['rfc'].iteritems():
							if rfc_v['ORD_NUM'] in rfc_tgt_key_list:
								# Analyze for RFC/DOT conflicts:
								# TIP: Ex. Output: {'111111111':'0', '222222222':'E': '333333333':['str', 'str']}.
								s5dotrfc_conflict_resdict = iqcc.dotvsrfc(rfc_v, s5dot_list)
								s5dotrfc_conflict_resdict_vals = s5dotrfc_conflict_resdict.values()
								if len([rv for rv in s5dotrfc_conflict_resdict_vals if isinstance(rv, list)]) != 0:
									s5dotrfc_conflict_valstr = str({conflictk:conflictv for conflictk,conflictv in s5dotrfc_conflict_resdict.iteritems() if isinstance(conflictv, list)})
									flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'1', 'val':s5dotrfc_conflict_valstr, 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
								else:
									if len(s5dotrfc_conflict_resdict_vals) == len([rd for rd in s5dotrfc_conflict_resdict_vals if rd == '0']):
										flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'0', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})
									else:
										flag_s5dotrfc_resdictlist.append({'nm':'flag_s5dotrfc_val', 'ver':'U', 'val':'U', 'cn1':'s5', 'ORD_NUM1':str(v['ORD_NUM']), 'cn2':'rfc', 'ORD_NUM2':rfc_v['ORD_NUM']})

		# Finalize results:
		flag_s5dotrfc_conflict_resdictlist_vervals = [subd['ver'] for subd in flag_s5dotrfc_resdictlist]
		if '1' in flag_s5dotrfc_conflict_resdictlist_vervals:
			flag_s5dotrfc_conflict_ver = '1'
			flag_s5dotrfc_conflict_val = [subd for subd in flag_s5dotrfc_resdictlist if subd['ver'] == '1']
			return flag_s5dotrfc_conflict_ver, flag_s5dotrfc_conflict_val
		else:
			if len(set(flag_s5dotrfc_conflict_resdictlist_vervals)) == 1 and flag_s5dotrfc_conflict_resdictlist_vervals[0] == '0':
				return '0', []
			else:
				return 'U', []

	except Exception:
		logger.exception('EXCEPTION')
		return 'E', []


# Define IQ controller function that will call select IQ functions above
# to return a dictionary of IQ data point names and values:
def run(iq_input_dict, iq_decision_str):
	"""Processes data associated with a single INSIGHT decision observation (consisting of
	a dictionary and a processed decision string) to generate additional structured
	data about the quality of that decision observation.

	The dictionary contains both data values extracted from the decision
	string and pre-existing structured data values from systems such as MEDIB and
	MHOADS.	 The input decision text reflects spelling, OCR-focused, and other
	lightweight corrections to the text, as well as trimming to the 'Findings' portion
	of the decision with the 'List of Exhibits' section removed (equivalent to
	ie.decisionfindingsltd).

	Args:
		iq_input_dict: {dict} A dictionary containing structured data values
			related to the decision text passed in iq_decision_str and the
			case that decision text addresses.
		iq_decision_str: {str}: The processed decision text (i.e. the decision
		text string normalized/cleaned by INSIGHT Extract) as a string value.
	Returns:
		A dictionary containing quality-related structured data. If a TypeError
		or exception occurs, 'E' values will be returned.
	Raises:
		N/A.
	"""

	# Create IQ dictionary and set default values:
	iq_dict = {}

	try:
		# Check argument types:
		if bool(isinstance(iq_input_dict, dict)) is False:
			iq_dict = {k:'E' for k,v in iq_dict.iteritems()}
			return iq_dict
		if bool(isinstance(iq_decision_str, str)) is False:
			iq_dict = {k:'E' for k,v in iq_dict.iteritems()}
			return iq_dict

		# Call IQ functions:

		# Step 1:
		# NOTE: Disabling until SEQY data available:
		#iq_dict['flag_s1sgaver1seqy_ver'] = s1sgavsseqy_calc(iq_input_dict, iq_decision_str)
		# IN DEVELOPMENT (see notes in function):
		#iq_dict['flag_s1sgaver234nortl_ver'] = s1sgaver234nortl_ver_calc(iq_input_dict, iq_decision_str)

		# Step 2:
		iq_dict["flag_s2txtsxasmdi_ver"], iq_dict["flag_s2txtsxasmdi_val"], iq_dict["flag_s2txtuncertain_ver"], iq_dict["flag_s2txtuncertain_val"] = s2txtquality_calc(iq_input_dict)
		iq_dict["flag_s2txtonlysx_ver"], iq_dict["flag_s2txtonlysx_val"] = s2txtonlysx_calc(iq_input_dict)
		# NOTE 12.19.2016: Disabling for now; not very helpful.
		# iq_dict['flag_s2mentalmdiparb_ver'] = s2mentalmdiparb_ver_calc(iq_input_dict, iq_decision_str)
		iq_dict["flag_s2mdi_selfwt_ver"], iq_dict["flag_s2mdi_selfwt_val"] = s2mdi_selfwt_calc(iq_input_dict, iq_decision_str)

		# Step 3 Meets/Equals:
		iq_dict['flag_s3ver3nomeref_ver'], iq_dict['flag_s3ver3nomeref_val'] = s3ver3nomeref_calc(iq_input_dict, iq_decision_str)

		# RFC:
		iq_dict['flag_rfcmdi_cts_ver'], iq_dict['flag_rfcmdi_cts_val'] = rfcmdi_cts_calc(iq_input_dict)
		iq_dict['flag_rfcmdi_blind_ver'], iq_dict['flag_rfcmdi_blind_val'] = rfcmdi_blind_calc(iq_input_dict)
		iq_dict['flag_rfcparb_cpp_ver'], iq_dict['flag_rfcparb_cpp_val'] = rfcparb_cpp_calc(iq_input_dict)
		iq_dict['flag_rfcparb_sf_ver'], iq_dict['flag_rfcparb_sf_val'] = rfcparb_sf_calc(iq_input_dict)
		iq_dict['flag_rfcits_ver'], iq_dict['flag_rfcits_val'] = rfcits_calc(iq_input_dict)
		iq_dict['flag_rfc_logicconflict_ver'], iq_dict['flag_rfc_logicconflict_val'] = rfc_logicconflict_calc(iq_input_dict)
		iq_dict["flag_rfc_vague_gen_ver"], iq_dict["flag_rfc_vague_gen_val"], iq_dict["flag_rfc_vague_fa_ver"], iq_dict["flag_rfc_vague_fa_val"] = rfc_vague_calc(iq_input_dict)

		# Step 4:
		iq_dict['flag_s4ver1s4actgenu_ver'], iq_dict['flag_s4ver1s4actgenu_val'] = s4ver1s4actgenU_calc(iq_input_dict, iq_decision_str)
		iq_dict['flag_s4dot_lookuperr_ver'], iq_dict['flag_s4dot_lookuperr_val'] = s4dot_lookuperr_calc(iq_input_dict)
		iq_dict['flag_s4dotrfc_ver'], iq_dict['flag_s4dotrfc_val'] = s4dotrfc_calc(iq_input_dict, iq_decision_str)

		# Step 5:
		iq_dict['flag_s5dot_lookuperr_ver'], iq_dict['flag_s5dot_lookuperr_val'] = s5dot_lookuperr_calc(iq_input_dict)
		iq_dict['flag_s5dotrfc_ver'], iq_dict['flag_s5dotrfc_val'] = s5dotrfc_calc(iq_input_dict, iq_decision_str)
		iq_dict['flag_s5mvrlookuperr_ver'], iq_dict['flag_s5mvrlookuperr_val'] = s5mvrlookuperr_calc(iq_input_dict)
		iq_dict['flag_s5mvrrfcexlvl_ver'], iq_dict['flag_s5mvrrfcexlvl_val'] = s5mvrrfcexlvl_calc(iq_input_dict)
		iq_dict['flag_s5mvragepai_ver'], iq_dict['flag_s5mvragepai_val'] = s5mvragepai_calc(iq_input_dict, iq_decision_str)
		iq_dict['flag_s5mvragepaiend_ver'], iq_dict['flag_s5mvragepaiend_val'] = s5mvragepaiend_calc(iq_input_dict, iq_decision_str)
		iq_dict['flag_s5mvred_ver'], iq_dict['flag_s5mvred_val'] = s5mvred_calc(iq_input_dict)
		iq_dict['flag_s5mvrtx_ver'], iq_dict['flag_s5mvrtx_val'] = s5mvrtx_calc(iq_input_dict)
		iq_dict['flag_s5mvrnoprw_ver'], iq_dict['flag_s5mvrnoprw_val'] = s5mvrnoprw_calc(iq_input_dict)
		iq_dict['flag_s5bordage_ver'], iq_dict['flag_s5bordage_val'] = s5bordage_calc(iq_input_dict, iq_decision_str)

		return iq_dict
	except Exception:
		logger.exception('EXCEPTION')
		iq_dict = {k:'E' for k,v in iq_dict.iteritems()}
		return iq_dict

