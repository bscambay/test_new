﻿namespace INSIGHT_Request.Models
{
    public class PACAR_result
    {
        public int HOFC_WRK_UNIT_UID { get; set; }
        public string CLMT_SSN { get; set; }
        public string CLMT_NM25 { get; set; }
        public string CLM_TYP { get; set; }
        public string HRG_TYP { get; set; }
        public string WKLD_TYP { get; set; }
        public string RQST_RCVDT { get; set; }
        public string HOFC_DSPN_DT { get; set; }
        public string link { get; set; }

    }
}