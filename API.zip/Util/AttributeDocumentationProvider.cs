﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Controllers;
using System.Web.Http.Description;

namespace INSIGHT_Request.Util
{
    public class AttributeDocumentationProvider : IDocumentationProvider
    {
        public string GetDocumentation(HttpControllerDescriptor controllerDescriptor)
        {
            throw new NotImplementedException();
        }
        #region IDocumentationProvider Members

        public string GetDocumentation(HttpParameterDescriptor parameterDescriptor)
        {
            ReflectedHttpParameterDescriptor reflectedParameterDescriptor =
                parameterDescriptor as ReflectedHttpParameterDescriptor;
            if (reflectedParameterDescriptor != null)
            {
                var display = reflectedParameterDescriptor.ParameterInfo
                    .GetCustomAttributes(typeof(DisplayAttribute), false)
                    .OfType<DisplayAttribute>().FirstOrDefault();
                if (display != null)
                    return display.Description;
                else
                    return reflectedParameterDescriptor.ParameterInfo.Name;
            }

            return string.Empty;
        }

        public string GetDocumentation(HttpActionDescriptor actionDescriptor)
        {
            ReflectedHttpActionDescriptor reflectedActionDescriptor =
                actionDescriptor as ReflectedHttpActionDescriptor;
            if (reflectedActionDescriptor != null)
            {
                var display = reflectedActionDescriptor.MethodInfo
                    .GetCustomAttributes(typeof(DisplayAttribute), false)
                    .OfType<DisplayAttribute>().FirstOrDefault();
                if (display != null)
                    return display.Description;
                else
                    return reflectedActionDescriptor.MethodInfo.Name;
            }

            return string.Empty;
        }

        public string GetResponseDocumentation(HttpActionDescriptor actionDescriptor)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
