/// INSIGHT Hearing Level Tools Page JQuery 
/// Author: Kurt Glaze, U.S. Social Security Administration, Office of Appellate Operations, Division of Quality, Br. 9 / Gerald Ray Academy 
/// Date Last Updated: 01.24.2017
/// WARNING: The following is alpha-level/prototype software whose output quality has not 
/// yet been formally validated and whose documentation is not yet fully formed. 
/// Caution is therefore urged in utilizing this software or its output for 
/// programmatic purposes. 
/// ======================================================================================

/// Define JQuery Scripts for Individual 'Full Results' slideToggles
$(document).ready(function(){
	
	
	/// TODO: Migrate Tools page-centric 'myjquery.js' code to this
	/// file.

	$("#alerts_containerdiv").show();
    $("#impexp_containerdiv").show();
    $("#rfcdot_containerdiv").show();
	$("#agecalc_containerdiv").show();
    $("#sso_containerdiv").show();
	
	$("#showhideallbutton").click(function(){
		if (( $("#alerts_containerdiv").css('display') == 'block') || ( $("#impexp_containerdiv").css('display') == 'block') || ( $("#rfcdot_containerdiv").css('display') == 'block') || ( $("#sso_containerdiv").css('display') == 'block') || ( $("#bmi_containerdiv").css('display') == 'block')  || ( $("#agecalc_containerdiv").css('display') == 'block')) {
				$("#alerts_containerdiv").slideUp();
				$("#alerts_moreinfodiv").slideUp();
				$("#impexp_containerdiv").slideUp();
				$("#impexpmoreinfodiv").slideUp();
				$("#rfcdot_containerdiv").slideUp();
				$("#rfcdotmoreinfodiv").slideUp();
				$("#sso_containerdiv").slideUp();
				$("#ssomoreinfodiv").slideUp();
				$("#bmi_containerdiv").slideUp();
				$("#bmimoreinfodiv").slideUp();
				$("#agecalc_moreinfodiv").slideUp();
				$("#agecalc_containerdiv").slideUp();
		} else {
			$("#alerts_moreinfodiv").slideUp();
			$("#impexpmoreinfodiv").slideUp();
			$("#rfcdotmoreinfodiv").slideUp();
			$("#ssomoreinfodiv").slideUp();
			$("#bmimoreinfodiv").slideUp();
			$("#agecalc_moreinfodiv").slideUp();
			$("#alerts_containerdiv").slideDown();
			$("#impexp_containerdiv").slideDown();
			$("#rfcdot_containerdiv").slideDown();
			$("#sso_containerdiv").slideDown();
			$("#bmi_containerdiv").slideDown();
			$("#agecalc_containerdiv").slideDown();
		}
	});
	
	

    $("#alerts_showhide_btn").click(function(){
		if ( $("#alerts_containerdiv").css('display') == 'block'){
				$("#alerts_containerdiv").slideToggle();
				$("#alerts_moreinfodiv").slideUp();
		} else {
			$("#alerts_containerdiv").slideToggle();
		}
    });

    $("#impexp_showhide_btn").click(function(){
		if ( $("#impexp_containerdiv").css('display') == 'block'){
				$("#impexp_containerdiv").slideToggle();
				$("#impexpmoreinfodiv").slideUp();
		} else {
			$("#impexp_containerdiv").slideToggle();
		}
    });
    
    $("#rfcdot_showhide_btn").click(function(){
		if ( $("#rfcdot_containerdiv").css('display') == 'block'){
				$("#rfcdot_containerdiv").slideToggle();
				$("#rfcdotmoreinfodiv").slideUp();
		} else {
			$("#rfcdot_containerdiv").slideToggle();
		}
    });
    
    $("#sso_showhide_btn").click(function(){
		if ( $("#sso_containerdiv").css('display') == 'block'){
				$("#sso_containerdiv").slideToggle();
				$("#ssomoreinfodiv").slideUp();
		} else {
			$("#sso_containerdiv").slideToggle();
		}
    });
	
    $("#bmi_showhide_btn").click(function(){
		if ( $("#bmi_containerdiv").css('display') == 'block'){
				$("#bmi_containerdiv").slideToggle();
				$("#bmimoreinfodiv").slideUp();
		} else {
			$("#bmi_containerdiv").slideToggle();
		}
    });
	
    $("#agecalc_showhide_btn").click(function(){
		if ( $("#agecalc_containerdiv").css('display') == 'block'){
				$("#agecalc_containerdiv").slideToggle();
				$("#agecalc_moreinfodiv").slideUp();
		} else {
			$("#agecalc_containerdiv").slideToggle();
		}
    });
	
});