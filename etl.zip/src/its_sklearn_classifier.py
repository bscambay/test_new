# INSIGHT INABILITY TO SUSTAIN LOGISTIC REGRESSION CLASSIFIER
#
# AUTHOR:
# Kurt Glaze / Eric Kim
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 08.24.2016
#
# SUMMARY:
# A suite of scripts that support a logistic regression classifier algorithm
# designed to take 'raw' disability hearing decision RFC text (INSIGHT
# 'rfctxt' value) as input and output a classification as to whether each
# subsection of it does or does not contain 'inability to sustain' language.
#
# WARNING: The following is alpha-level/prototype software whose output
# quality has not yet been formally validated and whose documentation is not
# yet fully formed.
# ==============================================================================

import logging
import os.path
import re

import numpy as np
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

import regex_strings as rs
import text_cleaner as tc
from its_preprocessing import generate_snippets

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Define non-text features of snippet:
def snippet_features(snippet):
    try:
        features = {}

        snippet = snippet.lower()
        snippet = tc.remove_format_numbers(snippet)

        contains_neg = bool(re.search(rs.neg_words_regex, snippet))
        contains_workplace = bool(re.search(rs.workplace_words_regex, snippet))
        contains_rigor = bool(re.search(rs.rigor_words_regex, snippet))
        contains_work = bool(re.search(rs.work_words_regex, snippet))

        if contains_neg:
            features['contains neg work rigor workplace'] = contains_work and contains_rigor and contains_workplace
            features['contains neg rigor workplace'] = contains_rigor and contains_workplace
            features['contains neg workplace'] = contains_workplace
            features['contains neg rigor'] = contains_rigor
            features['contains neg work'] = contains_work
        else:
            features['contains work rigor workplace'] = contains_work and contains_rigor and contains_workplace
            features['contains rigor workplace'] = contains_rigor and contains_workplace
            features['contains workplace'] = contains_workplace
            features['contains rigor'] = contains_rigor
            features['contains work'] = contains_work

        false_keys = []
        for key in features.iterkeys():
            if not features[key]:
                false_keys.append(key)

        for key in false_keys:
            features.pop(key, None)

        return features
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Append non-text features to snippet:
def add_snippet_features(snippet):
    try:
        features = snippet_features(snippet)
        for key, value in features.iteritems():
            snippet += ' ' + '_'.join(key.split())
            if isinstance(value, bool):
                if value:
                    snippet += '_true'
                else:
                    snippet += '_false'
            else:
                snippet += '_' + str(value)
        return snippet
    except Exception:
        logger.exception('EXCEPTION')
        raise


# Preprocess snippets (cleaning/normalization/adding features):
def preprocess_feature_text(snippet):
    try:
        snippet = tc.final_spelling_corrections(snippet)
        snippet = tc.remove_format_numbers(snippet)
        snippet = add_snippet_features(snippet)
        return snippet
    except Exception:
        logger.exception('EXCEPTION')
        raise


# ITS classifier:
def classify(rfctxt):
    """Classifies whether subsections of RFC text do or do not constitute
    'inability to sustain' language.

    Args:
            rfctxt: {str} A string value containing the text of an RFC finding.
    Returns:
            A list of tuples where tuple[0] = a subsection of the
            RFC text and tuple[1] is its classified label ['y' or 'n'].
    Raises:
            N/A (returns 'E' classifications if exception).
    """
    try:
        rfctxt_snippets = generate_snippets(rfctxt)
        snippet_features_new = [unicode(preprocess_feature_text(snippet)) for snippet in rfctxt_snippets]

        # TIP: The snippets are changed/appended to after preprocessing, so
        # we need the original snippets when appending.
        results = []
        for i in range(len(rfctxt_snippets)):
            results.append((rfctxt_snippets[i], rfc_its_clf.predict(np.array([snippet_features_new[i]]))[0][0]))

        return results
    except Exception:
        logger.exception('EXCEPTION')
        return [(rfctxt, 'E')]


# Generate an ITS classifier from training data:
try:
    df = pandas.read_csv(os.path.join(datadir, "rfcits_mergeddata_08-08-16_152403PM.csv"), dtype=str)
    df = df[df['DOCU_CTL_ID'] != 'EMPTY']

    training_verdict_features = []
    training_verdict_labels = []

    for row_tuple in df.iterrows():
        row = row_tuple[1]

        # TIP: Confirming that we have all neceessary data by row, then creating features and labels:
        if row['DOCU_CTL_ID'] != 'EMPTY' and row['SNIPPET'].split() and (
                row['STRICT_PRESENT?'].lower() == 'y' or row['STRICT_PRESENT?'].lower() == 'n'):

            if row['STRICT_PRESENT?'].lower() == 'y' or row['NONSTRICT_NONCOMPLIANT_PRESENT?'].lower() == 'y':
                label = 'y'
            else:
                label = 'n'
            training_verdict_labels.append(label)

            feature = preprocess_feature_text(row['SNIPPET'])
            training_verdict_features.append(unicode(feature))

    X_training_set = np.array(training_verdict_features)
    y_training_set = np.array(training_verdict_labels)

    vectorizer = TfidfVectorizer(analyzer='word', sublinear_tf=True, lowercase=False, ngram_range=(1, 3))
    its_logrel_clf = LogisticRegression()
    rfc_its_clf = Pipeline([('tfvec', vectorizer), ('clf', its_logrel_clf)])
    rfc_its_clf.fit(X_training_set, y_training_set)

except Exception as ex:
    logger.exception('EXCEPTION: '+str(ex))
    raise