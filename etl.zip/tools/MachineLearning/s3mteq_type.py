# step 3 finding, I don't know what mteq_type is here

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S3VERDICTTYPEFEATURESREV3.txt", 'OneVsRestClassifier', 3, logging_dir)
ml.run()
