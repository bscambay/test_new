# INSIGHT REGEX PATTERN STORAGE
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 09.08.2016

# SUMMARY: 
# Houses certain REGEX patterns used by various components of INSIGHT.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

# TIP: Not loading logging module here as this is a storage script.

# REGEX used in ie_common_calcs for state-to-circuit parsing:
state_search1_regex = r"\b(Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming|District of Columbia|Puerto Rico|Guam|American Samoa|(U.S. )?Virgin Islands|Northern Mariana Islands) ?([\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])(\-[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])?$"
state_search2_regex = r"\b(Ala\.|Alaska|Ariz\.|Ark\.|Calif\.|Colo\.|Conn\.|Del\.|D\.C\.|Fla\.|Ga\.|Hawaii|Idaho|Ill\.|Ind\.|Iowa|Kans\.|Ky\.|La\.|Maine|Md\.|Mass\.|Mich\.|Minn\.|Miss\.|Mo\.|Mont\.|Nebr\.|Nev\.|N\.H\.|N\.J\.|N\. Mex\.|N\.Y\.|N\.C\.|N\. Dak\.|Ohio|Okla\.|Oreg\.|Pa\.|R\.I\.|S\.C\.|S\. Dak\.|Tenn\.|Tex\.|Utah|Vt\.|Va\.|Wash\.|W\. Va\.|Wis\.|Wyo\.|A\.S\.|Guam|M\.P\.|P\.R\.|V\.I\.) ?([\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])(\-[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])?$"
state_search3_regex = r"\b(AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|AS|DC|FM|GU|MH|MP|PW|PR|VI) ?([\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])(\-[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d] ?[\|\]\[L\d])?$"

# REGEX used in text_cleaner:
letter_ssn_search_regex = r'(?:[\dldOl|]\s{,2}){3}-(?:[\dldOl|]\s{,2}){2}-(?:[\dldOl|]\s{,2}){3}[\dldOl|]'
letter_ssn_search2_regex = r'(?:[\dldOl|]\s{0,2}){8}[\dldOl|]'
letter_zip_search_regex = r'(?:[\dldOl|]\s{,3}){4}[\dldOl|]'
letter_mvr_search_regex = r'[\dldOl|]{3}\.[\dldOl|]{2}'
letter_listing_search_regex = r'[\dldOl|]{1,3}\.[\dldOl|]{2}'
see_next_page_regex = r'See\s{,6}Next\s{,6}Page.{5,300}Page\s{,6}\d{1,2}\s{,6}of\s{,6}\d{1,2}'

# REGEX used in text_cleaner.remove_margin_text:
margin_page_number_regex = 'Page\s{,6}\d{1,2}\s{,6}of\s{,6}\d{1,2}'
margin_see_next_page_regex = 'See\s{,6}Next\s{,6}Page'

# REGEX used in nlp_helper (roughly/anecdotally longest to shortest):
# TODO: These will not capture certain outlier names such as
# 'James van der Schalie' or 'Maria de los Santos' or 'Maria Pasos y Mesos'.
# Add in this functionality; consult medical source name REGEXes.

# Fully written first + fully written middle + fully written confirmational/additional name + optional particle + fully written last name + suffix, e.g. "Kurt Aaron Tiberius Glaze, Jr.":
name_search0_regex = r"([A-Z]'?[A-Za-z\-]+ ){3}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))"
# Fully written first + fully written middle + optional particle + fully written last name + optional suffix, e.g. "JoEllen Christine D'Andrea-Doyle", "Ellen Christine Doyle":
name_search1_regex = r"([A-Z]'?[A-Za-z\-]+ ){2}((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?([A-Z]'?[A-Za-z\-]+)((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# Fully written first + middle initial + fully written last name + intervening particle + fully written last name + optional suffix, e.g. "Elena M. Spiritu e Santu":
name_search2_regex = r"[A-Z][A-Za-z\-]+ [A-Z]{1}\.? [A-Z]'?[A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# Fully written first + middle initial + particle + last name + optional suffix, e.g. "JoEllen C. D'Andrea-Doyle", "JoEllen C. D'Andrea":
name_search3_regex = r"[A-Z][A-Za-z\-]+ [A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# First initial + fully written middle, last name + optional suffix, e.g. "C. McGann D'Andrea-Solis", "C. McGann D'Andrea":
name_search4_regex = r"[A-Z]{1}\.? [A-Z]'?[A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# Fully written first + optional particle + fully written last name + optional suffix, e.g. "JoEllen D'Andrea-Solis", "JoEllen D'Andrea"
name_search5_regex = r"[A-Z][A-Za-z\-]+ ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# First initial + middle initial + optional particle + fully written last name + optional suffix, e.g. "T.C. D'Andrea-Solis", "T.C. D'Andrea":
name_search6_regex = r"([A-Z]{1}\.? ?){2} ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"
# First initial + optional particle + fully written last name + optional suffix, e.g. "C. D'Andrea-Solis", "C. D'Andrea":
name_search7_regex = r"[A-Z]{1}\.? ((Van Der|van der|De La|de la|Della|della|Del|del|Des|des|Von|von|Van|van|De|de|Da|da|Di|di|Du|du|Le|le|E|e|Y|y|D|d)('| ))?[A-Z]'?[A-Za-z\-]+((, | )(Junior\b|Senior\b|Jr\.?|Sr\.?|II\b|III\b|IV\b|V\b|VI\b|VII\b))?"



# REGEX used in s4actgenmlassemblerv2
actually_words_regex = r'actuall?y?|\bas ?(the ?claimant|he|she|it ?was) ?perform\w*'
performed_in_economy_regex = r'\bperforme?d? ?\w+? ?in ?the ?(regional|national) ?economy'
generally_words_regex = r'\bgenerall?y?|\bnormall?y?|\bcustomari?l?y|\btypicall?y?|\busuall?y?'
neg_words_regex = (r'\bnot\b|\bcan ?not\b|\bcan\'t\b|\bcouldn\'t\b|\bcould ?not\b\b(?<!not) ?unable\b|'
					'\b(?<!not) ?incapable\b|\b(?<!not) ?preclude\w*|\b(?<!not) ?prevent\w*|'
					'\b(?<!not) ?exclude\w*\b|not ?able\b|\blimited\b')
pos_words_regex = (r'\bable\b|\bcan ?(?!not)\b|\bcould ?(?!not)\b|\bcapable\b|\bnot ?unable\b|\bnot ?incapable\b|'
					'\bnot ?precludew*|\bnot ?prevent\w*|\bnot ?exclude\w*|\bonly ?as|\bis ?(?!not)\b|\bwas ?(?!not)\b')

# REGEX used in rfc_its_ml_classifier
workplace_words_regex = (r'\bemployment\b|\benvironment\b|\b(?:work)? ?schedule\b|\bwork ?setting\b|'
						'\bwork ?activities\b|\bwork ?day\b|\bwork ?week\b')
rigor_words_regex = (r'\b(?:regular|continuing|consistent) ?basis\b|\bcompetitive\b|\bfull ?\- ?time\b|'
					'\b(?:8|40) ?\-? ?hour\b')
work_words_regex = (r'\bmeet(?:ing)?.*requirements?\b|\bnecessary\b|\bsustain(?:ing)?\b|\bengage?(?:ing)?\b|'
					'\bwork(?:ing)?\b')
nonlim_words_regex = (r'(?<!not)(( |^)without|( |^)free of|( |^)absent|( |^)no|( |^)lacks?|( |^)devoid of|'
						'( |^)no [a-z]+)( ?\w+?,? ?\w+? ?| ?\w+? ?| ?)(significant|major|serious|material|'
						'discernible|definitive|definite|clear|perceptible|pronounced|apparent|'
						'ascertainable|evident|manifest|substantial|tangible|visible|observable|obvious|'
						'considerable|meaningful|acute|critical|severe|marked|consequential|)'
						'( ?\w+?,? ?\w+? ?| ?\w+? ?| ?)(limitation|limits|limited|restrictions|restricted|'
						'impeded|constrained|hindered|inhibited|impediment|constraint|difficulty|hindrance|'
						'trouble|inhibition)')
nonlim_words2_regex = (r'(not ?)(significantly|major|seriously|materially|discernibly|definitively|clearly|'
						'perceptibly|ascertainably|evidently|manifestly|substantially|tangibly|visibly|'
						'observably|obviously|considerably|meaningfully|acutely|critically|severely|markedly|'
						'consequentially|)(limited|restricted|impeded|restrained|hindered|constrained|'
						'troubled|inhibited)(?! to )')
nonlim_words3_regex = (r'\bunlimited\b|\bunrestricted\b|\bunimpeded\b|\buninhibited\b|\bunconstrained\b|'
						'\buntroubled\b')

# REGEX used in its_preprocessing
nonlist_conj_words_regex = (r'\bbut\b|\byet\b|, ?while(?= \w+)|, ?however(?= \w+)|, ?whereas(?= \w+)|'
							', ?except(?= \w+)|, ?with ?the ?exception|, ?only (?!occasional\w*)|'
							', ?only (?!frequent\w*)|, ?only (?!constant\w*)|, ?only (?!concentrated\w*)|'
							', ?only (?!moderate\w*)')
