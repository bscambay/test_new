# INSIGHT UMLS IMPAIRMENT EXPLORER
#
# AUTHOR:
# Eric Kim & Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# Organizes/executes UMLS Step 2 finding text ('s2txt') related operations
# (e.g. UMLS term extraction from 's2txt', retrieval of UMLS and listing
# data associated with the extracted UMLS terms).
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os.path

import umls_analyzer as ua

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "data")
logdir = os.path.join(insightdir, "log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load umls_exclusion_whitelist:
umls_exclusion_whitelist = []
with open(os.path.join(datadir, "umls_exclusion_whitelist.txt"), 'r') as whitelist_file:
    whitelist_filelines = whitelist_file.readlines()
    for line in whitelist_filelines:
        if bool(line.startswith('#')) is False and line != '':
            line = line.strip()
            umls_exclusion_whitelist.append(line)
            line_plural = line + 'S'
            umls_exclusion_whitelist.append(line_plural)


# New version of UMLS extraction function designed to
# - output as many results as found (no cap)
# - be compatible with SCHEMA 2
def extract_umls_data_insight_tgt(input_dict, tgt_nm):
    '''Generates additional structured data on medical concepts
    present in a targeted string value.  Structured data is derived
    from a custom subset of the UMLS Metathesaurus.

    Arguments:
        input_dict {dict}: An INSIGHT observation dictionary.
        tgt_nm {str}: The column/key name of the INSIGHT observation
            data point targeted.
    Returns:
        umls_res_dict_list {list}: A list of 'mdi' observation
            dictionaries.
    Raises:
        N/A (will log exception and return empty dictionary if exception
            occurs.
    '''
    try:
        # Check arguments:
        if not isinstance(input_dict, dict):
            errstr = 'umls_extract.extract_umls_data_insight_tgt() - Argument Type Error - input_dict - type passed = %s' % type(
                input_dict)
            logger.critical(errstr)
            return {}
        if not isinstance(tgt_nm, str):
            errstr = 'umls_extract.extract_umls_data_insight_tgt() - Argument Type Error - tgt_nm - type passed = %s' % type(
                tgt_nm)
            logger.critical(errstr)
            return {}

        # If target string not 'substantive', nothing to parse:
        tgt_str = input_dict[tgt_nm]
        if tgt_str in ['U', 'P', 'E', '']:
            return {}

        # Attempt to determine whether an 'adult', 'child' or 'both' claim type:
        # TODO: Update to leverage structured claim data.
        claim_type_ver = 'U'
        claimtype = input_dict['claimtype']
        if claimtype not in ['U', 'P', 'E', '']:
            if claimtype in ['T16 SSI Child', 'T16 SSI CDR Child']:
                claim_type_ver = 'child'
            else:
                if 'T16 SSI Child' not in claimtype and 'T16 SSI CDR Child' not in claimtype and 'T16 SSI Child+Adult' not in claimtype:
                    claim_type_ver = 'adult'
                else:
                    claim_type_ver = 'both'

        # Prepare other arguments:
        paistart = input_dict['paistart']
        paiend = input_dict['paiend']
        tgt_src = 'U'
        tgt_src_nm = tgt_nm + 'src'
        if tgt_src_nm in input_dict.keys():
            tgt_src = input_dict[tgt_src_nm]

        # Extract UMLS data:
        umls_res_dict_list = extract_umls_data(tgt_str, tgt_nm, tgt_src, claim_type_ver, paistart, paiend)

        # Return:
        return umls_res_dict_list

    except Exception:
        logger.exception('EXCEPTION')
        return {}


# Extract UMLS data from parsed argument values (child function):
def extract_umls_data(text, text_type, text_src, claim_type, paistart, paiend):
    '''
    Generates a dictionary of UMLS Metathesaurus-derived data from an input
    's2.s2txt' observation.
    '''
    try:
        # Extract CUI, type, and term name entities:
        if text_type == 's2txt':
            res_dict_list = ua.extract_terms_s2txt_returntxt(text, text_src, '1')[0]
        else:
            res_dict_list = ua.extract_terms_s2txt_returntxt(text, text_type, '0')[0]
        # Extracts a short definition for each term.
        res_dict_list = ua.term_def(res_dict_list)
        # Extracts affected body parts and systems (anatomy and physiology).
        res_dict_list = ua.affected_ap_terms(res_dict_list)
        # Extracts signs or symptoms.
        res_dict_list = ua.ss_terms(res_dict_list)
        # Extracts listing data, incluaing the listing number (also return
        # ICD9 tuples for incorporation):
        res_dict_list = ua.term_listing_numbers_v2(res_dict_list, claim_type, paistart, paiend)
        # Filter out whitelist of 'low information'/
        # undersirable results:
        res_dict_list = [subd for subd in res_dict_list if subd['TXT'].strip() not in umls_exclusion_whitelist]

        return res_dict_list

    except Exception:
        logger.exception('EXCEPTION')

#################################################################################################################
# Full extract_umls_data() docstring:
#
# The dictionary's keys and values are as follows:
# CUI: [string]
# TYP: [string]
# TXT: string
# DEF: string
# AP: [string]
# SS: [string]
# LISTING: [dictionary]
#
# For LISTING, the dictionary's keys are as follows: whitelisted (bool), imprmnt_uid (string), listg_num (string), desc (string), hiv_manif (bool), eff_endt (bool)
# Whitelisting is True if the listing code is a current listing number in the SSA regulations, or if it is a parent listing number (e.g. 1.00).
#
# -------------------------------------------------
#
# SAMPLE OUTPUT:
# CUI
# ['C1963064', 'C0003467', 'C0003469']
#
# TYP
# ['Finding', 'Mental or Behavioral Dysfunction']
#
# TXT
# ANXIETY
#
# AP
# ['HEART', 'NTS']
#
# SS
# ['DYSPNEA', 'RESTLESSNESS', 'TENSE']
#
# LISTING
# [{whitelisted: True, imprmnt_uid: '199', listg_num: '12.06', desc: 'Anxiety Related Disorders', hiv_manif: False, eff_endt: False),
# 	{whitelisted: True, imprmnt_uid: '548', listg_num: '12.xx', desc: 'Mental', hiv_manif: False, eff_endt: False)]
#################################################################################################################
