# step 3 finding, I don't know what mteq_id is here

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S3VERDICTIDFEATURESREV3.txt", 'LogisticRegression', 2, logging_dir)
ml.run()
