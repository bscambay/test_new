# INSIGHT QUALITY COMMON CALCULATIONS UNIT TESTS
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 05.26.2017
# 
# 
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os.path
import sys
import logging
import unittest
import numpy as np

# Set directories:
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)
import ifs_iq_common_calcs as iqcc

# Disable all logging during testing:
# TIP: Disabling does not persist beyond test execution.
for k,v in logging.Logger.manager.loggerDict.iteritems():
	logging.disable(logging.CRITICAL)


# Create unittest class:
class Test(unittest.TestCase):
	
	# def setUp(self):
	
	def test_locate_relevant_finding_obs_correct_functioning(self):
		input_dict = {'s3mteq':{0: {'s3parbsf': '4', 's3parbcpp': '4', 'ORD_NUM': 0, 's3mteqver': '1', 's3mteqtxt': '6. The claimant does not have an impairment or combination of impairments that meets or medically equals the severity of one of the listed impairments in 20 CFR Part 404, Subpart P, Appendix 1 (20 CFR 404.1520(d), 404.1525, 404.1526, 416.920(d), 416.925 and 416.926).', 's3parbdecomp': '3', 'body_loc_end': 7914, 's3mteqtxtsrc': '0', 'loc_end': 2138, 's3mteqlistnum': [], 's3parbadl': '2', 'loc_st': 1869, 's3mteqversrc': '0'}}, 'rfc':{0: {'rfcbalancelol': 'U', 'rfcreachpresent': '1', 'rfcclimbrampstairlol': 'U', 'flag_rfc_lessthan_lol_ver': '0', 'rfcextremeheatlol': 'U', 'flag_rfc_nolimlang_ver': '0', 'rfcwalklol': '2', 'body_loc_end': 20494, 'rfcvibrationlol': 'U', 'rfccolorvisionlol': 'U', 'rfckneelpresent': '0', 'rfctalkpresent': '0', 'rfcdepthperceptionlol': 'U', 'rfcsitstandpresent': '0', 'rfcnearacuitypresent': '0', 'rfccolorvisionpresent': '0', 'rfcsitlol': '2', 'rfchearlol': 'U', 'rfchandlelol': 'U', 'rfcfeellol': 'U', 'rfcwalkpresent': '1', 'rfcexposuretoweatherpresent': '0', 'rfchazardslol': 'U', 'rfchumiditylol': 'U', 'rfccarrypresent': '0', 'rfcclimbpresent': '1', 'rfcstandlol': '2', 'rfcliftpresent': '0', 'rfcstooplol': 'N', 'rfcliftlol': 'U', 'rfcmentalsfintpubpresent': '0', 'rfcexlvl_parsed': 'S', 'rfcfootcontrolspresent': '0', 'rfctastepresent': '0', 'rfcextremecoldlol': 'U', 'ORD_NUM': 0, 'rfctoxiccausticchemicalslol': 'U', 'rfcclimbingobjectspresent': '1', 'flag_rfc_nolimlang_val': 'P', 'rfctxtsrc': '0', 'rfchearpresent': '0', 'rfcfaracuitylol': 'U', 'rfcnoisepresent': '0', 'rfctxt': '6. After careful consideration of the entire record, I find that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a) except he cannot climb ladders, ropes and scaffolds. He can possibly reach overhead. He can engage in frequent manipulative activities, but he cannot stoop. He can sit, stand, and walk for a total of 2 hours in an 8 hour day. He cannot work around unprotected heights or dangerous moving mechanical parts. Due to his symptoms, he is unable to work activity for 8 hours per day for 40 hours per week.', 'flag_rfc_vague_parblol_val': 'P', 'rfctoxiccausticchemicalspresent': '0', 'rfcfootcontrolslol': 'U', 'rfcpulllol': 'U', 'rfcwetnesslol': 'U', 'rfcreachlol': 'U', 'rfcbalancepresent': '0', 'flag_rfc_minlang_val': 'P', 'rfccrawllol': 'U', 'rfcmovingmechanicallol': 'U', 'rfcmentalcpppresent': '0', 'rfccrouchpresent': '0', 'rfcwetnesspresent': '0', 'rfcpushpullpresent': '0', 'rfcfitexlvlsrc': '0', 'rfcfeelpresent': '0', 'rfctalklol': 'U', 'rfcclimblrslol': 'N', 'rfcdepthperceptionpresent': '0', 'rfckneellol': 'U', 'rfcallmanipulativespresent': '1', 'loc_end': 8572, 'loc_st': 7914, 'flag_rfc_lessthan_lol_val': 'P', 'rfcaccomodationlol': 'U', 'rfcnearacuitylol': 'U', 'rfctastelol': 'U', 'rfcfaracuitypresent': '0', 'rfchazardspresent': '0', 'rfchumiditypresent': '0', 'rfcexposuretoweatherlol': 'U', 'rfcvibrationpresent': '0', 'rfcfitexlvl': 'S', 'rfcsitpresent': '1', 'rfcatmosphericconditionslol': 'U', 'flag_rfc_vague_lol_ver': '0', 'rfcfieldofvisionlol': 'U', 'rfcexposedheightslol': 'N', 'rfcatmosphericconditionspresent': '0', 'rfcextremetempspresent': '0', 'rfccrouchlol': 'U', 'rfchandlepresent': '0', 'rfccrawlpresent': '0', 'rfcstandpresent': '1', 'rfcmentalsfintanypresent': '0', 'rfcexposedheightspresent': '1', 'rfcfingerlol': 'U', 'rfcmovingmechanicalpresent': '1', 'rfcpushlol': 'U', 'rfcaccomodationpresent': '0', 'rfcsmelllol': 'U', 'flag_rfc_vague_lol_val': 'P', 'rfcfingerpresent': '0', 'rfccarrylol': 'U', 'flag_rfc_vague_parblol_ver': '0', 'rfcsmellpresent': '0', 'flag_rfc_minlang_ver': '0', 'rfcfieldofvisionpresent': '0', 'rfcstooppresent': '1'}}, }
		origin_obs_nm = 's3mteq'
		origin_obs_ordnum = 0
		target_obs_nm = 'rfc'
		direction_type = 'after'
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, origin_obs_nm, origin_obs_ordnum, target_obs_nm, direction_type), [0])
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, origin_obs_nm, 1, target_obs_nm, direction_type), [])

	def test_locate_relevant_finding_obs_erroneous_inputs(self):
		input_dict = {'s3mteq':{0: {'s3parbsf': '4', 's3parbcpp': '4', 'ORD_NUM': 0, 's3mteqver': '1', 's3mteqtxt': '6. The claimant does not have an impairment or combination of impairments that meets or medically equals the severity of one of the listed impairments in 20 CFR Part 404, Subpart P, Appendix 1 (20 CFR 404.1520(d), 404.1525, 404.1526, 416.920(d), 416.925 and 416.926).', 's3parbdecomp': '3', 'body_loc_end': 7914, 's3mteqtxtsrc': '0', 'loc_end': 2138, 's3mteqlistnum': [], 's3parbadl': '2', 'loc_st': 1869, 's3mteqversrc': '0'}}, 'rfc':{0: {'rfcbalancelol': 'U', 'rfcreachpresent': '1', 'rfcclimbrampstairlol': 'U', 'flag_rfc_lessthan_lol_ver': '0', 'rfcextremeheatlol': 'U', 'flag_rfc_nolimlang_ver': '0', 'rfcwalklol': '2', 'body_loc_end': 20494, 'rfcvibrationlol': 'U', 'rfccolorvisionlol': 'U', 'rfckneelpresent': '0', 'rfctalkpresent': '0', 'rfcdepthperceptionlol': 'U', 'rfcsitstandpresent': '0', 'rfcnearacuitypresent': '0', 'rfccolorvisionpresent': '0', 'rfcsitlol': '2', 'rfchearlol': 'U', 'rfchandlelol': 'U', 'rfcfeellol': 'U', 'rfcwalkpresent': '1', 'rfcexposuretoweatherpresent': '0', 'rfchazardslol': 'U', 'rfchumiditylol': 'U', 'rfccarrypresent': '0', 'rfcclimbpresent': '1', 'rfcstandlol': '2', 'rfcliftpresent': '0', 'rfcstooplol': 'N', 'rfcliftlol': 'U', 'rfcmentalsfintpubpresent': '0', 'rfcexlvl_parsed': 'S', 'rfcfootcontrolspresent': '0', 'rfctastepresent': '0', 'rfcextremecoldlol': 'U', 'ORD_NUM': 0, 'rfctoxiccausticchemicalslol': 'U', 'rfcclimbingobjectspresent': '1', 'flag_rfc_nolimlang_val': 'P', 'rfctxtsrc': '0', 'rfchearpresent': '0', 'rfcfaracuitylol': 'U', 'rfcnoisepresent': '0', 'rfctxt': '6. After careful consideration of the entire record, I find that the claimant has the residual functional capacity to perform sedentary work as defined in 20 CFR 404.1567(a) and 416.967(a) except he cannot climb ladders, ropes and scaffolds. He can possibly reach overhead. He can engage in frequent manipulative activities, but he cannot stoop. He can sit, stand, and walk for a total of 2 hours in an 8 hour day. He cannot work around unprotected heights or dangerous moving mechanical parts. Due to his symptoms, he is unable to work activity for 8 hours per day for 40 hours per week.', 'flag_rfc_vague_parblol_val': 'P', 'rfctoxiccausticchemicalspresent': '0', 'rfcfootcontrolslol': 'U', 'rfcpulllol': 'U', 'rfcwetnesslol': 'U', 'rfcreachlol': 'U', 'rfcbalancepresent': '0', 'flag_rfc_minlang_val': 'P', 'rfccrawllol': 'U', 'rfcmovingmechanicallol': 'U', 'rfcmentalcpppresent': '0', 'rfccrouchpresent': '0', 'rfcwetnesspresent': '0', 'rfcpushpullpresent': '0', 'rfcfitexlvlsrc': '0', 'rfcfeelpresent': '0', 'rfctalklol': 'U', 'rfcclimblrslol': 'N', 'rfcdepthperceptionpresent': '0', 'rfckneellol': 'U', 'rfcallmanipulativespresent': '1', 'loc_end': 8572, 'loc_st': 7914, 'flag_rfc_lessthan_lol_val': 'P', 'rfcaccomodationlol': 'U', 'rfcnearacuitylol': 'U', 'rfctastelol': 'U', 'rfcfaracuitypresent': '0', 'rfchazardspresent': '0', 'rfchumiditypresent': '0', 'rfcexposuretoweatherlol': 'U', 'rfcvibrationpresent': '0', 'rfcfitexlvl': 'S', 'rfcsitpresent': '1', 'rfcatmosphericconditionslol': 'U', 'flag_rfc_vague_lol_ver': '0', 'rfcfieldofvisionlol': 'U', 'rfcexposedheightslol': 'N', 'rfcatmosphericconditionspresent': '0', 'rfcextremetempspresent': '0', 'rfccrouchlol': 'U', 'rfchandlepresent': '0', 'rfccrawlpresent': '0', 'rfcstandpresent': '1', 'rfcmentalsfintanypresent': '0', 'rfcexposedheightspresent': '1', 'rfcfingerlol': 'U', 'rfcmovingmechanicalpresent': '1', 'rfcpushlol': 'U', 'rfcaccomodationpresent': '0', 'rfcsmelllol': 'U', 'flag_rfc_vague_lol_val': 'P', 'rfcfingerpresent': '0', 'rfccarrylol': 'U', 'flag_rfc_vague_parblol_ver': '0', 'rfcsmellpresent': '0', 'flag_rfc_minlang_ver': '0', 'rfcfieldofvisionpresent': '0', 'rfcstooppresent': '1'}}, }
		origin_obs_nm = 's3mteq'
		origin_obs_ordnum = 0
		target_obs_nm = 'rfc'
		direction_type = 'after'
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, 'dog', origin_obs_ordnum, target_obs_nm, direction_type), [])
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, origin_obs_nm, 'dog', target_obs_nm, direction_type), [])
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, origin_obs_nm, origin_obs_ordnum, 'dog', direction_type), [])
		self.assertEqual(iqcc.locate_relevant_finding_obs(input_dict, origin_obs_nm, origin_obs_ordnum, target_obs_nm, 'dog'), [])
		
	
	def test_dotlookupcheck_correct_functioning(self):
		self.assertEqual(iqcc.dotlookupcheck('311477030'), True)
		self.assertEqual(iqcc.dotlookupcheck('311477031'), False)
		
	def test_dotlookupcheck_erroneous_inputs(self):
		self.assertEqual(iqcc.dotlookupcheck(311477030), False)
		self.assertEqual(iqcc.dotlookupcheck(np.nan), False)
		self.assertEqual(iqcc.dotlookupcheck(None), False)
		
	def test_dotlookupcheck_exception_trigger(self):
		self.assertEqual(iqcc.dotlookupcheck([]), 'E')
		
	
	
	
	
	# def tearDown(self):

# Run:
if __name__=='__main__':
	unittest.main(exit=False)