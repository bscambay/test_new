# INSIGHT SELENIUM TEST SCRIPT'S CONFIGURATION FILE
# AUTHOR:
# Bhavin Shah
# Social Security Administration

# SUMMARY:
# Configuration dirver and url for selenium scripts
# =============================================================================
import os
import htmllib
from selenium import webdriver 
#from selenium import HTMLUNIT      
Proxy = "http://access.lb.ssa.gov:80"

        #webdriver.DesiredCapabilities.CHROME['proxy']={
        #   "httpProxy":Proxy,
        #    "ftpProxy":Proxy,
        #    "sslProxy":Proxy,
        #    "noProxy":"*.ssa.gov",
        #    "proxyType":"MANUAL",
        #    "autodetect":False
        #}


driver = webdriver.Remote(
        desired_capabilities=webdriver.DesiredCapabilities.CHROME,
        command_executor='http://selenium-hub.labs.addev.ssa.gov:4444/wd/hub'
           
)
#driver = webdriver.Chrome("C:\\IEDriver\\chromedriver.exe")
        #Instantiate webdriver IE browser
        #self.driver = webdriver.Ie("bin/IEDriverServer.exe")
        #Navigate to Insight Web app
OaO_url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results"
Hearing_url = "http://s1ff532.ba.ad.ssa.gov:8189/draftanalysis/1"
#"http://s1ff531.ba.ad.ssa.gov:8189/oaoapp/1"
#"http://s1ff532.ba.ad.ssa.gov:8189/draftanalysis/1"
        #self.user_id = "027763"
        #Wait for a certain amount time before throwing an exception if page is not found.
        
