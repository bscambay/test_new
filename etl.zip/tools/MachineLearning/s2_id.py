# step 2 finding, I don't know what id is here

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S2VERDICTIDFEATURESREV2.txt", 'LogisticRegression', 2, logging_dir)
ml.run()
