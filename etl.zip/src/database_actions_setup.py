# INSIGHT FULL SUITE - INSIGHT DATABASE SETUP ACTIONS
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 06.29.2017
#
# SUMMARY: 
# Contains scripts designed to help 'set up' an instance of the
# INSIGHT database, such as populating reference table data.
# 
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os
import os.path
import urllib

import pandas
from sqlalchemy import create_engine, MetaData

# Import config_sec:
# secdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../../sec"))
# sys.path.insert(0, secdir)
import config_sec as cfg_sec

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")


# Define function to INSERT and/or UPDATE static data into INSIGHT DB:
def push_static_data(static_data_fn):
	'''Push INSIGHT static data housed in the 'data' directory
	to a corresponding INSIGHT DB table.
	
	NOTE: Designed to work where the static file base name matches the
	name of the target INSIGHT DB table.
	
	WARNING: As configured, any time the corresponding INSIGHT
	DB table exists already, this will truncate that table and
	then insert the data.  This is done to maintain the schema
	data types, which otherwise would be replaced if 'if_exists'
	were not set to 'append'.
	
	Args:
		static_data_fn {str}: The file name of the static data
			file whose contents you wish to push to its
			corresponding INSIGHT DB table.
	Returns:
		N/A.
	Raises:
		All exceptions will be raised.
	'''
	try:
	
		# Get file name without extension to use as target table name:
		static_fn_noext = os.path.splitext(static_data_fn)[0]
		
		# Load static file into DataFrame:
		static_df = pandas.read_csv(os.path.join(datadir, static_data_fn), dtype=str)
	
		# Create INSIGHT DB connection string, 
		# then connect via sqlalchemy:
		ifs_db_cnxn_str = 'Driver={SQL Server};Server=%s;Database=%s;uid=%s;pwd=%s' % (cfg_sec.ifs_server_nm, cfg_sec.ifs_database_nm, cfg_sec.ifs_database_uid, cfg_sec.ifs_database_pw)
		params = urllib.quote_plus(ifs_db_cnxn_str)
		engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
		conn = engine.connect()
		metadata = MetaData(conn)
		
		# Truncate target table:
		truncate_sql = "TRUNCATE TABLE %s" % static_fn_noext
		engine.execute(str(truncate_sql).execution_options(autocommit=True))
		
		# Write DataFrame contents to target table:
		static_df.to_sql(static_fn_noext, engine, if_exists="append", index=False)
		
		# Close connection:
		conn.close()
	
	except Exception:
		try:
			conn.close()
		except Exception:
			pass
		raise




