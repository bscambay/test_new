# step 2 finding, not sure what type means

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S2VERDICTTYPEFEATURESREV2.txt", 'LogisticRegression', 5, logging_dir)
ml.run()
