# INSIGHT - INDIVIDUAL DECISION HTML TOOLS PAGE HTML GENERATOR 
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# SUMMARY:
# Generates custom INSIGHT Web App page HTML string based on
# INSIGHT data values for a given case entity.
#
# TODO: Consider migration to template engine to enhance
# DRYness (http://www.codereadability.com/reducing-repetition-in-html-templates/)
# and ensuring greater separation between front-end work and back-end logic.
# See also https://wiki.python.org/moin/Templating.
#
# CRITICAL TODO:
# (2) REVISE STRUCT AGEREL VALUES TO RELY EXCLUSIVELY ON STRUCTURED DATA (USE CODE CREATED HERE, I.E. parse_disp_type_struct())
# 
# DATE LAST UPDATED: 
# 06.06.2017
#
#==============================================================================

# Import modules:
import re
import datetime
import ast
import io
import os.path
import math
from operator import itemgetter
from string import maketrans, translate
import logging
import pandas
import date_helper as dh
import database_actions_misc as ifsdam
import bmi_revised as bmi
import config as cfg
import common_calcs as cc
import umls_extract as umls_extract
from iqrgenerator_templatesnippets import *
import iqrgenerator_common_calcs as ifsiqrcc

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load flag data (filtering to prod only):
flagdatadf = pandas.read_csv(os.path.join(datadir, "flagdata.csv"), dtype=str)
flagdatadf = flagdatadf[[cn for cn in flagdatadf.columns.tolist() if not cn.startswith('Unnamed')]]
flagdatadf = flagdatadf.loc[flagdatadf['prod_ready_ver'] == '1']

# Load AR data:
ardf = pandas.read_csv(os.path.join(datadir, "ar_data.csv"), dtype=str)

# Misc. setup actions:
flagval_NOFCloldict = {'S':'Sedentary', 'L':'Light', 'M':'Medium', 'H':'Heavy', 'VH':'Very Heavy', 'N':'never', 'O':'occasional', 'F':'frequent', 'C':'constant', 'OCCASIONALEQUIV':'equivalent to occasional', 'FREQUENTEQUIV':'equivalent to frequent'}

# Perform misc. setup actions:
notranstab = maketrans("", "")

# Define INSIGHT Web App page generation function:
def run(input_dict):
	"""Creates a custom INSIGHT Web App page string from a dictionary
	containing an INSIGHT case entity's data values.

	Args:
		input_dict: {dict} A dictionary containing data values for a single hearing
			decision text instance, where keys = INSIGHT data value namespaces or
			child table names and values = their values (or child table observations
			as subdictionaries). For the OAO App, this dictionary is generated from
			database_actions.retrieve_case_entity_schema2().
		(DEPRECATED 06.02.2017) iqrepgen_vsn: {'oao', 'hearing'} [default='hearing']:
			The version of the INSIGHT Quality report to output.  OAO version is a
			temporary version that omits user feedback form elements.
	Returns:
		iqhtml {str}: INSIGHT Web App page HTML containing
			quality feedback and other information tailored to the
			INSIGHT case entity observation whose data was passed
			as inputs.
	Raises:
		N/A (returns 'E' if exception occurs).
	"""
	try:
		# Check argument types:
		if bool(isinstance(input_dict, dict)) is False:
			logger.exception('EXCEPTION')
			return 'E'

		# Normalize input dict values:
		iqrepgen_dict = {}
		for k, v in input_dict.iteritems():
			if not isinstance(v, dict):
				if v is None or (isinstance(v, float) and math.isnan(v)) or (isinstance(v, str) and v == ''):
					iqrepgen_dict[k] = 'U'
				else:
					iqrepgen_dict[k] = v
			else:
				chd_dictlist = v.values()
				chd_dictlist_nml = []
				for chd_d in chd_dictlist:
					chd_d_nml = {}
					for subk, subv in chd_d.iteritems():
						if subv is None or (isinstance(subv, float) and math.isnan(subv)) or ((isinstance(subv), str) and subv == ''):
							chd_d_nml[k] = 'U'
						else:
							chd_d_nml[k] = subv
					chd_dictlist_nml.append(chd_d_nml)
				iqrepgen_dict[k] = chd_dictlist_nml
				
		# Mirroring items in 'batch.py', parse the data to
		# create additional data points helpful to template generation:
		iqrepgen_dict['CLAIMDISP_STRUCT'] = ifsiqrcc.convert_struct_claimdisp(iqrepgen_dict['struct_hodisp'])
		claimtypelist = [subd['CLM_TYP'] for subd in iqrepgen_dict['CLAIMDISP_STRUCT']]
		
		# Load report HTML template file:
		htmlfile = io.open(os.path.join(templatesdir, "iqrtemplate_prod.html"), encoding='ascii', errors='strict', mode='r')
		iqhtml = htmlfile.read()
		htmlfile.close()
		
		# Set AJAX paths:
		iqhtml = iqhtml.replace('AJAX_RT_VAR', cfg.ajax_rt)
		
		# Claimant SSN:
		try:
			ssn_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'CLMT_SSN', 'U', 'U', 'U')
			if not ssn_struct_val_list:
				ssn = iqrepgen_dict['ssn']
				if bool(re.search(r"^[0-9]{9}$", ssn)):
					ssn = "###-##-" + ssn[5:]
				else:
					ssn = ifsiqrcc.trans_stock_vals('E')
				iqhtml = re.sub(r'ssn_HTML', ssn, iqhtml)
			else:
				if len(list(set(ssn_struct_val_list))) == 1:
					ssn_struct = ssn_struct_val_list[0]
					ssn = "###-##-" + ssn_struct[5:]
					iqhtml = re.sub(r'ssn_HTML', ssn, iqhtml)
				else:
					ssn = iqrepgen_dict['ssn']
					if bool(re.search(r"^[0-9]{9}$", ssn)):
						ssn = "###-##-" + ssn[5:]
					else:
						ssn = ifsiqrcc.trans_stock_vals('E')
					iqhtml = re.sub(r'ssn_HTML', ssn, iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"ssn_HTML", ifsiqrcc.trans_stock_vals("E"), iqhtml)
		
		# eView Hyperlink:
		try:
			efldrnum_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'EFLDR_NUM', 'U', 'U', 'U')
			efldrnum_struct_val_list = [str(ef) for ef in efldrnum_struct_val_list]
			if len(list(set(efldrnum_struct_val_list))) == 1:
				eview_url = "http://eview.ba.ssa.gov/disability/ServletUtilNavToPage?theNextPage=utilities/utileviewdirectfirstscreen.jsp&edcsNumber=%s" % efldrnum_struct_val_list[0]
				iqhtml = re.sub(r"eview_HREF", eview_url, iqhtml)
			else:
				iqhtml = re.sub(r"eview_HREF", "LOOKUP_ERROR", iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"eview_HREF", "LOOKUP_ERROR", iqhtml)

		# Decision Document Hyperlink:
		try:
			docu_ctl_id = iqrepgen_dict['DOCU_CTL_ID']
			if docu_ctl_id not in ['U', 'P', 'E', '']:
				decision_url = "http://cmwasprd.ba.ssa.gov/DMAeClient/DMAInit?notify=sdr&action=view&docid=" + docu_ctl_id
				iqhtml = re.sub(r"decision_HREF", decision_url, iqhtml)
			else:
				iqhtml = re.sub(r"decision_HREF", "LOOKUP_ERROR", iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"decision_HREF", "LOOKUP_ERROR", iqhtml)

		# Disposition Type:
		# First attempt to translate using structured data, then fall back to INSIGHT data:
		# TIP: 'CLM_TYP' values already sufficiently translated within CLAIMDISP_STRUCT.
		try:
			if iqrepgen_dict['CLAIMDISP_STRUCT']:
				disp_typ_trans_str = ifsiqrcc.parse_disp_type_struct(iqrepgen_dict['CLAIMDISP_STRUCT'])
				if disp_typ_trans_str != 'E':
					iqhtml = re.sub(r"disptype_HTML", disp_typ_trans_str, iqhtml)
				else:
					disptypedict = {"1":"Unfavorable", "2":"Unfavorable (Plus Title II Dismissal Action)", "3": "Partially Favorable", "4":"Partially Favorable (Plus Title II Dismissal Action)", "5":"Fully Favorable", "6":"Fully Favorable (Plus Title II Dismissal Action)", "7":"Dismissal"}
					if not iqrepgen_dict['claimdisp']:
						iqhtml = re.sub(r"disptype_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)
					else:
						claimtype_translist = []
						claimdisp_listofdicts = []
						# TIP: Parse between list of dicts (DB retrieval) and dict of dicts (direct run):
						if isinstance(iqrepgen_dict['claimdisp'], dict):
							for subd in iqrepgen_dict['claimdisp'].values():
								claimdisp_listofdicts.append(subd)
						else:
							for subd in iqrepgen_dict['claimdisp']:
								claimdisp_listofdicts.append(subd)
						
						for subd in claimdisp_listofdicts:
							if subd['disptype'] in disptypedict.keys():
								if subd['claimtype'] not in ['U', 'P', 'E', '']:
									disptype_strentry = "%s (%s)" % (disptypedict[subd['disptype']], subd['claimtype'])
									claimtype_translist.append(disptype_strentry)
								else:
									disptype_strentry = "%s (%s)" % (disptypedict[subd['disptype']], ifsiqrcc.trans_stock_vals(subd['claimtype']))
									claimtype_translist.append(disptype_strentry)
							else:
								if subd['claimtype'] not in ['U', 'P', 'E', '']:
									disptype_strentry = "%s (%s)" % (ifsiqrcc.trans_stock_vals(subd['disptype']), subd['claimtype'])
									claimtype_translist.append(disptype_strentry)
								else:
									disptype_strentry = "Error"
									claimtype_translist.append(disptype_strentry)
						claimtype_translist_str = '; '.join(list(set(claimtype_translist)))
						iqhtml = re.sub(r"disptype_HTML", claimtype_translist_str, iqhtml)
			else:
				disptypedict = {"1":"Unfavorable", "2":"Unfavorable (Plus Title II Dismissal Action)", "3": "Partially Favorable", "4":"Partially Favorable (Plus Title II Dismissal Action)", "5":"Fully Favorable", "6":"Fully Favorable (Plus Title II Dismissal Action)", "7":"Dismissal"}
				if not iqrepgen_dict['claimdisp']:
					iqhtml = re.sub(r"disptype_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)
				else:
					claimtype_translist = []
					for k,v in iqrepgen_dict['claimdisp'].iteritems():
						if v['disptype'] in disptypedict.keys():
							if v['claimtype'] not in ['U', 'P', 'E', '']:
								disptype_strentry = "%s (%s)" % (disptypedict[v['disptype']], v['claimtype'])
								claimtype_translist.append(disptype_strentry)
							else:
								disptype_strentry = "%s (%s)" % (disptypedict[v['disptype']], ifsiqrcc.trans_stock_vals(v['claimtype']))
								claimtype_translist.append(disptype_strentry)
						else:
							if v['claimtype'] not in ['U', 'P', 'E', '']:
								disptype_strentry = "%s (%s)" % (ifsiqrcc.trans_stock_vals(v['disptype']), v['claimtype'])
								claimtype_translist.append(disptype_strentry)
							else:
								disptype_strentry = "Error"
								claimtype_translist.append(disptype_strentry)
					claimtype_translist_str = '; '.join(list(set(claimtype_translist)))
					iqhtml = re.sub(r"disptype_HTML", claimtype_translist_str, iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"disptype_HTML", ifsiqrcc.trans_stock_vals("E"), iqhtml)
		
		# Critical Status:
		try:
			crit_ver = 'N'
			crit_str = 'Yes '
			dn_ver = 0
			phom_ver = 0
			suic_ver = 0
			teri_ver = 0
			for subd in iqrepgen_dict['struct_oao']:
				if subd['DIRE_NEED_SW'] == 'Y':
					dn_ver = 1
					crit_ver = 'Y'
				if subd['PTNTLY_HOMCDL_SW'] == 'Y':
					phom_ver = 1
					crit_ver = 'Y'
				if subd['SUICIDL_SW'] == 'Y':
					suic_ver = 1
					crit_ver = 'Y'
				if subd['TERI_SW'] == 'Y':
					teri_ver = 1
					crit_ver = 'Y'
			if crit_ver == 'Y':
				crit_type_list = []
				if dn_ver == 1:
					crit_type_list.append('Dire Need')
				if phom_ver == 1:
					crit_type_list.append('Potentially Homicidal')
				if suic_ver == 1:
					crit_type_list.append('Suicidal')
				if teri_ver == 1:
					crit_type_list.append('Terminal Illness')
				crit_str += '; '.join(crit_type_list)
				iqhtml = re.sub(r"critical_CLASS", "headingcrit", iqhtml)
				iqhtml = re.sub(r"critical_HTML", crit_str, iqhtml)
			else:
				iqhtml = re.sub(r"critical_CLASS", "headingnotcrit", iqhtml)
				iqhtml = re.sub(r"critical_HTML", "No", iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"critical_HTML", ifsiqrcc.trans_stock_vals("E"), iqhtml)
		
		# Case Summary:
		try:
			# Retrieve/set up CS HTML:
			cs_div = cs_div_tpl
			cs_p_tpl = """<p class="narrowp"><span class="narrowpbold">cs_title: </span>cs_val</p>"""
			cs_p_purplecontent = """<p class="narrowppurple"><span class="narrowpbold">cs_title: </span>cs_val</p>"""
			# Iterate through items you'd like to add to CS section:
			for tup in [("SSO code for the claimaint zip code in the decision (clzip_HTML)", "sso"), ("Claimant Weight Analysis (Based on Disability Report Self-Reporting)", "weight"), ("Claim(s)", "claimtype"), ("Disposition Type(s)", "disptype"), ("DOB", "CLMT_DOB"), ("DOF", "dof"), ("AOD", "aod"), ("Disp. Date", "did"), ("DLI", "dli"), ("Circuit", "circuit"), ("Request for Review Info", "CRNT_RQSTD_DT"), ("Age at Start of PAI", "STRUCT_AGEREL_PAISTART"), ("Age at End of PAI", "STRUCT_AGEREL_PAIEND")]:
				
				# Claim Type(s):
				if tup[1] == 'claimtype':
					if not claimtypelist:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_claimtype_HTML", cs_p, cs_div)
					else:
						claimtypestr = '; '.join(claimtypelist)
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', claimtypestr)
						cs_div = re.sub(r"cs_claimtype_HTML", cs_p, cs_div)
				
				# Disposition Type(s):
				elif tup[1] == 'disptype':
					disptypestr = ifsiqrcc.parse_disp_type_struct(iqrepgen_dict['CLAIMDISP_STRUCT'])
					if disptypestr in ['', 'E']:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_disptype_HTML", cs_p, cs_div)
					else:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', disptypestr)
						cs_div = re.sub(r"cs_disptype_HTML", cs_p, cs_div)
				
				# DOB:
				elif tup[1] == "CLMT_DOB":
					dob_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
					if len([v for v in dob_struct_val_list if v in ['U', 'E']]) == len(dob_struct_val_list):
						iqhtml = re.sub(r"cs_clmtdob_HTML", "Unknown", iqhtml)
					else:
						if len(list(set(dob_struct_val_list))) == 1:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', dob_struct_val_list[0])
							cs_div = re.sub(r"cs_clmtdob_HTML", cs_p, cs_div)	
						else:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
							cs_div = re.sub(r"cs_clmtdob_HTML", cs_p, cs_div)	
				
				# AOD:
				# TIP: Don't output AOD for solely adult T16 SSI claims - not valuable!
				elif tup[1] == 'aod':
					if len([ct for ct in claimtypelist if 'T16' in ct]) != len(claimtypelist):
						# Prefer decision AOD over structured value:
						tupres = iqrepgen_dict[tup[1]]
						if tupres in ['U', 'P', 'E', '']:
							aod_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'ALLGD_DISB_ONST_DT', 'U', 'U', 'U')
							if len([v for v in aod_struct_val_list if v in ['U', 'E']]) == len(aod_struct_val_list):
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
								cs_div = re.sub(r"cs_aod_HTML", cs_p, cs_div)
							else:
								aodvalstr = "; ".join(list(set(aod_struct_val_list)))
								aodstr = "%s (NOTE: Not derived from decision - double check this value's accuracy)" % aodvalstr
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', aodstr)
								cs_div = re.sub(r"cs_aod_HTML", cs_p, cs_div)
						else:
							# Get whether AOD was amended:
							aodamendver = iqrepgen_dict['aodamendver']
							if aodamendver == '1':
								aodstr = "%s (Amended)" % tupres
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', aodstr)
								cs_div = re.sub(r"cs_aod_HTML", cs_p, cs_div)
							else:
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupres)
								cs_div = re.sub(r"cs_aod_HTML", cs_p, cs_div)
					else:
						cs_div = re.sub(r"cs_aod_HTML", "", cs_div)
				
				# DOF:
				elif tup[1] == 'dof':
					# TIP: Don't output DOF for solely Age 18 Redeterminations - not valuable!
					if len([ct for ct in claimtypelist if ct == 'T16 SSI Age 18 Redetermination']) != len(claimtypelist):
						appdtlist = []
						for subd in iqrepgen_dict['CLAIMDISP_STRUCT']:
							if subd['PFLG_DT'] != 'E':
								appdtstr = "%s (%s) (Protective Filing Date)" % (subd['PFLG_DT'], subd['CLM_TYP'])
								appdtlist.append(appdtstr)
							else:
								if subd['APP_DT'] != 'E':
									appdtstr = "%s (%s)" % (subd['APP_DT'], subd['CLM_TYP'])
									appdtlist.append(appdtstr)
								else:
									if subd['CLM_TYP'] not in ['U', 'P', 'E', '']:
										appdtstr = "Unknown (%s)" % subd['CLM_TYP']
										appdtlist.append(appdtstr)
									else:
										appdtlist.append("Unknown")
						if not appdtlist:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
							cs_div = re.sub(r"cs_dof_HTML", cs_p, cs_div)
						else:
							appdtstr = "; ".join(appdtlist)
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', appdtstr)
							cs_div = re.sub(r"cs_dof_HTML", cs_p, cs_div)
					else:
						cs_div = re.sub(r"cs_dof_HTML", "", cs_div)
				
				# DLI:
				# TIP: Don't output DLI for solely T16 claims - not relevant!
				elif tup[1] == 'dli':
					if len([ct for ct in claimtypelist if 'T2' in ct]) != 0:
						# Prefer decision DLI over structured value:
						tupres = iqrepgen_dict[tup[1]]
						if tupres in ['U', 'P', 'E', '']:
							dli_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'DLI', 'U', 'U', 'U')
							if len([v for v in dli_struct_val_list if v == 'U']) == len(dli_struct_val_list):
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
								cs_div = re.sub(r"cs_dli_HTML", cs_p, cs_div)
							else:
								dlivalstr = "; ".join(set(dli_struct_val_list))
								dlistr = "%s (NOTE: Not derived from decision - double check this value's accuracy)" % dlivalstr
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', dlistr)
								cs_div = re.sub(r"cs_dli_HTML", cs_p, cs_div)
						else:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupres)
							cs_div = re.sub(r"cs_dli_HTML", cs_p, cs_div)
					else:
						cs_div = re.sub(r"cs_dli_HTML", "", cs_div)
				
				# DID:
				elif tup[1] == 'did':
					# Prioritize decision value over structured DID:
					tupres = iqrepgen_dict[tup[1]]
					if tupres not in ['U', 'P', 'E']:
						tupresstr = "%s" % tupres
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupresstr)
						cs_div = re.sub(r"cs_did_HTML", cs_p, cs_div)
					else:
						struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'FNL_DSPN_DT', 'U', 'U', 'U')
						if len(set(struct_val_list)) == 1 and struct_val_list[0] not in ['U', 'P', 'E']:
							tupresstr = "%s (NOTE: Not derived from decision - double check this value's accuracy)" % struct_val_list[0]
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupresstr)
							cs_div = re.sub(r"cs_did_HTML", cs_p, cs_div)
						else:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
							cs_div = re.sub(r"cs_dli_HTML", cs_p, cs_div)
				
				# Circuit:
				elif tup[1] == 'circuit':
					# Prefer decision circuit over structured value:
					tupres = iqrepgen_dict[tup[1]]
					if tupres in ['U', 'P', 'E', '']:
						circuit_struct = iqrepgen_dict['CIRCUIT_STRUCT']
						if not circuit_struct or circuit_struct in ['U', 'P', 'E', '']:
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
							cs_div = re.sub(r"cs_circuitar_HTML", cs_p, cs_div)
						else:
							circuitvalstr = circuit_struct
							circuitstr = "%s (NOTE: Not derived from decision - double check this value's accuracy)" % circuitvalstr
							cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', circuitstr)
							# Retrieve relevant AR data for this circuit, and append it to cs_p as a list:
							ardf_rel = ardf.loc[ardf.ar_circuit == str(circuit_struct)]
							if len(ardf_rel) != 0:
								ardf_rel_dictlist = ardf_rel.to_dict(orient='records')
								ardf_rel_linklist = ["""<a href="%s" target="_blank">%s - %s: %s</a>""" % (subd['ar_url'], subd['ar_shortnm'], subd['ar_longnm'], subd['ar_desc']) for subd in ardf_rel_dictlist]
								ardf_rel_linklist = ["<li>%s</li>" % link for link in ardf_rel_linklist]
								cs_p = cs_p + "<ul>" + "\n".join(ardf_rel_linklist) + "</ul>"
							cs_div = re.sub(r"cs_circuitar_HTML", cs_p, cs_div)
					else:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupres)
						# Retrieve relevant AR data for this circuit, and append it to cs_p as a list:
						ardf_rel = ardf.loc[ardf.ar_circuit == str(tupres)]
						if len(ardf_rel) != 0:
							ardf_rel_dictlist = ardf_rel.to_dict(orient='records')
							ardf_rel_linklist = ["""<a href="%s" target="_blank">%s - %s: %s</a>""" % (subd['ar_url'], subd['ar_shortnm'], subd['ar_longnm'], subd['ar_desc']) for subd in ardf_rel_dictlist]
							ardf_rel_linklist = ["<li>%s</li>" % link for link in ardf_rel_linklist]
							cs_p = cs_p + "<ul>" + "\n".join(ardf_rel_linklist) + "</ul>"
						cs_div = re.sub(r"cs_circuitar_HTML", cs_p, cs_div)
				
				# Date RR Filed and RR Deadline:
				# TIP: 'iqrtemplate.html' placeholder = 'cs_rrtimely_HTML'
				elif tup[1] == 'CRNT_RQSTD_DT':
					
					# If own motion, do NOT parse RR deadline (not relevant):
					wkld_typ_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_oao', 'WKLD_TYP', 'U', 'U', 'U')
					if 'URR' in wkld_typ_list:
						cs_div = re.sub(r"cs_rrtimely_HTML", "", cs_div)
					else:
					
						# Retrieve 'didval', with 'did' prioritized over 'FNL_DSPN_DT':
						didval = 'U'
						did = iqrepgen_dict['did']
						if did in ['U', 'P', 'E', ''] or ';' in did:
							fnldspndt_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'FNL_DSPN_DT', 'U', 'U', 'U')
							fnldspndt_struct_val_nonu = [v for v in fnldspndt_struct_val_list if v not in ['U', 'E']]
							if len(set(fnldspndt_struct_val_nonu)) == 1:
								didval = fnldspndt_struct_val_nonu[0]
						else:
							didval = did
							
						# Calc 'rr_deadline_str' using 'didval':
						rr_deadline_str = 'U'
						if didval != 'U':
							rr_deadline_restup = ifsiqrcc.calc_rr_deadline(didval)
							if rr_deadline_restup[0] != 'E':
								rr_deadline_str = rr_deadline_restup[0]
							
						# Retrieve ARPS RR filing date:
						rrfdval = 'U'
						rrdt_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_oao', 'CRNT_RQSTD_DT', 'U', 'U', 'U')
						rrdt_struct_val_nonu = [v for v in rrdt_struct_val_list if v not in ['U', 'E']]
						if len(set(rrdt_struct_val_nonu)) == 1:
							rrfdval = rrdt_struct_val_nonu[0]
						
						# Calc timeliness:
						timelinessver = 'U'
						if rr_deadline_str != 'U' and rrfdval != 'U':
							rr_deadline_dt = dh.parse_date_todatetime_struct(rr_deadline_str)
							rrfdval_dt = dh.parse_date_todatetime_struct(rrfdval)
							if rr_deadline_dt != 'E' and rrfdval_dt != 'E':
								if rrfdval_dt > rr_deadline_dt:
									timelinessver = 'No'
								else:
									timelinessver = 'Yes'
						
						# Generate output:
						rr_str = 'U'
						if timelinessver == 'No':
							if rr_deadline_restup[1] not in ['U', 'E']:
								rr_str = 'Possibly Untimely (Filing Deadline: %s %s; ARPS RR Filing Date: %s)' % (rr_deadline_restup[0], rr_deadline_restup[1], rrfdval)
								cs_p = cs_p_purplecontent.replace('cs_title', tup[0]).replace('cs_val', rr_str)
								cs_div = re.sub(r"cs_rrtimely_HTML", cs_p, cs_div)
							else:
								rr_str = 'Possibly Untimely (Filing Deadline: %s; ARPS RR Filing Date: %s)' % (rr_deadline_restup[0], rrfdval)
								cs_p = cs_p_purplecontent.replace('cs_title', tup[0]).replace('cs_val', rr_str)
								cs_div = re.sub(r"cs_rrtimely_HTML", cs_p, cs_div)
						else:
							if rr_deadline_str != 'U':
								if rr_deadline_restup[1] not in ['U', 'E']:
									rr_str = 'Filing Deadline: %s %s' % (rr_deadline_restup[0], rr_deadline_restup[1])
									cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', rr_str)
									cs_div = re.sub(r"cs_rrtimely_HTML", cs_p, cs_div)
								else:
									rr_str = 'Filing Deadline: %s' % rr_deadline_restup[0]
									cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', rr_str)
									cs_div = re.sub(r"cs_rrtimely_HTML", cs_p, cs_div)
							else:
								rr_str = 'Unknown'
								cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', rr_str)
								cs_div = re.sub(r"cs_rrtimely_HTML", cs_p, cs_div)
				
				# SSO Code based on Claimant Address Zip Code in Decision:
				elif tup[1] == 'sso':
					clzip_txt = iqrepgen_dict['clzip']
					if clzip_txt in ['U', 'P', 'E', ''] or ';' in clzip_txt:
						cs_title_custom = tup[0].replace(" (clzip_HTML)", "")
						cs_p = cs_p_tpl.replace('cs_title', cs_title_custom).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_sso_decisionzip_HTML", cs_p, cs_div)
					else:
						cs_title_custom = tup[0].replace("clzip_HTML", clzip_txt)
						sso_res = ifsdam.retrieve_doors(clzip_txt)
						if sso_res == 'E':
							sso_return_html = """We're sorry, SSO code retrieval is temporarily unavailable. But here is the <a href="https://sso.ba.ssa.gov/doorsRwWeb/_#findUsaByZip?zipCode=%s" target="_blank">DOORS page</a> for this zip code.""" % clzip_txt
							cs_p = cs_p_tpl.replace('cs_title', cs_title_custom).replace('cs_val', sso_return_html)
							cs_div = re.sub(r"cs_sso_decisionzip_HTML", cs_p, cs_div)
						elif sso_res == 'U':
							sso_return_html = """Unable to locate an SSO code for this zip code.  Please try another zip code using the SSO Code Lookup Tool or consult <a href="https://sso.ba.ssa.gov/doorsRwWeb/" target="_blank">DOORS</a>."""
							cs_p = cs_p_tpl.replace('cs_title', cs_title_custom).replace('cs_val', sso_return_html)
							cs_div = re.sub(r"cs_sso_decisionzip_HTML", cs_p, cs_div)
						else:
							sso_return_html = """<a href="https://sso.ba.ssa.gov/doorsRwWeb/_#findUsaByZip?zipCode=%s" target="_blank">%s</a>""" % (clzip_txt, sso_res)
							cs_p = cs_p_tpl.replace('cs_title', cs_title_custom).replace('cs_val', sso_return_html)
							cs_div = re.sub(r"cs_sso_decisionzip_HTML", cs_p, cs_div)
				
				
				# Age at Start of PAI & PAI Start Date:
				elif tup[1] == 'STRUCT_AGEREL_PAISTART':
					tupres = iqrepgen_dict[tup[1]]
					tupres_src = iqrepgen_dict['STRUCT_AGEREL_PAISTART_SRC']
					paistart = iqrepgen_dict['paistart']
					clmt_dob = 'U'
					dob_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
					if dob_struct_val_list and len(list(set(dob_struct_val_list))) == 1:
						clmt_dob = dob_struct_val_list[0]
					if tupres in ['U', 'P', 'E', ''] or paistart in ['U', 'P', 'E', '']:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_structagerelpaistart_HTML", cs_p, cs_div)
					else:
						# Calculate applicable age category:
						paistartstr = 'start of PAI: Unknown'
						if tupres_src == '1':
							paistartstr = 'start of PAI: %s [NOTE: calculated from structured data]' % paistart
						else:
							paistartstr = 'start of PAI: %s' % paistart
						tupres_str = 'Unknown'
						tupres_agecat = 'E'
						if paistart not in ['U', 'P', 'E'] and clmt_dob != 'U':
							tupres_agecat = ifsiqrcc.calc_agecat(clmt_dob, paistart)
						if tupres_agecat != 'E':
							tupres_str = "%s / %s (%s)" % (tupres, tupres_agecat, paistartstr)
						else:
							tupres_str = "%s (%s)" % (tupres, paistartstr)
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupres_str)
						cs_div = re.sub(r"cs_structagerelpaistart_HTML", cs_p, cs_div)
						
				# Age at End of PAI & PAI End Date:
				elif tup[1] == 'STRUCT_AGEREL_PAIEND':
					tupres = iqrepgen_dict[tup[1]]
					tupres_src = iqrepgen_dict['STRUCT_AGEREL_PAIEND_SRC']
					paiend = iqrepgen_dict['paiend']
					clmt_dob = 'U'
					dob_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
					if dob_struct_val_list and len(list(set(dob_struct_val_list))) == 1:
						clmt_dob = dob_struct_val_list[0]
					if tupres in ['U', 'P', 'E', ''] or paiend in ['U', 'P', 'E', '']:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_structagerelpaiend_HTML", cs_p, cs_div)
					else:
						# Calculate applicable age category:
						paiendstr = 'end of PAI: Unknown'
						if tupres_src == '1':
							paiendstr = 'end of PAI: %s [NOTE: calculated from structured data]' % paiend
						else:
							paiendstr = 'end of PAI: %s' % paiend
						tupres_str = 'Unknown'
						tupres_agecat = 'E'
						if paiend not in ['U', 'P', 'E'] and clmt_dob != 'U':
							tupres_agecat = ifsiqrcc.calc_agecat(clmt_dob, paiend)
						if tupres_agecat != 'E':
							tupres_str = "%s / %s (%s)" % (tupres, tupres_agecat, paiendstr)
						else:
							tupres_str = "%s (%s)" % (tupres, paiendstr)
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', tupres_str)
						cs_div = re.sub(r"cs_structagerelpaiend_HTML", cs_p, cs_div)
						
				# Claimant Weight Analysis Result Based on Self Reports:
				elif tup[1] == 'weight':
					
					# Custom Claimant Report-Based BMI:
					# Gather argument values needed to calculate/interpret BMI:
					sex = 'U'
					sex_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'SEX', 'U', 'U', 'U')
					if sex_struct_val_list and len(list(set(sex_struct_val_list))) == 1:
						sex = sex_struct_val_list[0]

					ht_inch = 'U'
					ht_inch_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'HT_INCH', 'U', 'U', 'U')
					if ht_inch_struct_val_list and len(list(set(ht_inch_struct_val_list))) == 1:
						ht_inch = ht_inch_struct_val_list[0]

					wt_lb = 'U'
					wt_lb_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'WT_LB', 'U', 'U', 'U')
					if wt_lb_struct_val_list and len(list(set(wt_lb_struct_val_list))) == 1:
						wt_lb = wt_lb_struct_val_list[0]
						
					clmt_dob = 'U'
					clmt_dob_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'CLMT_DOB', 'U', 'U', 'U')
					if clmt_dob_struct_val_list and len(list(set(clmt_dob_struct_val_list))) == 1:
						clmt_dob = clmt_dob_struct_val_list[0]

					fnl_dspn_dt = 'U'
					fnl_dspn_dt_struct_val_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'struct_hodisp', 'FNL_DSPN_DT', 'U', 'U', 'U')
					if fnl_dspn_dt_struct_val_list and len(list(set(fnl_dspn_dt_struct_val_list))) == 1:
						fnl_dspn_dt = fnl_dspn_dt_struct_val_list[0]				
					
					struct_agerel_paiend = iqrepgen_dict['STRUCT_AGEREL_PAIEND']
					
					# Call weight parsing function:
					wt_resdict = bmi.parse_weight(sex, ht_inch, wt_lb, struct_agerel_paiend, clmt_dob, fnl_dspn_dt)
					wt_interp_str = wt_resdict['interp_str']
					if wt_interp_str != 'E':
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', wt_interp_str)
						cs_div = re.sub(r"cs_selfwt_HTML", cs_p, cs_div)
					else:
						cs_p = cs_p_tpl.replace('cs_title', tup[0]).replace('cs_val', 'Unknown')
						cs_div = re.sub(r"cs_selfwt_HTML", cs_p, cs_div)
			
			# Insert 'cs_div' into 'iqhtml':
			iqhtml = iqhtml.replace('<!--cs_div_HTML-->', cs_div)

		except Exception:
			logger.exception('EXCEPTION')
		
		
		# Quality Issue Count:
		try:
			iqrepgen_dict_vernmlist = [c for c in iqrepgen_dict.keys() if '_ver' in c and 'flag_' in c]
			# Filter to only production flags:
			flagdatadf_cols = [v + '_ver' for v in flagdatadf['iqvarnm'].tolist()]
			iqrepgen_dict_vernmlist = [cn for cn in iqrepgen_dict_vernmlist if cn in flagdatadf_cols]
			# Count values:
			flagct = 0
			for cn in iqrepgen_dict_vernmlist:
				cn_val = iqrepgen_dict[cn]
				if cn_val == '1':
					flagct += 1
			if flagct == 0:
				iqhtml = re.sub(r"qualityissuectclass_HTML", "reportsectionqsummarynone", iqhtml)
			else:
				iqhtml = re.sub(r"qualityissuectclass_HTML", "reportsectionqsummaryred", iqhtml)
			
			qualityissuect_resstr = "Total Quality Issues Detected: %s" % str(flagct)
			iqhtml = iqhtml.replace('qualityissuect_HTML', qualityissuect_resstr)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = iqhtml.replace('qualityissuect_HTML', '')

		# Step 1 SGA Verdict:
		try:
			s1sgaver_dict = {"1":"No period of SGA", "2":"Period of SGA and 12+ month period of non-SGA", "3":"Period of SGA (whether 12+ month period of non-SGA unknown)", "4":"Period of SGA (whether 12+ month period of non-SGA unknown)"}
			s1sgaver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's1sga', 's1sgaver', 1, s1sgaver_dict)
			iqhtml = re.sub(r"s1sgaver_HTML", s1sgaver_txt, iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"s1sgaver_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)

		# Step 2 Verdict:
		try:
			s2ver_dict = {"1":"Severe MDI(s)", "2":"Non-Severe MDI(s)", "3":"No MDI(s)"}
			s2ver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's2', 's2ver', 1, s2ver_dict)
			iqhtml = re.sub(r"s2ver_HTML", s2ver_txt, iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"s2ver_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)

		# Step 3 Meets/Equals Verdict:
		try:
			s3mteqver_dict = {"1":"Does Not Meet/Equal Listing(s)", "2":"Yes, Meets Listing(s)", "3":"Yes, Medically Equals Listing(s)", "4":"Yes, Meets/Medically Equals Listing(s) (Precise Type Unknown)"}
			s3mteqver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's3mteq', 's3mteqver', 1, s3mteqver_dict)
			iqhtml = re.sub(r"s3mteqver_HTML", s3mteqver_txt, iqhtml)			
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"s3mteqver_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)

		# Generate 'exclusively child claim' verdict data to determine 
		# whether or not to omit RFC, Step 4, and Step 5 content:
		ecc_anychildver = 'U'
		ecc_allchildver = 'U'
		try:
			clm_typ_list = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 'CLAIMDISP_STRUCT', 'CLM_TYP', 'U', 'U', 'U')
			# Check if any structured claim types are 'child' claim types:
			if clm_typ_list:
				if len([c for c in clm_typ_list if 'Child' in c and 'Adult' not in c]) != 0:
					ecc_anychildver = '1'
				else:
					ecc_anychildver = '0'
			# Check if all structured claim types are 'child' claim types:
			if clm_typ_list:
				if len(clm_typ_list) == len([c for c in clm_typ_list if 'Child' in c and 'Adult' not in c]):
					ecc_allchildver = '1'
				else:
					ecc_allchildver = '0'
		except Exception:
			logger.exception('EXCEPTION')

		# Step 3 Functionally Equals Verdict:
		try:
			s3feqver_dict = {"1":"Yes, Functionally Equals", "2":"Does Not Functionally Equal"}
			if not iqrepgen_dict['s3feq'] and ecc_anychildver == 0:
				pass
			else:
				iqhtml = re.sub(r"<!-- s3feq_PH -->", s3feq_PH_tpl, iqhtml)
				s3feqver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's3feq', 's3feqver', 1, s3feqver_dict)
				iqhtml = re.sub(r"s3feqver_HTML", s3feqver_txt, iqhtml)
		except Exception:
			logger.exception('EXCEPTION')
			iqhtml = re.sub(r"<!-- s3feq_PH -->", s3feq_PH_tpl, iqhtml)
			iqhtml = re.sub(r"s3feqver_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)
		
		# Branching logic for RFC onward:
		if not iqrepgen_dict['rfc'] and not iqrepgen_dict['s4'] and not iqrepgen_dict['s5'] and ecc_allchildver == '1':
			pass
		else:
			
			# RFC Exertional Level:
			try:
				iqhtml = re.sub(r"<!-- rfc_PH -->", rfc_PH_tpl, iqhtml)
				rfcexlvl_dict = {"F":"Full Exertion", "H":"Heavy Exertion", "M":"Medium Exertion", "L":"Light Exertion", "S":"Sedentary Exertion"}
				rfcexlvl_parsed_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 'rfc', 'rfcexlvl_parsed', 1, rfcexlvl_dict)
				iqhtml = re.sub(r"rfcfitexlvl_HTML", rfcexlvl_parsed_txt, iqhtml)
			except Exception:
				logger.exception('EXCEPTION')
				iqhtml = re.sub(r"<!-- rfc_PH -->", rfc_PH_tpl, iqhtml)
				iqhtml = re.sub(r"rfcfitexlvl_HTML", ifsiqrcc.trans_stock_vals("U"), iqhtml)

			# Step 4 Verdict:
			try:
				iqhtml = re.sub(r"<!-- s4_PH -->", s4_PH_tpl, iqhtml)
				s4ver_dict = {"1":"Can Perform PRW", "2":"Cannot Perform PRW", "3":"Has No PRW", "4":"Expedited Finding"}
				s4ver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's4', 's4ver', 1, s4ver_dict)
				iqhtml = iqhtml.replace("s4ver_HTML", s4ver_txt)
			except Exception:
				logger.exception('EXCEPTION')
				iqhtml = re.sub(r"<!-- s4_PH -->", s4_PH_tpl, iqhtml)
				iqhtml = iqhtml.replace("s4ver_HTML", ifsiqrcc.trans_stock_vals("U"))

			# Step 5 Verdict & MVR Values:
			try:
				# Calculate the Step 5 string value:
				s5ver_dict = {"1":"Can Perform Other Work", "2":"Can Perform Other Work (Alternative Finding)", "3":"Cannot Perform Other Work"}
				s5ver_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 's5', 's5ver', 1, s5ver_dict)
				# Calculate MVR parenthetical value:
				if s5ver_txt != 'Unknown':
					s5mvr_txt = ifsiqrcc.createbgtxt_findingchild(iqrepgen_dict, 'mvr', 's5mvr', 0, {})
					if s5mvr_txt != 'Unknown':
						s5ver_txt = s5ver_txt + ' (MVRs: ' + s5mvr_txt + ')'
				iqhtml = re.sub(r"<!-- s5_PH -->", s5_PH_tpl, iqhtml)
				iqhtml = iqhtml.replace("s5ver_HTML", s5ver_txt)
			except Exception:
				logger.exception('EXCEPTION')
				iqhtml = re.sub(r"<!-- s5_PH -->", s5_PH_tpl, iqhtml)
				iqhtml = iqhtml.replace("s5ver_HTML", ifsiqrcc.trans_stock_vals("U"))
		

		# Quality Flags:

		# Define JQuery container list and SEP step container lists:
		jquerycontainer = []
		s1flagprobtuplist = []
		s1flagothertuplist = []
		s2flagprobtuplist = []
		s2flagothertuplist = []
		s3mteqflagprobtuplist = []
		s3mteqflagothertuplist = []
		s3feqflagprobtuplist = []
		s3feqflagothertuplist = []
		rfcflagprobtuplist = []
		rfcflagothertuplist = []
		s4flagprobtuplist = []
		s4flagothertuplist = []
		s5flagprobtuplist = []
		s5flagothertuplist = []
		
		# (DEV)
		impexpreslist = []
		impexpimpairmentslist = []
		impexpfindingslist = []

		# Flag text creation function for self-contained flags (i.e. flags where the variable
		# name 'val' is sufficient in itself to create the flag's human-readable content):
		def createflagtext_selfcontained(varnm, valpresent):
			try:
				vernm = varnm + "_ver"
				ver = iqrepgen_dict[vernm]
				if ver == "1":
					if valpresent == "1":
						try:
							# Gather all 'quality.val' entries:
							valnm = varnm + "_val"
							val_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							val_reslist_cleaned = []
							for resd in val_resdictlist:
								val = resd['val']
								val = str(val)
								val = val.translate(notranstab, "[]")
								val = val.strip()
								val = re.sub(r"^(\"|')", "", val)
								val = re.sub(r"(\"|')$", "", val)
								val = val.replace("', '", ", ")
								val = val.replace("(TEXT=", "&nbsp;&nbsp;(TEXT=")
								val_reslist_cleaned.append(val)
							flagtxt = "&#x2718; " + " / ".join(val_reslist_cleaned)
						except Exception, x:
							flagtxt = "&#x2718; (Error - Cannot Retrieve Flag Value Text [Error Message: " + str(x) + "])"
						return flagtxt
					else:
						flagtxt = "&#x2718;"
						return flagtxt
				elif ver == "0":
					flagtxt = "&#x2714;"
					return flagtxt
				elif ver.startswith("P"):
					flagtxt = "Unknown"
					return flagtxt
				elif ver.startswith("U"):
					flagtxt = "Unknown"
					return flagtxt
				elif ver.startswith("E"):
					flagtxt = "Error - Internal"
					return flagtxt
				else:
					flagtxt = "Error - Unknown Data Point Value (Value: " + ver + ")"
					return flagtxt
			except KeyError:
				flagtxt = "Error - Structured Data Not Linked"
				return flagtxt
			except Exception:
				logger.exception('EXCEPTION')
				flagtxt = "Error - Insight Quality Report Generation Script Error"
				return flagtxt

		# Flag text creation function for NON-self-contained flags
		# (i.e. flags whose content cannot be geenerated solely
		# by translation of that flag's target IQ variable
		# verdict and value, but also require other data values in the
		# IQ dictionary):
		def createflagtext_nonselfcontained(varnm, valpresent):
			try:

				# Step 1:

				# Step 2:
				if varnm == "flag_s2mdi_selfwt":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									resd_val = resd_val.replace("color:red", "color:#9900cc")
									flag_htmlreslist.append(resd_val)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"					

				# Step 3 Meets/Equals:

				# Step 3 Functionally Equals:

				# RFC:
				elif varnm == "flag_rfc_logicconflict":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									logicconflict_transdict = {"1":"Claimant's capacities to sit, stand, and walk total less than 8 hours", "2":"Sedentary exertion paired with a finding that the claimant cannot stoop"}
									if resd_val in logicconflict_transdict:
										flag_htmlreslist.append(logicconflict_transdict[resd_val])
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"	

				# Step 4:
				elif varnm == "flag_s4dotrfc":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							# Begin custom flag text creation for 'flag_s4dotrfc_conflict':
							
							valnm = varnm + "_val"
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								flag_s4dotrfc_alls4obs_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									if isinstance(resd_val, str):
										resd_val = ast.literal_eval(resd_val)
									# TIP: Example resd: {'569686046': ['rfcreachlol=N vs dotreachlol=O'], '311472010': ['rfcreachlol=F vs dotreachlol=C', 'rfchandlelol=F vs dothandlelol=C', 'rfcfingerlol=F vs dotfingerlol=C', 'rfcfeellol=F vs dotfeellol=C']}
									# TIP: Target output:
									# """
									# 569686046: RFC reach capacity level = never, but DOT reach capacity level = occasional 
									# <br>
									# 311472010: RFC reach capacity level = frequent, but DOT reach capacity level = constant; RFC handle capacity level = frequent, but DOT handle capacity level = constant
									# """
									flag_s4dotrfc_val_combined = []
									for k,v in resd_val.iteritems():
										conflict_trans_list = []
										for conflict in v:
											try:
												conflicttrans = ""
												rfcflagval = conflict.split(" vs ")[0]
												rfcflagval_FA_RAW = rfcflagval.split("=")[0]
												rfcflagval_FA = rfcflagval_FA_RAW[3:]
												rfcflagval_FA = rfcflagval_FA[:-3]
												rfcflagval_FA = ifsiqrcc.translate_rfc_fa(rfcflagval_FA)
												conflicttrans += str("RFC " + rfcflagval_FA + " capacity level = ")
												rfcflagval_LOL = rfcflagval.split("=")[1]
												if '; ' in rfcflagval_LOL:
													rfcflagval_LOL = rfcflagval_LOL.split('; ')
													rfcflagval_LOL = ', '.join([ifsiqrcc.translate_rfc_lol(el) for el in rfcflagval_LOL])
												else:
													rfcflagval_LOL = ifsiqrcc.translate_rfc_lol(rfcflagval_LOL)
												conflicttrans += str(rfcflagval_LOL + ", but DOT " + rfcflagval_FA + " capacity level = ")
												
												dotflagval = conflict.split(" vs ")[1]
												dotflagval_LOL = dotflagval.split("=")[1]
												if '[' in dotflagval_LOL:
													dotflagval_LOL = ast.literal_eval(dotflagval_LOL)
													dotflagval_LOL = ', '.join([ifsiqrcc.translate_rfc_lol(el) for el in dotflagval_LOL])
												else:
													dotflagval_LOL = ifsiqrcc.translate_rfc_lol(dotflagval_LOL)
												conflicttrans += dotflagval_LOL
												conflict_trans_list.append(conflicttrans)
											except Exception:
												logger.exception('EXCEPTION')
												conflict_trans_list.append(conflict)
										
										conflict_trans_list_joined = "; ".join(conflict_trans_list)
										flagstr = "DOT " + k + ": " + conflict_trans_list_joined
										flag_s4dotrfc_val_combined.append(flagstr)
									
									flag_s4dotrfc_alls4obs_htmlreslist.append("<br>".join(flag_s4dotrfc_val_combined))
								
								flag_s4dotrfc_alls4obs_html = "<br><br>".join(flag_s4dotrfc_alls4obs_htmlreslist)
								flag_s4dotrfc_alls4obs_html = "&#x24be; <br>" + flag_s4dotrfc_alls4obs_html
								return flag_s4dotrfc_alls4obs_html
					except Exception:
						logger.exception('EXCEPTION')
						logger.critical(iqrepgen_dict['flag_s4dotrfc_ver'])
						return "Error - Unknown INSIGHT Quality Report Generation Error"
				
				# Step 5:

				# flag_s5dotrfc_conflict:
				elif varnm == "flag_s5dotrfc":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							valnm = varnm + "_val"
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								flag_s5dotrfc_alls5obs_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									if isinstance(resd_val, str):
										resd_val = ast.literal_eval(resd_val)
									# TIP: Example resd: {'569686046': ['rfcreachlol=N vs dotreachlol=O'], '311472010': ['rfcreachlol=F vs dotreachlol=C', 'rfchandlelol=F vs dothandlelol=C', 'rfcfingerlol=F vs dotfingerlol=C', 'rfcfeellol=F vs dotfeellol=C']}
									# TIP: Target output:
									# """
									# 569686046: RFC reach capacity level = never, but DOT reach capacity level = occasional 
									# <br>
									# 311472010: RFC reach capacity level = frequent, but DOT reach capacity level = constant; RFC handle capacity level = frequent, but DOT handle capacity level = constant
									# """
									flag_s5dotrfc_val_combined = []
									for k,v in resd_val.iteritems():
										conflict_trans_list = []
										for conflict in v:
											try:
												conflicttrans = ""
												rfcflagval = conflict.split(" vs ")[0]
												rfcflagval_FA_RAW = rfcflagval.split("=")[0]
												rfcflagval_FA = rfcflagval_FA_RAW[3:]
												rfcflagval_FA = rfcflagval_FA[:-3]
												rfcflagval_FA = ifsiqrcc.translate_rfc_fa(rfcflagval_FA)
												conflicttrans += str("RFC " + rfcflagval_FA + " capacity level = ")
												rfcflagval_LOL = rfcflagval.split("=")[1]
												if '; ' in rfcflagval_LOL:
													rfcflagval_LOL = rfcflagval_LOL.split('; ')
													rfcflagval_LOL = ', '.join([ifsiqrcc.translate_rfc_lol(el) for el in rfcflagval_LOL])
												else:
													rfcflagval_LOL = ifsiqrcc.translate_rfc_lol(rfcflagval_LOL)
												conflicttrans += str(rfcflagval_LOL + ", but DOT " + rfcflagval_FA + " capacity level = ")
												
												dotflagval = conflict.split(" vs ")[1]
												dotflagval_LOL = dotflagval.split("=")[1]
												if '[' in dotflagval_LOL:
													dotflagval_LOL = ast.literal_eval(dotflagval_LOL)
													dotflagval_LOL = ', '.join([ifsiqrcc.translate_rfc_lol(el) for el in dotflagval_LOL])
												else:
													dotflagval_LOL = ifsiqrcc.translate_rfc_lol(dotflagval_LOL)
												conflicttrans += dotflagval_LOL
												conflict_trans_list.append(conflicttrans)
											except Exception:
												logger.exception('EXCEPTION')
												conflict_trans_list.append(conflict)
										
										conflict_trans_list_joined = "; ".join(conflict_trans_list)
										flagstr = "DOT " + k + ": " + conflict_trans_list_joined
										flag_s5dotrfc_val_combined.append(flagstr)
									
									flag_s5dotrfc_alls5obs_htmlreslist.append("<br>".join(flag_s5dotrfc_val_combined))
								
								flag_s5dotrfc_alls5obs_html = "<br><br>".join(flag_s5dotrfc_alls5obs_htmlreslist)
								flag_s5dotrfc_alls5obs_html = "&#x2718; <br>" + flag_s5dotrfc_alls5obs_html
								return flag_s5dotrfc_alls5obs_html
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5bordage:
				elif varnm == "flag_s5bordage":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							valnm = varnm + "_val"
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									mvr_reslist = []
									resd_val_split = resd['val'].split('; ')
									for resd_val_mvr in resd_val_split:
										mvr_reslist.append(resd_val_mvr)
									
									struct_age_paiend = iqrepgen_dict['STRUCT_AGEREL_PAIEND']
									paiend = iqrepgen_dict['paiend']
									# NOTE: Ok, so at this juncture your IQ result for flag_s5mvrbordage may entail a semicolon-divided STRUCT_AGEREL_PAIEND,
									# e.g. "25-y-6-m (T2 DIB); 32-y-1-m (T16 SSI)".	 You'll need to be cognizant of that fact here.	 But for now,
									# I'll simply output the value, semicolon or no.
									flag_s5mvrbordage_HTML_text = "Claimant age at end of PAI (%s): %s vs. borderline MVR(s): %s" % (paiend, struct_age_paiend, '; '.join(mvr_reslist))
									flag_htmlreslist.append(flag_s5mvrbordage_HTML_text)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5mvrrfcexlvl:
				elif varnm == "flag_s5mvrrfcexlvl":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								rfcfitexlvl_strdict = {"F":"Full", "H":"Heavy", "M":"Medium", "L":"Light", "S":"Sedentary"}
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val_split = resd['val'].split(' vs ')
									rfcexlvl_list = ast.literal_eval(resd_val_split[0])
									rfcexlvl_list_trans_str = '; '.join([rfcfitexlvl_strdict[exlvl] for exlvl in rfcexlvl_list])
									mvr_list_trans_str = '; '.join(ast.literal_eval(resd_val_split[1]))
									resd_val_str = "RFC Exertional Level(s): " + rfcexlvl_list_trans_str + " vs MVR(s): " + mvr_list_trans_str
									flag_htmlreslist.append(resd_val_str)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5mvragepai:
				elif varnm == "flag_s5mvragepai":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								struct_agerel_paistart = iqrepgen_dict["STRUCT_AGEREL_PAISTART"]
								struct_agerel_paistart_year = re.search(r"^\d+", struct_agerel_paistart).group()
								struct_agerel_paiend = iqrepgen_dict["STRUCT_AGEREL_PAIEND"]
								struct_agerel_paiend_year = re.search(r"^\d+", struct_agerel_paiend).group()
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									resd_val_str = "Claimant Age Range: " + struct_agerel_paistart_year + "-" + struct_agerel_paiend_year + " vs MVR(s): " + resd_val
									flag_htmlreslist.append(resd_val_str)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5mvragepaiend:
				elif varnm == "flag_s5mvragepaiend":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								struct_agerel_paiend = iqrepgen_dict["STRUCT_AGEREL_PAIEND"]
								struct_agerel_paiend_year = re.search(r"^\d+", struct_agerel_paiend).group()
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									resd_val_str = "Claimant Age at End of PAI: " + struct_agerel_paiend_year + " vs MVR(s): " + resd_val
									flag_htmlreslist.append(resd_val_str)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5mvred:
				elif varnm == "flag_s5mvred":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								edver_val_translation_dict = {"I":"Illiterate", "M":"Marginal", "L":"Limited", "H":"High School"}
								
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									edver = iqrepgen_dict['edver']
									edver_split = edver.split('; ')
									edver_trans = ' '.join([edver_val_translation_dict[ev] for ev in edver_split])
									#edver_trans = edver_val_translation_dict[edver]
									resd_val_str = "Education level(s) found: " + edver_trans + " vs MVR(s): " + resd_val
									flag_htmlreslist.append(resd_val_str)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# flag_s5mvrtx:
				elif varnm == "flag_s5mvrtx":
					try:
						vernm = varnm + "_ver"
						ver = iqrepgen_dict[vernm]
						valnm = varnm + "_val"
						if ver == "0" or bool(ver.startswith("P")) or bool(ver.startswith("U")) or bool(ver.startswith("E")):
							flagtxt = createflagtext_selfcontained(varnm, valpresent)
							return flagtxt
						else:
							flag_resdictlist = ifsiqrcc.gather_quality_val(iqrepgen_dict['quality'], valnm)
							if not flag_resdictlist:
								return "Error - Unable to Retrieve Quality Flag Details"
							else:
								txskillsver_strdict = {"1":"Yes TX Skills", "2":"No TX Skills", "3":"TX Skills Not An Issue/Material"}
								flag_htmlreslist = []
								for resd in flag_resdictlist:
									resd_val = resd['val']
									txskillsver = iqrepgen_dict['txskillsver']
									txskillsver_trans = txskillsver_strdict[txskillsver]
									resd_val_str = "Transferability finding: " + txskillsver_trans + " vs MVR(s): " + resd_val
									flag_htmlreslist.append(resd_val_str)
								flag_htmlreslist_txt = ' / '.join(flag_htmlreslist)
								flag_htmlreslist_txt = "&#x2718; " + flag_htmlreslist_txt
								return flag_htmlreslist_txt
					except Exception:
						logger.exception('EXCEPTION')
						return "Error - Unknown INSIGHT Quality Report Generation Error"

				# If none of these matched, return error text:
				else:
					err_str = "Error - iqrgenerator.createflagtext_nonselfcontained() could not locate parser for 'iqvarnm' (%s)" % varnm
					logger.critical(err_str)
					return "Error - Unable to Retrieve Quality Flag Details"
			
			except Exception:
				logger.exception('EXCEPTION')
				return "Error - Unable to Retrieve Quality Flag Details"


		# (DEVELOPMENT) Create RFC/DOT table:
		# TODO: Generalize this so that it works for Step 5 DOT/RFC conflict table generation:
		def createtablerows():
			try:
				# Gather DOT-specific content:
				s4dotcombinedtgt_resdict = {}
				s4dotcombinedtgtlist = ['s4dotfinding1', 's4dotfinding2', 's4dotfinding3', 's4dotfinding4', 's4dotfinding5', 's4dotbody1', 's4dotbody2', 's4dotbody3', 's4dotbody4', 's4dotbody5']
				for varnm in s4dotcombinedtgtlist:
					varnm = "flag_s4dotrfc_" + varnm + "_val"
					varval = iqrepgen_dict[varnm]
					s4dotcombinedtgt_resdict[varnm] = varval
				if len([v for v in s4dotcombinedtgt_resdict.values() if v not in ['LE', 'E', '0', 'P']]) == 0:
					s4dotrfc_tablerrmsg = "Error generating table."
					return s4dotrfc_tablerrmsg
				else:
					s4dotrfc_rowhtmllist = []
					for k,v in s4dotcombinedtgt_resdict.iteritems():
						if isinstance(v, list):
							# Get DOT value:
							newk = k.replace("flag_s4dotrfc_", "")
							newk = newk.replace("_val", "")
							dotval = iqrepgen_dict[newk]
							if dotval not in ["E", "U", "P", ""]:
								newrow = dotrfc_tablerow.replace("VARIABLE_dotcode", dotval)
								conflictstr_all_list = []
								for conflict in v:
									conflictstr = ""
									rfcflagval = conflict.split(" vs ")[0]
									rfcflagval_FA = rfcflagval.split("=")[0]
									rfcflagval_FA = rfcflagval_FA[3:]
									rfcflagval_FA = rfcflagval_FA[:-3]
									if rfcflagval_FA == 'fitex':
										rfcflagval_FA = 'exertional'
									conflictstr += str("RFC " + rfcflagval_FA + " level of limitation = ")
									rfcflagval_LOL = rfcflagval.split("=")[1]
									rfcflagval_LOL = flagval_NOFCloldict[rfcflagval_LOL]
									conflictstr += str(rfcflagval_LOL + ", but DOT " + rfcflagval_FA + " capacity level = ")
									dotflagval = conflict.split(" vs ")[1]
									dotflagval_LOL = dotflagval.split("=")[1]
									dotflagval_LOL = flagval_NOFCloldict[dotflagval_LOL]
									conflictstr += dotflagval_LOL
									conflictstr_all_list.append(conflictstr)
								conflictstr_all_list_joined = " / ".join(conflictstr_all_list)
								newrow = newrow.replace("VARIABLE_rfcconflictstrs", conflictstr_all_list_joined)
								s4dotrfc_rowhtmllist.append(newrow)
					return "\n".join(s4dotrfc_rowhtmllist)
			except KeyError:
				flagtxt = "Error - Structured Data Not Linked"
				return flagtxt
			except Exception:
				logger.exception('EXCEPTION')
				flagtxt = "Error - Insight Quality Report Generation Script Error"
				return flagtxt


		# 'Create flag' function that will parse each 'flagdata' CSV row to determine if
		# the flag text is self-contained (and thus text creation can be routed to the self-contained flag text creation function) OR
		# is NOT self-contained (and thus text creation needs to be routed to a custom flag text creation function for that row)
		# and ultimately place some sort of HTML entity into the appropriate SEP step bin:
		def create_flagandff(row):
			try:
				# Set default values and retrieve flag template HTML:
				probver = '0'
				ffbtnplusform = ff_fullHTMLtemplate
				ffbtnplusform_textvarvals = ['VARIABLE_ffabout', 'VARIABLE_ffreg']
				ffbtnplusform_nontextvarvals = ['VARIABLE_fftogglebutton', 'VARIABLE_ffdiv', 'VARIABLE_ff', 'VARIABLE_ff_othertextbox', 'VARIABLE_ff_submit', 'VARIABLE_ff_reset']

				# Generate flag text, color, and assign 'probver' routing value:
				try:
					flagtxt_brief_desc = row['brief_desc'] + " "
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagtext_brief_desc", flagtxt_brief_desc)

					varnm = row['iqvarnm']
					valpresent = row['valpresent']
					selfcontainver = row['selfcontainver']
					
					# Create flag text translation value for this flag:
					if selfcontainver == '1':
						flagtxt = createflagtext_selfcontained(varnm, valpresent)
					else:
						flagtxt = createflagtext_nonselfcontained(varnm, valpresent)
					
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagtext", flagtxt)

					# (IN DEVELOPMENT)
					# If an RFC/DOT flag, generate DOT / RFC table:
					# TIP: This outputs below the standard 'flagtext' beside the flag name and colon.
					# OPENQ: Does this output even if no problems?
					# TODO: UPDATE FLAG DATA TO REFLECT REVISED S4DOTRFC VARIABLE NAME.
					# if "s4dotrfc" in varnm:
						# # TIP: If no s4dot #'s reflect an error, this will return an empty string.
						# tablerows = createtablerows()
						# if tablerows.startswith("Error") or tablerows == '':
							# pass
						# else:
							# # TIP: 'dotrfc_table' is an HTML snippet in iqrgenerator_templatesnippets.
							# tablehtml = dotrfc_table.replace("<!--DOTRFCROWSGOHERE-->", tablerows)
							# ffbtnplusform = ffbtnplusform.replace("<!--OPTIONALTABLEVARIABLE-->", tablehtml)
					
					
					# Based on 'flagtxt' output, set 'probver' routing value and flag color:
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagtext", flagtxt)
					if flagtxt.startswith("&#x2718;"):
						probver = "1"
						flagcolor = row['flagcolor']
						if flagcolor == "red":
							ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "redflagspan")
						elif flagcolor == "purple":
							ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "errflagspan")
						else:
							ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "orangeflagspan")
					elif flagtxt.startswith("&#x2714;"):
						ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "noflagspan")
					elif flagtxt.startswith("&#x24be;"):
						probver = "1"
						ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "errflagspan")
					elif flagtxt.startswith("Unknown"):
						ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "noflagspan")
					elif flagtxt.startswith("Error"):
						ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "errflagspan")
				except Exception:
					logger.exception('EXCEPTION')
					item_txt = "Error"
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagtext", item_txt)
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_flagcolor", "errflagspan")
					
				# Replace feedback form 'about' and 'reg' text:
				for item in ffbtnplusform_textvarvals:
					try:
						itemlookup = item.split("_")[1]
						itemtxt = row[itemlookup]
						ffbtnplusform = ffbtnplusform.replace(item, itemtxt)
					except Exception, x:
						logger.exception('EXCEPTION')
						item_txt = "Error - Cannot Retrieve Flag Dropdown Text [Error Message: " + str(x) + "]"
						ffbtnplusform = ffbtnplusform.replace(item, item_txt)

				# Replace feedback form 'checkbox' text:
				try:
					checkboxHTMLlist = []
					checkbox_txt = row['ffcheckboxstrlist']
					checkbox_txt_list = ast.literal_eval(checkbox_txt)
					for i, txt in enumerate(checkbox_txt_list):
						# Create a custom checkbox ID names:
						ff_checkbox_var = "VARIABLE_ffcheckboxCT".replace("VARIABLE", row['iqvarnm'])
						ff_checkbox_var = ff_checkbox_var.replace("CT", str(i))
						# Create the checkbox HTML (including subbing in the custom checkbox ID name):
						ff_checkbox = ff_checkboxtemplate.replace("VARIABLE_ffcheckboxCT", ff_checkbox_var)
						ff_checkbox = ff_checkbox.replace("TEXT", txt)
						ff_checkbox = "<label>" + ff_checkbox + "</label>"
						checkboxHTMLlist.append(ff_checkbox)
					checkboxHTMLlistjoined = "\n".join(checkboxHTMLlist)
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_CHECKBOXES", checkboxHTMLlistjoined)
				except Exception, x:
					logger.exception('EXCEPTION')
					item_txt = "Error - Cannot Retrieve Feedback Form Text [Error Message: " + str(x) + "]"
					logger.error(item_txt)
					ffbtnplusform = ffbtnplusform.replace("VARIABLE_CHECKBOXES", item_txt)

				# Replace NON-text, static 'VARIABLE' instances in the template with the variable name (e.g. 'VARIABLE_ff' becomes 'flag_s1sgaver1seqy_ff'):
				for item in ffbtnplusform_nontextvarvals:
					newitem = item.replace("VARIABLE", varnm)
					ffbtnplusform = ffbtnplusform.replace(item, newitem)

				# Route the completed 'ffbtnplusform' to the appropriate SEP location bin:
				seploc = row['seploc']
				seporder = int(row['seporder'])
				if seploc == 's1':
					if probver == "1":
						s1flagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s1flagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "s2":
					if probver == "1":
						s2flagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s2flagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "s3mteq":
					if probver == "1":
						s3mteqflagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s3mteqflagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "s3feq":
					if probver == "1":
						s3feqflagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s3feqflagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "rfc":
					if probver == "1":
						rfcflagprobtuplist.append((seporder, ffbtnplusform))
					else:
						rfcflagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "s4":
					if probver == "1":
						s4flagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s4flagothertuplist.append((seporder, ffbtnplusform))
				elif seploc == "s5":
					if probver == "1":
						s5flagprobtuplist.append((seporder, ffbtnplusform))
					else:
						s5flagothertuplist.append((seporder, ffbtnplusform))

				# Finally, create JQuery scripting for this flag entity:
				# If AC version, load JQuery version that does NOT process feedback forms:
				jqentry = ff_JQtoggletemplate
				jqentry = jqentry.replace("VARIABLE", varnm)
				jquerycontainer.append(jqentry)
			
			except Exception:
				logger.exception('EXCEPTION')
				err_str = "iqrgenerator.create_flagandff() Error: 'row' = %s" % str(row)

		# Retrieve & iterate through 'prod ready' flags:
		for i, row in flagdatadf.iterrows():
			create_flagandff(row)
		

		# Impairment Explorer:
		# For OAO runs, re-generate non-database-stored UMLS data by re-generating
		# all UMLS data:
		umls_resdictlist = []
		if iqrepgen_dict['mdi'] and 'AP' not in iqrepgen_dict['mdi'][0].keys():
			if iqrepgen_dict['s2']:
				claimtype_merged = 'U'
				if iqrepgen_dict['CLAIMDISP_STRUCT']:
					claimtype_merged = [subd['CLM_TYP'] for subd in iqrepgen_dict['CLAIMDISP_STRUCT']]
					claimtype_merged = [c for c in claimtype_merged if c != 'U']
				for subd in iqrepgen_dict['s2']:
					umls_input_dict = dict({'claimtype':claimtype_merged, 'paistart':iqrepgen_dict['paistart'], 'paiend':iqrepgen_dict['paiend']}.items() + subd.items())
					umls_obs_resdictlist = umls_extract.extract_umls_data_insight_tgt(umls_input_dict, 's2txt')
					for resd in umls_obs_resdictlist:
						resd['S2_ORD_NUM'] = subd['ORD_NUM']
						umls_resdictlist.append(resd)
		else:
			if iqrepgen_dict['mdi']:
				umls_resdictlist = iqrepgen_dict['mdi'].values()

		# Change the name of the button id for when the Send button is clicked.
		# The button is a variation of a fullresultstogglebutton rather than a fftogglebutton.
		jqentry = ff_JQtoggletemplate.replace('VARIABLE', 'impexpmoreinfo')
		jquerycontainer.append(jqentry)
		
		
		# Function to create individual Imp. Exp. HTML/JQuery entities:
		def create_impexp_flag_v2(mdiobs_dict, obsnum, childadultver):
			try:
			
				impexpbuttonplusform = impexp_fullHTMLtemplate

				# Generate impairment explorer 'heading' content:
				impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_flagtext_brief_desc', mdiobs_dict['TXT'] + ':')
				impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_flagtext', '; '.join(mdiobs_dict['TYP']))

				# Generate impairment explorer 'definition' content:
				if mdiobs_dict['DEF'] != 'U':
					resultsfound_searchterm = mdiobs_dict['TXT']
					resultsfound_searchterm = "+".join(resultsfound_searchterm.split())
					searchlink_custom = searchlink.replace("SEARCHTERM", resultsfound_searchterm)
					termdef = mdiobs_dict['DEF'] + ' ' + searchlink_custom
					impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_termdef', termdef)
				else:
					if mdiobs_dict['TXT'] not in ['U', 'P', '']:
						noresultsfound_searchterm = mdiobs_dict['TXT']
						noresultsfound_searchterm = "+".join(noresultsfound_searchterm.split())
						noresultsfound_custom = noresultsfound_withsearch.replace("SEARCHTERM", noresultsfound_searchterm)
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_termdef', noresultsfound_custom)
					else:
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_termdef', noresultsfound)

				# Check if there's any data to put in the table section. If not, remove it:
				if mdiobs_dict['AP'] != 'U' or mdiobs_dict['SS'] != 'U' or mdiobs_dict['LISTING'] != 'U':

					# Format AP replacement:
					if mdiobs_dict['AP'] != 'U':
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_apdata', "<br>".join('&#8226 ' + apterm for apterm in mdiobs_dict['AP']))
					else:
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_apdata', noresultsfound)

					# Format signs/symptoms replacement:
					if mdiobs_dict['SS'] != 'U':
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_ssdata', "<br>".join('&#8226 ' + ssterm for ssterm in mdiobs_dict['SS']))
					else:
						impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_ssdata', noresultsfound)


					# Format listing replacement:

					# TIP: 'umls_extract' outputs 'U' if no results emerge from calling the listing function.
					if mdiobs_dict['LISTING'] == 'U':
						adultlistingurl = "https://www.ssa.gov/disability/professionals/bluebook/AdultListings.htm"
						childlistingurl = "https://www.ssa.gov/disability/professionals/bluebook/ChildhoodListings.htm"
						if childadultver == 'child':
							noresultsfound_withlistinglink_custom = noresultsfound_withlistinglink.replace("URLVAR", childlistingurl)
							impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_listingdata', noresultsfound_withlistinglink_custom)
						else:
							noresultsfound_withlistinglink_custom = noresultsfound_withlistinglink.replace("URLVAR", adultlistingurl)
							impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_listingdata', noresultsfound_withlistinglink_custom)
					else:
						# Reduce listingdict['listg_num'] by applying rule that if multiple listing # values match exactly (e.g. multiple 3.02), then retain only
						# the one that has no effective date value (i.e. that's still in effect); rationale is that the only difference between
						# them (considering the listing # is the same) is the term used to describe the listing # in 'DSPL_DIG_DESC' - the value
						# still in effect typically has a value that mirrors what's in the presently authoritative online version of the listings:
						# TIP: If multiple listing # values overlap, and each is associated with an effective end date value, then just keep all of them.
						termdict_listing_listofdicts = mdiobs_dict['LISTING']
						termdict_listing_listofdicts_rev1 = []
						for d in termdict_listing_listofdicts:
							if not termdict_listing_listofdicts_rev1:
								termdict_listing_listofdicts_rev1.append(d)
							else:
								if d['listg_num'] not in [revd['listg_num'] for revd in termdict_listing_listofdicts_rev1]:
									termdict_listing_listofdicts_rev1.append(d)
								else:
									rel_dicts =	 [exd for exd in termdict_listing_listofdicts_rev1 if exd['listg_num'] == d['listg_num']]
									# If already a dict with this listing # with no eff_endt, don't add this one:
									if len([reld for reld in rel_dicts if reld['eff_endt'] is False]) >= 1:
										pass
									else:
										# If this dict has no eff_endt, delete all existing dicts then add this one:
										if d['eff_endt'] is False:
											for deprecated_d in [revd for revd in termdict_listing_listofdicts_rev1 if revd['listg_num'] == d['listg_num']]:
												termdict_listing_listofdicts_rev1.remove(deprecated_d)
											termdict_listing_listofdicts_rev1.append(d)
										else:
											termdict_listing_listofdicts_rev1.append(d)

						listingparentnamedict = {'1':'Musculoskeletal System','2':'Special Senses and Speech','3':'Respiratory System','4':'Cardiovascular System','5':'Digestive System','6':'Genitourinary Disorders','7':'Hematological Disorders','8':'Skin Disorders','9':'Endocrine Disorders','10':'Congenital Disorders','11':'Neurological','12':'Mental Disorders', '13':'Cancer','14':'Immune System Disorders', '100':'Low Birth Weight, etc.', '101':'Musculoskeletal System', '102':'Special Senses and Speech', '103':'Respiratory System', '104':'Cardiovascular System', '105':'Digestive System', '106':'Genitourinary Disorders', '107':'Hematological Disorders', '108':'Skin Disorders', '109':'Endocrine Disorders', '110':'Congenital Disorders', '111':'Neurological', '112':'Mental Disorders', '113':'Cancer', '114':'Immune System Disorders'}
						listinglist = []
						for listingdict in termdict_listing_listofdicts_rev1:
							listingstring = listingdict['listg_num']
							if 'xx' in listingstring:
								try:
									listingstring_parent = listingstring.split('.')[0].strip()
									listingstring = listingstring + ': ' + listingparentnamedict[listingstring_parent]
								except Exception:
									logger.exception('EXCEPTION')
									pass
							else:
								listingstring = listingdict['listg_num'] + ': ' + listingdict['desc']
								if listingdict['hiv_manif']:
									listingstring += ' (HIV manifestation)'
							listinglist.append(listingstring)

						# Tailor listing output on whether claim type is child, adult, or both:
						# TIP: This doesn't rely on the 'LISTG_TYP' column's values (that's only
						# utilized for HIV manifestation), so don't curate that for adult/child
						# tagging.
						if childadultver == 'child':
							listinglist = [item for item in listinglist if len(item.split(': ')[0].split('.')[0]) == 3]
						if childadultver == 'adult':
							listinglist = [item for item in listinglist if len(item.split(': ')[0].split('.')[0]) != 3]

						# Sort unique results from smallest to largest:
						listinglist = sorted(list(set(listinglist)), key=lambda item: float(re.sub(r'[a-zA-Z]', '0', item).split(':')[0]))


						# (TABLING 09.13.2016 - why omit parent, may be more accurate) If a more specific listing of the same parent # is present,
						# omit the more general of the same parent # (e.g. '12.06' and 12.xx'):

						# Create hyperlinks using listinglist results:
						listingcategorydict = {'1': 'Musculoskeletal', '2': 'SpecialSensesandSpeech',
							'3': 'Respiratory', '4': 'Cardiovascular', '5': 'Digestive',
							'6': 'Genitourinary', '7': 'HemicandLymphatic', '8': 'Skin',
							'9': 'Endocrine', '10': 'MultipleBody', '11': 'Neurological',
							'12': 'MentalDisorders', '13': 'NeoplasticDiseases-Malignant',
							'14': 'Immune', '0': 'GrowthImpairment'}

						for i in range(len(listinglist)):
							linkstring = 'https://www.ssa.gov/disability/professionals/bluebook/'
							categorynum = listinglist[i].split('.')[0]
							linkstring += categorynum + '.00-'

							if len(categorynum) == 3:
								if categorynum[1] == '0':
									if categorynum[2] in listingcategorydict:
										linkstring += listingcategorydict[categorynum[2]]
									else:
										continue
								else:
									if categorynum[1:] in listingcategorydict:
										linkstring += listingcategorydict[categorynum[1:]]
									else:
										continue
								linkstring += '-Childhood.htm#'
							else:
								linkstring += listingcategorydict[categorynum] + '-Adult.htm#'

							listingnum = listinglist[i].split(':')[0]
							if listingnum[-2:] != 'xx':
								linkstring += re.sub(r'[a-zA-Z]', '', listingnum.replace('.', '_'))

							# Replace items in listinglist with their newly created hyperlink:
							listinglist[i] = '<a class="listinglink" href="%s" target="blank">%s</a>' % (linkstring, listinglist[i])

						if listinglist:
							impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_listingdata', "<br>".join(listinglist))
						else:
							impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_listingdata', noresultsfound)
				else:
					impexpbuttonplusform = re.sub(r'\<table\>.*\</table\>', '', impexpbuttonplusform, flags=re.DOTALL)

				impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_fftogglebutton', 'flag_impexp_term%d_fftogglebutton' % obsnum)
				impexpbuttonplusform = impexpbuttonplusform.replace('VARIABLE_ffdiv', 'flag_impexp_term%d_ffdiv' % obsnum)

				jqentry = ff_JQtoggletemplate.replace('VARIABLE', 'flag_impexp_term%d' % obsnum)

				return impexpbuttonplusform, jqentry
			
			except Exception:
				logger.exception('EXCEPTION')
				logger.critical(mdiobs_dict)
		
		# Determine if it's an adult, child, or both claim type:
		childadultver = 'both'
		try:
			claimtypelist = [subd['CLM_TYP'] for subd in iqrepgen_dict['CLAIMDISP_STRUCT']]
			if claimtypelist:
				if claimtypelist == ['T16 SSI Termination Child'] or claimtypelist == ['T16 SSI Child'] or claimtypelist == ['T16 SSI Adult+Child']:
					childadultver = 'child'
				else:
					if len([c for c in claimtypelist if 'Child' in c]) == 0:
						childadultver = 'adult'
					else:
						childadultver = 'both'
		except KeyError:
			logger.exception('EXCEPTION')
			pass
		
		# Iterate through MDI observation dicts to generate HTML/JQuery:
		for i, subd in enumerate(umls_resdictlist):
			impexp_formres, impexp_jqentry = create_impexp_flag_v2(subd, i, childadultver)
			impexpreslist.append(impexp_formres)
			jquerycontainer.append(impexp_jqentry)

		### END Impairment Explorer ###

		# Order each container using 'flagdata' 'seporder' values:
		s1flagprobtuplist = sorted(s1flagprobtuplist,key=itemgetter(0))
		s1flagothertuplist = sorted(s1flagothertuplist,key=itemgetter(0))
		s2flagprobtuplist = sorted(s2flagprobtuplist,key=itemgetter(0))
		s2flagothertuplist = sorted(s2flagothertuplist,key=itemgetter(0))
		s3mteqflagprobtuplist = sorted(s3mteqflagprobtuplist,key=itemgetter(0))
		s3mteqflagothertuplist = sorted(s3mteqflagothertuplist,key=itemgetter(0))
		s3feqflagprobtuplist = sorted(s3feqflagprobtuplist,key=itemgetter(0))
		s3feqflagothertuplist = sorted(s3feqflagothertuplist,key=itemgetter(0))
		rfcflagprobtuplist = sorted(rfcflagprobtuplist,key=itemgetter(0))
		rfcflagothertuplist = sorted(rfcflagothertuplist,key=itemgetter(0))
		s4flagprobtuplist = sorted(s4flagprobtuplist,key=itemgetter(0))
		s4flagothertuplist = sorted(s4flagothertuplist,key=itemgetter(0))
		s5flagprobtuplist = sorted(s5flagprobtuplist,key=itemgetter(0))
		s5flagothertuplist = sorted(s5flagothertuplist,key=itemgetter(0))

		# Now parse out what to replace each SEP step 'flagprob_HTML'/'other_HTML'
		# container with (e.g. if 'prob' flags present for that SEP step,
		# replace its 'probtuplist' container with the flag HTML; if not, replace
		# it with the generic 'noprob' HTML):

		# (DISABLING writing to s1 variables until access to earnings
		# data obtained - 06.02.2017):
		# if len(s1flagprobtuplist) >= 1:
			# s1flagprobHTMLlist = [tup[1] for tup in s1flagprobtuplist]
			# s1flagprobHTMLlistjoined = "\n\n".join(s1flagprobHTMLlist)
			# iqhtml = iqhtml.replace("s1flagprob_HTML", s1flagprobHTMLlistjoined)
		# else:
			# iqhtml = iqhtml.replace("s1flagprob_HTML", noprobdiv)
		# if len(s1flagothertuplist) >= 1:
			# s1flagotherHTMLlist = [tup[1] for tup in s1flagothertuplist]
			# s1flagotherHTMLlistjoined = "\n\n".join(s1flagotherHTMLlist)
			# iqhtml = iqhtml.replace("s1flagother_HTML", s1flagotherHTMLlistjoined)
		# else:
			# iqhtml = iqhtml.replace("s1flagother_HTML", nootherdiv)

		#s2:
		if len(s2flagprobtuplist) >= 1:
			s2flagprobHTMLlist = [tup[1] for tup in s2flagprobtuplist]
			s2flagprobHTMLlistjoined = "\n\n".join(s2flagprobHTMLlist)
			iqhtml = iqhtml.replace("s2flagprob_HTML", s2flagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s2flagprob_HTML", noprobdiv)
		if len(s2flagothertuplist) >= 1:
			s2flagotherHTMLlist = [tup[1] for tup in s2flagothertuplist]
			s2flagotherHTMLlistjoined = "\n\n".join(s2flagotherHTMLlist)
			iqhtml = iqhtml.replace("s2flagother_HTML", s2flagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s2flagother_HTML", nootherdiv)

		#s3mteq
		if len(s3mteqflagprobtuplist) >= 1:
			s3mteqflagprobHTMLlist = [tup[1] for tup in s3mteqflagprobtuplist]
			s3mteqflagprobHTMLlistjoined = "\n\n".join(s3mteqflagprobHTMLlist)
			iqhtml = iqhtml.replace("s3mteqflagprob_HTML", s3mteqflagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s3mteqflagprob_HTML", noprobdiv)
		if len(s3mteqflagothertuplist) >= 1:
			s3mteqflagotherHTMLlist = [tup[1] for tup in s3mteqflagothertuplist]
			s3mteqflagotherHTMLlistjoined = "\n\n".join(s3mteqflagotherHTMLlist)
			iqhtml = iqhtml.replace("s3mteqflagother_HTML", s3mteqflagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s3mteqflagother_HTML", nootherdiv)

		#s3feq:
		if len(s3feqflagprobtuplist) >= 1:
			s3feqflagprobHTMLlist = [tup[1] for tup in s3feqflagprobtuplist]
			s3feqflagprobHTMLlistjoined = "\n\n".join(s3feqflagprobHTMLlist)
			iqhtml = iqhtml.replace("s3feqflagprob_HTML", s3feqflagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s3feqflagprob_HTML", noprobdiv)
		if len(s3feqflagothertuplist) >= 1:
			s3feqflagotherHTMLlist = [tup[1] for tup in s3feqflagothertuplist]
			s3feqflagotherHTMLlistjoined = "\n\n".join(s3feqflagotherHTMLlist)
			iqhtml = iqhtml.replace("s3feqflagother_HTML", s3feqflagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s3feqflagother_HTML", nootherdiv)

		#rfc:
		if len(rfcflagprobtuplist) >= 1:
			rfcflagprobHTMLlist = [tup[1] for tup in rfcflagprobtuplist]
			rfcflagprobHTMLlistjoined = "\n\n".join(rfcflagprobHTMLlist)
			iqhtml = iqhtml.replace("rfcflagprob_HTML", rfcflagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("rfcflagprob_HTML", noprobdiv)
		if len(rfcflagothertuplist) >= 1:
			rfcflagotherHTMLlist = [tup[1] for tup in rfcflagothertuplist]
			rfcflagotherHTMLlistjoined = "\n\n".join(rfcflagotherHTMLlist)
			iqhtml = iqhtml.replace("rfcflagother_HTML", rfcflagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("rfcflagother_HTML", nootherdiv)

		#s4:
		if len(s4flagprobtuplist) >= 1:
			s4flagprobHTMLlist = [tup[1] for tup in s4flagprobtuplist]
			s4flagprobHTMLlistjoined = "\n\n".join(s4flagprobHTMLlist)
			iqhtml = iqhtml.replace("s4flagprob_HTML", s4flagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s4flagprob_HTML", noprobdiv)
		if len(s4flagothertuplist) >= 1:
			s4flagotherHTMLlist = [tup[1] for tup in s4flagothertuplist]
			s4flagotherHTMLlistjoined = "\n\n".join(s4flagotherHTMLlist)
			iqhtml = iqhtml.replace("s4flagother_HTML", s4flagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s4flagother_HTML", nootherdiv)

		#s5:
		if len(s5flagprobtuplist) >= 1:
			s5flagprobHTMLlist = [tup[1] for tup in s5flagprobtuplist]
			s5flagprobHTMLlistjoined = "\n\n".join(s5flagprobHTMLlist)
			iqhtml = iqhtml.replace("s5flagprob_HTML", s5flagprobHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s5flagprob_HTML", noprobdiv)
		if len(s5flagothertuplist) >= 1:
			s5flagotherHTMLlist = [tup[1] for tup in s5flagothertuplist]
			s5flagotherHTMLlistjoined = "\n\n".join(s5flagotherHTMLlist)
			iqhtml = iqhtml.replace("s5flagother_HTML", s5flagotherHTMLlistjoined)
		else:
			iqhtml = iqhtml.replace("s5flagother_HTML", nootherdiv)

		#impexp:
		if len(impexpreslist) >= 1:
			impexpimpairmentsHTMLlistjoined = "\n\n".join(impexpreslist)
			# Get all UMLS TXT entries:
			
			s2txtlist = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 's2', 's2txt', 'U', 'U', 'U')
			s2txtlist = [s2txt for s2txt in s2txtlist if s2txt not in ['U', 'P', 'E', '']]
			if s2txtlist:
				s2txtlist = ['"%s"' % s2 for s2 in s2txtlist]
				s2txtlist_str = " / ".join(s2txtlist)
				umls_text_list = [resd['TXT'] for resd in umls_resdictlist]
				for txt in umls_text_list:
					txt_plus_ulinespan = """<span class="impexps2txtuline">""" + txt.lower() + """</span>"""
					txt_re = r"\b%s\b" % txt
					s2txtlist_str = re.sub(txt_re, txt_plus_ulinespan, s2txtlist_str, flags=re.I)
				s2txtlist_html = """<p class="impexps2txt"><span class="impexps2txt">Step 2 Finding Heading(s): </span>%s</p>""" % s2txtlist_str.strip()
				impexpimpairmentsHTMLlistjoined = s2txtlist_html + impexpimpairmentsHTMLlistjoined
			iqhtml = iqhtml.replace("impexpimpairments_HTML", impexpimpairmentsHTMLlistjoined)
		else:
			noimp_html = noprobdiv.replace('No issues detected', 'No impairments found')
			noimp_html = noimp_html.replace('No issues meriting attention relating to this area were detected.', 'No impairments were extracted from the Step 2 finding heading text (if any).')
			s2txtlist = ifsiqrcc.gather_container_tgt(iqrepgen_dict, 's2', 's2txt', 'U', 'U', 'U')
			s2txtlist = [s2txt for s2txt in s2txtlist if s2txt not in ['U', 'P', 'E', '']]
			if s2txtlist:
				s2txtlist = ['"%s"' % s2 for s2 in s2txtlist]
				s2txtlist_str = " / ".join(s2txtlist)
				s2txtlist_html = """<p class="impexps2txt"><span class="impexps2txt">Step 2 Finding Heading(s): </span>%s</p>""" % s2txtlist_str.strip()
				noimp_html = s2txtlist_html + noimp_html
			iqhtml = iqhtml.replace("impexpimpairments_HTML", noimp_html)
		
		# Modify the REQUESTID value in the report:
		reqid = iqrepgen_dict['REQID']
		reqid = str(reqid)
		if reqid.isdigit():
			iqhtml = iqhtml.replace('reqid_HTML', reqid)
		else:
			iqhtml = iqhtml.replace('reqid_HTML', 'U')

		# Join then sub in JQuery into the report:
		jquerycontainerjoined = "\n\n".join(jquerycontainer)
		iqhtml = iqhtml.replace("flagbtnjquery_JQUERY", jquerycontainerjoined)

		# Return HTML:
		return iqhtml

	except Exception, x:
		logger.exception('EXCEPTION')
		return 'E'



