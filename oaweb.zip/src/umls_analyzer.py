# INSIGHT UMLS ANALYZER
#
# AUTHOR:
# Eric Kim & Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 09.09.2016
#
# SUMMARY:
# Contains several helper functions designed to leverage UMLS data to
# analyze hearing decision free text.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import logging
import os.path
import re

import pandas

import date_helper
import nlp_helper
import text_cleaner as tc

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "data")
logdir = os.path.join(insightdir, "log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load datasets:

# Load umls_exclusion_whitelist:
umls_exclusion_whitelist_nonsx = []
with open(os.path.join(datadir, "umls_exclusion_whitelist_nonsx.txt"), 'r') as whitelist_file:
    whitelist_filelines = whitelist_file.readlines()
    for line in whitelist_filelines:
        if bool(line.startswith('#')) is False and line != '':
            line = line.strip()
            umls_exclusion_whitelist_nonsx.append(line)
            line_plural = line + 'S'
            umls_exclusion_whitelist_nonsx.append(line_plural)

# Load UMLS-based datasets:
# TIP: Sometimes setting index_col=0 for def_df so that the CUIs serve as indices.
terms_df_v1 = pandas.read_csv(os.path.join(datadir, 'umls_types_terms_list_vsn1.txt'), dtype=str, na_filter=False,
                              sep='|')
terms_df_sx = pandas.read_csv(os.path.join(datadir, 'umls_sx_types_terms_list_approach3_sorted.txt'), dtype=str,
                              na_filter=False, sep='|')
def_df = pandas.read_csv(os.path.join(datadir, 'umls_def_list.txt'), dtype=str, na_filter=False, sep='|', index_col=0)
ap_df = pandas.read_csv(os.path.join(datadir, 'umls_ap_terms_list.txt'), dtype=str, na_filter=False, sep='|')
ss_df = pandas.read_csv(os.path.join(datadir, 'umls_ss_terms_list.txt'), dtype=str, na_filter=False, sep='|')

# Load development copy of custom GCESTIMP GRT:
# TODO: Remove any row with no DIG or DIG_ALT values.
# TIP: 'E' utilized in the interest of uniformity, as 'parse_date_todatetime_struct()'
# outputs 'E' if a datetime object cannot be returned.
gcestimp_custom = pandas.read_csv(os.path.join(datadir, 'GCESTIMP_07122017.csv'), dtype=str, na_filter=False)
gcestimp_custom.fillna('E', inplace=True)
gcestimp_custom.replace('', 'E', inplace=True)
gcestimp_custom['EFF_STDT'] = gcestimp_custom['EFF_STDT'].apply(
    lambda x: date_helper.parse_date_todatetime_struct(x))
gcestimp_custom['EFF_ENDT'] = gcestimp_custom['EFF_ENDT'].apply(
    lambda x: date_helper.parse_date_todatetime_struct(x))
for col in [c for c in gcestimp_custom.columns.tolist() if c not in ['EFF_STDT', 'EFF_ENDT']]:
    gcestimp_custom[col].replace(r' +$', r'', regex=True, inplace=True)
gcestimp_custom.replace('', 'E', inplace=True)


def normalize_listgcd(listgcd):
    try:
        if listgcd == 'E':
            return listgcd
        else:
            listgcd = listgcd.strip()
            listgcd = re.sub(r'^0+', '', listgcd)
            listgcd = re.sub(r'&.*', '', listgcd)
            listgcd = listing = ''.join([char for char in list(listgcd) if char.isdigit() or char == '.'])
            if listgcd.endswith('.1') or listgcd.endswith('.2') or listgcd.endswith('.3'):
                listgcd = listgcd + '0'
            if len(listgcd) == 1 and listgcd[0].isdigit():
                listgcd = listgcd + '.00'
            return listgcd
    except Exception:
        raise


gcestimp_custom['LISTG_CD'] = gcestimp_custom['LISTG_CD'].apply(lambda x: normalize_listgcd(x))


def normalize_bodysyscd(row):
    bodysyscd = row['BODYSYS_CD']
    listgtyp = row['LISTG_TYP']
    if listgtyp == 'CHILDHOOD':
        if bodysyscd == '19':
            bodysyscd = '100'
        elif bodysyscd in ['1', '2', '3', '4', '5', '6', '7', '8', '9']:
            bodysyscd = '10' + bodysyscd
        elif bodysyscd in ['10', '11', '12', '13', '14']:
            bodysyscd = '1' + bodysyscd
    return bodysyscd


gcestimp_custom['BODYSYS_CD'] = gcestimp_custom.apply(lambda row: normalize_bodysyscd(row), axis=1)

# Define list of impairment '_TXT' names to never search for length-2 ICD9/DIG # matches:
nolen2matchwhitelist = ['OBESITY']

# Load ICD dataset:
new_icd9_df = pandas.read_csv(os.path.join(datadir, 'NEWICD_V8.csv'), dtype=str, na_filter=False, index_col=0)
icd9_cui_list = new_icd9_df.index

# Load umls_exclusion_whitelist:
umls_exclusion_whitelist = []
with open(os.path.join(datadir, "umls_exclusion_whitelist.txt"), 'r') as whitelist_file:
    whitelist_filelines = whitelist_file.readlines()
    for line in whitelist_filelines:
        if bool(line.startswith('#')) is False and line != '':
            line = line.strip()
            umls_exclusion_whitelist.append(line)
            line_plural = line + 'S'
            umls_exclusion_whitelist.append(line_plural)

umls_comma_whitelist = []
with open(os.path.join(datadir, "umls_comma_whitelist.txt"), 'r') as whitelist_file:
    whitelist_filelines = whitelist_file.readlines()
    for line in whitelist_filelines:
        if bool(line.startswith('#')) is False and line != '':
            line = line.strip()
            umls_comma_whitelist.append(line)


# UMLS Term Extraction Function That
# Returns Text and Targets UMLS Symptoms
# in Subset (designed for iq.s2txtonlysx_calc)
# TODO: Consider creation of a custom appendix to the
# UMLS data you have, e.g. creating an entry for
# 'degenerative changes' equivalent to osteoarthritis because
# a medical source states that they're equivalent
# (source: http://www.mayoclinic.org/diseases-conditions/osteoarthritis/expert-answers/arthritis/faq-20058457)
# Can do this for other high frequency residual terms/phrases as well.
def extract_terms_s2txt_returntxt_sx(text_input, text_input_src, cleantxtver):
    '''Extracts UMLS data from an INSIGHT observation 's2txt' string.

    Args:
        text_input {str}: An INSIGHT observation's 's2txt' string from which to
            extract UMLS data.
        text_input_src {str}: An INSIGHT observation's 's2txtsrc' value - facilitates
            custom text precleaning.
        cleantxtver {str}: An indicator whether to clean or not clean the input
            text of FIT Step 2 language. '1' = clean, '0' = do not clean.
    Returns:
        res_tup {tuple}: Tuple[0] = term_dict {dict} A dictionary
            where each UMLS extracted entity is accorded a number and consists
            of 3 keys formatted as 's2mdi#_CUI', 's2mdi#_TYP', and 's2mdi#_TXT'.
            'CUI' is the UMLS CUI value associated with the 'TXT'.  'TYP' is the
            UMLS semantic type associated with the CUI value. Tuple[1] = the
            text remaining after UMLS term identification and removal.
    Raises:
            General exception.
    '''
    try:
        # Check arguments:
        if not isinstance(text_input, str):
            errstr = 'umls_analyzer.extract_terms_s2txt() - Argument Type Error - text_input - type passed = %s' % type(
                text_input)
            logger.critical(errstr)
            return {}
        if not isinstance(text_input_src, str):
            errstr = 'umls_analyzer.extract_terms_s2txt() - Argument Type Error - text_input_src - type passed = %s' % type(
                text_input)
            logger.critical(errstr)
            return {}

        # Apply universal cleaners (pre):
        text_input = ' '.join(text_input.split()).upper()

        # Apply 's2txt' cleaners depending on 'src' value:
        if cleantxtver == '1':
            if text_input_src == '0':
                text_input = nlp_helper.s2txt_cleaner_fit(text_input)
            else:
                text_input = nlp_helper.s2txt_cleaner_nonfit(text_input)

        # Apply universal cleaners (ensures proper spacing):
        text_input = text_input.replace('/', ' / ')
        text_input = re.sub(r"([a-z0-9])(\(|\[)", r"\1 \2", text_input, flags=re.I)
        text_input = re.sub(r"(\.|:|;|,|\)|\])([a-z0-9])", r"\1 \2", text_input, flags=re.I)
        text_input = ' '.join(text_input.split())

        # Transform text by putting underscores before periods, commas, semicolons,
        # and colons and by replacing spaces with underscores.
        # That way, the underscores act as boundaries so that we don't select words
        # subsumed by terms, e.g. "shiver" contains "hiv":
        text_input = tc.normalize_with_underscores(text_input)

        # (DEPRECATED 03132017: Does not improve performance) Reduce terms DF
        # based on SME knowledge of target string content:
        # sub_terms_df = terms_df_v1[~terms_df_v1['str'].str.contains("@", regex=False)]

        # (DEPRECATED 03132017: Does not improve performance) Reduce terms DF
        # based on input length:
        # text_input_len = len(text_input)
        # sub_terms_df = sub_terms_df.loc[sub_terms_df['str'].str.len() <= text_input_len]

        resdictlist = []
        for row in zip(terms_df_sx['cui'], terms_df_sx['str']):
            if row[1] in text_input:
                resdict = {}
                resdict['CUI'] = row[0].split(', ')
                resdict['TXT'] = row[1].replace('_,', ',').replace('_;', ';').replace('_', ' ').strip()
                resdictlist.append(resdict)
                text_input = text_input.replace(row[1], '_')

        return resdictlist, text_input
    except Exception:
        logger.exception('EXCEPTION')
        raise


# UMLS Term Extraction Function That
# Returns Text:
# TODO: Consider creation of a custom appendix to the
# UMLS data you have, e.g. creating an entry for
# 'degenerative changes' equivalent to osteoarthritis because
# a medical source states that they're equivalent
# (source: http://www.mayoclinic.org/diseases-conditions/osteoarthritis/expert-answers/arthritis/faq-20058457)
# Can do this for other high frequency residual terms/phrases as well.
def extract_terms_s2txt_returntxt(text_input, text_input_src, cleantxtver):
    '''Extracts UMLS data from an INSIGHT observation 's2txt' string, or, if
    'cleantxtver' != '1', you can perform these actions on non-'s2txt' strings.

    Args:
        text_input {str}: An INSIGHT observation's 's2txt' string from which to
            extract UMLS data.
        text_input_src {str}: An INSIGHT observation's 's2txtsrc' value - facilitates
            custom text precleaning.
        cleantxtver {str}: An indicator whether to clean the input
            text of Step 2 program/non-MDI language. '1' = clean, '0' = do not clean.
    Returns:
        res_tup {tuple}: Tuple[0] = A list of dicts, where each dict is a UMLS-matching
            entity and consists of 3 keys formatted as 'CUI', 'TYP', and 'TXT'.
            'CUI' is the UMLS CUI value associated with the 'TXT'.  'TYP' is the
            UMLS semantic type associated with the CUI value. Tuple[1] = the
            text remaining after UMLS term identification and removal.
    Raises:
            N/A (returns tuple of empty list and empty string if exception).
    '''
    try:

        # Check arguments:
        if not isinstance(text_input, str):
            errstr = 'umls_analyzer.extract_terms_s2txt() - Argument Type Error - text_input - type passed = %s' % type(
                text_input)
            logger.critical(errstr)
            return [], ''
        if not isinstance(text_input_src, str):
            errstr = 'umls_analyzer.extract_terms_s2txt() - Argument Type Error - text_input_src - type passed = %s' % type(
                text_input)
            logger.critical(errstr)
            return [], ''

        # Apply universal cleaners (pre):
        text_input = ' '.join(text_input.split()).upper()

        # Apply 's2txt' cleaners depending on 'src' value:
        if cleantxtver == '1':
            if text_input_src == '0':
                text_input = nlp_helper.s2txt_cleaner_fit(text_input)
            else:
                text_input = nlp_helper.s2txt_cleaner_nonfit(text_input)

        # Apply universal cleaners (ensures proper spacing; some overlap
        # with nlp_helper functions):
        text_input = text_input.replace('/', ' / ')
        text_input = re.sub(r"([a-z0-9])(\(|\[)", r"\1 \2", text_input, flags=re.I)
        text_input = re.sub(r"(\.|:|;|,|\)|\])([a-z0-9])", r"\1 \2", text_input, flags=re.I)
        text_input = ' '.join(text_input.split())

        # Transform text by inserting underscore boundaries before periods,
        # commas, semicolons, and colons and replacing spaces with underscores.
        text_input = tc.normalize_with_underscores(text_input)

        # (DEPRECATED 03132017: Does not improve performance) Reduce terms DF
        # based on SME knowledge of target string content:

        # (DEPRECATED 03132017: Does not improve performance) Reduce terms DF
        # based on input length:

        resdictlist = []
        for row in zip(terms_df_v1['cui'], terms_df_v1['type'], terms_df_v1['str'], terms_df_v1['commavsn']):
            if row[3] != '_U_' and row[3] in text_input:
                resdict = {}
                resdict['CUI'] = row[0].split(', ')
                resdict['TYP'] = row[1].split(', ')
                resdict['TXT'] = row[3].replace('_;', ';').replace('_', ' ').strip()
                resdictlist.append(resdict)
                text_input = text_input.replace(row[3], '_')
            elif row[2] != '_U_' and row[2] in text_input:
                resdict = {}
                resdict['CUI'] = row[0].split(', ')
                resdict['TYP'] = row[1].split(', ')
                resdict['TXT'] = row[2].replace('_,', ',').replace('_;', ';').replace('_', ' ').strip()
                resdictlist.append(resdict)
                text_input = text_input.replace(row[2], '_')

        return resdictlist, text_input
    except Exception:
        logger.exception('EXCEPTION')
        return [], ''


# UMLS Definition Extraction Script:
def term_def(extracted_terms_dictlist):
    '''UMLS definition extraction from custom
    UMLS definition file.

    Args:
        extracted_terms_dictlist {list}: A list of dicts where
            each dict contains a 'CUI', 'TYP', and 'TXT' value.
    Returns:
        extracted_terms_dictlist {list}: A list of dicts where
            each dict contains a 'CUI', 'TYP', and 'TXT' value,
            as well as a 'DEF' value.  The def value is a string
            containing the definition associated with the CUI in
            the dict.  If more than one definition found, each will
            be present, formatted as '1. [def 1] / 2. [def 2]'.
    Raises:
        N/A (returns original 'extracted_terms_dictlist' if
        exception).
    '''
    try:
        if extracted_terms_dictlist:
            for subd in extracted_terms_dictlist:
                cui_list = subd['CUI']
                if not cui_list:
                    subd['DEF'] = 'U'
                else:
                    try:
                        defresser = def_df.loc[cui_list]['shortdef']
                        defreslist = defresser[defresser.notnull()].tolist()
                        defreslist = list(set(defreslist))
                        def_res_str = ''
                        for i, d in enumerate(defreslist):
                            def_res_str += '%i: %s / ' % (i + 1, d)
                        subd['DEF'] = def_res_str
                    except KeyError:
                        subd['DEF'] = 'U'
        return extracted_terms_dictlist
    except Exception:
        logger.exception('EXCEPTION')
        extracted_terms_dictlist = [dict(item, **{'DEF':'E'}) for item in extracted_terms_dictlist]
        return extracted_terms_dictlist


# UMLS Body Part (Anatomy) Term Extraction from Term Definitions Parent Script:
# TODO: Revise 'ap_df' content to include all semantic types cited in
# 05082017 notes.
def affected_ap_terms(extracted_terms_dictlist):
    try:
        return disease_effects(extracted_terms_dictlist, ap_df, 'AP')
    except Exception:
        logger.exception('EXCEPTION')
        extracted_terms_dictlist = [dict(item, **{'AP':[]}) for item in extracted_terms_dictlist]
        return extracted_terms_dictlist


# UMLS Signs/Symptoms Term Extraction from Term Definitions Parent Script:
# TODO: Revise 'ss_df' content to include all semantic types cited in
# 05082017 notes.
def ss_terms(extracted_terms_dictlist):
    try:
        return disease_effects(extracted_terms_dictlist, ss_df, 'SS')
    except Exception:
        logger.exception('EXCEPTION')
        extracted_terms_dictlist = [dict(item, **{'SS':[]}) for item in extracted_terms_dictlist]
        return extracted_terms_dictlist


# UMLS Term Extraction from Term Definitions Script:
# TODO: Prior version of 'disease_effects()' contained a
# section that would remove shorter versions of longer terms present
# in the results list.  It was flawed in significant respects (e.g.
# would omit even partial term matches).  However, some sort of 'decluttering'
# step should be added at the end of this FX to deal with output such as the
# following, which is the 'AP' result for 'gout':
# 'AP': ['SET OF JOINTS', 'TENDONS', 'JOINTS', 'JOINT'].
# Clearly this is not ideal.  It happens because even with recursive deletion
# longest to short, shorter versions of the same phrase are also present.
def disease_effects(extracted_terms_dictlist, def_search_term_df, def_search_term_tgtnm):
    try:
        if extracted_terms_dictlist:
            for subd in extracted_terms_dictlist:
                def_str = subd['DEF']
                if def_str in ['U', 'E', '']:
                    subd[def_search_term_tgtnm] = []
                else:
                    def_str = def_str.upper()
                    def_str = def_str.replace('/', ' / ')
                    def_str = re.sub(r"([a-z0-9])(\(|\[)", r"\1 \2", def_str, flags=re.I)
                    def_str = re.sub(r"(\.|:|;|,|\)|\])([a-z0-9])", r"\1 \2", def_str, flags=re.I)
                    def_str = ' '.join(def_str.split())
                    def_str = tc.normalize_with_underscores(def_str)

                    reslist = []
                    for row in zip(def_search_term_df['str'], def_search_term_df['commavsn']):
                        if row[0] != '_U_' and row[0] in def_str:
                            reslist.append(row[0].replace('_', ' ').strip())
                            def_str = def_str.replace(row[0], '_')
                        elif row[1] != '_U_' and row[1] in def_str:
                            reslist.append(row[1].replace('_', ' ').strip())
                            def_str = def_str.replace(row[1], '_')

                    subd[def_search_term_tgtnm] = reslist
        return extracted_terms_dictlist
    except Exception:
        logger.exception('EXCEPTION')
        extracted_terms_dictlist = [dict(item, **{def_search_term_tgtnm:[]}) for item in extracted_terms_dictlist]
        return extracted_terms_dictlist


# UMLS ICD-9 Extraction Script:
# TIP: This is never meant to be called directly.  It is a helper
# function for 'term_listing_numbers_v2'.
# OPENQ: Do ICD9 entries in data contain trailing zeroes that would actually match here at 4 digits?
# OPENQ: For items like HIV, does the dataset properly add a leading zero (i.e. '0430')?
# TODO (see update below): Some items don't have ICD9 counterparts, e.g. 'borderline intellectual functioning'.
# You'll need to supplement your ICD9 dataset with 'best equivalencies' for these if you ever
# want a listing to populate (the ICD10 bridging may resolve some of these but still).
# TODO LONG TERM: In a significant enough number of instances, there are
# no ICD-9 codes associated with the CUI(s) at issue and thus the
# listing number association script below fails.  A few high level
# solutions:
# (1) Map another UI directly to listing #'s and
# use that UI instead of ICD-9 (lots of work)..
# (2) Find a reliable bridge between CUI - UI - ICD-9 wherein you
# search for the middle UI whenever no direct ICD-9 value is located
# in data.	Most obvious candidate is ICD-10 and there seem to be a
# good number of crosswalks possibly available.	 BUT see this report
# on the complexity and perhaps futility of such an effort:
# http://www.cms.org/uploads/ICDLogicGEMSWhitePaper.pdf
# UPDATE: Attempt at option 2 implemented below.
def cui_icd9_codes(extracted_terms_dictlist):
    '''Retrieves all ICD9 numbers associated with
    an 'mdi' observation's 'CUI' number(s).

    Args:
        extracted_terms_dictlist {list}: A list
            of 'mdi' observations.
    Returns:
        extracted_terms_dictlist: A list
            of 'mdi' observations, each with a
            'CUI' key and list value added.
    Raises:
        General exception.
    '''
    try:
        for subd in extracted_terms_dictlist:
            cui_list = subd['CUI']
            if not cui_list:
                subd['ICD9'] = []
            else:
                try:
                    icd9resser = new_icd9_df.loc[cui_list]['icd9']
                    icd9reslist = icd9resser[icd9resser.notnull()].tolist()
                    icd9reslist = list(set(icd9reslist))
                    subd['ICD9'] = icd9reslist
                except KeyError:
                    subd['ICD9'] = []
        return extracted_terms_dictlist
    except Exception:
        logger.exception('EXCEPTION')
        extracted_terms_dictlist = [dict(item, **{'ICD9':[]}) for item in extracted_terms_dictlist]
        return extracted_terms_dictlist


# Listing Number Extraction Script - Revised:
# TIP: 'term_dict' is a dictionary containing UMLS data but only
# CUI (list of strings), TYP (list of strings) and TXT (string).
# TEMPORARY: Adding 'paistart' and 'paiend' values as arguments, which for
# effectuation will require updates to 'ifs.py' and to 'ie_common_calcs.py'.
# TODO: Make it so that if PAI values cannot be determined, you fall back to whatever
# listings are CURRENTLY in force/not expired.
# OPENQ: How to handle the following case: s2txt cites to 'osteoarthritis', which is associated
# with ICD9 715-.  Presently, GCESTIMP has no listing associated with 7150 entries; instead,
# a parent listing code of 1.xx would be output.  Perhaps this is the desired outcome.	If so,
# perhaps it would be wise to have SMEs detail why such a common condition doesn't go to any particular
# listing.
# OPENQ: Obesity per SSR 02-1p doesn't have a precise corresponding listing per regs; however,
# presently this function will take an obesity ICD-9 # (e.g. 279), get down to 2 digits, then
# output listing parent # matches, e.g. a 3.xx and 14.xx.  This is clearly inconsistent with
# the guidance for obesity.	 How do we handle this issue? Whitelist out items like obesity?
# Seems better than changing the code to NEVER output on a 2 match.
def term_listing_numbers_v2(extracted_terms_dictlist, claim_type, paistart_input, paiend_input):
    '''Retrieves all listing numbers associated with
    an 'mdi' observation's 'ICD9' number(s).

    Args:
        extracted_terms_dictlist {dict}: A list of 'mdi' dictionary observations.
        claim_type {str}: A verdict as to whether
            the claimant is a 'child', 'adult', or
            'both' during the period adjudicated.
        paistart_input {str}: An INSIGHT-formatted date string
            indicating the beginning of the period at issue.
        paiend_input {str}: An INSIGHT-formatted date string
            indicating the end of the period at issue.
    Returns:
        extracted_terms_dictlist_plusicd {list}: The list of input
            'extracted_terms_dictlist' dictionaries, but with each
            dictionary also having 'ICD9' and 'LISTING' key/value
            pairs as well.
    Raises:
        N/A.
    '''
    try:
        # Check arguments:
        if bool(isinstance(extracted_terms_dictlist, list)) is False:
            logger.critical("term_listing_numbers_v2() - 'extracted_terms_dictlist' TypeError")
            raise TypeError("term_listing_numbers_v2() - 'extracted_terms_dictlist' TypeError")
        if bool(isinstance(claim_type, str)) is False:
            logger.critical("term_listing_numbers_v2() - 'claim_type' TypeError")
            raise TypeError("term_listing_numbers_v2() - 'claim_type' TypeError")
        if bool(isinstance(paistart_input, str)) is False:
            logger.critical("term_listing_numbers_v2() - 'paistart_input' TypeError")
            raise TypeError("term_listing_numbers_v2() - 'paistart_input' TypeError")
        if bool(isinstance(paiend_input, str)) is False:
            logger.critical("term_listing_numbers_v2() - 'paiend_input' TypeError")
            raise TypeError("term_listing_numbers_v2() - 'paiend_input' TypeError")

        # If claim type == 'U', retrieve both types of listings for now.
        if claim_type.lower() not in ['child', 'adult', 'both', 'u']:
            logger.critical("term_listing_numbers_v2() - valid 'claim_type' value not passed:")
            logger.critical(claim_type)
            raise ValueError("term_listing_numbers_v2() - valid 'claim_type' value not passed")
        if claim_type == 'U':
            claim_type = 'both'

        # Retrieve all ICD-9 codes:
        extracted_terms_dictlist_plusicd = cui_icd9_codes(extracted_terms_dictlist)

        # Parse 'paiend' argument:
        paiend_dt = date_helper.parse_date_todatetime_struct(paiend_input)

        # Parse 'paistart' argument:
        paistart_dt = date_helper.parse_date_todatetime_struct(paistart_input)

        # Limit GCESTIMP to only observations relevant to the PAI:
        # TIP: If no 'paistart' value is passed, this will filter out all
        # values with an effective end date by passing today's date.
        def gcestimp_filter_dt(row):
            '''Attempt to filter out any observation whose 'EFF_ENDT' date is PRIOR to the decision observation 'PAISTART' date, as
            we don't want to bring up listings that are not relevent to the claim.
            OPENQ: If no 'PAISTART' date, then what? Keep all?	Restrict manually to earlier of structured data
            AOD/DOF values (which should always be present)?
            Example 1:
            Decision on a solely T2 DIB claim with an AOD of 01/01/2005 and a DOF of 06/01/2010.
            The PAISTART date here is 12/01/2005.  If a severe MDI of 'obesity' is found, we WOULD
            want to raise Listing 9.09 (associated with GCESTIMP.IMPRMT_UID 148) because 148's
            EFF_ENDT date is 8/11/2005, which is *after* the PAI began (i.e. it is relevant during
            at least some part of the PAI).
            Example 2:
            Decision on a solely T16 claim with an AOD of 01/01/2005 and a DOF of 06/01/2010.
            The PAISTART date here is 06/01/2010.  If a severe MDI of 'obesity' is found, we would NOT
            want to raise Listing 9.09 (associated with GCESTIMP.IMPRMT_UID 148) because 148's
            EFF_ENDT date is 8/11/2005, which is *before* the PAI began (i.e. it is not relevant during
            the PAI).'''
            eff_endt = row['EFF_ENDT']
            eff_stdt = row['EFF_STDT']

            outcomever = True

            if eff_endt != 'E' and paistart_dt != 'E':
                if eff_endt >= paistart_dt:
                    pass
                else:
                    outcomever = False

            if eff_stdt != 'E' and paiend_dt != 'E':
                if paiend_dt >= eff_stdt:
                    pass
                else:
                    outcomever = False

            return outcomever

        # Filter listings dataset to those observations applicable to this claim's PAI start and end dates:
        gcestimp_custom_ltd = gcestimp_custom[gcestimp_custom.apply(lambda row: gcestimp_filter_dt(row), axis=1)]

        # Limit GCESTIMP to only CHILDHOOD 'LISTG_TYP' if claim_type == 'child';
        # if 'adult', remove child entries (retains observations with NO 'LISTG_TYP'
        # value at least for 'adult'; if 'both', make no changes.
        if claim_type.lower() == 'child':
            gcestimp_custom_ltd = gcestimp_custom_ltd[gcestimp_custom_ltd['LISTG_TYP'] == 'CHILDHOOD']
        elif claim_type.lower() == 'adult':
            gcestimp_custom_ltd = gcestimp_custom_ltd[gcestimp_custom_ltd['LISTG_TYP'] != 'CHILDHOOD']

        # Iterate through 'GCESTIMP_V2' rows to attempt to locate a match
        # between each extracted ICD-9 and a DIG or DIG_ALT:
        for subd in extracted_terms_dictlist_plusicd:
            results = []
            icd9list = subd['ICD9']
            for icdsublist in icd9list:
                icd_split = icdsublist.split("; ")
                for icd in icd_split:
                    for code_match_length in range(4, 1, -1):

                        code_length_results = []
                        # TIP: Odd ordering helps ease updating - basically, new columns added to
                        # GCESTIMP are appended to end of this 'zip()'.
                        # TIP: Eric found that a zip() iteration was more performant
                        # than PANDAS built-in slicing methods.
                        for row in zip(gcestimp_custom_ltd['IMPRMT_UID'], gcestimp_custom_ltd['LISTG_CD'],
                                       gcestimp_custom_ltd['BODYSYS_CD'], gcestimp_custom_ltd['DIG'],
                                       gcestimp_custom_ltd['DSPL_DIG_DESC'], gcestimp_custom_ltd['LISTG_TYP'],
                                       gcestimp_custom_ltd['EFF_ENDT'], gcestimp_custom_ltd['BODYSYS_LBL'],
                                       gcestimp_custom_ltd['DIG_ALT'], gcestimp_custom_ltd['DIG_DESC'],
                                       gcestimp_custom_ltd['EFF_STDT']):
                            if icd[:code_match_length] == row[3][:code_match_length]:
                                if code_match_length == 4:
                                    if row[1] not in ['E', '']:
                                        # TIP: 'GCESTIMP_V2' listing values only ever have one real listing number per row.
                                        listing = row[1]
                                        listing = re.sub(r"[^0-9\.].*", "", listing)
                                        listing = ''.join(
                                            [char for char in list(listing) if char.isdigit() or char == '.'])
                                        listing_dict = {}
                                        listing_dict['whitelisted'] = False
                                        listing_dict['imprmnt_uid'] = row[0]
                                        listing_dict['listg_num'] = listing
                                        listing_dict['desc'] = row[4]
                                        listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                        listing_dict['DIG'] = row[3]
                                        if row[6] == 'E':
                                            listing_dict['eff_endt'] = False
                                        else:
                                            listing_dict['eff_endt'] = True
                                        code_length_results.append(listing_dict)
                                    else:
                                        if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                            listing = row[2] + '.xx'
                                            listing_dict = {}
                                            listing_dict['whitelisted'] = False
                                            listing_dict['imprmnt_uid'] = row[0]
                                            listing_dict['listg_num'] = listing
                                            listing_dict['desc'] = row[4]
                                            listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                            listing_dict['DIG'] = row[3]
                                            if row[6] == 'E':
                                                listing_dict['eff_endt'] = False
                                            else:
                                                listing_dict['eff_endt'] = True
                                            code_length_results.append(listing_dict)
                                elif code_match_length == 3:
                                    if row[1] not in ['E', '']:
                                        # TIP: 'GCESTIMP_V2' listing values only ever have one real listing number per row.
                                        listing = row[1]
                                        listing = re.sub(r"[^0-9\.].*", "", listing)
                                        listing = ''.join(
                                            [char for char in list(listing) if char.isdigit() or char == '.'])
                                        listing_dict = {}
                                        listing_dict['whitelisted'] = False
                                        listing_dict['imprmnt_uid'] = row[0]
                                        listing_dict['listg_num'] = listing
                                        listing_dict['desc'] = row[4]
                                        listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                        listing_dict['DIG'] = row[3]
                                        if row[6] == 'E':
                                            listing_dict['eff_endt'] = False
                                        else:
                                            listing_dict['eff_endt'] = True
                                        code_length_results.append(listing_dict)
                                    else:
                                        if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                            listing = row[2] + '.xx'
                                            listing_dict = {}
                                            listing_dict['whitelisted'] = False
                                            listing_dict['imprmnt_uid'] = row[0]
                                            listing_dict['listg_num'] = listing
                                            listing_dict['desc'] = row[4]
                                            listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                            listing_dict['DIG'] = row[3]
                                            if row[6] == 'E':
                                                listing_dict['eff_endt'] = False
                                            else:
                                                listing_dict['eff_endt'] = True
                                            code_length_results.append(listing_dict)
                                # TIP: If match length only 2, output only
                                # the listing parent number (e.g. 12.xx); if
                                # only 1, output nothing.
                                # TIP: Only search for length-2 matches if
                                # impairment name NOT in nolen2matchwhitelist
                                elif code_match_length == 2:
                                    if subd['TXT'] not in nolen2matchwhitelist:
                                        if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                            listing = row[2] + '.xx'
                                            listing_dict = {}
                                            listing_dict['whitelisted'] = False
                                            listing_dict['imprmnt_uid'] = row[0]
                                            listing_dict['listg_num'] = listing
                                            listing_dict['desc'] = row[4]
                                            listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                            listing_dict['DIG'] = row[3]
                                            if row[6] == 'E':
                                                listing_dict['eff_endt'] = False
                                            else:
                                                listing_dict['eff_endt'] = True
                                            code_length_results.append(listing_dict)

                            else:
                                # If DIG_ALT match, parse:
                                if icd[:code_match_length] in [cd[:code_match_length] for cd in row[8].split('; ')]:
                                    if code_match_length == 4:
                                        if row[1] not in ['', 'E']:
                                            # TIP: 'GCESTIMP_V2' listing values only ever have one real listing number per row.
                                            listing = row[1]
                                            listing = re.sub(r"[^0-9\.].*", "", listing)
                                            listing = ''.join(
                                                [char for char in list(listing) if char.isdigit() or char == '.'])
                                            listing_dict = {}
                                            listing_dict['whitelisted'] = False
                                            listing_dict['imprmnt_uid'] = row[0]
                                            listing_dict['listg_num'] = listing
                                            listing_dict['desc'] = row[4]
                                            listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                            listing_dict['DIG'] = row[3]
                                            if row[6] == 'E':
                                                listing_dict['eff_endt'] = False
                                            else:
                                                listing_dict['eff_endt'] = True
                                            code_length_results.append(listing_dict)
                                        else:
                                            if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                                listing = row[2] + '.xx'
                                                listing_dict = {}
                                                listing_dict['whitelisted'] = False
                                                listing_dict['imprmnt_uid'] = row[0]
                                                listing_dict['listg_num'] = listing
                                                listing_dict['desc'] = row[4]
                                                listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                                listing_dict['DIG'] = row[3]
                                                if row[6] == 'E':
                                                    listing_dict['eff_endt'] = False
                                                else:
                                                    listing_dict['eff_endt'] = True
                                                code_length_results.append(listing_dict)
                                    elif code_match_length == 3:
                                        if row[1] not in ['', 'E']:
                                            # TIP: 'GCESTIMP_V2' listing values only ever have one real listing number per row.
                                            listing = row[1]
                                            listing = re.sub(r"[^0-9\.].*", "", listing)
                                            listing = ''.join(
                                                [char for char in list(listing) if char.isdigit() or char == '.'])
                                            listing_dict = {}
                                            listing_dict['whitelisted'] = False
                                            listing_dict['imprmnt_uid'] = row[0]
                                            listing_dict['listg_num'] = listing
                                            listing_dict['desc'] = row[4]
                                            listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                            listing_dict['DIG'] = row[3]
                                            if row[6] == 'E':
                                                listing_dict['eff_endt'] = False
                                            else:
                                                listing_dict['eff_endt'] = True
                                            code_length_results.append(listing_dict)
                                        else:
                                            if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                                listing = row[2] + '.xx'
                                                listing_dict = {}
                                                listing_dict['whitelisted'] = False
                                                listing_dict['imprmnt_uid'] = row[0]
                                                listing_dict['listg_num'] = listing
                                                listing_dict['desc'] = row[4]
                                                listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                                listing_dict['DIG'] = row[3]
                                                if row[6] == 'E':
                                                    listing_dict['eff_endt'] = False
                                                else:
                                                    listing_dict['eff_endt'] = True
                                                code_length_results.append(listing_dict)
                                    # TIP: If match length only 2, output only
                                    # the listing parent number (e.g. 12.xx); if
                                    # only 1, output nothing.
                                    elif code_match_length == 2:
                                        if subd['TXT'] not in nolen2matchwhitelist:
                                            if row[2] not in ['', 'E'] and row[2] not in ['19', '20']:
                                                listing = row[2] + '.xx'
                                                listing_dict = {}
                                                listing_dict['whitelisted'] = False
                                                listing_dict['imprmnt_uid'] = row[0]
                                                listing_dict['listg_num'] = listing
                                                listing_dict['desc'] = row[4]
                                                listing_dict['hiv_manif'] = bool(row[5] == 'HIV MANIFESTATION')
                                                listing_dict['DIG'] = row[3]
                                                if row[6] == 'E':
                                                    listing_dict['eff_endt'] = False
                                                else:
                                                    listing_dict['eff_endt'] = True
                                                code_length_results.append(listing_dict)

                        # Check 'results' to see if there were any matches at this length.
                        # If there were, break; else, press on:
                        if len(code_length_results) >= 1:
                            for res in code_length_results:
                                results.append(res)
                            break

            subd['LISTING'] = results

        return extracted_terms_dictlist_plusicd
    except Exception:
        logger.exception('EXCEPTION')
        if extracted_terms_dictlist:
            extracted_terms_dictlist = [dict(item, **{'ICD9':[]}) for item in extracted_terms_dictlist]
            extracted_terms_dictlist = [dict(item, **{'LISTING':[]}) for item in extracted_terms_dictlist]
            return extracted_terms_dictlist
        else:
            return extracted_terms_dictlist
