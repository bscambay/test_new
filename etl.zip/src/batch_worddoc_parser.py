# INSIGHT FULL SUITE - BATCH PROCESSOR - HEARING DECISION WORD DOCUMENT LOCATOR 
# AND PARSER
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.17.2017
#
# SUMMARY: 
# Attempt to locate a single hearing decision Microsoft Word '.docx' file
# associated with a given targeted DOCU_CTL_ID value, then optionally save
# the text of that '.docx' to a target directory using the same DOCU_CTL_ID
# value as its file name.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os
import os.path
import shutil
import logging
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
inputdir = os.path.join(insightdir, "Input/Input")
processingdir = os.path.join(insightdir, "Input/Processing")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Locate word document path from DMA fork:
def locate_worddoc(docu_ctl_id_input, dspn_ocd_input, tgt_dspn_dt_fldr_str):

	try:
		cfg.batch_worddoc_fork_parentdir
		
		tgtdir1 = os.path.join(cfg.batch_worddoc_fork_parentdir, dspn_ocd_input)
		tgtdir2 = os.path.join(tgtdir1, tgt_dspn_dt_fldr_str)
		tgtdir3 = os.path.join(tgtdir2, '3110')
		tgtfn = docu_ctl_id_input + '.doc'
		tgtfp = os.path.join(tgtdir3, tgtfn)
		print 'tgtfp:'
		print tgtfp
		if os.path.isfile(tgtfp):
			return tgtfp
		else:
			return 'E'
		
	except Exception:
		logging.exception('EXCEPTION')
		return 'E'

	






















	