
# Set directories:
import setup_config

"""Mock Case Search unit test"""

from mock import Mock, patch
from bottle_oao import case_search
import pytest
import json


# Case search unit test mock class. Fakes a http request to
# without relying on actual end point to test case search functionality
@pytest.mark.skipif(pytest.config.getvalue("--cov"), reason="--cov not compatible")
class TestCaseSearch(object):
    """Case Search test class"""
    @classmethod
    def setup_class(cls):
        """Setup before testing"""
        cls.mock_get_patcher = patch('requests.post')
        cls.mock_post = cls.mock_get_patcher.start()

    @classmethod
    def teardown_class(cls):
        """Tear Down after testing"""
        cls.mock_get_patcher.stop()

    def test_case_search_content_valid(self):
        """Mock test using a valid admin pin and valid case pin. Return: JSON content"""
        admin_pin = None
        case_pin = '897960'
        ssn = None
        self.mock_post.return_value.ok = True
        info = [{'HOFC_WRK_UNIT_UID': 12022700, 'CLMT_SSN': '123456789',
                 'WKLD_TYP': 'RR ', 'HOFC_DSPN_DT': '10/31/2016 12:00:00 AM',
                 'CLMT_NM25': 'DOE, JANE L     ',
                 'HRG_TYP': '10',
                 'RQST_RCVDT': '11/16/2016 12:00:00 AM',
                 'link': 'http://S1FF515:8189/oaoapp/800',
                 'CLM_TYP': 'DIWC'},
                {'HOFC_WRK_UNIT_UID': 11239495, 'CLMT_SSN': '222255555',
                 'WKLD_TYP': 'BP ', 'HOFC_DSPN_DT': '1/26/2006 12:00:00 AM',
                 'CLMT_NM25': 'DOE, JOHN R         ',
                 'HRG_TYP': '50',
                 'RQST_RCVDT': '2/13/2018 12:00:00 AM',
                 'link': '',
                 'CLM_TYP': 'SSID'}]
        info = json.dumps(info)
        self.mock_post.return_value = Mock()
        self.mock_post.return_value.json.return_value = info
        json_mock_content = case_search(case_pin, admin_pin)
        assert info == json_mock_content

    def test_case_search_struct_valid(self):
        """Mock test case for a valid json structure using a \
            valid admin pin and valid case pin. Return: JSON content keys only"""
        admin_pin = None
        case_pin = '897960'
        info = [{'HOFC_WRK_UNIT_UID': 12022700, 'CLMT_SSN': '123456789',
                 'WKLD_TYP': 'RR ', 'HOFC_DSPN_DT': '10/31/2016 12:00:00 AM',
                 'CLMT_NM25': 'DOE, JANE L     ',
                 'HRG_TYP': '10',
                 'RQST_RCVDT': '11/16/2016 12:00:00 AM',
                 'link': 'http://S1FF515:8189/oaoapp/800',
                 'CLM_TYP': 'DIWC'},
                {'HOFC_WRK_UNIT_UID': 11239495, 'CLMT_SSN': '222255555',
                 'WKLD_TYP': 'BP ', 'HOFC_DSPN_DT': '1/26/2006 12:00:00 AM',
                 'CLMT_NM25': 'DOE, JOHN R         ',
                 'HRG_TYP': '50',
                 'RQST_RCVDT': '2/13/2018 12:00:00 AM',
                 'link': '',
                 'CLM_TYP': 'SSID'}]

        self.mock_post.return_value = Mock()
        self.mock_post.return_value.json.return_value = info
        json_mock_content = case_search(case_pin, admin_pin)
        info_keys = info.pop().keys()
        json_mock_content_keys = json_mock_content.pop().keys()
        assert list(json_mock_content_keys) == list(info_keys)

    def test_case_search_is_not_valid(self):
        """Mock test using a valid admin pin and invalid case pin. \
            Return: User pin error"""
        admin_pin = None
        invalid_case_pin = 'XoXoXo!!'
        error_msg = {'Error': 'User PIN or Office not Authorized'}
        self.mock_post.return_value = Mock()
        self.mock_post.return_value.json.return_value = error_msg
        json_mock_content = case_search(invalid_case_pin, admin_pin)
        assert error_msg == json_mock_content

    def test_case_search_is_404(self):
        """Mock test using for a 404 error using a valid admin pin and valid \
        case pin. Return: 404 error"""
        admin_pin = None
        case_pin = '897960'
        error_msg_404 = {'status': 404}
        self.mock_post.return_value = Mock()
        self.mock_post.return_value.json.return_value = error_msg_404
        json_mock_content = case_search(case_pin, admin_pin)
        assert error_msg_404 == json_mock_content
