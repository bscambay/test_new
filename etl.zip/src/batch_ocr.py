# INSIGHT OCR SCRIPT
# AUTHOR: Kurt Glaze, U.S. Social Security Administration, Office of Appellate Operations, Division of Quality, Br. 9 / Gerald Ray Academy 
# DATE LAST UPDATED: 06.30.2016
#
# PURPOSE: This script is designed to extract text from TIF images using Tesseract OCR.
#
# NOTICE: The INSIGHT config file must be located in the same directory as any INSIGHT Python script file utilizing its configuration data.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has not yet been formally validated and whose documentation is not yet fully formed. 
# Caution is therefore urged in utilizing this software or its output for programmatic purposes.
# ============================================================================================================================================


### IMPORT MODULES ###
from __future__ import print_function
from __future__ import print_function
from __future__ import print_function
from __future__ import print_function
from __future__ import print_function
from __future__ import print_function
import os
import os.path
import ntpath
import multiprocessing
import subprocess
import logging
import timeit
import pandas
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


### DEFINE OCR FUNCTION ###
def ocr(decisionfp):
    try:
        tesseractpath = "C:\\Program Files (x86)\\Tesseract-OCR\\tesseract.exe"
        # tesseractpath = "C:\\Temp\\Tesseract-OCR\\tesseract.exe"
        decisionfilename = ntpath.basename(decisionfp)
        decisionid = os.path.splitext(decisionfilename)[0]
        outputdir = os.path.dirname(decisionfp)
        outputpathname = outputdir + "\\" + decisionid
        call = tesseractpath + " " + str(decisionfp) + " " + str(
            outputpathname) + " hocr lns.txt"  # TIP: Creates Tesseract terminal call utilizing custom config file whitelist.
        subprocess.call(call)
    except Exception as x:
        print(decisionfp)
        print(str(x))
        logger.error("Exception: "+str(x))


### DEFINE 'MAIN' SCRIPT ###
if __name__ == '__main__':

    # Create full path to temp dir:
    batch_temp_dir = cfg.batch_temp_dir

    # Assemble list of decision TIF decids:
    decisiontifdecidlist = [fn[:-4] for fn in os.listdir(batch_temp_dir) if fn.endswith('.tif')]
    print('decisiontifdecidlist len: ' + str(len(decisiontifdecidlist)))

    # Filter out already-OCR'd:
    alreadyocrddecidlist = [fn[:-5] for fn in os.listdir(batch_temp_dir) if fn.endswith('html')]
    # alreadyocrddecidlist = [fn[:-5] for fn in os.listdir(batch_temp_dir) if fn.endswith('hocr')]
    decisionpathlist_filtered = list(set(decisiontifdecidlist) - set(alreadyocrddecidlist))
    print('decisionpathlist_filtered len: ' + str(len(decisionpathlist_filtered)))

    # Create full paths to target TIFs:
    decisionpathlist_filtered_fp = [os.path.join(batch_temp_dir, str(decid + '.tif')) for decid in
                                    decisionpathlist_filtered]
    print(decisionpathlist_filtered_fp[0])
    print('decisionpathlist_filtered_fp len: ' + str(len(decisionpathlist_filtered_fp)))

    # Start the multiprocess:
    start = timeit.default_timer()
    # TEMPORARY: Determine virtualized server CPU levels precisely before
    # using 'configured' CPU count.
    # batch_mp_process_ct = cfg.batch_mp_process_ct
    batch_mp_process_ct = 'U'
    if batch_mp_process_ct == 'U':
        cpu_count = multiprocessing.cpu_count()
        batch_mp_process_ct = int(round(cpu_count * float(0.5)))
    pool = multiprocessing.Pool(processes=batch_mp_process_ct)
    pool.map(ocr, decisionpathlist_filtered_fp)
    pool.close()
    pool.join()
    stop = timeit.default_timer()
