var nlpid = window.location;
var fullpath = nlpid['pathname'];
if (nlpid['search'] != "" ) {
	nlpid = nlpid['search'];
	nlpid = nlpid.split('=')[1];
}
else {
	nlpid = nlpid['pathname']
	if (nlpid.split('/').length == 3) {
		nlpid = nlpid.split('/')[2];
	}
	else {
		nlpid = nlpid.split('/')[1];
	}
}

function bmiCalc() {
	var htft =  $("#adulthtft").val().replace(/^0{1,}(.+)/, '$1'),
		htin =  $("#adulthtin").val().replace(/^0{1,}(.+)/, '$1'),
		wt =  $("#adultwt").val().replace(/^0{1,}(.+)/, '$1'),
		bmiResult = $("#bmiresult");

	if (htft.trim() == '' || htin.trim() == '' || wt.trim() == ''){
		bmiResult.html("");
	} else {

		var wtvalres = /^[1-9]$|^[1-9][0-9]{1,2}$/.test(wt);
		var htftvalres = /^[0-9]$/.test(htft);
		var htinvalres = /^0$|^[1-9]$|^0[1-9]$|^1(0|1|2)$/.test(htin);

		if (wtvalres == false) {
			bmiResult.css({'font-style': 'italic', 'color': '#ce0000'})
					.html("BMI not calculated - please enter a valid weight as a number from 1 to 999.");
		} else if (htftvalres == false) {
			bmiResult.css({'font-style': 'italic', 'color': '#ce0000'})
					.html("BMI not calculated - please enter a valid height in feet as a single number from 0 to 9.");
		} else if (htinvalres == false) {
			bmiResult.css({'font-style': 'italic', 'color': '#ce0000'})
					.html("BMI not calculated - please enter a valid height in inches as a number from 0 to 12.");
		} else if (htft == '0' && htin == '0') {
			bmiResult.css({'font-style': 'italic', 'color': '#ce0000'})
				.html("BMI not calculated - please enter a valid height (must be greater than 0).");
		} else {
			var htft = parseInt(htft);
			var htin = parseInt(htin);
			var wt = parseInt(wt);
			var totht = htft * 12 + htin;
			var tothtsq = Math.pow(totht, 2);
			var res1 = wt / tothtsq;
			var res2 = res1 * 703;
			var res2fixed = res2.toFixed(3);
			var res2fixedstr = res2fixed.toString();
			var bmiverdictstr = "";

			if (res2fixed < 17.5) {
				bmiverdictstr =  res2fixedstr + " - Underweight - Possible <a style=\"color:#ce0000;font-weight:600;\" href=\"https://www.ssa.gov/disability/professionals/bluebook/5.00-Digestive-Adult.htm#5_08\" target=\"blank\">5.08</a> Meets/Equals BMI Level";
				bmiResult.css({'color': '#ce0000', 'font-weight': 600}).
						html(bmiverdictstr);
			} else if (res2fixed >= 17.5 && res2fixed <= 18.5) {
				bmiverdictstr = res2fixedstr + " - Underweight";
				bmiResult.css({'color': 'purple', 'font-weight': 600}).
						html(bmiverdictstr);
			} else if (res2fixed >= 18.5 && res2fixed <= 24.999) {
				bmiverdictstr = res2fixedstr + " - Normal";
				bmiResult.css({'color': 'green', 'font-weight': 600}).
						html(bmiverdictstr);
			} else if (res2fixed >= 24.999 && res2fixed <= 29.999) {
				bmiverdictstr = res2fixedstr + " - Overweight";
				bmiResult.css({'color': 'purple', 'font-weight': 600}).
						html(bmiverdictstr);
			} else {
				bmiverdictstr = res2fixedstr + " - Obese";
				bmiResult.css({'color': '#ce0000', 'font-weight': 600}).
						html(bmiverdictstr);
			}

		}
	}
}

$.fn.clearForm = function() {
	return this.each(function() {
   var type = this.type, tag = this.tagName.toLowerCase();
   if (tag == "form")
	 return $(":input",this).clearForm();
	   if (type == "text" || type == "password" || tag == "textarea")
		 this.value = "";
	   else if (type == "checkbox" || type == "radio")
		 this.checked = false;
		 else if (type == "hidden"){}
	   else if (tag == "select")
		 this.selectedIndex = -1;
	});
};

/// Define JQuery Scripts for Individual 'Full Results' slideToggles
$(document).ready(function(){
	$.ajax({
		type: 'POST',
		url: '/_logaccess',
		data: "&fullpath=" + fullpath,
		async:false,
		 success: function(response) {
			console.log(response);
		},
		error: function(error) {
			console.log(error);
		}
	});

	$("#adulthtft, #adulthtin, #adultwt").on('input change', function(){
		bmiCalc();
	});

	$("#agecalc_cldob, #agecalc_did").click(function(e){
		e.preventDefault();

		var el = $(this),
			resultLbl = $('#' + el.data('result'));

		$.ajax({
			type: 'POST',
			url: el.data('post-url'),
			data: JSON.stringify( {"reqid": nlpid} ),
			success: function(response) {
				resultLbl.val(response);
			},
			error: function(error) {
				console.log(error);
				alert(el.data('field') + " request error: " + error.responseText);
			}
		});
	});

	$('form').submit(function(e) {
		e.preventDefault();
		var form_ = $(this);

		$.ajax({
			type: 'POST',
			url: form_.data('post-url'),
			data: form_.serialize() + "&reqid=" + nlpid,
			success: function(response) {
				var resultLbl = $('#' + form_.data('result') );
				if(resultLbl.length){
					resultLbl.html(response).focus();
				}
				else { // feed back form
					alert ('Thank You for the Feedback!');
					console.log(response);
					form_.clearForm();
				}
			},
			error: function(error) {
				var fieldLbl = form_.data('field');
				if(typeof fieldLbl !== 'undefined'){
					alert(fieldLbl + " request error: " + error.responseText);
				}
				console.log(error);
			}
		});
		return true;
	});

	$("a.reportsection").click(function(e){
		e.preventDefault();
	});

	$('#otherflagsdiv1, #otherflagsdiv2, #otherflagsdiv3, #otherflagsdiv4, #otherflagsdiv5, #otherflagsdiv6, #otherflagsdiv7, #casesummary_moreinfodiv, #impexp_moreinfodiv, #impexp_allgn_impairmentsdiv, #impexp_allgn_findingsdiv, #sso_moreinfodiv, #alerts_moreinfodiv, #rfcdotmoreinfodiv, #bmi_moreinfodiv, #childbmi_moreinfodiv, #templategen_moreinfodiv, #agecalc_moreinfodiv, #casesummary, #impexp_moreinfodiv, #sso_moreinfodiv, #templategen_moreinfodiv, #bmi_moreinfodiv, #childbmi_moreinfodiv, #agecalc_moreinfodiv, #qualityreport, #tools').hide();

	$("#impexp_tooldiv, #templategen_tooldiv, #bmi_tooldiv, #childbmi_tooldiv, #agecalc_tooldiv, #sso_tooldiv").show();

	$(".feedbacktogglebutton, .feedbacktogglebuttontools").each(function(index){
		var el = $(this);
		if(typeof el.data('is-accordian') !== 'undefined'){
			$('#' + el.data('toggle-id')).hide();
			el.attr('aria-label', el.attr('aria-label').replace('\u2718', 'Failed').replace("\u2714", "Passed") );
		}
	});

	$("button[type=reset]").click(function(){
		var el = $(this),
			namePrefix = el.attr('id').replace("reset", ""),
			submitBtn = $('#' + namePrefix + 'submit');

		submitBtn.val('Send').attr("disabled", false).css({
			"font-style": "normal",
			"background-color": "white",
			"cursor": "pointer"
		});
	});

	$("#casesummarymoreinfobtn, #impexpmoreinfobtn, #ssomoreinfobtn, #rfcdotmoreinfobtn, #bmimoreinfobtn, #childbmimoreinfobtn, #alertsmoreinfobtn, #templategenmoreinfobtn, #agecalcmoreinfobtn, #reportsectionbtn_casesummary, #reportsectionbtn_qualityreport, #reportsectionbtn_tools, .fullresultstogglebutton, .feedbacktogglebutton, .feedbacktogglebuttontools").click(function(){
		var el = $(this),
			item2Toggle = $('#' + el.data('toggle-id') ),
			item2Hide = $('#' + el.data('hide-id') );

		item2Toggle.slideToggle(400, function(){
			el.attr('aria-expanded', item2Toggle.is(':visible') );
		});

		if(item2Toggle.is(':visible') && item2Hide.length > 0){
			item2Hide.slideUp();
		}

		if(typeof el.data('is-accordian') !== 'undefined'){
			el.text(el.text() === '\u02c5' ? '\u02c4' : '\u02c5');
		}
    });

	/// Define JQuery script to set the present URL as the value for all hidden form inputs of class "location" (this data is used to associate feedback with a particular IQ data entry).
	var myNodeList = document.getElementsByClassName("location");
	var i;
	for (i = 0; i < myNodeList.length; i++) {
		myNodeList[i].value = window.location.href;
	}

	/// Define navigation script:
	// Add smooth scrolling to all links
	$(".navlink").on('click', function(event) {

    	// Make sure this.hash has a value before overriding default behavior
		if (this.hash !== "") {
			// Prevent default anchor click behavior
			event.preventDefault();

			if (this.hash == "#top") {
				$('html, body').animate({ scrollTop: 0}, 800, function(){
				});
				$('#top').focus();
			}
			else {
				// Store hash
				var scrollEle = $(this.hash);

				// Using jQuery's animate() method to add smooth page scroll
				// The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
				$('html, body').animate({
						scrollTop: scrollEle.offset().top-75
					}, 800, function(){
				});

				scrollEle.focus();
				}
			} // End if
		return false;
	});
});
