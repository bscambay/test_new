# INSIGHT HEARING DECISION QUALITY ANALYSIS ALGORITHM (INSIGHT Quality) - 
# DATA LOADER
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 07.29.2016
# 
# SUMMARY:
# Loads datasets utilized by INSIGHT Quality.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has not
# yet been formally validated and whose documentation is not yet fully formed.
# ==============================================================================

# Import modules:
import re
import logging
import os.path
import io
import ast
import sys
import pandas
from nltk.tokenize import word_tokenize
from nltk.tokenize.punkt import PunktSentenceTokenizer, PunktParameters
from nltk.corpus import stopwords

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load datasets:
try:
    # Load stopwords:
    cachedStopWords = stopwords.words("english")

    # Load DOT data:
    dotdf = pandas.read_csv(os.path.join(datadir, "DOT_Data.csv"), dtype=str, na_filter=False)
    dotdf.set_index('DOTCODE', inplace=True)
    dotdfkeys = dotdf.index.values.tolist()
    dotdffrozenset = frozenset(dotdfkeys)

    # Load MVR data (as dictionaries where k=mvr and v=mvr value):
    mvrdf = pandas.read_csv(os.path.join(datadir, "mvrtable.csv"),
                            dtype={'mvr': 'str', 'ex_lvl': 'str', 'age_min': 'int', 'age_max': 'int', 'ed': 'str',
                                   'prev_word_tx_skills': 'str', 'disability_ver': 'int'})
    mvrdf.set_index('mvr', inplace=True)

    # Load Step 2 text quality data:
    # (a) Load MDI_ENT dataset:
    # TIP: Consists of MDI_ENT names (NOT as REGEX patterns) + any associated
    # ICD-9 data; same format as 'diseaselist' dataset.
    # NOTE: Omits ICD-9 78 and 79 (symptoms) as well as V and E
    # entries (for speed).
    diseaselistpath = os.path.join(datadir, "S2_MDIENT_FINAL.txt")
    diseaselistfilelines = io.open(diseaselistpath, "rt", encoding="utf8", errors="ignore")
    diseaselistfilelines = diseaselistfilelines.readlines()
    diseaselistfilelines = [line.rstrip() for line in diseaselistfilelines]
    diseaselistfilelines = [line.split("===")[0] for line in diseaselistfilelines]
    diseaselist = [" ".join(line.split()) for line in diseaselistfilelines]

    # (b) Load SX_ENT dataset (consists of 'escape-presumed' REGEX patterns):
    # NOTE: Consists of experience-based SX language and ICD-9-classified SX
    # language (780-799). But does not ALL ICD-9 78/79 entries, specifically:
    # - ICD-9 classified 'symptoms' containing 'MDI'-like terms
    # (e.g. '[X] condition/disorder/syndrome') - even if formally
    # classified as 'symptoms', that would be too confusing for end users.
    # - Other bespoke omissions based on experience/judgment
    # (e.g. '[reduced|limited|etc.] visual acuity' is so close in meaning
    # to myopia that raising a flag for it would be unhelpful).
    sxfile = open(os.path.join(datadir, "S2_SX_ENT_FINAL.txt"), "r")
    sxlines = sxfile.readlines()
    sxlines = [item for item in sxlines if bool(item.startswith("#")) is False and any(c.isalpha() for c in item)]
    sxlist = [item.rstrip() for item in sxlines]
    sxlist = [r'%s' % item for item in sxlist]
    sxlist.sort(key=len, reverse=True)

    # (c) Load UNCERT_ENT dataset (consists of
    # 'escape-presumed' REGEX patterns):
    uncertainfile = open(os.path.join(datadir, "S2_UNCERTAIN_ENT_FINAL.txt"), "r")
    uncertainlines = uncertainfile.readlines()
    uncertainlines = [item for item in uncertainlines if
                      bool(item.startswith("#")) is False and any(c.isalpha() for c in item)]
    uncertainlist = [item.rstrip() for item in uncertainlines]
    uncertainlist = [r'%s' % item for item in uncertainlist]
    uncertainlist.sort(key=len, reverse=True)

    # (d)(1) Load ASSOC_ENT dataset (consists of
    # 'escape-presumed' REGEX patterns):
    assocphrasefile = open(os.path.join(datadir, "S2_ASSOC_ENT_FINAL.txt"), "r")
    assocphraselines = assocphrasefile.readlines()
    assocphraselines = [item for item in assocphraselines if
                        bool(item.startswith("#")) is False and any(c.isalpha() for c in item)]
    assocphraselist = [line.rstrip() for line in assocphraselines]
    assocphraselist = [r'%s' % item for item in assocphraselist]
    assocphraselist.sort(key=len, reverse=True)

    # (d)(2) Load ASSOC_ENT dataset for uncertainty parsing (consists of
    # 'escape-presumed' REGEX patterns):
    assocphrasefile2 = open(os.path.join(datadir, "S2_ASSOC_ENT_FINAL_UNCERTAIN.txt"), "r")
    assocphraselines2 = assocphrasefile2.readlines()
    assocphraselines2 = [item for item in assocphraselines2 if
                         bool(item.startswith("#")) is False and any(c.isalpha() for c in item)]
    assocphraselist2 = [line.rstrip() for line in assocphraselines2]
    assocphraselist2 = [r'%s' % item for item in assocphraselist2]
    assocphraselist2.sort(key=len, reverse=True)

    # (e) Load non-MDI/non-SX programmatic and
    # date dataset:
    nonlistfile = open(os.path.join(datadir, "S2_NONMDINONSX_FINAL.txt"), "r")
    nonlistfilerl = nonlistfile.readlines()
    nonlist = [item.rstrip() for item in nonlistfilerl]
    nonlist = [r'%s' % item for item in nonlist]
    nonlist.sort(key=len, reverse=True)

    # (f) Load body system and directionals list:
    bodysystemfile = open(os.path.join(datadir, "S2_BODYSYS_FINAL.txt"), "r")
    bodysystemlines = bodysystemfile.readlines()
    bodysystemlist = [line.rstrip() for line in bodysystemlines]
    bodysystemlist = [r'%s' % item for item in bodysystemlist]
    bodysystemlist.sort(key=len, reverse=True)

    # Load LOL_NLD dataset:
    lol_nld_regex = []
    with open(os.path.join(datadir, "RFCLOLFA_lol_nld_NEW_IQVSN_NEWDIVIDER.txt"), "r") as lol_nld_file:
        lol_nld_fileread = lol_nld_file.readlines()
        lol_nld_fileread = [line.rstrip() for line in lol_nld_fileread]
        lol_nld_fileread = [line for line in lol_nld_fileread if bool(line.startswith("#")) is False]
        lol_nld_fileread = [ast.literal_eval(line) for line in lol_nld_fileread]
        for line in lol_nld_fileread:
            lol_nld_regex.append(line[1])

    # Load CUI semantic relations dataset:
    # WARNING 03282017: At least some semantic relations contained here are NOT
    # ideal for your desired uses of this dataset.  For example:
    # 'obesity' (C0028754) brings up a semrel of 'coronary artery disease' (C1956346)
    # along with its more reasonable semrels such as 'corpulence'.  Use ONLY after
    # manually checking the target's semrels for the time being.
    cui_semrel_dict = {}
    with open(os.path.join(datadir, 'CUI_semantic_relations.csv'), 'r') as cui_semrel_file:
        cui_semrel_filelines = cui_semrel_file.readlines()
        for line in cui_semrel_filelines:
            linesplit = line.split(",", 1)
            cui_semrel_dict[linesplit[0]] = linesplit[1].strip()

    # Load CUI relation networks:
    # TIP: Example of retrieval:
    # "cui_rel_ntwk_dict['C0007286']['CUI'].tolist()"
    cui_rel_ntwk_dict = {}
    for fp in [os.path.join(datadir, fn) for fn in os.listdir(datadir) if 'relation_network' in fn]:
        fn = os.path.basename(fp)
        nm = os.path.splitext(fn)[0].replace('_close_relation_network', '')
        df = pandas.read_csv(fp, delimiter="|", dtype=str)
        df.sort_values(by='STR', ascending=False, inplace=True)
        cui_rel_ntwk_dict[nm] = df

except Exception:
    logger.exception('EXCEPTION')
    raise
