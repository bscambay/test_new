'''Setup coverage directory for reporting.'''

import os
def create_coverage_directory(coverage_directory):
    current_directory = os.getcwd()
    coverage_directory = os.path.join(current_directory, coverage_directory)
    if not os.path.exists(coverage_directory):
        os.makedirs(coverage_directory)

create_coverage_directory('coverage')