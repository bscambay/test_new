# step 3 finding, I don't know what feq_id is here; will update it when finding out

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S3FEVERDICTIDFEATURESREV3.txt", 'LogisticRegression', 2, logging_dir)
ml.run()
