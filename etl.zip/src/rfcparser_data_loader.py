# INSIGHT RFC LEVEL OF LIMITATION / FUNCTIONAL AREA PARSER - DATA LOADER
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 09.01.2016
#
# SUMMARY: 
# Loads data required by the INSIGHT RFC Level of Limitation / Functional
# Area parsing module (rfcparser.py).
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

# Import modules:
import os.path
from nltk.corpus import stopwords
import logging

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Load data:
try:
	# Set INSIGHT directories:
	insightdir = os.path.dirname(os.path.realpath(__file__))
	datadir = os.path.join(insightdir, "Data")
	
	# Function to load/preprocess files and load lines into lists:
	def preprocess_and_eval_files(file_path, file_lines_list, *other_lists):
		file_lines = open(file_path, 'r').readlines()
		file_lines = [line.rstrip() for line in file_lines]
		file_lines = [eval(line) for line in file_lines if bool(line.startswith('#')) is False]
		for line in file_lines:
			file_lines_list.append(line)
			for list in other_lists:
				list.append(line)
		
	# Load data:
	allpos = []
	allposbutlolhrlollb = []
	alllol = []
	alltargetfa = []
	lol_ex = []
	allnn = []
	allsplitters = []
	
	lol_ex_hr_splitters = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_ex_hr_DEVCOPY_NEW_NEWDIVIDER_splitting.txt'), 
								lol_ex_hr_splitters, allsplitters)
	lol_ex_hr_splitters.sort(key=lambda x: len(x[1]), reverse=True)
	
	lol_ex_lb_splitters = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_ex_lb_DEVCOPY_NEW_NEWDIVIDER_splitting.txt'), 
								lol_ex_lb_splitters, allsplitters)
	lol_ex_lb_splitters.sort(key=lambda x: len(x[1]), reverse=True)

	lol_ex_hr = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_ex_hr_DEVCOPY_NEW_NEWDIVIDER.txt'), 
								lol_ex_hr, lol_ex, allpos, alllol)
	lol_ex_hr.sort(key=lambda x: len(x[1]), reverse=True)

	lol_ex_lb = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_ex_lb_DEVCOPY_NEW_NEWDIVIDER.txt'), 
								lol_ex_lb, lol_ex, allpos, alllol)
	lol_ex_lb.sort(key=lambda x: len(x[1]), reverse=True)

	lol_nonex = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_nonex_NEW_NEWDIVIDER.txt'), 
								lol_nonex, allpos, alllol, allposbutlolhrlollb)

	lol_envt = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_envt_NEW_NEWDIVIDER.txt'), 
								lol_envt, allpos, alllol, allposbutlolhrlollb)

	lol_xx = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_xx_NEW_DEV_09012016_NEWDIVIDER.txt'), 
								lol_xx, allpos, allposbutlolhrlollb)

	lol_nld = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_lol_nld_NEW_NEWDIVIDER.txt'), 
								lol_nld, allpos, alllol, allposbutlolhrlollb)

	nnfa = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_nnfa_xx_NEW_DEV_09012016_NEWDIVIDER.txt'), 
								nnfa, allpos, allposbutlolhrlollb, allnn)

	nnfa_nonex = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_nnfa_nonex_NEW_NEWDIVIDER.txt'), 
								nnfa_nonex, allpos, alltargetfa, allposbutlolhrlollb, allnn)

	nnfa_envt = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_nnfa_envt_NEW_NEWDIVIDER.txt'), 
								nnfa_envt, allpos, alltargetfa, allposbutlolhrlollb, allnn)
								
	nnfa_ex_hr = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_nnfa_ex_hr_NEW_NEWDIVIDER.txt'), 
								nnfa_ex_hr, allpos, alltargetfa, allposbutlolhrlollb, allnn)

	nnfa_ex_lb = []
	preprocess_and_eval_files(os.path.join(datadir, 'RFCLOLFA_nnfa_ex_lb_NEW_NEWDIVIDER.txt'), 
								nnfa_ex_lb, allpos, alltargetfa, allposbutlolhrlollb, allnn)

	lol_ex.sort(key=lambda x: len(x[1]), reverse=True)
	allpos.sort(key=lambda x: len(x[1]), reverse=True)
	allpos_customposrepl = [item for item in allpos if len(item) >= 3]
	alllol.sort(key=lambda x: len(x[1]), reverse=True)
	alltargetfa.sort(key=lambda x: len(x[1]), reverse=True)
	allposbutlolhrlollb.sort(key=lambda x: len(x[1]), reverse=True)
	allnn.sort(key=lambda x: len(x[1]), reverse=True)
	allsplitters.sort(key=lambda x: len(x[1]), reverse=True)
	xxmodpos = [listitem for listitem in lol_xx if listitem[0] == 'XX_MODPOS']
	
	# Perform misc. setup actions (define stopword sets; create POS tagger 
	# instance, etc.):
	stopwords_raw = stopwords.words('english')
	#stopword_file = open(os.path.join(datadir, 'rfcparser_sw_coll.txt'), 'r')
	#stopwords_raw = stopword_file.readlines()
	#stopwords_raw = [line.rsplit() for line in stopwords_raw if bool(line.startswith('#')) is False]
	stopword_coordinatingandmisc = [sw for sw in stopwords_raw if sw not in ['but', 'while', 'if', 'whereas', 'no', 'nor']]
except Exception:
	logger.exception('EXCEPTION')
	raise

# Testing:
if __name__ == '__main__':
	for item in allpos_customposrepl:
		if ' NO ' in str(item):
			print type(item)
			print item