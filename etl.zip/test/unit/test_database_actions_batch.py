
import unittest
import pandas
from pandas._libs.tslib import Timestamp
from mock import Mock, patch
import setup_config
import database_actions_batch as dab

nan = None

test_dict = {'ALLGD_DISB_ONST_DT': {12579: 'E', 12580: 'E'},
             'BIC': {12579: u'A ', 12580: u'A '},
             'CASE_GRP_CD': {12579: u'02', 12580: u'02'},
             'CLMT_DECD_SW': {12579: u'N', 12580: u'N'},
             'CLMT_DOB': {12579: Timestamp('1974-05-11 00:00:00'),
                          12580: Timestamp('1956-10-29 00:00:00')},
             'CLMT_NM25': {12579: u'SMITH, WENDALL F         ',
                           12580: u'WILLIAMSON, ROBERT J     '},
             'CLMT_SSN': {12579: u'097809302', 12580: u'004585502'},
             'CLMT_ST': {12579: u'MD', 12580: u'ME'},
             'CLM_TYP': {12579: u'DIWC', 12580: u'DIWC'},
             'CLM_UID': {12579: 2921, 12580: 2904},
             'CRITL_CASE_CTGY_SW': {12579: u'N', 12580: u'N'},
             'CRNT_RQSTD_DT': {12579: '02/18/2009', 12580: '02/18/2009'},
             'DIRE_NEED_SW': {12579: u'N', 12580: u'N'},
             'DLI': {12579: 'E', 12580: 'E'},
             'DOCU_CTL_ID': {12579: u'A1001001A09B17B02123B39047',
                             12580: u'A1001001A09B17B24722F99742'},
             'EDIB_CD': {12579: u'F', 12580: u'F'},
             'EFLDR_NUM': {12579: 53132051, 12580: 53084028},
             'FNL_DSPN_DT': {12579: Timestamp('2009-02-17 00:00:00'),
                             12580: Timestamp('2009-02-17 00:00:00')},
             'HEDULVL_CD': {12579: nan, 12580: nan},
             'HOFC_WRK_UNIT_UID': {12579: 3261, 12580: 3245},
             'HRG_ISU_CD': {12579: u'D', 12580: u'D'},
             'HRG_TYP': {12579: u'10', 12580: u'10'},
             'HT_INCH': {12579: 'U', 12580: 'U'},
             'OHA_DAA_CD': {12579: u'N', 12580: u'N'},
             'PTNTLY_HOMCDL_SW': {12579: u'N', 12580: u'N'},
             'REP_UID': {12579: None, 12580: None},
             'SEX': {12579: 'U', 12580: 'U'},
             'SUICIDL_SW': {12579: u'N', 12580: u'N'},
             'T16_APP_DT': {12579: 'E', 12580: 'E'},
             'T16_DSPN_CD': {12579: u'    ', 12580: u'    '},
             'T16_GLBL_BSS_UID_1': {12579: nan, 12580: nan},
             'T16_GLBL_BSS_UID_2': {12579: nan, 12580: nan},
             'T16_PFLG_DT': {12579: 'E', 12580: 'E'},
             'T16_PRTL_FFVRBL_CD': {12579: u' ', 12580: u' '},
             'T2_APP_DT': {12579: '01/07/2006', 12580: '03/27/2001'},
             'T2_DSPN_CD': {12579: u'UAFF', 12580: u'UAFF'},
             'T2_GLBL_BSS_UID_1': {12579: 77.0, 12580: 48.0},
             'T2_GLBL_BSS_UID_2': {12579: nan, 12580: nan},
             'T2_PFLG_DT': {12579: '01/07/2006', 12580: '03/27/2001'},
             'T2_PRTL_FFVRBL_CD': {12579: u' ', 12580: u' '},
             'TERI_SW': {12579: u'N', 12580: u'N'},
             'TRML_ILLNESS_SW': {12579: u'N', 12580: u'N'},
             'WG_ERNR_SSN': {12579: u'097809302', 12580: u'004585502'},
             'WKLD_TYP': {12579: u'RR ', 12580: u'RR '},
             'WT_LB': {12579: 'U', 12580: 'U'},
             'hofc_wrk_unit_AC': {12579: 3762, 12580: 3764},
             'noncovered_ver': {12579: 0, 12580: 0},
             'wg_ernr_ssn_AC': {12579: u'097809302', 12580: u'004585502'}}

testdf = pandas.DataFrame(test_dict)


class DatabaseActionTest(unittest.TestCase):
    def test_insert_failed_schema2(self):
        p = patch("database_actions_batch.get_sql_db_connect")
        self.addCleanup(p.stop)
        self.get_sql_db_connect_mock = p.start()
        self.db_mock = self.get_sql_db_connect_mock.return_value
        self.cursor_mock = self.db_mock.cursor.return_value
        expected_res = dab.insert_failed_schema2(testdf, "No DMA document downloaded.")
        self.assertEqual(dab.insert_failed_schema2(testdf, "No DMA document downloaded."), expected_res)


    def test_insert_failed_schema2_failure(self):
        p = patch("database_actions_batch.get_sql_db_connect")
        self.addCleanup(p.stop)
        self.get_sql_db_connect_mock = p.start()
        self.db_mock = self.get_sql_db_connect_mock.return_value
        self.cursor_mock = self.db_mock.cursor.return_value
        dab.insert_failed_schema2(testdf, "No DMA document downloaded.")
        self.assertNotEqual(dab.insert_failed_schema2(testdf, "No DMA document downloaded."), "R")




# Run:
if __name__ == '__main__':
    unittest.main(exit=False)
