# INSIGHT RFC TEXT PARSER - FUNCTION TERM PRESENCE / ABSENCE PARSER
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 09.07.2016
#
# SUMMARY: 
# Parses RFC finding heading text to determine whether references to 
# targeted functions are or are not present.  Note that as a general
# rule, the the presence/absence values generated herein should not
# be interpreted as reflecting *semantic presence* (e.g. the language
# ('the claimant cannot stand up to confrontation' would trigger a
# 'present' value for 'rfcstandpresent', even though 'stand' in this
# context does not refer to the physical function of standing).  While
# some REGEX patterns below do attempt to restrict 'presence' values to
# appropriate semantic contexts, these are minimal measures. 
# 
# INPUT: 
# An individual RFC string.
# 
# OUTPUT: 
# A dictonary where keys = INSIGHT RFC presence/absence data point names and
# values = values for those data point names.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

# Import modules:
import re
import os.path
import logging

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Define presence/absence parser function:
def rfc_presabs_parser(rfc_str):
	'''Parse RFC string to determine whether various function 
	terms are or are not present.
	
	Args:
		rfc_str {str}: A string containing the RFC
		text of an RFC finding, cleaned/normalized
		from its original form by by 'rfcparser' and
		originally extracted from hearing decision text
		via 'ie' ('rfctxt' in INSIGHT Extract
		Data Dictionary).
	Returns:
		Dictionary where INSIGHT RFC function term
		presence/absence data point names are
		keys and values are presence/absence values.
	Raises:
		N/A
	'''

	# Create RFC presence/absence dictionary and set default values:
	rfc_presabs_dict = {}
	rfc_presabs_dict['rfcsitpresent'] = 'U'
	rfc_presabs_dict['rfcstandpresent'] = 'U'
	rfc_presabs_dict['rfcwalkpresent'] = 'U'
	rfc_presabs_dict['rfcliftpresent'] = 'U'
	rfc_presabs_dict['rfccarrypresent'] = 'U'
	rfc_presabs_dict['rfcpushpullpresent'] = 'U'
	rfc_presabs_dict['rfcsitstandpresent'] = 'U'
	rfc_presabs_dict['rfcclimbpresent'] = 'U'
	rfc_presabs_dict['rfcclimbingobjectspresent'] = 'U'
	rfc_presabs_dict['rfcbalancepresent'] = 'U'
	rfc_presabs_dict['rfcstooppresent'] = 'U'
	rfc_presabs_dict['rfckneelpresent'] = 'U'
	rfc_presabs_dict['rfccrouchpresent'] = 'U'
	rfc_presabs_dict['rfccrawlpresent'] = 'U'
	rfc_presabs_dict['rfcreachpresent'] = 'U'
	rfc_presabs_dict['rfchandlepresent'] = 'U'
	rfc_presabs_dict['rfcfingerpresent'] = 'U'
	rfc_presabs_dict['rfcfeelpresent'] = 'U'
	rfc_presabs_dict['rfcallmanipulativespresent'] = 'U'
	rfc_presabs_dict['rfcnearacuitypresent'] = 'U'
	rfc_presabs_dict['rfcfaracuitypresent'] = 'U'
	rfc_presabs_dict['rfcdepthperceptionpresent'] = 'U'
	rfc_presabs_dict['rfcaccomodationpresent'] = 'U'
	rfc_presabs_dict['rfccolorvisionpresent'] = 'U'
	rfc_presabs_dict['rfcfieldofvisionpresent'] = 'U'
	rfc_presabs_dict['rfcfootcontrolspresent'] = 'U'
	rfc_presabs_dict['rfcexposuretoweatherpresent'] = 'U'
	rfc_presabs_dict['rfcnoisepresent'] = 'U'
	rfc_presabs_dict['rfcextremetempspresent'] = 'U'
	rfc_presabs_dict['rfcwetnesspresent'] = 'U'
	rfc_presabs_dict['rfchumiditypresent'] = 'U'
	rfc_presabs_dict['rfcvibrationpresent'] = 'U'
	rfc_presabs_dict['rfcatmosphericconditionspresent'] = 'U'
	rfc_presabs_dict['rfchazardspresent'] = 'U'
	rfc_presabs_dict['rfcmovingmechanicalpresent'] = 'U'
	rfc_presabs_dict['rfcexposedheightspresent'] = 'U'
	rfc_presabs_dict['rfctoxiccausticchemicalspresent'] = 'U'
	rfc_presabs_dict['rfctalkpresent'] = 'U'
	rfc_presabs_dict['rfchearpresent'] = 'U'
	rfc_presabs_dict['rfctastepresent'] = 'U'
	rfc_presabs_dict['rfcsmellpresent'] = 'U'
	rfc_presabs_dict['rfcmentalcpppresent'] = 'U'
	rfc_presabs_dict['rfcmentalsfintpubpresent'] = 'U'
	rfc_presabs_dict['rfcmentalsfintanypresent'] = 'U'
	
	try:
		
		# If 'rfc_str' value passed is not a string, set 'rfcparsingdict'
		# values to 'E' and return (Rationale: Ultimate interest is ensuring
		# INSIGHT processing continues.  No 'raise'-ing allowed.).
		# TODO: Log this!
		if bool(isinstance(rfc_str, str)) is False:
			rfc_presabs_dict = {k:'E' for k,v in rfc_presabs_dict.iteritems()}
			return rfc_presabs_dict
		
		# If 'rfc_str' value passed == INSIGHT Extract Data Dictionary value 
		# indicating no RFC text value was extracted (via either 'U' or 'P'
		# value depending on context of why no RFC text value was extracted), 
		# set 'rfc_presabs_dict' values to appropriate matching value and return:
		if rfc_str == 'U':
			return rfc_presabs_dict
		if rfc_str == 'P':
			rfc_presabs_dict = {k:'P' for k,v in rfc_presabs_dict.iteritems()}
			return rfc_presabs_dict

		# Begin presence/absence parsing of individual functions:
		# TIP: These REGEX patterns are curated.  They take into account SME 
		# knowledge of what should and should not be deemed to 'satisfy' each 
		# targeted function. They also take into account, to extent deemed 
		# prudent, all related 'definitional' articulations of each function as 
		# specified in policies such as POMS DI 25001.001.
		if bool(re.search(r"\bsit\b|\bsits\b|\bsitting\b|\bsat\b|\bseated\b", rfc_str)):
			rfc_presabs_dict['rfcsitpresent'] = '1'
		else:
			rfc_presabs_dict['rfcsitpresent'] = '0'

		if bool(re.search(r"\bstand\b|\bstands\b|\bstanding\b|\bstood\b|\bremain ?on ?(their|his|her) ?feet", rfc_str)):
			rfc_presabs_dict['rfcstandpresent'] = '1'
		else:
			rfc_presabs_dict['rfcstandpresent'] = '0'

		if bool(re.search(r"\bwalk\b|\bwalks\b|\bwalking\b|\bwalked\b|\bmov[a-z]+ ?about ?on ?(their|his|her)? ?(foot|feet)", rfc_str)):
			rfc_presabs_dict['rfcwalkpresent'] = '1'
		else:
			rfc_presabs_dict['rfcwalkpresent'] = '0'

		if bool(re.search(r"\blift\b|\blifts\b|\blifting\b|\blifted\b|\bpull(ing)? ?upward|\b(raising|raise) ?or ?(lowering|lower) ?(objects|an ?object|items|an ?item) ?from ?one ?level ?to ?another", rfc_str)):
			rfc_presabs_dict['rfcliftpresent'] = '1'
		else:
			rfc_presabs_dict['rfcliftpresent'] = '0'

		if bool(re.search(r"\bcarry(?! out)|\bcarries(?! out)|\bcarrying(?! out)|\bcarried\b|\btransport(ing)? ?(objects|an ?object|items|an ?item)", rfc_str)):
			rfc_presabs_dict['rfccarrypresent'] = '1'
		else:
			rfc_presabs_dict['rfccarrypresent'] = '0'

		if bool(re.search(r"\bpush\b|\bpull\b|\bpushes\b|\bpulls\b|\bpushing\b|\bpulling\b|\bpushed\b|\bpulled\b|\bexert(ing)? ?force ?(upon|on) ?an ?(object|item) ?so ?that ?(the ?object|the ?item|it) ?moves ?(toward|away ?from) ?the ?force", rfc_str)):
			rfc_presabs_dict['rfcpushpullpresent'] = '1'
		else:
			rfc_presabs_dict['rfcpushpullpresent'] = '0'

		if bool(re.search(r"switch ?(between|from) ?(standing.{0,10}sitting|sitting.{0,10}standing)|sit ?and.{0,2}or ?stand ?at ?will|(alternate ?|alternate ?between ?|alternatively ?)(from ?|)(stand.{0,10}(sitting|sit)|(sitting|sit).{0,10}stand)|sit( ?- ?| ?\/ ?| ?\\ ?)stand ?option|change ?positions[a-z ]{1,10}(stand.{0,10}(sitting|sit)|(sitting|sit).{0,10}stand)|option.{1,10}(\bsit|\bstand).{1,10}(\bsit|\bstand)|(sit\w*|stand\w*) (for|) ?\w+ minutes ([a-z]+ ){1,3}(sit\w*|stand\w*) (for|) ?\w+ minutes", rfc_str)):
			rfc_presabs_dict['rfcsitstandpresent'] = '1'
		else:
			rfc_presabs_dict['rfcsitstandpresent'] = '0'
			
		if bool(re.search(r"\bclimb\b|\bclimbs\b|\bclimbing\b|\bclimbed\b|\bascend(ing)? ?(and|or) ?descend(ing)? ?(ramp|stair|ladder|rope|scaffold|pole)", rfc_str)):
			rfc_presabs_dict['rfcclimbpresent'] = '1'
		else:
			rfc_presabs_dict['rfcclimbpresent'] = '0'
			
		if bool(re.search(r"\b(ramp|stair|ladder|rope|scaffold|pole)", rfc_str)):
			rfc_presabs_dict['rfcclimbingobjectspresent'] = '1'
		else:
			rfc_presabs_dict['rfcclimbingobjectspresent'] = '0'

		if bool(re.search(r"\bbalance\b|\bbalances\b|\bbalancing\b|\bbalanced\b|body ?equilibrium|maintain ?equilibrium", rfc_str)):
			rfc_presabs_dict['rfcbalancepresent'] = '1'
		else:
			rfc_presabs_dict['rfcbalancepresent'] = '0'

		if bool(re.search(r"\bstoop\b|\bstoops\b|\bstooping\b|\bstooped\b|\bbend(ing)? ?(downward|down) ?(and|or) ?forward ?by ?bending ?the ?spine ?at ?the ?waist", rfc_str)):
			rfc_presabs_dict['rfcstooppresent'] = '1'
		else:
			rfc_presabs_dict['rfcstooppresent'] = '0'

		if bool(re.search(r"\bkneel\b|\bkneels\b|\bkneeling\b|\bkneeled\b|\brest(ing)? ?on ?(their|his|her|the) ?knees?", rfc_str)):
			rfc_presabs_dict['rfckneelpresent'] = '1'
		else:
			rfc_presabs_dict['rfckneelpresent'] = '0'

		if bool(re.search(r"\bcrouch\b|\bcrouchs\b|\bcrouching\b|\bcrouched\b", rfc_str)):
			rfc_presabs_dict['rfccrouchpresent'] = '1'
		else:
			rfc_presabs_dict['rfccrouchpresent'] = '0'

		if bool(re.search(r"\bcrawl\b|\bcrawls\b|\bcrawling\b|\bcrawled\b|\bmoving ?(about)? ?on ?(his|her|the)? ?hands ?and ?(knees|feet)", rfc_str)):
			rfc_presabs_dict['rfccrawlpresent'] = '1'
		else:
			rfc_presabs_dict['rfccrawlpresent'] = '0'

		if bool(re.search(r"\breach\b|\breaches\b|\breaching\b|\breached\b|(\bextend|\bextending) ?(of)? ?(his|her|the) ?hands ?and ?arms", rfc_str)):
			rfc_presabs_dict['rfcreachpresent'] = '1'
		else:
			rfc_presabs_dict['rfcreachpresent'] = '0'
			
		if bool(re.search("\\b(handling|handle)\\b(?! ?[-'a-z0-9]+ ?(low ?- ?stress|work|job|environment|situation|production|stress|non ?- ?production|low ?stress|[-'a-z0-9]*stress[-'a-z0-9]*|[-'a-z0-9]*production[-'a-z0-9]*|interact))(?! ?(low ?- ?stress|work|job|environment|situation|production|interact|stress|non ?- ?production|low ?stress|[-'a-z0-9]*stress[-'a-z0-9]*|[-'a-z0-9]*production[-'a-z0-9]*))", rfc_str)):
			rfc_presabs_dict['rfchandlepresent'] = '1'
		else:
			rfc_presabs_dict['rfchandlepresent'] = '0'		 

		if bool(re.search(r"\bfinger\b|\bfingers\b|\bfingering\b|\bfingered\b|\bfine ?(manipulative|manipulation)", rfc_str)):
			rfc_presabs_dict['rfcfingerpresent'] = '1'
		else:
			rfc_presabs_dict['rfcfingerpresent'] = '0'

		if bool(re.search(r"\bfeel\b|\bfeeling\b|\b(perceiving|perceive) ?attributes ?of ?objects ?and ?materials ?such ?as ?size, ?shape, ?temperature, ?or ?texture, ?by ?means ?of ?receptors ?in ?the ?skin, ?particularly ?those ?of ?the ?fingertips", rfc_str)):
			rfc_presabs_dict['rfcfeelpresent'] = '1'
		else:
			rfc_presabs_dict['rfcfeelpresent'] = '0'

		if any(rfc_presabs_dict[item] == '1' for item in ['rfchandlepresent', 'rfcfingerpresent', 'rfcfeelpresent']):
			rfc_presabs_dict['rfcallmanipulativespresent'] = '1'
		elif bool(re.search(r"\bmanipulate|\bmanipulating|\bmanipulation|\bmanipulative|\bhands\w*|\bgrasp\w*|\bfinger\b|\bfingers\b|\bfingering\b|\bfingered\b|\bfine ?manipulat\w*|\bhandle\b|\bhandles\b|\bhandling\b|\bhandled\b|\bfeel\b|\bfeeling\b|\bgrip\b|\bgripping\b|\bmanual ?dexterity\b", rfc_str)):
			rfc_presabs_dict['rfcallmanipulativespresent'] = '1'
		else:
			rfc_presabs_dict['rfcallmanipulativespresent'] = '0'
			
		if bool(re.search(r"\btalk\b|\btalks\b|\btalking\b|\btalked\b", rfc_str)):
			rfc_presabs_dict['rfctalkpresent'] = '1'
		else:
			rfc_presabs_dict['rfctalkpresent'] = '0'

		if bool(re.search(r"\bhear\b|\bhears\b|\bhearing\b|\bheard\b", rfc_str)):
			rfc_presabs_dict['rfchearpresent'] = '1'
		else:
			rfc_presabs_dict['rfchearpresent'] = '0'

		if bool(re.search(r"\btaste\b|\btastes\b|\btasting\b|\btasted\b", rfc_str)):
			rfc_presabs_dict['rfctastepresent'] = '1'
		else:
			rfc_presabs_dict['rfctastepresent'] = '0'

		if bool(re.search(r"\bsmell\b|\bsmells\b|\bsmelling\b|\bsmelled\b", rfc_str)):
			rfc_presabs_dict['rfcsmellpresent'] = '1'
		else:
			rfc_presabs_dict['rfcsmellpresent'] = '0'

		if bool(re.search(r"\bnear ?acuity\b|\bclarity ?of ?vision ?at ?20 ?inches ?or ?less", rfc_str)):
			rfc_presabs_dict['rfcnearacuitypresent'] = '1'
		else:
			rfc_presabs_dict['rfcnearacuitypresent'] = '0'
		
		if bool(re.search(r"\bfar ?acuity\b|\bclarity ?of ?vision ?at ?20 ?feet ?or ?more", rfc_str)):
			rfc_presabs_dict['rfcfaracuitypresent'] = '1'
		else:
			rfc_presabs_dict['rfcfaracuitypresent'] = '0'

		if bool(re.search(r"depth ?perception|\b(ability|able) ?to ?judge ?distances ?and ?spatial ?relationships ?to ?see ?objects ?where ?and ?as ?they ?actually ?are ?in ?three ?dimensional ?vision", rfc_str)):
			rfc_presabs_dict['rfcdepthperceptionpresent'] = '1'
		else:
			rfc_presabs_dict['rfcdepthperceptionpresent'] = '0'

		if bool(re.search(r"\baccommodation ?\w+ ?vision|(visual|vision) ?accommodation|\badjustment ?of ?the ?lens ?of ?(his|her|the) ?eye ?to ?bring ?(an ?object|objects) ?into ?(sharp)? ?focus", rfc_str)):
			rfc_presabs_dict['rfcaccomodationpresent'] = '1'
		else:
			rfc_presabs_dict['rfcaccomodationpresent'] = '0'
			
		if bool(re.search(r"(color\s{\s0,}vision)|(color\b(\S+\b){0,2}(visual|vision|see|discern))|((visual|vision|see|discern)\b(\S+\b){0,2}color)|\bability ?to ?identify ?and ?distinguish ?color", rfc_str)):
			rfc_presabs_dict['rfccolorvisionpresent'] = '1'
		else:
			rfc_presabs_dict['rfccolorvisionpresent'] = '0'

		if bool(re.search(r"\bfield\w* ?of ?vision|visual ?field|\b(observing|observe) ?an ?area ?that ?can ?be ?seen ?up ?and ?down ?or ?to ?the ?right ?or ?left ?while ?eyes ?are ?fixed ?on ?a ?given ?point", rfc_str)):
			rfc_presabs_dict['rfcfieldofvisionpresent'] = '1'
		else:
			rfc_presabs_dict['rfcfieldofvisionpresent'] = '0'

		if bool(re.search(r"(feet|foot) ?(control|pedal)|(control\w*|pedal\w*) ?(with|using|via|by) ?(his|her|the|) ?(feet|foot)", rfc_str)):
			rfc_presabs_dict['rfcfootcontrolspresent'] = '1'
		else:
			rfc_presabs_dict['rfcfootcontrolspresent'] = '0'

		if bool(re.search(r"\bweather(?!ing)|\boutside ?atmospheric ?conditions", rfc_str)):
			rfc_presabs_dict['rfcexposuretoweatherpresent'] = '1'
		else:
			rfc_presabs_dict['rfcexposuretoweatherpresent'] = '0'
			
		if bool(re.search(r"extreme ?(heat|cold|temperature)|extremes ?of ?(heat|cold|temperature)|extremely ?(hot|cold)|temperature|\bhot\b|\bheat\b|\bcold\b", rfc_str)):
			rfc_presabs_dict['rfcextremetempspresent'] = '1'
		else:
			rfc_presabs_dict['rfcextremetempspresent'] = '0'

		if bool(re.search(r"\bwet\w*|\bdamp(?!en)\w*|\bcontact ?with ?water ?( ?or ?other ?liquids)?", rfc_str)):
			rfc_presabs_dict['rfcwetnesspresent'] = '1'
		else:
			rfc_presabs_dict['rfcwetnesspresent'] = '0'
		
		if bool(re.search(r"\bhumid\w*", rfc_str)):
			rfc_presabs_dict['rfchumiditypresent'] = '1'
		else:
			rfc_presabs_dict['rfchumiditypresent'] = '0'

		if bool(re.search(r"\bvibrat\w*|\bexposure ?to ?(a)? ?shaking ?(object|surface)", rfc_str)):
			rfc_presabs_dict['rfcvibrationpresent'] = '1'
		else:
			rfc_presabs_dict['rfcvibrationpresent'] = '0'

		if bool(re.search(r"\bdust|\bodor|\bfume|\bgas(?!tro)\w*|\bventilation|\batmospher\w*|(respiratory|pulmonary) ?(condition|irritant|hazard|expos)|\bair ?quality", rfc_str)):
			rfc_presabs_dict['rfcatmosphericconditionspresent'] = '1'
		else:
			rfc_presabs_dict['rfcatmosphericconditionspresent'] = '0'
			
		if bool(re.search(r"\bmachinery\b|\bmachines\b|\bmachine\b|\bmechanical", rfc_str)):
			rfc_presabs_dict['rfcmovingmechanicalpresent'] = '1'
		else:
			rfc_presabs_dict['rfcmovingmechanicalpresent'] = '0'

		if bool(re.search(r"\bexposed ?heights|unprotected ?height|\bheights", rfc_str)):
			rfc_presabs_dict['rfcexposedheightspresent'] = '1'
		else:
			rfc_presabs_dict['rfcexposedheightspresent'] = '0'

		if bool(re.search(r"\b(workplace|work ?place) ?hazards|\bhazardous|\bhazards|\bhazard(?![a-z])", rfc_str)):
			rfc_presabs_dict['rfchazardspresent'] = '1'
		else:
			rfc_presabs_dict['rfchazardspresent'] = '0'

		if bool(re.search(r"(\btoxic|\bcaustic) ?chemical|\bchemical", rfc_str)):
			rfc_presabs_dict['rfctoxiccausticchemicalspresent'] = '1'
		else:
			rfc_presabs_dict['rfctoxiccausticchemicalspresent'] = '0'

		if bool(re.search(r"\bnoise|\bnoisy|\bloud|\bquiet|\bvolume|\bsoundless\b|\bsound\b|\bhushed\b|\bsilent\b|\bdeafening\b", rfc_str)):
			rfc_presabs_dict['rfcnoisepresent'] = '1'
		else:
			rfc_presabs_dict['rfcnoisepresent'] = '0'

		if bool(re.search(r"tasks ?which ?(can|could) ?be ?learned ?in|(that|which) ?(is|are) ?(simple|routine|unskilled|not ?skilled)|\btask(-| )completion|routine[and\,\s]+repetitive[\, ]+tasks|routine ?tasks|short ?cycle|repetetive,? [a-z]+,? ?[a-z]+,? ?(work|task|job|duties)| unskilled ?(work|tasks)|simple ?tasks|simple[\, ]+routine[\, ]+(tasks|work)|(unskilled|simple|routine) ?(instruction|work|task|assignment|job|function|dut\w*)|(specific(-| ?)vocational(-| ?)preparation|svp)|unskilled|(\blow|\blower|\bless|\breduced)(-| )stress|non-production|(\bno|\bnot|\babsent|\bwithout|not ?complete|not ?engage ?in) ?production|free ?of ?production|change\w* ?in ?(workplace|work ?place|work ?setting)|decisionmaking|decision making|detailed|complex|semi-skilled|semiskilled|skilled", rfc_str)):
			rfc_presabs_dict['rfcmentalcpppresent'] = '1'
		elif bool(re.search(r"simple ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?routine ?(,|and|) ?(repetitive|) ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?repetitive ?(,|and|) ?(unskilled|) ?(,|and|) ?(work|tasks|duties|instruction|job)|(simple|) ?(,|and|) ?(routine|) ?(,|and|) ?(repetitive|) ?(,|and|) ?unskilled ?(,|and|) ?(work|tasks|duties|instruction|job)", rfc_str)):
			rfc_presabs_dict['rfcmentalcpppresent'] = '1'
		elif bool(re.search(r"\bconcentration\b|production.?(rate|pace|quota)|\b(slow|fast|moderate).?paced?|\bconcentrate\b|persistence|\bto ?(reason\b|persist\b|comprehend\b|understand\b)|\bintellectual|\bintelligen|\biq\b|\bsimplistic\b|decision ?making|adapt ?to ?change|instructions|grade reading level|\breading\b|\battention\b", rfc_str)):
			rfc_presabs_dict['rfcmentalcpppresent'] = '1'
		elif bool(re.search(r"\bsimple,? ?routine\b|(1|one|two|three|\d)( ?to ?| ?- ?| ?- ?to ?- ?)(\d|two|three|four|five|six)( ?|- ?)(steps?)|\bhigh.?quota|fast.?pace|\blearn\b|\bentry.?level|set.?schedule|\bsame.?routine|\boff(-| |)task|\broutine ?setting", rfc_str)):
			rfc_presabs_dict['rfcmentalcpppresent'] = '1'
		else:
			rfc_presabs_dict['rfcmentalcpppresent'] = '0'

		if bool(re.search(r"\bgeneral ?public|public(!? speaking)|non-public|\bthe ?public\b", rfc_str)):
			rfc_presabs_dict['rfcmentalsfintpubpresent'] = '1'
		else:
			rfc_presabs_dict['rfcmentalsfintpubpresent'] = '0'

		if bool(re.search(r"\brespond ?appropriately|appropriatel?y? ?respon|\bsocial|interaction|interact ?with|public|co-workers|coworkers|associates|peers|colleagues|supervisor|superiors|non-confrontation|(objects|things) ?rather ?than ?people|object-focused|objects ?rather|social ?functioning|proximity( ?to ?| ?with ?)others|others|other ?people", rfc_str)):
			rfc_presabs_dict['rfcmentalsfintanypresent'] = '1'
		else:
			rfc_presabs_dict['rfcmentalsfintanypresent'] = '0'

		return rfc_presabs_dict
		
	except Exception:
		logger.exception('EXCEPTION')
		rfc_presabs_dict = {k:'E' for k,v in rfc_presabs_dict.iteritems()}
		return rfc_presabs_dict


# Testing:
if __name__ == '__main__':

	simpletest = "He can never stoop, crouch, or crawl in excess of occasionally.  He can occasionally objects."
	unittest1 = u"djflkajsdklfjasdlkfjsdkljaflljds"
	unittest2 = 100
	
	manualtest = 1

	if manualtest == 1:
		
		test_rfc = simpletest
		result = rfc_presabs_parser(test_rfc)
		print "RESULTS (all non-'U'/'P'/'E'/zero values):"
		try:
			print "ORIGINAL RFC TEXT PASSED: " + test_rfc
		except TypeError:
			pass
		for k, v in sorted(result.items(), key=lambda x:x[0]):
			if v not in ['U', 'P', 'E', '0']:
				print str(v) + "  (" + str(k) + ")"

