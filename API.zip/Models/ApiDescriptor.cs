﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace INSIGHT_Request.Models
{
    public class ApiDescriptor
    {
        public List<ApiActionDescriptor> Apis { get; set; } = new List<ApiActionDescriptor>();
    }
    public class ApiActionDescriptor
    {
        public string Description { get; set; } = "";
        public string Uri { get; set; } = "";
        public string Method { get; set; } = "";
        public List<ApiParameterDescriptor> Parameters { get; set; } = new List<ApiParameterDescriptor>();


    }
    public class ApiParameterDescriptor
    {
        public string Name { get; set; } = "";
        
        public string Source { get; set; } = "";
        public string Description { get; set; } = "";
        public string ClassFullName { get; set; } = "";
        public List<PropertyInfo> ClassProperties { get; set; }
        //public List<dynamic> ClassProperties
        //{
        //    get
        //    {
        //        ApiClassProperty pi = new ApiClassProperty(_ClassProperties);
        //        return new List<ApiClassProperty(_ClassProperties)>();
        //    }

        //    set
        //    {
        //        _ClassProperties = value;
        //    }
        //}

    }
    public class ApiClassProperty
    {
        public ApiClassProperty(PropertyInfo pi)
        {
            this.Name = pi.Name;
            this.Type = pi.PropertyType.Name;
        }
        public string Name { get; set; } = "";
        public string Type { get; set; } = "";

    }
}