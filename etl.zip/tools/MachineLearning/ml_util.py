from __future__ import print_function
import io
import os
import logging
import numpy as np
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn import metrics

def get_diff_list(l1, l2):
    idx = []
    for i, value in enumerate(l1):
        if value != l2[i]:
            idx.append(i)

    return idx

class ML_util(object):
    def __init__(self, training_data, clf_name, ngram_range_end, logging_file = None):
        # training_data is located in \src\data folder; clf_type is the classifier used in ie_data_loader.py; ngram_range_end is for specifying up to the number you specify to do the feature extraction
        self.logging_file = logging_file
        self.diff_list = []
        self.vectorizer = None
        self.clf_name = clf_name
        self.dataset_path = training_data
        self.ngram_end = ngram_range_end
        self.x_train = None
        self.x_test = None
        self.y_train = None
        self.y_test = None
        self.y_pred = None
        self.clf = None
        self.x_training_set = None
        self.y_training_set = None
        self.x_train_raw = None
        self.x_test_raw = None

        this_dir = os.path.dirname(os.path.realpath(__file__))
        parent_dir = os.path.abspath(os.path.join(this_dir, os.pardir))
        self.data_dir = os.path.abspath(os.path.join(parent_dir, "../src/data"))

    def logging_info(self):
        logging.getLogger(__file__)
        if self.logging_file is None:
            self.logging_file = self.dataset_path.split('.') + '.log'
        logging.basicConfig(filename=self.logging_file, format='%(asctime)s || %(name)s || %(levelname)s || %(message)s', level=logging.DEBUG)

    def predict_testset(self):
        self.y_pred = self.clf.predict(self.x_test)

    def log_diff_list(self):
        self.diff_list = get_diff_list(self.y_test, self.y_pred)
        logging.info("\n")
        logging.info(self.diff_list)
        logging.info(len(self.diff_list) * 1.0 / len(self.y_test))
        logging.info("\n")

        if self.diff_list:
            for i in self.diff_list:
                logging.info('Record #' + str(i) + " has been predited wrong: " + self.x_test_raw[i])
                logging.info('It got predicted: ' + str(self.y_pred[i]) + ' instead marked:' + str(self.y_test[i]))
                logging.info("\n")

    def show_confusion_matrix(self, target_names=[]):
        print("Classification metrics")
        if target_names:
            print(metrics.classification_report(self.y_test, self.y_pred, target_names=target_names))
        else:
            print(metrics.classification_report(self.y_test, self.y_pred))

        print('=' * 80)
        print("Confusion metrics")
        print(metrics.confusion_matrix(self.y_test, self.y_pred))

    def predict(self, new_data):
        self.y_pred = self.clf.predict(self.vectorizer.transform(np.array(new_data)))
        return self.y_pred

    def train(self):
        if self.clf_name == 'LogisticRegression':
            classifier = LogisticRegression()
        elif self.clf_name == 'OneVsRestClassifier':
            classifier = OneVsRestClassifier(LogisticRegression())

        self.clf = classifier.fit(self.x_train, self.y_train)

    def print_testing_accuracy(self):
        print('Testing set accuracy: {:.3f}'.format(self.clf.score(self.x_test, self.y_test)))
        print('=' * 80)

    def generate_training_sets(self):
        data_path = os.path.join(self.data_dir, self.dataset_path)
        verdict_features = []
        verdict_labels = []
        with io.open(data_path, "rt", encoding="utf8", errors="ignore") as ml_data:
            for line in ml_data:
                try:
                    label = int(line[0])
                    verdict_labels.append(label)
                    feature = line[2:].strip()
                    verdict_features.append(unicode(feature))
                except Exception:
                    pass

        self.x_training_set = np.array(verdict_features)
        self.y_training_set = np.array(verdict_labels)
        # print x_training_set.dtype
        # print x_training_set.shape, y_training_set.shape
        self.x_train_raw, self.x_test_raw, self.y_train, self.y_test = train_test_split(self.x_training_set, self.y_training_set)
        # print x_train.shape, x_test.shape, y_train.shape, y_test.shape
        # print x_train[0]
        # exit()
        self.vectorizer = TfidfVectorizer(analyzer='word', sublinear_tf=True, lowercase=False, ngram_range=(1, self.ngram_end))
        self.x_train = self.vectorizer.fit_transform(self.x_train_raw)
        self.x_test = self.vectorizer.transform(self.x_test_raw)

    def run(self):
        self.logging_info()

        # this will extract features from the provided text using TF_IDF vectorizer
        self.generate_training_sets()

        # instantiate and train the classifier
        self.train()

        # print out the accuracy score when the classifier works on testing dataset
        self.print_testing_accuracy()

        # logging the difference of prediction vs testing marked
        self.predict_testset()
        self.log_diff_list()

        # print out the confusion metrics
        self.show_confusion_matrix()
