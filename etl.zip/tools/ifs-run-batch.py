'''
    NOTE:
    1. The test decision text is located in https://confluence.ba.ssa.gov/display/INS/Test+Decisions. Download and save the file in c:\WS\input\decisionfiles folder(if you don't have this folder then you need to create it) as A1001000000000000000000000.txt (file name is the same as the value of the DOCU_CTL_ID key of the following dictionary)
    2. use PyCharm as I showed in the Dev-Talk to set your interested break point in modules such as ifs.py, ie.py, iq.py and right click on this file to debug and the execuation will stop at the first break point that you just set
'''

import os.path
import sys

# Set directories:
this_dir = os.path.dirname(os.path.realpath(__file__))
# parent directory
parent_dir = os.path.abspath(os.path.join(this_dir, os.pardir))

# Import IFS module:
sys.path.insert(0, parent_dir)

from src import ifs
input_dict = {'DOCU_CTL_ID':'A1001000000000000000000000', 'CLMT_DOB':'12/01/1965', 'FNL_DSPN_DT':'06/29/2017', 'DLI':'09/30/2018', 'CLMT_SSN':'555555555', 'CLMT_ST':'MA', 'CLAIMDISP_STRUCT':[], 'EXP':[], 'HT_INCH':'60', 'WT_LB':'150', 'SEX':'M'}

tgt_uid_colnm = 'DOCU_CTL_ID'

def test_ifs_run():
    ifs.runsuite_batch(input_dict, tgt_uid_colnm)

if __name__ == "__main__":
    test_ifs_run()
