# INSIGHT FULL SUITE - BOTTLE SERVER - OAO VERSION
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 06.07.2017
#
# SUMMARY:
# This server faciliates INSIGHT's OAO-level functionality via the
# INSIGHT Web App.
#
# This script is designed to be executed directly and will load all
# datasets and modules necessary to operate the INSIGHT OAO Web App server.
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has not
# yet been formally validated and whose documentation is not yet fully formed.

# NOTE: Bottle 0.12.13 has a known issue testing on 'localhost' using IE, and
# workaround is to use 'cherrypy' or another server in the 'run' call. However, this
# raises an Exception in  Bottle of "ImportError: cannot import name wsgiserver".  This also
# is a known issue.  The solution, however, is to modify bottle.py as follows (based on this
# guidance at https://github.com/cmoberg/bottle-yang-extractor-validator/issues/4):
# Update CherryPyServer class in bottle.py to:
# class CherryPyServer(ServerAdapter):
#     def run(self, handler):
#         try:
#             from cheroot.wsgi import Server as wsgiserver
#         except ImportError:
#             from cherrypy.wsgiserver import CherryPyWSGIServer as wsgiserver
#         self.options['bind_addr'] = (self.host, self.port)
#         self.options['wsgi_app'] = handler
#
#         certfile = self.options.get('certfile')
#         if certfile:
#             del self.options['certfile']
#         keyfile = self.options.get('keyfile')
#         if keyfile:
#             del self.options['keyfile']
#
#         #server = wsgiserver.CherryPyWSGIServer(**self.options)
#         server = wsgiserver(**self.options)
#         if certfile:
#             server.ssl_certificate = certfile
#         if keyfile:
#             server.ssl_private_key = keyfile
#
#         try:
#             server.start()
#         finally:
#             server.stop()
# ==============================================================================

from __future__ import print_function

import ast
import logging
import os.path
import sys
import re
import json

import psycopg2
import jinja2
import requests
from bottle import run, route, static_file, request, error, response, default_app

import bmi_revised as bmi
import config as cfg
import database_actions as ifsda
import database_actions_misc as ifsdam
import date_helper as dh

from iqrgenerator import iqrgenerator as iqrepgen
import iqrgenerator.iqrgenerator_common_calcs as ifsiqrcc
import widget_templategen as templategen
from healthCheck.health_check_helper import HcHelper

# Set INSIGHT directories:
insight_dir = os.path.dirname(os.path.realpath(__file__))
static_dir = os.path.join(insight_dir, "static")
temp_dir = os.path.join(insight_dir, "temp")
views_dir = os.path.join(insight_dir, "views")
css_dir = os.path.join(static_dir, 'css')
js_dir = os.path.join(static_dir, 'js')
scripts_dir = os.path.join(static_dir, 'Scripts')
images_dir = os.path.join(static_dir, 'images')
fonts_dir = os.path.join(static_dir, 'fonts')
docs_dir = os.path.join(static_dir, 'docs')

# Set up parent lgoger:
# TIP: logger.exception() is associated with the ERROR level.
# TIP: If root logger level were not modified, default would be WARNING.
logger = logging.getLogger('ifs')
logger.setLevel(logging.DEBUG)
log_fh = logging.FileHandler('oao_webapp_log.log')
log_fh.setLevel(logging.DEBUG)
log_ch = logging.StreamHandler()
log_ch.setLevel(logging.WARNING)
#log_formatter = logging.Formatter('%(asctime)s || %(name)s || %(levelname)s || %(message)s')
log_formatter = logging.Formatter('%(module)s|%(funcName)s|%(asctime)s|%(name)s|%(levelname)s|%(lineno)s:%(message)s')
log_fh.setFormatter(log_formatter)
log_ch.setFormatter(log_formatter)
logger.addHandler(log_fh)
logger.addHandler(log_ch)

# Load error template:
# TIP: Contains '<!-- OPTIONAL -->' comment, which can
# be replaced with customizable 'err_msg_html':
err_msg_html = """<h2 class="heading">MESSAGE</h2><br>"""
with open(os.path.join(views_dir, "error.html"), 'r') as ifs_error_file:
    ifs_error_html = ifs_error_file.read()

with open(os.path.join(views_dir, "tools.html"), 'r') as tools_file:
    tools_html = tools_file.read()

# Create function to print to standard err (for debugging)
def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


# Define usage logging function:
def log_usage(reqid, nm, input_dict, response):
    try:
        # Check arguments:
        if not reqid.isdigit():
            reqid = None
        if not isinstance(nm, str):
            nm = 'E'
        if not isinstance(input_dict, dict):
            input_dict = {}
        if not isinstance(response, str):
            response = 'E'
        # Log:
        args = (reqid, nm, str(input_dict), response)
        conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
        with psycopg2.connect(conn_str) as conn:
            with conn.cursor() as cur:
                sql = 'INSERT INTO appeals.usagelog (reqid, nm, inputs, response) VALUES (%s, %s, %s, %s)'
                cur.execute(sql, args)

    except Exception as e:
        logger.exception('EXCEPTION')
        logger.exception(args)
        logger.exception(str(e))

# Define feedback logging function:
def insert_feedback(rid, vname, vvalue, insert_src):
    args = (1, rid, vname, vvalue, insert_src)
    try:
        conn_str = "host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
        with psycopg2.connect(conn_str) as conn:
            with conn.cursor() as cur:
                sql = 'INSERT INTO appeals.feedback (fid, rid, vname, vvalue, insert_src) values (%s, %s, %s, %s, %s)'
                cur.execute(sql, args)
        return '1'
    except Exception:
        logger.exception('EXCEPTION')
        logger.exception(args)
        return 'E'

# Define usage logging function:
def insert_access(userpin_input, url_input):
    """
    Insert access information into INSIGHT DB.

    Args:
        userpin_input {str}: The user PIN of
            the accesser.
        url_input {str}: The full URL of the
            INSIGHT page accessed by the user.
    Returns:
        N/A.
    Raises:
        N/A (exceptions will be logged).
    """
    try:
        # Check arguments:
        if not userpin_input or not isinstance(userpin_input, str):
            userpin_input = 'E'
        if not url_input or not isinstance(url_input, str):
            url_input = 'E'
        # Log access:

        conn_str = 'host=%s port=%s dbname=%s user=%s password=%s' % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password)
        with psycopg2.connect(conn_str) as conn:
            with conn.cursor() as cur:
                sql = "INSERT into appeals.access_log_ajax (LOGGED_IN_USER, HTML_file_path) values (%s, %s)"
                cur.execute(sql, (userpin_input, url_input))
    except Exception:
        logger.exception('EXCEPTION')

# Define Bottle routing actions:


# Serve fonts:
@route('/static/<filename:re:.*\.ttf>')
@route('/static/fonts/<filename:re:.*\.ttf>')
def server_static_fonts(filename):
    return static_file(filename, root=fonts_dir, mimetype='application/octet-stream')


@route('/static/docs/<filename:re:.*\.(pdf)>')
@route('/docs/<filename:re:.*\.(pdf)>')
def server_static_docs(filename):
    return static_file(filename, root=docs_dir)


# Generate a custom error message for 404 errors:
@error(404)
def error404(error):
    return static_file("404.html", root=views_dir)


# Serve favicon:
@route('/favicon.ico')
@route('/static/favicon.ico')
@route('/static/images/favicon.ico')
def favicon():
    return static_file('favicon.ico', root=images_dir)


# Serve about page:
@route('/about')
@route('/about.html')
@route('/oaoapp/about')
@route('/oaoapp/about.html')
def server_static_about():
    return static_file("about.html", root=views_dir)


# Serve help page:
@route('/help')
@route('/help.html')
@route('/oaoapp/help')
@route('/oaoapp/help.html')
def server_static_help():
    return static_file("help.html", root=views_dir)

# Access logging:
@route('/_logaccess', method='POST')
def log_access():
    try:
        # Retrieve user ID:
        user = request.headers.get("X-Remote-User")
        # Retrieve page URL:
        page_url = request.forms.get('fullpath', type=str)
        # Log these values:
        insert_access(user, page_url)
    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        eprint('log_access() exception!')
        eprint(x)


# OAO Analysis Template Generator Widget:
@route('/oaoapp/generatetemplate/<requestid:re:[0-9]+>')
def generatetemplate(requestid):
    try:
        document_fn_res = "U"
        if requestid.isdigit():
            document_fn_res = "U"
            document_fn_res = templategen.template_generator(requestid)
            if document_fn_res != "U":
                log_usage(requestid, 'templategen', {}, '1')
                return static_file(document_fn_res, root=temp_dir, download=True)
            else:
                log_usage(requestid, 'templategen', {}, 'E')
                msg = "Specifically, INSIGHT experienced an error while attempting to generate the analysis template."
                exception_err_msg_html = err_msg_html.replace('MESSAGE', msg)
                exception_ifs_error_html = ifs_error_html.replace('<!-- OPTIONAL -->', exception_err_msg_html)
                return exception_ifs_error_html
        else:
            log_usage(None, 'templategen', {}, 'E (validation - requestid)')
            repgen_error_str = 'Error - invalid request ID value (request ID: %s)' % requestid
            repgen_error_msg_html = err_msg_html.replace('MESSAGE', repgen_error_str)
            generatetemplate_error_html = ifs_error_html.replace('<!-- OPTIONAL -->', repgen_error_msg_html)
            return ifs_error_html
    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        msg = "Server-side error (%s)" % str(x)
        exception_err_msg_html = err_msg_html.replace('MESSAGE', msg)
        exception_ifs_error_html = ifs_error_html.replace('<!-- OPTIONAL -->', exception_err_msg_html)
        return exception_ifs_error_html


# OAO SSO Code Lookup Widget:
@route('/_ssolookup', method='POST')
def ssolookup():
    try:
        # TESTING - retrieve user ID:
        user = request.headers.get("X-Remote-User")

        # Retrieve inputs:
        inputs_dict = dict([(name, value) for name, value in request.POST.iteritems() if name != 'reqid'])
        reqid = request.forms.get('reqid', type=str)
        inputzip = request.forms.get('inputzip', type=str)
        # Check input:
        inputzip = inputzip.strip()
        if not isinstance(inputzip, str) or not inputzip.isdigit() or len(inputzip) != 5:
            log_usage(reqid, 'ssolookup', inputs_dict, 'E (validation - inputzip)')
            return '<span class="sso" style="color:purple">Invalid zip code input.  Please enter a zip code as exactly 5 numbers.</span>'
        # Query SSO and parse result:
        sso_res = ifsdam.retrieve_doors(inputzip)
        if sso_res == 'E':
            temp_sso_return_str = """We're sorry, SSO code retrieval is temporarily unavailable. But here is the <a href="https://sso.ba.ssa.gov/doorsRwWeb/_#findUsaByZip?zipCode=%s" target="_blank">DOORS page</a> for this zip code (TIP: Click the 'By Zip Code' tab to see the information).""" % (inputzip)
            log_usage(reqid, 'ssolookup', inputs_dict, 'E')
            return temp_sso_return_str
        elif sso_res == 'U':
            temp_sso_return_str = """Unable to locate an SSO code for %s. Please check that the zip code entered is accurate and try again.""" % (inputzip)
            log_usage(reqid, 'ssolookup', inputs_dict, 'U')
            return temp_sso_return_str
        else:
            log_usage(reqid, 'ssolookup', inputs_dict, '1')
            sso_return_html = """<a href="https://sso.ba.ssa.gov/doorsRwWeb/_#findUsaByZip?zipCode=%s" target="_blank">%s</a>""" % (inputzip, sso_res)
            return sso_return_html
    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        msg = "Server-side error (%s)" % str(x)
        exception_err_msg_html = err_msg_html.replace('MESSAGE', msg)
        exception_ifs_error_html = ifs_error_html.replace('<!-- OPTIONAL -->', exception_err_msg_html)
        return exception_ifs_error_html


# Child BMI Calculator Widget:
@route('/_childbmi', method='POST')
def childbmi():
    try:
        # Retrieve input:
        inputs_dict = dict([(name, value) for name, value in request.POST.iteritems() if name != 'reqid'])
        reqid = request.forms.get('reqid', type=str)
        ht_ft = request.forms.get('childhtft', type=str)
        ht_in = request.forms.get('childhtin', type=str)
        wt_lb = request.forms.get('childwt', type=str)
        age_yr = request.forms.get('ageyr', type=str)
        age_mo = request.forms.get('agemo', type=str)
        sex = request.forms.get('sex', type=str)

        # Validate inputs:
        if not ht_ft.isdigit() or int(ht_ft) not in range(0, 10):
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - htft)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Invalid height (feet) input.  Please enter a single digit between 0 and 9.</span>'
        if not ht_in.isdigit() or int(ht_in) not in range(0, 13):
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - htin)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Invalid height (inch) input.  Please enter only digits between 0 and 12.</span>'
        if not wt_lb.isdigit() or int(wt_lb) not in range(0, 1501):
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - wtlb)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Invalid weight input.  Please enter only digits between 0 and 1500.</span>'
        if not age_yr.isdigit() or int(age_yr) not in range(0, 18):
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - ageyr)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Invalid age (year) input.  Please enter only digits between 0 and 17.</span>'
        if not age_mo.isdigit() or int(age_mo) not in range(0, 13):
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - agemo)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Invalid age (month) input.  Please enter only digits between 0 and 12.</span>'
        if sex not in ['M', 'F']:
            log_usage(reqid, 'childbmi', inputs_dict, 'E (validation - sex)')
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Please select a sex.</span>'

        # Transform input:
        ht_in = str((int(ht_ft) * 12) + int(ht_in))
        age = "%s-y-%s-m" % (age_yr, age_mo)

        # Calculate BMI:
        wt_resdict = bmi.parse_weight(sex, ht_in, wt_lb, age, 'U', 'U')

        wt_interp_str = wt_resdict['interp_str']
        if wt_interp_str != 'E':
            # TIP: Make output here bold:
            wt_interp_str = wt_interp_str.replace("color:", "font-weight: 600; color:")
            log_usage(reqid, 'childbmi', inputs_dict, wt_resdict['interp_var'])
            return wt_interp_str
        else:
            return '<span class="sso" style="color:purple" id="bmiresultclaimant">Calculation error. Please try ' \
                   'again.  If this issue persists, please consult the Help Page for more information on how to seek ' \
                   'assistance.</span> '

    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        msg = "Server-side error (%s)" % str(x)
        return msg


# Age Calculator Widget - Claimant DOB Retrieval:
@route('/_getcldob', method='POST')
def getcldob():
    try:
        reqiddict = ast.literal_eval(str(request.body.read()))
        if not isinstance(reqiddict, dict):
            return 'Unknown'
        else:
            reqid = reqiddict['reqid']
            reslist = ifsda.retrieve_select_schema2(reqid, 'struct_hodisp', 'CLMT_DOB')
            if reslist and len(set(reslist)) == 1 and reslist[0] != 'U':
                return reslist[0]
            else:
                return 'Unknown'

    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        return 'Unknown'


# Age Calculator Widget - DID Retrieval:
# TIP: INSIGHT 'did' is first priority because structured
# equivalents are often several days off the date displayed on
# the decision text itself, which legally controls:
@route('/_getdid', method='POST')
def getcldid():
    try:
        reqiddict = ast.literal_eval(str(request.body.read()))
        if not isinstance(reqiddict, dict):
            return 'Unknown'
        else:
            reqid = reqiddict['reqid']
            reslist = ifsda.retrieve_select_schema2(reqid, 'dspn_doc', 'did')
            if reslist and len(set(reslist)) == 1 and reslist[0] not in ['U', 'P', 'E', '']:
                return reslist[0]
            else:
                reslist = ifsda.retrieve_select_schema2(reqid, 'struct_hodisp', 'FNL_DSPN_DT')
                if reslist and len(set(reslist)) == 1 and reslist[0] != 'U':
                    return reslist[0]
                else:
                    return 'Unknown'

    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        return 'Unknown'


# Age Calculator Widget:
@route('/_agecalc', method='POST')
def agecalc():
    try:
        # Retrieve input:
        inputs_dict = dict([(name, value) for name, value in request.POST.iteritems() if name != 'reqid'])
        reqid = request.forms.get('reqid', type=str)
        agecalcdob = request.forms.get('agecalcdob', type=str)
        enddate = request.forms.get('enddate', type=str)

        # Validate inputs:
        if agecalcdob.strip() == '':
            log_usage(reqid, 'agecalc', inputs_dict, 'E (validation - agecalcdob)')
            return '<span class="sso" style="color:purple; font-weight:600">Please enter a date of birth.</span>'
        if enddate.strip() == '':
            log_usage(reqid, 'agecalc', inputs_dict, 'E (validation - enddate)')
            return '<span class="sso" style="color:purple; font-weight:600">Please enter an end date.</span>'
        if len([x for x in agecalcdob if x.isdigit()]) < 4:
            log_usage(reqid, 'agecalc', inputs_dict, 'E (validation - agecalcdob)')
            return """<span class="sso" style="color:purple; font-weight:600">Invalid date of birth input.  Please enter a date formatted as either 'MM/DD/YYYY' or fully written with a four digit year (e.g. 'June 24, 1984').</span>"""
        if len([x for x in enddate if x.isdigit()]) < 4:
            log_usage(reqid, 'agecalc', inputs_dict, 'E (validation - enddate)')
            return """<span class="sso" style="color:purple; font-weight:600">Invalid end date input.  Please enter a date formatted as either 'MM/DD/YYYY' or fully written with a four digit year (e.g. 'June 24, 1984').</span>"""

        # Calculate Age:
        age_res = dh.calc_age(agecalcdob, enddate)
        if age_res == 'E':
            log_usage(reqid, 'agecalc', inputs_dict, 'E')
            return """<span class="sso" style="color:purple; font-weight:600">Unable to calculate age for these inputs. Please try again with dates formatted as 'MM/DD/YYYY'. If this issue persists, please consult the Help Page for more information on how to seek assistance.</span>"""
        else:
            # Calculate applicable age category:
            age_res_agecat = ifsiqrcc.calc_agecat(agecalcdob, enddate)
            if age_res_agecat != 'E':
                age_res = "%s (%s)" % (age_res, age_res_agecat)
            age_html = """<span class="sso" style="color:#006666; font-weight: 600" id="bmiresultclaimant">%s</span>""" % age_res
            log_usage(reqid, 'agecalc', inputs_dict, '1')
            return age_html

    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        msg = "Server-side error (%s)" % str(x)
        return msg


# Store Feedback:
@route('/_oaofb', method='POST')
def oaofb():
    try:
        responsever = '0'
        inputs_dict = dict([(name, value) for name, value in request.POST.iteritems() if name != 'reqid'])

        inputs_dict_filtered = {k:v for k, v in inputs_dict.iteritems() if v.strip() != ''}
        if not inputs_dict_filtered:
            response.status = 400
            return "No feedback checkboxes checked and no text found in 'Other' field.  Please provide feedback and try again."
        reqid = request.forms.get('reqid', type=str)
        userpin = request.headers.get("X-Remote-User")
        for k, v in inputs_dict.iteritems():
            if v.strip() != '':
                insert_res_ver = insert_feedback(reqid, k, v, userpin)
                if insert_res_ver == 'E':
                    responsever = 'E'
                else:
                    responsever = '1'
        if responsever == '1':
            response.status = 200
            return 'Success'
        else:
            response.status = 400
            return 'Error'
    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        response.status = 400
        return str(x)


# OAO Case Entity Page Generation:
@route('/oaoapp/<reqid:re:[0-9]+>')
def getinsighthtml(reqid):
    try:
        # Retrieve decision INSIGHT content using reqid passed:
        resdict = ifsda.retrieve_case_entity_schema2(reqid)

        # If unable to locate data associated with REQID (including when
        # error occurred), log and output error HTML:
        if not resdict:
            msg = "Processing Error: INSIGHT is unable to retrieve information about this case [Case ID: %s]. Please try again for other cases.  If you continue to see this error message, please consult the Help page." % reqid
            logger.critical(msg)
            eprint(str("ERRMSG=" + str(msg)))
            err_msg_html_custom = err_msg_html.replace('MESSAGE', msg)
            ifs_error_html_custom = ifs_error_html.replace('<!-- OPTIONAL -->', err_msg_html_custom)
            return ifs_error_html_custom

        # Generate HTML:
        iqhtml = iqrepgen.run(resdict)

        # If error generating HTML, log and output error HTML:
        if iqhtml == 'E':
            logger_err_msg = "bottle_oao.getinsighthtml() - iqrgenerator.run() returned 'E' for REQID %s" % str(
                reqid)
            logger.critical(logger_err_msg)
            msg = "Processing Error: INSIGHT is unable to generate a Web App page for this case [Case ID: %s].  Please try again.  If you continue to see this error message, please consult the Help page." % reqid
            err_msg_html_custom = err_msg_html.replace('MESSAGE', msg)
            ifs_error_html_custom = ifs_error_html.replace('<!-- OPTIONAL -->', err_msg_html_custom)
            return ifs_error_html_custom

        # Return generated INSIGHT Web App page HTML:
        return iqhtml

    except Exception as x:
        logger.exception('BOTTLE EXCEPTION')
        logger_err_msg = "bottle_oao.getinsighthtml() - general exception for REQID %s" % str(reqid)
        logger.critical(logger_err_msg)
        msg = "Web Server Error: %s.  Please try again. If you continue to see this error message, please consult the Help page." % str(
            x)
        exception_err_msg_html = err_msg_html.replace('MESSAGE', msg)
        exception_ifs_error_html = ifs_error_html.replace('<!-- OPTIONAL -->', exception_err_msg_html)
        return exception_ifs_error_html


# Case-Search Code
error_info_dict = {'500': "Internal Server Error", '504': "Gateway Timeout Error",
                   '415': "Unsupported Media Type", '404': "Server Not Available",
                   '400': "Bad Request", '401': "Unauthorized Error", '403': "Forbidden Access",
                   '502': "Bad Gateway", '999': "User Pin is not authorized"}


@route('/admin/search_results/<case_pin:path>', method=['GET'])
@route('/admin/search_results/<case_pin:path>/', method=['GET'])
def generate_admin_srch_by_test_casepin(case_pin):
    """
    Handle route to authenticates a admin-user-pin and then uses
    a test user-pin (case_pin) passed in on the URL to display case claimant results for case_pin
    :param case_pin: test case_pin used to render claimant results
    :return: Insight case-search webpage
    """
    # xremoteuser_pin = request.headers.get('X-Remote-User', "ba\\632717")

    (xremoteuser_pin, auth_error) = process_case_pin()

    # execute in all environments
    valid_admin = 0
    if xremoteuser_pin:
        valid_admin = authenticate_admin_access(xremoteuser_pin)

    logger.info("case_pin: " + str(case_pin))
    if not case_pin or not valid_admin:
        auth_error = 1

    # need to pass in both test_user_pin and admin_user_pin
    insight_content = handle_case_search(case_pin=case_pin, admin_pin=xremoteuser_pin,
                                         ssn=None, access_error=auth_error)
    return insight_content

@route('/search_results/ssn/<case_pin:path>', method=['GET'])
@route('/search_results/ssn/<case_pin:path>/', method=['POST'])
@route('/search_results/ssn/<case_pin:path>', method=['POST'])
def generate_search_by_ssn_admin(case_pin):
    """
    Implements an API SSN search for admins using a test pin (case_pin)
    :param case_pin: test case_pin for admin usage
    :return: Insight case-search webpage
    """
    (xremoteuser_pin, auth_error) = process_case_pin()

    # execute in all environments
    valid_admin = 0
    if xremoteuser_pin:
        valid_admin = authenticate_admin_access(xremoteuser_pin)

    logger.info("valid_admin: " + str(valid_admin))
    logger.info("case_pin: " + str(case_pin))

    if not case_pin or not valid_admin:
        auth_error = 1

    ssn = request.forms.get('ssn_search')
    logger.info("ssn: " + str(ssn))
    # return ssn
    insight_content = handle_case_search(case_pin=case_pin, admin_pin=xremoteuser_pin,
                                         ssn=ssn, access_error=auth_error)
    return insight_content


@route('/search_results/ssn', method=['POST'])
@route('/search_results/ssn/', method=['POST'])
def generate_search_by_ssn():
    """
    Handle route to authenticate and display case search results by user pin and ssn
    :return: Insight claimants as a Case-Search web page
    """

    (case_pin, auth_error) = process_case_pin()
    admin_pin = None

    if case_pin:
        logger.info("case_pin after regex: " + str(case_pin))
    else:
        logger.error("The case_pin has not been set to a valid value")
        case_pin = None
        auth_error = 1

    ssn = request.forms.get('ssn_search')
    logger.debug("ssn: " + str(ssn))

    insight_content = handle_case_search(case_pin=case_pin, admin_pin=admin_pin,
                                         ssn=ssn, access_error=auth_error)
    return insight_content


@route('/search_results', method=['GET'])
@route('/search_results/', method=['GET'])
def generate_search_by_user_pin_from_header():
    """
    Handle route to authenticate and display case search results by user pin;
    retrieves the userpin from the request header
    :return: Insight claimants as a Case-Search web page
    """
    (case_pin, auth_error) = process_case_pin()
    admin_pin = None

    if case_pin:
        logger.info("case_pin after regex: " + str(case_pin))
    else:
        logger.error("The case_pin has not been set to a valid value")
        case_pin = None
        auth_error = 1

    logger.info("case_pin: " + str(case_pin))
    insight_content = handle_case_search(case_pin=str(case_pin), admin_pin=admin_pin,
                                         ssn=None, access_error=auth_error)
    return insight_content


def process_case_pin():
    """
    Extracts the case_pin from the 'X-Remote-User' header value; if that value
    is not found the case_pin is extracted from the 'username' environment value
    :param case_pin:
    :return: a tuple constituting the case_pin and a auth_error flag (case_pin, auth_error)
    """
    auth_error = 0

    case_pin = access_request_header('X-Remote-User')
    if case_pin:
        logger.info("case_pin from x-remote-user: " + str(case_pin))

    # use the case_pin in the local DEV environment if not available form X-Remote-User
    if not case_pin:
        logger.info("case_pin is not available via X-Remote-User...")
        logger.info("...attempting to access the case_pin from the environment")
        case_pin = retrieve_case_pin_from_env()
    else:
        logger.info("case_pin is available via X-Remote-User")

    if case_pin:
        logger.info("case_pin before regex: " + str(case_pin))
    else:
        auth_error = 1
        case_pin = None

    # extracting the numeric user-pin from the X-Remote-User header value
    re_obj = re.compile("^.*?\\ ?(\d+)$")
    match_obj = None
    try:
        match_obj = re_obj.match(case_pin)
    except TypeError as e:
        logger.debug("Encountered regex TypeError on match obj: " + str(e))
        logger.error("setting case_pin to None")
        auth_error = 1
        case_pin = None

    try:
        case_pin = match_obj.group(1)
    except AttributeError as e:
        logger.debug("Encountered regex AttributeError on group obj: " + str(e))
        logger.error("setting case_pin to None")
        auth_error = 1
        case_pin = None

    return case_pin, auth_error


def retrieve_case_pin_from_env():
    """
    If we are in development attempt to access the case_pin/username from the ENVIRONMENT
    :return: user case_pin from the ENVIRONMENT
    """
    case_pin = os.getenv('username', None)
    case_pin = 'ba\\' + case_pin
    return case_pin


def access_request_header(header_key_val):
    """
    Access a value from the request header
    :return: returns the value from the header (if available); else None
    """
    case_pin_from_header = request.headers.get(header_key_val, None)
    return case_pin_from_header


def authenticate_admin_access(alleged_admin_pin):
    """
    determine if a case_pin has admin privilege
    :param alleged_admin_pin:
    :return: admin access - 1 else 0
    """
    logger.info("executing development admin-verification API call")
    payload = {}
    url = 'http://' + cfg.case_srch_server + ':' + cfg.case_srch_port + \
          '/insight-request/insightuser/admincases/1'
    res = requests.post(url, headers={"adminpin": alleged_admin_pin,
                        'Content-type': 'text/plain'}, data=json.dumps(payload))
    try:
        ret_msg = res.text
        logger.info("ret_msg: " + str(ret_msg))
    except Exception as e:
        logger.error("Encountered error retrieving response text: " + str(e))
        return 0

    ret_msg = ret_msg.lstrip('"')
    ret_msg = ret_msg.rstrip('"')
    if not ret_msg.lower() == "administrator":
        logger.error("case_pin: " + str(alleged_admin_pin) + " is not an admin user")
        return 0
    else:
        return 1


def handle_case_search(case_pin, admin_pin=None, ssn=None, access_error=None):
    """
    Serves as a wrapper function to dictate when to implement def case_search or set a json error;
    Also determines whether to render claimant content or an error page
    :param case_pin: the pen used to query for and render claimants
    :param admin_pin: used to authenticate admin testing of a case_pin
    :param ssn: used to implement a SSN API search lookup
    :param access_error: json object to report an error response
    :return: Insight Case-Search content
    """

    if access_error:
        # prepare error response
        json_serialized_content = json_error_response(999)
    else:
        # assume this is valid json
        json_serialized_content = case_search(str(case_pin), admin_pin=admin_pin, ssn=ssn)

    # TEST-CASE FOR: invalid JSON
    # json_deserialized_content = "This is not json"

    # attempt to deserialize the JSON
    try:
        json_deserialized_content = json.loads(json_serialized_content)
        json_content = json_deserialized_content
    except Exception as e:
        error_info = {"Error": str(e)}
        # create a json str object to store an error/message
        json_serialized_content = json.dumps(error_info)
        json_content = json_serialized_content

    # generate case search
    if not admin_pin:
        case_pin = ""
    insight_srch_content = generate_src_template(json_content, case_pin)
    insight_content = insight_srch_content

    return insight_content


def make_error_filter(n):
    """
    creates a closure/anonymous function to select the correct error codes
    :param n: a list of http error codes
    :return: a closure/anonymous function
    """
    return lambda error_list: filter_error(error_list, n)


def filter_error(errors_list, n):
    """
    This closure/anonymous function filters the error list to return the correct error
    :param errors_list: contains list of http error codes
    :param n: a dictionary having error code as key and str message as a value
    :return: a http error code
    """
    ret_list = filter(lambda x: x in n, errors_list)
    if len(ret_list):
        return ret_list[0]
    else:
        return None


def generate_error_template(json_deserialized_content):
    """Generates a error page based on the error message from the API"""

    # if json_deserialized_content is a JSON str object we must use json.loads to decode it
    if isinstance(json_deserialized_content, str):
        json_deserialized_content = json.loads(json_deserialized_content)

    logger.debug("json_deserialized_content: " + str(json_deserialized_content))

    response_errors_list = error_info_dict.keys()
    error_filter = make_error_filter(response_errors_list)
    error_code = error_filter(json_deserialized_content)

    if 'Error' in json_deserialized_content:
        message = json_deserialized_content['Error']
    elif 'Message' in json_deserialized_content:
        message = json_deserialized_content['Message']
    elif error_code:
        message = json_deserialized_content[error_code]
    else:
        message = "Unexpected Server Response"

    # Create the jinja2 template ('views\err_api_auth_error.html')
    tmpl_obj = set_template('views\embedded_error_message.html')
    error_msg_tmpl_dict = {"API_ERROR_MESSAGE": message}

    error_content = tmpl_obj.render(error_msg_tmpl_dict)
    return error_content


def validate_content(json_content):
    """Checks for errors and validates the JSON content"""

    response_errors_list = error_info_dict.keys()
    error_filter = make_error_filter(response_errors_list)
    error_code = error_filter(json_content)

    # check for string object
    if isinstance(json_content, str):
        json_content = json.loads(json_content)
        if 'Error' in json_content:
            return 0
        elif 'Message' in json_content:
            return 0
        elif error_code in json_content:
            return 0

    # check for JSON dictionary
    if isinstance(json_content, dict):
        if 'Error' in json_content:
            return 0
        elif 'Message' in json_content:
            return 0
        elif error_code in json_content:
            return 0

    return 1


def format_columns(json_deserialized_content):
    """
    Provides Wrapper functionality for formatting any case-search column
    :param json_deserialized_content: case-search content from the API
    :return: modifies the json content by reference
    """
    all_funcs_dict = globals().copy()
    # logger.debug("all_funcs_dict: " + str(all_funcs_dict))
    for case_srch_row_dict in json_deserialized_content:

        # create a key to store the title data for the 'view' link
        if case_srch_row_dict['link']:
            case_srch_row_dict['link_title_data'] = ""

        row_dict = case_srch_row_dict

        for case_srch_key, case_srch_val in case_srch_row_dict.iteritems():
            func_name = 'format_' + str(case_srch_key)
            func_name = func_name.lower()
            # logger.debug("func_name: " + str(func_name))
            # logger.debug("func_val: " + str(type(case_srch_val)))

            method = all_funcs_dict.get(func_name)
            # logger.debug("format method: " + str(method))
            # if column has a formatting function call it and use the formatted value

            if method and case_srch_key == 'link' and case_srch_val:
                formatted_fld = method(row_dict)
                case_srch_row_dict['link_title_data'] = formatted_fld
            else:
                if method and not case_srch_key == 'link':
                    formatted_fld = method(case_srch_val)
                    # logger.info("formatted_fld: " + str(formatted_fld))
                    case_srch_row_dict[case_srch_key] = formatted_fld


def format_link(row_dict):
    """
    provides formatting for the 'view' link column's title attribute
    :param row_dict:
    :return: text for the view link attribute
    """
    link_title_dict = dict(CLMT_SSN="SSN:", CLMT_NM25="Claimant Name:", CLM_TYP="Claim Type:",
                           HRG_TYP="Hearing Type:", WKLD_TYP="Workload Type:")
    link_title_list = ["CLMT_SSN", "CLMT_NM25", "CLM_TYP", "HRG_TYP", "WKLD_TYP"]
    link_title_string = ""
    logger.debug("row_dict: " + str(row_dict))
    for link_key in link_title_list:
        logger.debug("link_key: " + str(link_key))

        link_text = link_title_dict[str(link_key)].strip()
        link_val = row_dict[str(link_key)].strip()
        logger.debug("link_text: " + str(link_text))
        logger.debug("link_val: " + str(link_val))
        link_title_string += link_text + " " + link_val + ", "

    link_title_string = link_title_string.rstrip(", ")
    logger.debug("link_title_string: " + str(link_title_string))
    return link_title_string


def format_clmt_ssn(case_srch_val):
    """
    provides formatting for the SSN column (CLMT_SSN) of the case-search results
    :param case_srch_val: value that needs to be formatted
    :return: ssn_with_hypens
    """
    re_obj = re.compile("^(\d{3})(\d{2})(\d{4})$")
    m_obj = re_obj.match(case_srch_val)
    # create the final string from a tuple
    ssn_with_hyphens = str("-".join((m_obj.group(1), m_obj.group(2), m_obj.group(3))))
    # logger.debug("ssn_with_hypens: " + str(ssn_with_hyphens))
    return ssn_with_hyphens


# Desc: Generates the search results template
def generate_src_template(json_deserialized_content, case_pin=None):
    """Generates the search results template"""

    rendered_srch_content = ""
    no_case_results_flag = True
    message_text = ""
    own_ssn_warning = ''
    celebrity_ssn_warning = ''

    valid_content = validate_content(json_deserialized_content)
    if not valid_content:
        message_text = generate_error_template(json_deserialized_content)
    else:
        # format any case-search columns by reference
        no_case_results_flag = False

        # Check if the api results are being returned with just casedata or
        # if they contain own/celebrity warnings.
        if isinstance(json_deserialized_content, dict) and 'CASEDATA' in json_deserialized_content.keys():
            case_data = json_deserialized_content['CASEDATA']
            own_ssn_warning = json_deserialized_content.get('OWNSSN', '')
            celebrity_ssn_warning = json_deserialized_content.get('IENP', '')
        else:
            case_data = json_deserialized_content
        format_columns(case_data)

        # Create the jinja2 template for 'template\search_row.html'
        search_row_tmpl_obj = set_template('templates\search_row.html')

        for row_dict in case_data:
            row_dict['VIEW_LINK_CONTENT'] = None
            if row_dict['link'] == '':
                row_dict['VIEW_LINK_CONTENT'] = 'No INSIGHT Review Available'
            else:
                view_link_template_obj = set_template('templates\srch_view_link.html')

                # view_link_template_o = template_env.get_template(srch_view_link_tmpl)
                view_link = cfg.case_srch_path + '/' + row_dict['link']
                link_dict = {'link': view_link, 'link_title_data': row_dict['link_title_data']}
                # link_dict = {'link': view_link}
                view_link_content = view_link_template_obj.render(link_dict)
                row_dict['VIEW_LINK_CONTENT'] = view_link_content

            output_text = search_row_tmpl_obj.render(row_dict)
            rendered_srch_content += output_text
        # end for

    # Create the jinja template for 'templates\case_search.html'
    srch_page_tmpl_obj = set_template('templates\case_search.html')

    main_tmpl_dict = {"SEARCH_RESULTS": rendered_srch_content,
                      "RESPONSE_MESSAGE": message_text,
                      "NO_CASE_RESULTS_FLAG": no_case_results_flag,
                      "OWN_SSN_WARNING": own_ssn_warning,
                      "CELEBRITY_SSN_WARNING": celebrity_ssn_warning}
    if case_pin:
        case_pin = '/' + case_pin
        main_tmpl_dict["CASE_PIN"] = case_pin
    rendered_srch_content = srch_page_tmpl_obj.render(main_tmpl_dict)
    return rendered_srch_content


@route('/css/<filename:re:.*\.(css)>')
@route('/static/css/<filename:re:.*\.(css)>')
def server_static_stylesheets(filename):
    return static_file(filename, root=css_dir)


@route('/js/<filename:re:.*\.(js)>')
@route('/static/js/<filename:re:.*\.(js)>')
def server_static_javascript(filename):
    return static_file(filename, root=js_dir)


@route('/images/<filename:re:.*\.(png|jpg|gif|ico)>')
@route('/static/images/<filename:re:.*\.(png|jpg|gif|ico)>')
def server_static_images(filename):
    return static_file(filename, root=images_dir)

# health check route
bottleApp = default_app()
HcHelper(bottleApp, '/healthcheck')
HcHelper(bottleApp, '/healthcheck/')
HcHelper(bottleApp, '/healthcheck/<reqid:re:[0-9]+>')


def set_template(tmpl_filename):
    """receives a template filename; attempts to return a template object"""

    # Create the jinja2 template
    template_loader = jinja2.FileSystemLoader(searchpath="/")
    template_env = jinja2.Environment(loader=template_loader)

    # jinja only works with unix style forward slashes
    tmpl = str(os.path.join(insight_dir, tmpl_filename))
    tmpl_list = tmpl.split('\\')

    # keep every element except the first [0]
    tmpl_list = tmpl_list[1:]
    tmpl = "/".join(tmpl_list)

    tmpl_obj = template_env.get_template(tmpl)
    return tmpl_obj


def json_error_response(status_code):
    """
    create a serialized JSON error
    :param status_code: a numeric error/status code
    :return: serialized JSON error object
    """
    logger.info("json_error_response/status_code: " + str(status_code))

    error_info = None
    # status_code = 502
    status_code = str(status_code)
    try:
        message = error_info_dict[status_code]
        error_info = {status_code: message}
    except KeyError as e:
        logger.error("json_error_response/ status_code: " + str(status_code))
        logger.error("json_error_response/ Encountered KeyError: " + str(e))

    if not isinstance(error_info, dict):
        error_info = {"000": "No Tracked HTTP Response Code Found"}

    json_serialized_content = json.dumps(error_info)
    json_content = json_serialized_content
    return json_content


def case_search(case_pin, admin_pin=None, ssn=None):
    """
    issues an api request to retrieve SSN row-sets as JSON (array of dictionaries)
    :param case_pin: pin from which claimants are derived
    :param admin_pin: administrator pin that allows testing of the case_pin
    :param ssn: social security number of a claimant
    :return: serialized JSON data comprising claimant data
    """
    logger.debug("case_pin: " + str(case_pin))
    logger.debug("admin_pin: " + str(admin_pin))
    logger.debug("ssn: " + str(ssn))

    if ssn:
        logger.debug("ssn api call")
        url = 'http://' + cfg.case_srch_server + ':' + cfg.case_srch_port + \
              '/insight-request/insightuser/casessnsearch'
        ssn = str(ssn)
        payload = {'searchssn': ssn}
    else:
        logger.debug("case_pin api call")
        if admin_pin:
            url = 'http://' + cfg.case_srch_server + ':' + cfg.case_srch_port + \
                  '/insight-request/insightuser/admincases'
            payload = {}
        else:
            url = 'http://' + cfg.case_srch_server + ':' + cfg.case_srch_port + \
                  '/insight-request/insightuser/casepinsearch'
            payload = {}

    res = None
    try:
        # res = requests.post(url, headers={"userpin": user_id},
        #                     data=json.dumps(payload))
        if admin_pin:
            # use the admin url
            res = requests.post(url, headers={"casepin": case_pin, "adminpin": admin_pin,
                                'Content-type': 'application/json'}, data=json.dumps(payload))
        else:
            res = requests.post(url, headers={"casepin": case_pin,
                                'Content-type': 'application/json'}, data=json.dumps(payload))

        if admin_pin and ssn:
            logger.info("admin_pin and ssn is available")
            logger.info("res.json type: " + str(res.json()))
            # if we have an admin_pin and a ssn lets check the response; if the response is an error
            # then that means we needs to do an SSN API request and not an admin test-case_pin
            # request (ie we found zero results from an admin search and now we want to do a ssn
            # search)
            if not validate_content(str(res.json())):
                logger.info("An error was encountered with the initial request...issuing a " +
                            "secondary non-admin request")
                res = requests.post(url, headers={"casepin": admin_pin,
                                    'Content-type': 'application/json'},
                                    data=json.dumps(payload))

    except requests.exceptions.HTTPError as e:
        logger.error("res: " + str(res) + "error: " + str(e))
        logger.error("res.json(): " + str(res.json()))
        status_code = e.response.status_code
        return json_error_response(status_code)
    except requests.exceptions.Timeout as e:
        logger.error("res: " + str(res) + "error: " + str(e))
        logger.error("res.json(): " + str(res.json()))
        status_code = e.response.status_code
        return json_error_response(status_code)
    except Exception as e:
        logger.error("res: " + str(res) + "error: " + str(e))
        logger.error("res.json(): " + str(res.json()))
        return json_error_response(res.status_code)

    logger.info("res: " + str(res))
    logger.info("res type: " + str(type(res)))

    if isinstance(res, requests.models.Response):
        if not (res.status_code == 200):
            logger.info("status code is not 200")
            # return json_error_response(502)
            return json_error_response(res.status_code)
    elif not res:
        logger.info("No response found")
        return json_error_response(503)
    else:
        # should never get here
        logger.info("No response found")
        return json_error_response(503)

    try:
        json_data = res.json()
        logger.info("json_data: " + str(json_data))
    except ValueError as e:
        error_info = {"Error": str(e)}
        # create a json str object to store an error/message
        json_serialized_content = json.dumps(error_info)
        json_data = json_serialized_content

    # print("json_data: " + str(json_data))
    json_content = json_data
    return json_content

# TIP: 'debug' and 'reloader' parameters assist with development.


if __name__ == "__main__":
    run(host=cfg.bottle_run_hn, server='cherrypy', port=cfg.bottle_run_port, reloader=True)
# run(host='s1ff500', server='cherrypy', port=8186, debug=True, reloader=True)
# run(host='10.18.99.37', port=8080, debug=True)

# run(host='localhost', debug=True, reloader=True)
