﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INSIGHT_Request.Models
{
    public abstract class OAOClaimant
    {
        
        [JsonProperty("cossn")]
        public virtual string CLMT_SSN { get; set; } = "";
        [JsonProperty("hofcWrkUnitUid")]
        public string HOFC_WRK_UNIT_UID { get; set; } = "";
        [JsonProperty("hofcWrkUnitUidHrg")]
        public string HOFC_WRK_UNIT_UID_HRG { get; set; } = "";
        [JsonProperty("clmType")]
        public string CLM_TYP { get; set; } = "";
        [JsonProperty("hrgType")]
        public string HRG_TYP { get; set; } = "";
        [JsonProperty("clmUid")]
        public string CLM_UID { get; set; } = "";
        [JsonProperty("caseGrpCd")]
        public string CASE_GRP_CD { get; set; } = "";
        [JsonProperty("clmtName")]
        public virtual string CLMT_NM25 { get; set; } = "";
        [JsonProperty("clmtState")]
        public string CLMT_ST { get; set; } = "";
        [JsonProperty("clmtDob")]
        public string CLMT_DOB { get ;  set; } = "";
        [JsonProperty("clientGender")]
        public string SEX { get; set; } = "";
        [JsonProperty("clientHeight")]
        public string HT_INCH { get; set; } = "";
        [JsonProperty("clientWeight")]
        public string WT_OUNCES { get; set; } = "";


        [JsonProperty("repUid")]
        public string REP_UID { get; set; } = "";
        [JsonProperty("criticleCase")]
        public string CRITL_CASE_CTGY_SW { get; set; } = "";
        [JsonProperty("deceased")]
        public string CLMT_DECD_SW { get; set; } = "";
        [JsonProperty("directions")]
        public string DIRE_NEED_SW { get; set; } = "";
        [JsonProperty("potientalyHomicidle")]
        public string PTNTLY_HOMCDL_SW { get; set; } = "";
        [JsonProperty("suicidal")]
        public string SUICIDL_SW { get; set; } = "";
        [JsonProperty("terminal")]
        public string TRML_ILLNESS_SW { get; set; } = "";
        [JsonProperty("wageEarner")]
        public virtual string WG_ERNR_SSN { get; set; } = "";
        [JsonProperty("bic")]
        public string BIC { get; set; } = "";
        [JsonProperty("hearingIssued")]
        public string HRG_ISU_CD { get; set; } = "";
        [JsonProperty("eDib")]
        public string EDIB_CD { get; set; } = "";
        [JsonProperty("daa")]
        public virtual string OHA_DAA_CD { get; set; } = "";
        [JsonProperty("folderNumber")]
        public string EFLDR_NUM { get; set; } = "";
        [JsonProperty("allegedDisabilityDate")]
        public string ALLGD_DISB_ONST_DT { get; set; } = "";
        [JsonProperty("t2ApplicationDate")]
        public string T2_APP_DT { get; set; } = "";
        [JsonProperty("t16ApplicationDate")]
        public string T16_APP_DT { get; set; } = "";
        [JsonProperty("t2PFlagDate")]
        public string T2_PFLG_DT { get; set; } = "";
        [JsonProperty("t16PFlagDate")]
        public string T16_PFLG_DT { get; set; } = "";
        [JsonProperty("dateLastInsured")]
        public string DLI { get; set; } = "";
        [JsonProperty("educationLevel")]
        public virtual string HEDULVL_CD { get; set; } = "";
        [JsonProperty("hearingExpert")]
        public List<OAOExpert> OAOExpert { get; set; } = new List<OAOExpert>();

        [JsonProperty("hearingDevelopment")]
        public List<OAODevelopment> OAODevelopment { get; set; } = new List<OAODevelopment>();

    }
}