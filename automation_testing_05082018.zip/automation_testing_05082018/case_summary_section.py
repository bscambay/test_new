import os
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
import config as cfg
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select

# Set directories:
#setup_config
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)


#pytest -v test_case_search.py::TestSSNSearch::test_ssn_sort
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_find
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_filter


class TestInsightHeaders(unittest.TestCase):

    '''Setup test'''
    def setUp(self):
        print
        #Instantiate webdriver IE browser
        #self.driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        self.driver = cfg.driver
        #webdriver.Chrome("C:\\IEDriver\\chromedriver.exe")
        #Navigate to Insight Web app
        #self.url = "http://localhost:8080/search_results/"
        self.url = cfg.Hearing_url
        #"http://s1ff531.ba.ad.ssa.gov:8189/oaoapp/1"
        self.user_id = "897960"
        #Wait for a certain amount time before throwing an exception if page is not found.
        self.wait = WebDriverWait(self.driver, 10)
        #self.menu_items = {'Home' ,'summary','Report', 'Tools'}
    def test_url(self):
        url = self.url
        "http://s1ff531.ba.ad.ssa.gov:8189/oaoapp/1"
        #"http://s1ff531.ba.ad.ssa.gov:8189/search_results/ssn"
        #"http://s1ff515:9008/search_results/"
        assert url

    def test_headers_sections(self):
        '''Test sort function for case search tool'''
        #driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        driver = self.driver
        #self.driver
        driver.get(self.url)
        #("http://s1ff531.ba.ad.ssa.gov:8189/search_results/")
        #("http://s1ff515:9008/search_results/")
        #(self.url)
        index = 1
        #rowElements = driver.find_elements_by_xpath("//th[contains(@class, 'header')]") #Define a list of headers to locate on the page
        elediv = driver.find_element_by_id('top')
        menu_items = {0:"Home" ,1:"Summary",2:"Report", 3:"Tools"}
        appmenu = list(menu_items)

        menulist = driver.find_elements_by_xpath("//ul[@class='nav']")
        for menuitem in menulist:
            menuitem =  driver.find_elements_by_class_name('navlink')
            
        i = 0  
        for menu in menuitem:            
            self.assertIn(menu.text, menu_items[i])
            print "Asserted: " + str(menu.text) + "  and  " + menu_items[i]
            print "Found Menu: " +menu.text
            i= i+1
            time.sleep(1)        
            print elediv.text
       
        #.find_elements_by_class_name('navlink')
        
        #item.text
        '''
        for item in items:           
            #t = item.text
            print item
            #print item
        '''
        self.headers = ['Case Summary', 'Quality Report', 'Tools']
        #driver = self.driver
        #driver.get(self.url)

            #Call assert method to test for Title/Label on the Page
        self.assertIn('INSIGHT', self.driver.title)
        print "Title: " + driver.title
        #Locate h1 headers
        elements = driver.find_elements_by_tag_name('h1')

        html_list = driver.find_elements_by_xpath("//div[@class='ffbutton']")
        for itemlist in html_list:
            itemlist =  driver.find_elements_by_class_name('reportsection')
        for item in itemlist:             
            print item.text
            time.sleep(1)
         #Locate h2 headers and find SSN format ###-###-9999
        elements = driver.find_elements_by_tag_name('h2')
        html_cliamants_ssn = driver.find_element_by_xpath("//span[@class='headingcustomcontent']")
        print html_cliamants_ssn.text
        # Split SSN
        first,second,third = html_cliamants_ssn.text.split("-")
        print str(third)
        print "Last 4 SSN's length is : " + str(len(third))
        # Assert the Last 4 of SSN is displayed
        self.assertIn(str(len(third)),str(4) )
        #letter_ssn_search_regex = r'(?:[\dldOl|]\s{,2}){3}-(?:[\dldOl|]\s{,2}){2}-(?:[\dldOl|]\s{,2}){3}[\dldOl|]'
        regsssn = "(###)[0-9]{3}([ -])(##)[0-9]{2}\1(?!0000)[0-9]{4}$"
        last_4SSN = re.match(regsssn,html_cliamants_ssn.text)
        print str(last_4SSN)
        #self.assertIn(html_cliamants_ssn.text, last_4SSN)
        print "Matched last 4 SSN" 
            #Test that headers are present on the page...i.e, Case Summary, Quality Report..etc
        #for ele in elements:
            #self.assertIn(str(ele.text), self.headers)
            #Dont close browser immediately!!
            #time.sleep(3)
    #def tearDown(self):
            #self.driver.close()


    if __name__== "__main__":
        runner = unittest.TextTestRunner()
        runner.run(suite())