# INSIGHT FULL SUITE - BOTTLE SERVER - COMMON CALCULATIONS
#
# AUTHOR: 
# Kurt Glaze & Eric Kim
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# SUMMARY:
# Common calculations for IFS_BOTTLE
#
# DATE LAST UPDATED: 
# 11.04.2016
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# ==============================================================================

# Import modules:
import re
import logging
import os.path
from datetime import timedelta
import datetime
import database_actions_misc as dam
import common_fx as cfx
import date_helper as dh

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Age Category Calculator:
def calc_agecat(earlier_date_input, later_date_input):
    '''Calcuate the appropriate age category
	for an input age string.
	
	Args:
		input_agestr {str}: An age, formatted as
			'#-y-#-m', where each # can be 1+ digits
			in length with no zero padding.
	Returns:
		A string containing the name of the applicable
			age category, or 'E' if exception occurs.
	Raises:
		N/A.
	'''
    try:
        # Convert later_date_input to DT:
        later_date_input_dt = dh.parse_date_todatetime_struct(later_date_input)

        # Add one day to later_date_input:
        # RATIONALE: If they're far from their birthday taking them
        # to the next higher age category, adding a day won't matter
        # for AGE CATEGORY parsing.
        if later_date_input_dt == 'E':
            return 'E'
        later_date_input_dt_plusone = later_date_input_dt + datetime.timedelta(days=1)

        # Recalculate age:
        agestr = dh.calc_age(earlier_date_input, later_date_input_dt_plusone)

        # Use recalculated age to ID age category:
        age_res_yr_srch = re.search(r"^\d+", agestr)
        if not age_res_yr_srch:
            return 'E'
        else:
            age_res_yr = int(age_res_yr_srch.group())
            if 18 > age_res_yr:
                return 'child'
            elif 44 >= age_res_yr >= 18:
                return 'younger individual age 18-44'
            elif 49 >= age_res_yr >= 45:
                return 'younger individual age 45-49'
            elif 54 >= age_res_yr >= 50:
                return 'closely approaching advanced age'
            elif 59 >= age_res_yr >= 55:
                return 'advanced age'
            elif age_res_yr >= 60:
                return 'closely approaching retirement age'
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# (DEPRECATION WARNING 06082017 - replacing with MHAODS call)
# ZIP-to-SSO function using DOORS database call:
def ziptosso_doors(zipstr):
    try:
        if not isinstance(zipstr, str):
            return 'E'
        zipstr = zipstr.strip()
        if len(zipstr) != 5:
            return 'E'
        res = dam.retrieve_doors(zipstr)
        return res
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# (DEPRECATION WARNING 03132017 - replaced by database call) 
# Define ZIP-to-SSO function (static file):
# def ziptosso(zipstr):
#     try:
#         res = zipsso[zipstr]
#         return res
#     except KeyError:
#         return 'KeyError'
#     except Exception:
#         logger.exception('EXCEPTION')
#         return 'E'


# Gather all quality subd 'val' entries for a given 'nm' value:
def gather_quality_val(input_quality_dictlist, input_nm):
    try:
        reslist = [subd for subd in input_quality_dictlist if subd['nm'] == input_nm]
        return reslist
    except Exception:
        logger.exception('EXCEPTION')
        return []


# Translate RFC / DOT Conflict FA Variable Strings:
def translate_rfc_fa(input_fa_str):
    try:
        if input_fa_str == 'fitex' or input_fa_str == 'exlvl':
            fa_res_str = 'exertion'
        elif input_fa_str == 'extremeheat':
            fa_res_str = 'extreme heat'
        elif input_fa_str == 'extremecold':
            fa_res_str = 'extreme cold'
        elif input_fa_str == 'atmosphericconditions':
            fa_res_str = 'atmospheric conditions'
        elif input_fa_str == 'climblrs':
            fa_res_str = 'climb ladders/ropes/scaffolds'
        elif input_fa_str == 'climbrampstair':
            fa_res_str = 'climb ramps/stairs'
        elif input_fa_str == 'colorvision':
            fa_res_str = 'color vision'
        elif input_fa_str == 'depthperception':
            fa_res_str = 'depth perception'
        elif input_fa_str == 'exposedheights':
            fa_res_str = 'exposed heights'
        elif input_fa_str == 'exposuretoweather':
            fa_res_str = 'exposure to weather'
        elif input_fa_str == 'faracuity':
            fa_res_str = 'far acuity'
        elif input_fa_str == 'nearacuity':
            fa_res_str = 'near acuity'
        elif input_fa_str == 'fieldofvision':
            fa_res_str = 'field of vision'
        elif input_fa_str == 'footcontrols':
            fa_res_str = 'foot controls'
        elif input_fa_str == 'toxiccausticchemicals':
            fa_res_str = 'toxic caustic chemicals'
        else:
            fa_res_str = input_fa_str
        return fa_res_str
    except Exception:
        logger.exception('EXCEPTION')
        return input_fa_str


# Translate RFC / DOT Conflict LOL Variable Strings:
def translate_rfc_lol(input_lol_str):
    try:
        flagval_NOFCloldict = {'S': 'Sedentary', 'L': 'Light', 'M': 'Medium', 'H': 'Heavy', 'VH': 'Very Heavy',
                               'N': 'never', 'O': 'occasional', 'F': 'frequent', 'C': 'constant',
                               'OCCASIONALEQUIV': 'equivalent to occasional', 'FREQUENTEQUIV': 'equivalent to frequent'}
        if input_lol_str in flagval_NOFCloldict.keys():
            return flagval_NOFCloldict[input_lol_str]
        else:
            if input_lol_str.isdigit():
                return input_lol_str
            else:
                err_str = "iqrgenerator_common_calcs.translate_rfc_lol() - input_lol_str (%s) not in flagval_NOFCloldict" % str(
                    input_lol_str)
                logger.critical(err_str)
                return input_lol_str
    except Exception:
        logger.exception('EXCEPTION')
        err_str = 'input_lol_str: %s' % str(input_lol_str)
        logger.exception(err_str)
        return input_lol_str


# Gather all UNIQUE target values from
# target container (schema 2 compliant):
def gather_container_tgt(input_dict, tgt_key, tgt_nm, tgt_ord_num, tgt_ord_num_subnm, tgt_ord_num_subval):
    '''Gather unique target values from all tgt_key observations
	in an INSIGHT observation dictionary.
	
	Args:
		input_dict {dict}: An INSIGHT observation
			dict containing an 'mdi' key.
		tgt_key {str}: The INSIGHT observation dict
			key value to target.
		tgt_nm {str}: The INSIGHT observation dict
			key value to target within the tgt_key
			values.
		tgt_ord_num {str}: The target ORD_NUM value to
			use to filter results.  If 'U', will not 
			apply filter.
		tgt_ord_num_subnm {str}: The target ORD_NUM sub-name
			to target using the value present in 'tgt_ord_nm', e.g.
			'S4_ORD_NUM'. If 'U', will not apply filter.
		tgt_ord_num_subval {int}: The target ORD_NUM sub-name
			value to target using the value present in 'tgt_ord_nm'.
			If 'U', will not apply filter.
	Returns:
		cui_list {list}: A list of unique 'CUI'
			values contained in the 'mdi'
			observations.
	Raises:
		N/A (returns empty list if exception).
	'''
    try:
        if tgt_ord_num == 'U':
            if tgt_ord_num_subnm == 'U':
                tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key]]
            else:
                tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key] if d[tgt_ord_num_subnm] == tgt_ord_num_subval]
        else:
            if tgt_ord_num_subnm == 'U':
                tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key] if d['ORD_NUM'] == tgt_ord_num]
            else:
                tgt_lol = [d[tgt_nm] for d in input_dict[tgt_key] if
                           d['ORD_NUM'] == tgt_ord_num and d[tgt_ord_num_subnm] == tgt_ord_num_subval]
        tgt_list = cfx.flatten_irreg(tgt_lol)
        tgt_list = list(tgt_list)
        tgt_list = list(set(tgt_list))
        return tgt_list
    except Exception:
        logger.exception('EXCEPTION')
        return []


# Convert structured data rows into a 
# 'CLAIMDISP_STRUCT' value:
def convert_struct_claimdisp(input_dictlist):
    '''Convert ARCHWKUT structured data observations
	into a more 'claimdisp'-like, individual claim-centric
	series of observations.
	
	Args:
		input_dictlist {List}: A list of dicts, where each
			dict equals an observation in 'struct_hodisp'
			associated with a given claim entity as extracted
			via database_actions.retrieve_case_entity_schema2().
	Returns:
		struct_claimdisp_resdictlist {list}: A list of 
			dictionaries, each dictionary representing
			an individual claim. An INSIGHT observations
			'CLAIMDISP_STRUCT' value.
	Raises:
		N/A (returns empty list if exception).
	'''
    try:
        struct_claimdisp_resdictlist = []
        for i, row in enumerate(input_dictlist):

            # Get CL age at FNL_DSPN_DT:
            clmt_age_fnl_dspn_dt = dh.calc_age(row['CLMT_DOB'], row['FNL_DSPN_DT'])

            clm_typ = row['CLM_TYP']

            # Parse T2 DWB:
            if clm_typ == 'DIWW':
                resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                           'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                resdict['CLM_TYP'] = 'T2 DWB'
                resdict['APP_DT'] = row['T2_APP_DT']
                resdict['PFLG_DT'] = row['T2_PFLG_DT']
                resdict['DSPN_CD'] = row['T2_DSPN_CD']
                resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                struct_claimdisp_resdictlist.append(resdict)

            # Parse T2 DIB:
            # TIP: No instances where a 'DIWC' value is
            # paired with a 'W' BIC variant.
            elif clm_typ == 'DIWC':
                if row['BIC'].startswith('C'):
                    resdict = {}
                    resdict['CLM_TYP'] = 'T2 CDB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                    resdict['DLI'] = row['DLI']
                    resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                else:
                    if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                        resdict = {}
                        resdict['CLM_TYP'] = 'T2 DIB Termination'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        resdict = {}
                        resdict['CLM_TYP'] = 'T2 DIB'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['ALLGD_DISB_ONST_DT'] = row['ALLGD_DISB_ONST_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['FNL_DSPN_DT'] = row['FNL_DSPN_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)

            # Parse T16 SSI:
            elif clm_typ == 'SSID':
                if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI Termination (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                else:
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:

                            clmt_age_t16_app_dt_ultimate = 'E'
                            if row['T16_PFLG_DT'] != 'E':
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_PFLG_DT'])
                            else:
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_APP_DT'])

                            if clmt_age_t16_app_dt_ultimate == 'E':
                                resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                           'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                                resdict['APP_DT'] = row['T16_APP_DT']
                                resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                struct_claimdisp_resdictlist.append(resdict)
                            else:
                                clmt_age_t16_app_dt_ultimate_yr = clmt_age_t16_app_dt_ultimate.split('-')[0]
                                if clmt_age_t16_app_dt_ultimate_yr >= 18:
                                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                                else:
                                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI Adult+Child'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)

            # Parse concurrent observations:
            elif clm_typ == 'SSDC':
                # Parse T2 portion:
                if row['BIC'].startswith('C'):
                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                    resdict['CLM_TYP'] = 'T2 CDB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                elif row['BIC'].startswith('W'):
                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                    resdict['CLM_TYP'] = 'T2 DWB'
                    resdict['APP_DT'] = row['T2_APP_DT']
                    resdict['PFLG_DT'] = row['T2_PFLG_DT']
                    resdict['DLI'] = row['DLI']
                    resdict['DSPN_CD'] = row['T2_DSPN_CD']
                    resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                    struct_claimdisp_resdictlist.append(resdict)
                else:
                    if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T2 DIB Termination'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T2 DIB'
                        resdict['APP_DT'] = row['T2_APP_DT']
                        resdict['DLI'] = row['DLI']
                        resdict['PFLG_DT'] = row['T2_PFLG_DT']
                        resdict['DSPN_CD'] = row['T2_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T2_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)

                # Parse T16 portion:
                if row['HRG_TYP'].endswith('1') or row['HRG_TYP'].endswith('3') or row['HRG_TYP'].endswith('6'):
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI Termination (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Termination Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)
                else:
                    if clmt_age_fnl_dspn_dt == 'E':
                        resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                   'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                        resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                        resdict['APP_DT'] = row['T16_APP_DT']
                        resdict['PFLG_DT'] = row['T16_PFLG_DT']
                        resdict['DSPN_CD'] = row['T16_DSPN_CD']
                        resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                        struct_claimdisp_resdictlist.append(resdict)
                    else:
                        if int(clmt_age_fnl_dspn_dt.split('-')[0]) >= 18:
                            clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_APP_DT'])
                            if row['T16_PFLG_DT']:
                                clmt_age_t16_app_dt_ultimate = dh.calc_age(row['CLMT_DOB'], row['T16_PFLG_DT'])
                            if clmt_age_t16_app_dt_ultimate == 'E':
                                resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                           'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                resdict['CLM_TYP'] = 'T16 SSI (Type Unknown)'
                                resdict['APP_DT'] = row['T16_APP_DT']
                                resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                struct_claimdisp_resdictlist.append(resdict)
                            else:
                                clmt_age_t16_app_dt_ultimate_yr = clmt_age_t16_app_dt_ultimate.split('-')[0]
                                if clmt_age_t16_app_dt_ultimate_yr >= 18:
                                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                                else:
                                    resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                               'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                                    resdict['CLM_TYP'] = 'T16 SSI Adult+Child'
                                    resdict['APP_DT'] = row['T16_APP_DT']
                                    resdict['PFLG_DT'] = row['T16_PFLG_DT']
                                    resdict['DSPN_CD'] = row['T16_DSPN_CD']
                                    resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                                    struct_claimdisp_resdictlist.append(resdict)
                        else:
                            resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                                       'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                            resdict['CLM_TYP'] = 'T16 SSI Child'
                            resdict['APP_DT'] = row['T16_APP_DT']
                            resdict['PFLG_DT'] = row['T16_PFLG_DT']
                            resdict['DSPN_CD'] = row['T16_DSPN_CD']
                            resdict['PRTL_FFVRBL_CD'] = row['T16_PRTL_FFVRBL_CD']
                            struct_claimdisp_resdictlist.append(resdict)

            # Output 'U' for all other values that are T2/T16-dependent:
            else:
                resdict = {'ALLGD_DISB_ONST_DT': row['ALLGD_DISB_ONST_DT'], 'DLI': row['DLI'],
                           'FNL_DSPN_DT': row['FNL_DSPN_DT']}
                resdict['CLM_TYP'] = row['CLM_TYP']
                resdict['APP_DT'] = 'U'
                resdict['PFLG_DT'] = 'U'
                resdict['DSPN_CD'] = 'U'
                resdict['PRTL_FFVRBL_CD'] = 'U'
                struct_claimdisp_resdictlist.append(resdict)

        # Return results:
        return struct_claimdisp_resdictlist

    except Exception:
        logger.exception('EXCEPTION')
        return []


# Convert 'CLAIMDISP_STRUCT' into a string of
# disposition types (with claim type parentheticals):
def parse_disp_type_struct(input_dictlist):
    '''Output a disposition type translation for the INSIGHT
	Web App by parsing an INSIGHT 'CLAIMDISP_STRUCT' list
	of dictionaries value.
	'''
    try:
        struct_disp_restuplist = []
        for subd in input_dictlist:
            if subd['DSPN_CD'] in ['FAFF', 'FREV']:
                prtl_ffvrbl_cd = subd['PRTL_FFVRBL_CD'].strip()
                if prtl_ffvrbl_cd == 'F':
                    struct_disp_restuplist.append(("Fully Favorable", subd['CLM_TYP']))
                elif subd['PRTL_FFVRBL_CD'] in ['L', 'C']:
                    struct_disp_restuplist.append(("Partially Favorable", subd['CLM_TYP']))
                else:
                    struct_disp_restuplist.append(("Favorable", subd['CLM_TYP']))
            elif subd['DSPN_CD'] in ['UAFF', 'UREV']:
                struct_disp_restuplist.append(("Unfavorable", subd['CLM_TYP']))
            elif 'DI' in subd['DSPN_CD']:
                struct_disp_restuplist.append(("Dismissal", subd['CLM_TYP']))
            else:
                struct_disp_restuplist.append(("Unknown", subd['CLM_TYP']))
        # If all claims share the same disposition type,
        # only output the disposition type:
        if len({f for f, g in struct_disp_restuplist}) == 1:
            return struct_disp_restuplist[0][0]
        # Else, output a string formatted as "[disposition type for
        # claim X] ([claim X type]); etc."
        else:
            return '; '.join(['%s (%s)' % (tup[0], tup[1]) for tup in struct_disp_restuplist])
    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Define translation function for
# 'stock' values, i.e. 'U', 'P', 'E', '':
def trans_stock_vals(iqval):
    try:
        bgval_transdict = {"U": "Unknown", "P": "Unknown", "E": "Error", "": "Unknown"}
        iqval = iqval.strip().upper()
        if "; " not in iqval:
            if iqval in bgval_transdict.keys():
                return bgval_transdict[iqval]
            else:
                logger.critical('iqrgenerator.trans_stock_vals() error - iqval not in bgval_transdict:')
                logger.critical(iqval)
                return bgval_transdict["E"]
        else:
            iqvalsplit = iqval.split("; ")
            if len(iqvalsplit) == len([v for v in iqvalsplit if v in bgval_transdict.keys()]):
                return bgval_transdict["U"]
            else:
                return bgval_transdict["E"]
    except Exception, x:
        logger.exception('EXCEPTION')
        errmsg = "Report Generation Error"
        return errmsg


# Define translation function for
# 'single ORD_NUM' finding child table values:
def createbgtxt_findingchild(input_dict, tgt_child_colnm, tgt_subkey_nm, sortver, transdict):
    """Background text creation function for
	# 'single key' finding child table values. If no values found,
	will return 'Unknown'.

	Args:
		input_dict {dict}: An INSIGHT observation dictionary.
		tgt_child_colnm {str}: The column name for the targeted finding
			child table (e.g. 's2').
		tgt_subkey_nm {str}: The targeted key value within the targeted
			finding child table (e.g. 's2ver').
		sortver {int}: Whether to sort by ORD_NUM - if 1, sort; if 0, do not sort.
		transdict {dict}: A dictionary containing string translations
			for INSIGHT 'tgt_subkey_nm' data point values. If empty dict
			passed, then no value-by-value translation will be attempted.
	Returns:
		A string containing the created text or 'Unknown' if no values found.
	Raises:
		N/A (will return 'Unknown' if error translating any retrieved value).
	"""
    try:
        # Get child table observation dict list:
        chd_dictlist = input_dict[tgt_child_colnm]
        if not chd_dictlist:
            return trans_stock_vals('U')

        # Sort according to 'ORD_NUM' value:
        if sortver == 1:
            chd_dictlist_sorted = sorted(chd_dictlist, key=lambda x: x['ORD_NUM'])
        else:
            chd_dictlist_sorted = chd_dictlist

        # Get target value in each observation:
        if tgt_subkey_nm != 'U':
            tgt_subkey_val_list = [subd[tgt_subkey_nm] for subd in chd_dictlist_sorted]
        else:
            tgt_subkey_val_list = chd_dictlist

        # Parse target value list to return appropriate translation:
        if not tgt_subkey_val_list:
            return 'Unknown'
        else:
            if not transdict:
                tgt_subkey_val_list_unique = []
                for v in tgt_subkey_val_list:
                    if v not in tgt_subkey_val_list_unique:
                        tgt_subkey_val_list_unique.append(v)
                return '; '.join(tgt_subkey_val_list_unique)
            tgt_subkey_val_translist = []
            for vres in tgt_subkey_val_list:
                for vsplit in vres.split('; '):
                    if vsplit in transdict.keys():
                        tgt_subkey_val_translist.append(transdict[vsplit])
                    elif vsplit in ['U', 'P']:
                        tgt_subkey_val_translist.append(trans_stock_vals('U'))
                    else:
                        err_msg = "ERROR iqrgenerator.createbgtxt_findingchild(): '%s' not in transdict for '%s'" % (
                            str(vsplit), str(tgt_subkey_nm))
                        logger.critical(err_msg)
                        tgt_subkey_val_translist.append(trans_stock_vals('E'))
            # If ANY error in translist, output only 'Error':
            if 'Error' in tgt_subkey_val_translist:
                return 'Unknown'
            else:
                # Only return unique values (keeping sequential order)
                tgt_subkey_val_translist_unique = []
                for v in tgt_subkey_val_translist:
                    if v not in tgt_subkey_val_translist_unique:
                        tgt_subkey_val_translist_unique.append(v)
                return '; '.join(tgt_subkey_val_translist_unique)
    except Exception:
        logger.exception('EXCEPTION')
        err_str = 'createbgtxt_findingchild() exception on DOCU_CTL_ID %s - tgt_child_colnm = %s - tgt_subkey_nm = %s' % (
            input_dict['DOCU_CTL_ID'], tgt_child_colnm, tgt_subkey_nm)
        logger.critical(err_str)
        return trans_stock_vals('U')


# Translate child table structured data (keep all instances)
def createbgtxt_findingchild_all(input_dict, tgt_child_colnm, tgt_subkey_nm, sortver, transdict):
    """Background text creation function for
	# 'single key' finding child table values. If no values found,
	will return 'Unknown'.  Will not force values to be unique.

	Args:
		input_dict {dict}: An INSIGHT observation dictionary.
		tgt_child_colnm {str}: The column name for the targeted finding
			child table (e.g. 's2').
		tgt_subkey_nm {str}: The targeted key value within the targeted
			finding child table (e.g. 's2ver').
		sortver {int}: Whether to sort by ORD_NUM - if 1, sort; if 0, do not sort.
		transdict {dict}: A dictionary containing string translations
			for INSIGHT 'tgt_subkey_nm' data point values. If empty dict
			passed, then no value-by-value translation will be attempted.
	Returns:
		A string containing the created text or 'Unknown' if no values found.
	Raises:
		N/A (will return 'Unknown' if error translating any retrieved value).
	"""
    try:
        # Get child table observation dict list:
        chd_dictlist = input_dict[tgt_child_colnm]
        if not chd_dictlist:
            return trans_stock_vals('U')

        # Sort according to 'ORD_NUM' value:
        if sortver == 1:
            chd_dictlist_sorted = sorted(chd_dictlist, key=lambda x: x['ORD_NUM'])
        else:
            chd_dictlist_sorted = chd_dictlist
        # Get target value in each observation:
        tgt_subkey_val_list = [subd[tgt_subkey_nm] for subd in chd_dictlist_sorted]
        # Parse target value list to return appropriate translation:
        if not tgt_subkey_val_list:
            return 'Unknown'
        else:
            if not transdict:
                tgt_subkey_val_list_unique = []
                for v in tgt_subkey_val_list:
                    if v not in tgt_subkey_val_list_unique:
                        tgt_subkey_val_list_unique.append(v)
                return '; '.join(tgt_subkey_val_list_unique)
            tgt_subkey_val_translist = []
            for vres in tgt_subkey_val_list:
                for vsplit in vres.split('; '):
                    if vsplit in transdict.keys():
                        tgt_subkey_val_translist.append(transdict[vsplit])
                    else:
                        err_msg = "ERROR iqrgenerator.createbgtxt_findingchild(): '%s' not in transdict for '%s'" % (
                            str(vsplit), str(tgt_subkey_nm))
                        logger.critical(err_msg)
                        tgt_subkey_val_translist.append(trans_stock_vals('E'))
            # If ANY error in translist, output only 'Error':
            if 'Error' in tgt_subkey_val_translist:
                return 'Unknown'
            else:
                # Return all values:
                return '; '.join(tgt_subkey_val_translist)
    except Exception:
        logger.exception('EXCEPTION')
        err_str = 'createbgtxt_findingchild() exception on DOCU_CTL_ID %s - tgt_child_colnm = %s - tgt_subkey_nm = %s' % (
            input_dict['DOCU_CTL_ID'], tgt_child_colnm, tgt_subkey_nm)
        logger.critical(err_str)
        return trans_stock_vals('U')


# Calculate OAO RR deadline given an input disposition date:
def calc_rr_deadline(input_date_str):
    '''Calculate the OAO RR deadline based on an
	input disposition date value (either dspn_doc.did or
	struct_hodisp.FNL_DSPN_DT).
	
	TIP: In line with at least Court Branch guidance (and
	in my opinion a plain reading of the HALLEX provisions
	on RR timeliness), we do not count the date of decision
	as one of the 65 days we use to determine the deadline.
	
	Args:
		input_date_str {str}: The input disposition date
			value.
	Returns:
		rr_deadline_restup {tuple}: A tuple where 
			tup[0] = An RR deadline date string
			formatted as 'MM/DD/YYYY' or 'E' if exception
			occurs.
			tup[1] = An optional explanatory parentheticals
			string explaining how the RR deadline date was
			formulated, or 'U' if no explanation needed, or 'E'
			if exception occurs.
	Raises:
		N/A (returns tuple containing 'E' values if
			exception occurs).
	'''
    try:
        rr_deadline_restup = ('E', 'U')
        input_date_dt = dh.parse_date_todatetime_struct(input_date_str)
        if input_date_dt == 'E':
            return rr_deadline_restup
        rr_deadline_dt = input_date_dt + timedelta(days=65)
        if rr_deadline_dt == 'E':
            return rr_deadline_restup
        else:
            if rr_deadline_dt.weekday() == 5:
                rr_deadline_dt = rr_deadline_dt + timedelta(days=2)
                rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                if rr_deadline_str in ['07/04/2017', '09/04/2017', '10/09/2017', '11/10/2017', '11/23/2017',
                                       '12/25/2017', '01/01/2018', '01/15/2018', '02/19/2018', '05/28/2018',
                                       '07/04/2018', '09/03/2018', '10/08/2018', '11/12/2018', '11/22/2018',
                                       '12/25/2018']:
                    rr_deadline_dt = rr_deadline_dt + timedelta(days=1)
                    rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                    rr_deadline_explan_str = ' (2 days added due to deadline falling on a Saturday; 1 day added due to deadline falling on a Federal holiday)'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)
                else:
                    rr_deadline_explan_str = ' (2 days added due to deadline falling on a Saturday)'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)

            elif rr_deadline_dt.weekday() == 6:
                rr_deadline_dt = rr_deadline_dt + timedelta(days=1)
                rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                if rr_deadline_str in ['07/04/2017', '09/04/2017', '10/09/2017', '11/10/2017', '11/23/2017',
                                       '12/25/2017', '01/01/2018', '01/15/2018', '02/19/2018', '05/28/2018',
                                       '07/04/2018', '09/03/2018', '10/08/2018', '11/12/2018', '11/22/2018',
                                       '12/25/2018']:
                    rr_deadline_dt = rr_deadline_dt + timedelta(days=1)
                    rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                    rr_deadline_explan_str = ' (1 day added due to deadline falling on a Sunday; 1 day added due to deadline falling on a Federal holiday)'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)
                else:
                    rr_deadline_explan_str = ' (1 day added due to deadline falling on a Sunday)'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)

            else:
                rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                if rr_deadline_str in ['07/04/2017', '09/04/2017', '10/09/2017', '11/10/2017', '11/23/2017',
                                       '12/25/2017', '01/01/2018', '01/15/2018', '02/19/2018', '05/28/2018',
                                       '07/04/2018', '09/03/2018', '10/08/2018', '11/12/2018', '11/22/2018',
                                       '12/25/2018']:
                    rr_deadline_dt = rr_deadline_dt + timedelta(days=1)
                    rr_deadline_str = dh.parse_datetime_to_ifs_date(rr_deadline_dt)
                    rr_deadline_explan_str = ' (1 day added due to deadline falling on a Federal holiday)'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)
                else:
                    rr_deadline_explan_str = 'U'
                    rr_deadline_restup = (rr_deadline_str, rr_deadline_explan_str)
            return rr_deadline_restup
    except Exception:
        logger.exception('EXCEPTION')
        return ('E', 'E')
