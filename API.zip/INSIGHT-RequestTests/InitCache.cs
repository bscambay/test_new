﻿using INSIGHT_Request;
using INSIGHT_Request.Models;
using INSIGHT_Request.Util;
using Newtonsoft.Json;
using System;
using System.Data;
using System.IO;
using System.Runtime.Caching;

namespace INSIGHT_RequestTests
{
    public class InitCache
    {
        public void addCacheObjects()
        {
            ObjectCache cache = MemoryCache.Default;

            DataSet appSettingDS = (DataSet)cache["appSettingDS"];
            string psqlUID = (string)cache["psqlUID"];
            string psqlPWD = (string)cache["psqlPWD"];

            string db2DSN = (string)cache["db2DSN"];
            string db2UID = (string)cache["db2UID"];
            string db2PWD = (string)cache["db2PWD"];
            string db2SCHEMA = (string)cache["db2SCHEMA"];

            string mhaDSN = (string)cache["mhaDSN"];
            string mhaUID = (string)cache["mhaUID"];
            string mhaPWD = (string)cache["mhaPWD"];
            string mhaSCHEMA = (string)cache["mhaSCHEMA"];
            string medibSCHEMA = (string)cache["medibSCHEMA"];
            string insightConnection = (string)cache["insightConnection"];
            string insightConnectionOAO = (string)cache["insightConnectionOAO"];
            string insightReportUrlOAO = (string)cache["insightReportUrlOAO"];


            CacheItemPolicy policy = new CacheItemPolicy();

            StreamReader SecFile = null;

            try
            {
                SecFile = File.OpenText(AppDomain.CurrentDomain.BaseDirectory + "\\.sec.json");
            }
            catch (FileNotFoundException f)
            {

                //For Command Line
                string secfilepath = Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, @"..\..\..\..\..\..\"));

                try
                {
                    SecFile = System.IO.File.OpenText(secfilepath + "\\.sec.json");
                }
                catch (FileNotFoundException)
                {
                    secfilepath = Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, @"..\..\..\"));

                    SecFile = System.IO.File.OpenText(secfilepath + "\\.sec.json");
                }
            }            

            string SecObj = SecFile.ReadToEnd();
            SecFile.Close();
            Sec sec = JsonConvert.DeserializeObject<Sec>(SecObj);

            //TODO: Convert Settings to DataTable and retrieval function need to do major refactoring here

            psqlUID = sec.uid;
            cache.Set("psqlUID", psqlUID, policy);

            psqlPWD = sec.pwd;
            cache.Set("psqlPWD", psqlPWD, policy);            

            appSettingDS = WWData.getSettingDS();
            cache.Set("appSettingDS", appSettingDS, policy);


            mhaDSN = Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-dsn");

            //mhaDSN = WWData.GetSetting("mha-dsn", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaDSN", mhaDSN, policy);

            mhaUID = Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-uid");

            //mhaUID = WWData.GetSetting("mha-uid", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaUID", mhaUID, policy);

            mhaPWD = Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-pwd");

            //mhaPWD = WWData.GetSetting("mha-pwd", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaPWD", mhaPWD, policy);

            mhaSCHEMA = Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-schema");

            //mhaSCHEMA = WWData.GetSetting("mha-schema", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaSCHEMA", mhaSCHEMA, policy);

            medibSCHEMA = Utils.ExtractValue(appSettingDS, "REF_SETTING", "medib-schema");

            //medibSCHEMA = WWData.GetSetting("medib-schema", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("medibSCHEMA", medibSCHEMA, policy);

            insightConnection = Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-connection-string");

            //insightConnection = WWData.GetSetting("insight-connection-string", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-connection-string", insightConnection, policy);

            insightConnectionOAO = Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-connection-string-oao");

            //insightConnectionOAO = WWData.GetSetting("insight-connection-string-oao", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-connection-string-oao", insightConnectionOAO, policy);

            insightReportUrlOAO = Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-oao-report-server");
            //insightConnectionOAO = WWData.GetSetting("insight-connection-string-oao", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-oao-report-server", insightReportUrlOAO, policy);

        }

    }
}
