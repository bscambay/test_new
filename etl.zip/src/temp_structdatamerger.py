# INSIGHT TEMPORARY STRUCTURED DATA FLAT FILE RETRIEVAL SCRIPT
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 12.15.2016
#
# SUMMARY: 
# Associates structured data stored in flat files but originating
# from SSA databases such as MHOADS with an observation of INSIGHT
# data related to a decision text instance.
#
# INPUT: 
# (1) A dictionary containing INSIGHT Extract data for a single
# hearing decision text string; 
#
# OUTPUT:
# A dictionary containing structured data associated with the UIDs present
# in the INSIGHT dictionary passed.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import os
import datetime
import logging
import os.path
import pandas
import numpy as np
import ifs_date_helper as dh

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up logging:
# TIP: logger.exception() is associated with the ERROR level.
# TIP: If root logger level were not modified, default would be WARNING.
logger = logging.getLogger('ifs')
logger.setLevel(logging.DEBUG)
log_fh = logging.FileHandler(os.path.join(logdir, "ifs_log.log"))
log_fh.setLevel(logging.DEBUG)
log_ch = logging.StreamHandler()
log_ch.setLevel(logging.WARNING)
log_formatter = logging.Formatter('%(asctime)s || %(name)s || %(levelname)s || %(message)s')
log_fh.setFormatter(log_formatter)
log_ch.setFormatter(log_formatter)
logger.addHandler(log_fh)
logger.addHandler(log_ch)

# Load structured data flat files:
structdf_list = []
# TODO: Add FY 15-beyond new structured data file and (if needed) comment out the files below). Because you'll only
# need this file when running batch processing locally, no need to migrate it over to S1FF500.
# structdf_fy2014_1 = pandas.read_csv(os.path.join(datadir, "STRUCT_DATA_FY2014.csv"), dtype=str, error_bad_lines=False)
# structdf_fy2014_1 = structdf_fy2014_1.replace(np.nan, "")
# structdf_list.append(structdf_fy2014_1)
# structdf_fy2015_1 = pandas.read_csv(os.path.join(datadir, "STRUCT_DATA_FY2015.csv"), dtype=str, error_bad_lines=False)
# structdf_fy2015_1 = structdf_fy2015_1.replace(np.nan, "")
# structdf_list.append(structdf_fy2015_1)
# structdf_fy2015_2 = pandas.read_csv(os.path.join(datadir, "STRUCT_DATA_FY2015_SAMPLE.csv"), dtype=str, error_bad_lines=False)
# structdf_fy2015_2 = structdf_fy2015_2.replace(np.nan, "")
# structdf_list.append(structdf_fy2015_2)

# TEMPORARY: Adding in validation quality subset structured data:
validationdf = pandas.read_csv(os.path.join(insightdir, 'test/functional/quality_study/qstudy_struct_data_rjk_v2.csv'), dtype=str, error_bad_lines=False)
validationdf = validationdf.replace(np.nan, "")
structdf_list.append(validationdf)


# Define structured data merging function:
def run(isdl_input_dict, isdl_tgt_uid):
	"""Uses UID values contained in a dictionary of INSIGHT data related to
	a single decision text entity to retrieve select structured data values
	related to that decision/claim/claimant that originate from SSA databases
	such as MHOADS, MEDIB, etc., but are housed in flat files.

	NOTE: This will retrieve ALL data values associated with the tgt_uid in
	input_dict, even those you won't end up saving via IFSDA/IFSDAB.
	
	Args:
			isdl_input_dict: {dict} A dictionary containing structured data values
				related to a single item of decision text processed by INISGHT
				extract.
			isdl_tgt_uid {str} [default='DOCU_CTL_ID'] The UID data point name
				to utilize to retrieve structured data.
	Returns:
			A dictionary containing structured data point values associated with
			the UIDs contained in isdl_input_dict.	Any data point that is unable
			to be retrieved will be assigned a 'U' value.  Any data point whose
			retrieval is compromised by an error (e.g. a key error) will be
			assigned an 'E' value.
	Raises:
			TypeError: Parameter passed is not appropriate type.
	"""
	try:
		# Check arguments:
		if bool(isinstance(isdl_input_dict, dict)) is False:
			raise TypeError
		if bool(isinstance(isdl_tgt_uid, str)) is False:
			raise TypeError


		# Set parameter values:
		tgt_uid = isdl_tgt_uid
		if tgt_uid.strip().lower() in ['default', '']:
			tgt_uid = 'DOCU_CTL_ID'


		# Retrieve UID from INSIGHT dictionary; if KeyError, return dictionary of
		# structured data points with 'E' values:
		try:
			tgt_uid_val = isdl_input_dict[tgt_uid]
		except KeyError:
			logger.exception('EXCEPTION')
			logger.critical('Unable to locate UID value in INSIGHT dict?')
			struct_colnms = [df.columns.tolist() for df in structdf_list]
			struct_colnms = [item for sublist in struct_colnms for item in sublist]
			struct_colnms_unique = list(set(struct_colnms))
			struct_dict = dict((k,'E') for k in struct_colnms_unique)
			return struct_dict
			

		# If UID retrieved but not a usable value, return 'E' structured data values:
		if tgt_uid_val in ['U', ''] or tgt_uid_val is None:
			logger.exception('EXCEPTION')
			logger.critical('Located UID value in INSIGHT dict but unuseable?')
			struct_colnms = [df.columns.tolist() for df in structdf_list]
			struct_colnms = [item for sublist in struct_colnms for item in sublist]
			struct_colnms_unique = list(set(struct_colnms))
			struct_dict = dict((k,'E') for k in struct_colnms_unique)
			return struct_dict

		# Retrieve all structured data:
		struct_data_dict_list = []
		for df in structdf_list:
			# IN DEVELOPMENT: Harmonize all empty *structured* data values
			# as empty strings:
			df.fillna('', inplace=True)
			df.replace('EMPTY', '', inplace=True)
			# TIP: Drop DUPs - should not affect data retrieval
			# unless a structured data observation has no data, and
			# given that I'm working with Robyn et al. to design
			# the structured data pulls, I know that won't be the case.
			df.drop_duplicates(subset='DOCU_CTL_ID', inplace=True)
			try:
				resdf = df.loc[df[tgt_uid] == tgt_uid_val]
				if len(resdf) == 0:
					continue
				elif len(resdf) == 1:
					resdf_dict = resdf.to_dict(orient='records')[0]
					struct_data_dict_list.append(resdf_dict)
				elif len(resdf) >= 1:
					continue
			except KeyError:
				pass


		# Merge list of resulting dictionaries:
		# TIP: Rule is take the first non-empty value for a given key.
		struct_data_dict_parsed = {}
		for d in struct_data_dict_list:
			for k,v in d.iteritems():
				if k not in struct_data_dict_parsed.keys():
					struct_data_dict_parsed[k] = v
				else:
					if struct_data_dict_parsed[k] in ['E', 'EMPTY', 'U', '']:
						struct_data_dict_parsed[k] = v
		
		# Ensure uniform output by ensuring every possible structured
		# data point name present in CSVs is output with a value:
		# OPENQ: Is this necessary? Didn't you already do this 'E' assignment?
		struct_colnms = [df.columns.tolist() for df in structdf_list]
		struct_colnms = [item for sublist in struct_colnms for item in sublist]
		struct_colnms_unique = list(set(struct_colnms))
		for nm in struct_colnms_unique:
			if nm in struct_data_dict_parsed.keys():
				pass
			else:
				logger.critical("Apparently a column name wasn't found?")
				logger.critical('DECID=')
				logger.critical(tgt_uid_val)
				logger.critical(nm)
				struct_data_dict_parsed[nm] = 'E'

		# Return merged dictionary of structured data:
		return struct_data_dict_parsed
	
	except Exception:
		logger.exception('EXCEPTION')
		raise
		
# Testing:
if __name__ == '__main__':

	# Testing call:
	testres = run({'DOCU_CTL_ID':'A1001001A11J20B53319I69776'}, 'default')
	print type(testres)
	print testres
	
