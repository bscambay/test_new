# INSIGHT DATE HELPER UNIT TESTS
#
# AUTHOR:
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 12.23.2016
#
# SUMMARY:
# This module consists of a suite of tools designed to extract, normalize,
# and otherwise parse date strings and datetime objects.
#
# To simply convert a date present in text to a 'normalized' INSIGHT string
# format, the following workflow is required:
# (1) parse_date_tostr(date_string)
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# =============================================================================

import datetime
import logging
import os.path
import sys
import unittest
import numpy as np
import setup_config
import date_helper as dh

# Disable all logging during testing:
# TIP: Disabling does not persist beyond test execution.
for k, v in logging.Logger.manager.loggerDict.iteritems():
    logging.disable(logging.CRITICAL)


# Create unittest class:
class Test(unittest.TestCase):
    # def setUp(self):

    # TIP: Not testing parse_date() as it is a helper function used only
    # by parse_date_tostr().

    def test_parse_date_tostr(self):
        self.assertEqual(dh.parse_date_tostr(np.nan), 'E')
        self.assertEqual(dh.parse_date_tostr(100), 'E')
        self.assertEqual(dh.parse_date_tostr(100.00), 'E')
        self.assertEqual(dh.parse_date_tostr(unicode('January 24, 1984')), '01/24/1984')
        self.assertEqual(dh.parse_date_tostr('January 24, 1984'), '01/24/1984')
        self.assertEqual(dh.parse_date_tostr('January24,1984'), '01/24/1984')
        self.assertEqual(dh.parse_date_tostr('January241984'), '01/[?]/[?] [Original: January241984]')
        self.assertEqual(dh.parse_date_tostr('January, 1984'), '01/[?]/1984 [Original: January, 1984]')
        self.assertEqual(dh.parse_date_tostr('January 1984'), '01/[?]/1984 [Original: January 1984]')
        self.assertEqual(dh.parse_date_tostr('  1 9 8 4  '), '[?]/[?]/1984 [Original:   1 9 8 4  ]')
        self.assertEqual(dh.parse_date_tostr('19845'), 'E')
        # TIP: Ensures 'Jane' isn't misread as the beginning of 'January':
        self.assertEqual(dh.parse_date_tostr('Jane 24, 1984'), '[?]/24/1984 [Original: Jane 24, 1984]')
        # TIP: This date format is not something 'test_parse_date_tostr' is designed to handle, thus
        # it appropriately misses the '24':
        self.assertEqual(dh.parse_date_tostr('1984January24'), '01/[?]/1984 [Original: 1984January24]')

    def test_parse_date_todatetime_struct(self):
        self.assertEqual(dh.parse_date_todatetime_struct(np.nan), 'E')
        self.assertEqual(dh.parse_date_todatetime_struct(100), 'E')
        self.assertEqual(dh.parse_date_tostr(100.00), 'E')
        self.assertEqual(dh.parse_date_todatetime_struct('January 24, 1984'), datetime.datetime(1984, 1, 24, 0, 0, 0))
        self.assertEqual(dh.parse_date_todatetime_struct('01/24/1984'), datetime.datetime(1984, 1, 24, 0, 0, 0))
        self.assertEqual(dh.parse_date_todatetime_struct('1/24/1984'), datetime.datetime(1984, 1, 24, 0, 0, 0))
        self.assertEqual(dh.parse_date_todatetime_struct('24Jan1984'), datetime.datetime(1984, 1, 24, 0, 0, 0))
        self.assertEqual(dh.parse_date_todatetime_struct('1984-01-24'), datetime.datetime(1984, 1, 24, 0, 0, 0))
        self.assertEqual(dh.parse_date_todatetime_struct('Jannnuary 24, 1984'), 'E')

    def test_calc_age(self):
        self.assertEqual(dh.calc_age(np.nan, 'June 24, 2016'), 'E')
        self.assertEqual(dh.calc_age(100, 'June 24, 2016'), 'E')
        self.assertEqual(dh.calc_age(100.00, 'June 24, 2016'), 'E')
        self.assertEqual(dh.calc_age('June 24, 2016', np.nan), 'E')
        self.assertEqual(dh.calc_age('June 24, 2016', 100), 'E')
        self.assertEqual(dh.calc_age('June 24, 2016', 100.00), 'E')
        self.assertEqual(dh.calc_age('January 24, 1984', 'June 24, 2016'), '32-y-5-m')
        self.assertEqual(dh.calc_age('01/24/1984', 'June 24, 2016'), '32-y-5-m')
        self.assertEqual(dh.calc_age('1/24/1984', 'June 24, 2016'), '32-y-5-m')
        self.assertEqual(dh.calc_age('24Jan1984', 'June 24, 2016'), '32-y-5-m')
        self.assertEqual(dh.calc_age('1984-01-24', 'June 24, 2016'), '32-y-5-m')
        self.assertEqual(dh.calc_age('Jannnuary 24, 1984', 'June 24, 2016'), 'E')

    # def tearDown(self):


# Run:
if __name__ == '__main__':
    unittest.main(exit=False)
