﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class HearingWork
    {
        [JsonProperty("hearingWorkListing")]
        public List<HearingClaimant_O> HearingWorkListing { get; set; } = new List<HearingClaimant_O>();
        public List<HearingFolderDocument> HearingFolderDocuments { get; set; } = new List<HearingFolderDocument>();
        public string rid { get; set; } = "-1";

    }
}
