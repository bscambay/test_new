# INSIGHT STEP 4 'ACTUAL/GENERAL' PERFORMANCE VERDICT CLASSIFIER
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy 
# 
# DATE LAST UPDATED: 
# 09.09.2016
# 
# SUMMARY: 
# Analyzes 'raw' disability hearing decision text to extract a broad
# range of structured data about the content of that decision text.
# 
# INPUT: 
# (1) A full path to a text file containing a hearing decision's text with the 
# UID data built into the file name in the path.
# 
# OUTPUT: 
# (1) A dictionary containing INSIGHT Extract values.
# (2) A cleaned/normalized version of the hearing decision text as a string.
# 
# WARNING: The following is alpha-level/prototype software whose output
# quality has not yet been formally validated and whose documentation is not
# yet fully formed.
#=============================================================================

# Import modules:
import sys
import os
import os.path
import re
import logging
from operator import itemgetter
import regex
import string
import nltk
import pandas
import nlp_helper
import regex_strings as rs

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Identify relevant 'actual/general' performance snippets:
def find_actually_generally_snippets(text):
	try:
		# If key lang found in sent, add it to list:
		# COMPLETE: Review unfavorable templates to ensure
		# these are the only FIT language items for an actual and/or general performance finding.
		actgen_comp_list = [re.compile(rs.actually_words_regex),
							re.compile(rs.performed_in_economy_regex),
							re.compile(r'\bactuall?y? ?\w+? ?\w+? ?performe?d?|'
										'(' + rs.generally_words_regex + ') ?\w+? ?\w+? ?performe?d?', re.I),
							re.compile(r'(has ?been|was|is) ?(capable ?of ?performing|'
										'able ?to ?perform)', re.I),
							re.compile(r'in ?comparing ?the ?.{1,12} ?residual ?functional ?'
										'capacity ?(the ?claimant ?had ?prior ?to ?attaining ?'
										'age ?22|with ?the ?physical ?and ?mental ?demands ?of)', re.I)]
		
		# Searches for sentences that contain at least one of the regex elements
		return nlp_helper.regex_list_sent_search(text, actgen_comp_list)
	except Exception:
		logger.exception('EXCEPTION')
		raise

# Calculate the distance between regex search results:
def regex_result_shortest_distance(str, regex1, regex2):
	try:
		return min(abs(word1.start() - word2.start()) for word1 in re.finditer(regex1, str) for word2 in re.finditer(regex2, str))
	except Exception:
		logger.exception('EXCEPTION')
		raise

# Construct the feature vector:
# WARNING: This assumes text is Step 4 finding heading text ('s4txt')
# indicating the claimant can perform PRW and that there is only 1
# PRW job entity cited in the finding heading text.
def text_features(text):
	try:
		features = {}
		
		# Find pertinent sentences:
		sents = find_actually_generally_snippets(text)
		sents_ct = len(sents)
		
		# See what words show up together in any of the sentences,
		# and set the rest to false after having gone through all the sentences.
		for sent in sents:
			contains_undersigned = re.search(r'\bi.*that\b', sent, flags=re.I) or re.search(r'\bthe ?undersigned.*that\b', sent, flags=re.I)
			contains_actually = re.search(rs.actually_words_regex, sent)
			contains_generally = re.search(rs.generally_words_regex + '|' + rs.performed_in_economy_regex, sent)
			contains_neg = re.search(rs.neg_words_regex, sent)
			contains_pos = re.search(rs.pos_words_regex, sent)
			
			if contains_undersigned:
				if contains_actually and contains_generally:
					if contains_neg and contains_pos:
						actually_index = sent.index(contains_actually.group())
						generally_index = sent.index(contains_generally.group())					
						neg_index = sent.index(contains_neg.group())
						pos_index = sent.index(contains_pos.group())
						
						# These features won't be defaulted to false or differentiated by having unsigned,
						# since they're so rare.
						# Check if a negating conjunction is between actually and generally
						if 'but' in sent or 'yet' in sent:
							conj_index = sent.index(re.search(r'but|yet', sent).group())
							if actually_index < conj_index and conj_index < generally_index:
								features['actually conj generally'] = True
							elif generally_index < conj_index and conj_index < actually_index:
								features['generally conj actually'] = True
						
						index_dict = {'actually': actually_index, 'generally': generally_index,
										'neg': neg_index, 'pos': pos_index}
						index_order = sorted(index_dict.items(), key=itemgetter(1))
						index_order = [word for (word, _) in index_order]
						features['index order'] = tuple(index_order)
					elif contains_neg:
						features['sent with undersigned neg actually generally'] = True
					elif contains_pos:
						features['sent with undersigned pos actually generally'] = True
				elif contains_actually:
					if contains_neg:
						features['sent with undersigned neg actually'] = True
					elif contains_pos:
						features['sent with undersigned pos actually'] = True
				elif contains_generally:
					if contains_neg:
						features['sent with undersigned neg generally'] = True
					elif contains_pos:
						features['sent with undersigned pos generally'] = True
			else:
				if contains_actually and contains_generally:
					if contains_neg and contains_pos:
						actually_index = sent.index(contains_actually.group())
						generally_index = sent.index(contains_generally.group())
						neg_index = sent.index(contains_neg.group())
						pos_index = sent.index(contains_pos.group())
						
						# These features won't be defaulted to false, since they're so rare.
						# Check if a negating conjunction is between actually and generally
						if 'but' in sent or 'yet' in sent:
							conj_index = sent.index(re.search(r'but|yet', sent).group())
							if actually_index < conj_index and conj_index < generally_index:
								features['actually conj generally'] = True
							elif generally_index < conj_index and conj_index < actually_index:
								features['generally conj actually'] = True
						
						index_dict = {'actually': actually_index, 'generally': generally_index,
										'neg': neg_index, 'pos': pos_index}
						index_order = sorted(index_dict.items(), key=itemgetter(1))
						index_order = [word for (word, _) in index_order]
						features['index order'] = tuple(index_order)
					elif contains_neg:
						features['sent with neg actually generally'] = True
					elif contains_pos:
						features['sent with pos actually generally'] = True
				elif contains_actually:
					if contains_neg:
						features['sent with neg actually'] = True
					elif contains_pos:
						features['sent with pos actually'] = True
				elif contains_generally:
					if contains_neg:
						features['sent with neg generally'] = True
					elif contains_pos:
						features['sent with pos generally'] = True
		
		sent_keys = ['sent with undersigned neg actually generally', 'sent with undersigned pos actually generally',
					'sent with undersigned neg actually', 'sent with undersigned pos actually',
					'sent with undersigned neg generally', 'sent with undersigned pos generally',
					'sent with neg actually generally', 'sent with pos actually generally',
					'sent with neg actually', 'sent with pos actually', 'sent with neg generally',
					'sent with pos generally']
		for key in sent_keys:
			if key not in features:
				features[key] = False
		
		return features, sents_ct
	except Exception:
		logger.exception('EXCEPTION')
		raise

# Define training data generator:
def generate_default_training_data():
	try:
		df = pandas.read_csv(os.path.join(datadir, "s4_actgen_ml_labeled_data_07252016.csv"), dtype=str, na_filter=False)
		df = df[df['LABEL_ACTUAL'] != 'E']
		default_training_set = []
		for row_tuple in df.iterrows():
			row = row_tuple[1]
			if row['LABEL_ACTUAL'].upper() in ['1', '2', '3', '4', '5', '6', '7', '8', 'U', 'P', 'E']:
				row_features = (row['CONTEXT'], row['LABEL_ACTUAL'].upper())
				default_training_set.append(row_features)
		return default_training_set
	except Exception:
		logger.exception('EXCEPTION')
		raise	
	

# Define classifier class:
class S4ActgenClassifier(nltk.ClassifierI):
	def __init__(self, training_data=generate_default_training_data(), classifier=nltk.NaiveBayesClassifier):
		
		training_set = []
		for text, label in training_data:
			text_features_dict, text_features_sentct = text_features(text)
			training_set.append((text_features_dict, label))

		self.classifier = classifier.train(training_set)
			
	def classify(self, text):
		text_features_dict, text_features_sentct = text_features(text)
		# If NO sentences are found containing targeted actual/general lang,
		# return 'P':
		if text_features_sentct == 0:
			return 'P'
		else:
			if any(value for value in text_features_dict.itervalues()):
				label = self.classifier.classify(text_features_dict)
			else:
				label = 'P'
			return str(label)