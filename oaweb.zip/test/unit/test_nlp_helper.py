# unit test script for nlp_help.py which utilitize NLTK

import re
from types import ListType
import pytest
import setup_config
import nlp_helper as nh

class Test_nlp_helper(object):
    # this tests those modules variables what are used in the nlp_helper script
    def test_module_variables(self):
        assert isinstance(nh.stop_words_minus_conjunctions, ListType) and len(nh.stop_words_minus_conjunctions) > 0
        assert isinstance(nh.stop_words_minus_conjunctions, ListType) and len(nh.stop_words_minus_conjunctions) > 0

    # @pytest.mark.parametrize("", [])
    # this tests splitting text into sentences if no white-listed word is found at the end
    @pytest.mark.parametrize("input, expected_list_len", [("3. The claimant has the following severe impairments: degenerative joint disease, degenerative disc disease and COPD (20 CFR404.1520(c)", 2),
    ("I live in u.s.a, Actually Maryland", 1)
    ])
    def test_sentence_splitter(self, input, expected_list_len):
        returned = nh.sentence_splitter(input)
        assert isinstance(returned, ListType) and len(returned) == expected_list_len

    @pytest.mark.parametrize("input, expected_list_len", [("His name is Kurt Glaze, ph.d. He is an attorney.", 2)])
    # this tests splitting text into sentences with mesaging from removing spaces/periods between postnominal letters
    def test_sentence_splitter_nersa(self, input, expected_list_len):
        returned = nh.sentence_splitter_nersa(input)
        assert isinstance(returned, ListType) and len(returned) == expected_list_len

    @pytest.mark.parametrize("input, expected", [('Kurt A. Glaze', 'Kurt A. Glaze'),
    ('Kurt Aaron Tiberius Glaze, Jr.', 'Kurt Aaron Tiberius Glaze, Jr.'),
    ("JoEllen D'Andrea-Solis", "JoEllen D'Andrea-Solis")
    ])
    # this tests extracting full name from text
    def test_name_searcher(self, input, expected):
        returned = nh.name_searcher(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [('The Fullv Favorable decision is based on code(404. 116)','The Fully Favorable decision is based on code(404.116)')])
    # this test the correction of decision text
    def test_correct_decision_text(self, input, expected):
        returned = nh.correct_decision_text(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [('See Next Page......Page 1 of 5 for more decision related information    ', 'for more decision related information')])
    # this test removing "see next page" and extra white spaces from text
    def test_generate_sents(self, input, expected):
        returned = nh.generate_sents(input)
        assert isinstance(returned, ListType) and ''.join(returned) == expected

    @pytest.mark.parametrize("input, expected", [('The claimant HAS been able to perform gained activity', 'The claimant has been able to perform gained activity')])
    # this tests search for matching from a list of regex and stops search whenever there is a match
    def test_regex_list_sent_search(self, input, expected):
        actgen_comp_list = [
                            re.compile(r'(has ?been|was|is) ?(capable ?of ?performing|'
                                       'able ?to ?perform)', re.I),
                            re.compile(r'in ?comparing ?the ?.{1,12} ?residual ?functional ?'
                                       'capacity ?(the ?claimant ?had ?prior ?to ?attaining ?'
                                       'age ?22|with ?the ?physical ?and ?mental ?demands ?of)', re.I)]

        returned = nh.regex_list_sent_search(input, actgen_comp_list)

        assert isinstance(returned, ListType) and returned[0] == 'the claimant has been able to perform gained activity'

    @pytest.mark.parametrize("input, expected", [('The claimant has   been able to perform gained activity. Therefore    The undersigned made unfavorable decision', 'claimant able perform gained activity. Therefore undersigned made unfavorable decision')])
    # test stop word removal
    def test_remove_stopwords(self, input, expected):
        returned = nh.remove_stopwords(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [('The claimant has   been able to perform gained activity, Therefore    The undersigned made unfavorable decision', 'claimant able perform gained activity, Therefore undersigned made unfavorable decision')])
    # this tests stop word and punctuation removal
    def test_remove_stopwords_pluspunct(self, input, expected):
        returned = nh.remove_stopwords_pluspunct(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [('The claimant has   been able to perform gained activity, so    The undersigned made unfavorable decision', 'claimant able perform gained activity, undersigned made unfavorable decision')])
    # this tests stop words but not conjunctions removal
    def test_remove_stopwords_minusconjunctions(self, input, expected):
        returned = nh.remove_stopwords_minusconjunctions(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [("twenty - one", "21"),
    ('sixteen', '16'),
    ('2 hundred and 56', '256'),
    ('2/thirds', '2/3')
    ])
    # test text to integer conversion
    def test_text2int(self, input, expected):
        returned = nh.text2int(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [('23, 4444', '[?]/23/4444 [Original: 23, 4444]'), ('January 23, 4444', '01/23/4444')])
    # test date conversion
    def test_dateconvert(self, input, expected):
        returned = nh.dateconvert(input)
        assert returned == expected

    @pytest.mark.skip(reason="Skip this due to functionality issue")
    @pytest.mark.parametrize("input, expected", [
        ("ain't", "am not"),
        ("aren't", "are not"),
        ("cannot", "can not"),
        ("can't", "can not"),
        ("could've", "could have"),
        ("couldn't", "could not"),
        ("couldn't've", "could not have"),
        ("didn't", "did not"),
        ("doesn't", "does not"),
        ("don't", "do not"),
        ("hadn't", "had not"),
        ("hadn't've", "had not have"),
        ("hasn't", "has not"),
        ("haven't", "have not"),
        ("he'd", "he would"),
        ("he'll", "he will"),
        ("he's", "he is"),
        ("how'd", "how would"),
        ("how'll", "how will"),
        ("how's", "how is"),
        ("I'd", "I would"),
        ("I'll", "I will"),
        ("I'm", "I am"),
        ("I've", "I have"),
        ("isn't", "is not"),
        ("it'd", "it would"),
        ("it'll", "it will"),
        ("it's", "it is"),
        ("let's", "let us"),
        ("ma'am", "madam"),
        ("mightn't", "might not"),
        ("might've", "might have"),
        ("mustn't", "must not"),
        ("must've", "must have"),
        ("needn't", "need not"),
        ("not've", "not have"),
        ("o'clock", "of the clock"),
        ("oughtn't", "ought not"),
        ("shan't", "shall not"),
        ("she'd", "she would"),
        ("she'll", " she will"),
        ("she's", "she is"),
        ("should've", "should have"),
        ("shouldn't", "should not"),
        ("somebody'd", "somebody would"),
        ("somebody'll", "somebody will"),
        ("somebody's", "somebody is"),
        ("someone'd", "someone would"),
        ("someone'll", "someone will"),
        ("someone's", "someone is"),
        ("something'd", "something would"),
        ("something'll", "something will"),
        ("something's", "something is"),
        ("that'll", "that will"),
        ("that's", "that is"),
        ("there'd", "there would"),
        ("there're", "there are"),
        ("there's", "there is"),
        ("they'd", "they would"),
        ("they'll", "they will"),
        ("they're", "they are"),
        ("they've", "they have"),
        ("wasn't", "was not"),
        ("we'd", "we would"),
        ("we'll", "we will"),
        ("we're", "we are"),
        ("we've", "we have"),
        ("weren't", "were not"),
        ("what'll", "what will"),
        ("what're", "what are"),
        ("what's", "what is / what does"),
        ("what've", "what have"),
        ("when's", "when is"),
        ("where'd", "where did"),
        ("where's", "where is"),
        ("where've", "where have"),
        ("who'd", "who had"),
        ("who'll", "who will"),
        ("who're", "who are"),
        ("who's", "who is"),
        ("who've", "who have"),
        ("why'll", "why will"),
        ("why're", "why are"),
        ("why's", "why is"),
        ("won't", "will not"),
        ("would've", "would have"),
        ("wouldn't", "would not"),
        ("y'all", "you all"),
        ("you'd", "you would"),
        ("you'll", "you will"),
        ("you're", "you are"),
        ("you've", "you have")
    ])
    # test Contraction expansion
    def test_contractionexpand(self, input, expected):
        returned = nh.contractionexpand(input)
        assert returned == expected

    @pytest.mark.parametrize("input, expected", [
        ("the FOLLOWING MEDICALLY  DETERMINABLE", ""),
        ("(20 C.F.R.", ""),
        ("1. The claimant has had the following   .severe impairments", "")
    ])
    # test for step 2 decision text remove program/generic language
    def test_s2txt_cleaner_nonfit(self, input, expected):
        returned = nh.s2txt_cleaner_nonfit(input)
        assert returned == expected





