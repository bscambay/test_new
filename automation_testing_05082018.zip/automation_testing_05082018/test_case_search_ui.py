import os.path
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
import config as cfg
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select

# Set directories:
#setup_config
""" unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data") """

# Import IFS module:
""" sys.path.insert(0, insightdir) """


#pytest -v test_case_search.py::TestSSNSearch::test_ssn_sort
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_find
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_filter


class TestCaseSearch(unittest.TestCase):
    def setUp(self):
        pass
    def test_url(self):
        self.driver = cfg.driver
        #url= self.OAO_url
        assert cfg.OaO_url 
        #self.OAO_url
        time.sleep(2)
        self.driver.close()
        #self.OAO_url
        #"http://s1ff531.ba.ad.ssa.gov:8189/search_results/ssn"
        #"http://s1ff515:9008/search_results/"
        #assert url 
        #url
         
    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_sort(self):
        '''Test sort function for case search tool'''
        #driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        driver = cfg.driver
        #self.driver
        #self.driver
        driver.get(cfg.OaO_url)
        #(self.OAO_url)
        #get(self.url)
        #("http://s1ff531.ba.ad.ssa.gov:8189/search_results/")
        #("http://s1ff515:9008/search_results/")
        #(self.url)
        index = 1
        rowElements = driver.find_elements_by_xpath("//th[contains(@class, 'header')]")
        index = 1
        for ele in rowElements: 
            if index == 1: 
                print index, ele.text
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
                assert sorted(data) == data
            elif index > 1:
                print index, ele.text  
                ele.click()   
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
            
                date_pattern = re.match("(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$", data[0].split()[0].strip())
                if date_pattern != None:
                    data = [item.split()[0] for item in data]
                    assert sorted(data, key=lambda x: datetime.datetime.strptime(x, '%m/%d/%Y')) \
                        ==  [item.split()[0] for item in data]
                else:
                    assert sorted(data) == data
            index = index + 1
            data = []
            time.sleep(2)

     
        
    #pytest.mark.skip(reason="Not needed!")
    def test_ssn_find(self):
        '''Test find function for case search tool'''
        driver = cfg.driver
        driver.get(cfg.OaO_url)
        ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        print len(ssn_list)
        sample_ssn_list = [str(item.text) for item in (sample(ssn_list[:10], len(ssn_list)))]
        #for item in (sample(ssn_list[:10], 3))]
        for ssn in sample_ssn_list:
            driver.find_element_by_name('ssn_search').send_keys(ssn)
            wait = WebDriverWait(driver, 5)
            confirm = wait.until(EC.element_to_be_clickable((By.ID, "ssn_find")))
            confirm.click()
            #driver.find_element_by_id('ssn_find').click()
            time.sleep(1)
            driver.find_element_by_name('ssn_search').clear()
            #driver.find_element_by_id('ssn_find').click()
            wait = WebDriverWait(driver, 5)
            confirm = wait.until(EC.element_to_be_clickable((By.NAME, "ssn_search")))
            confirm.click()
          
        time.sleep(3)

     #pytest.mark.skip(reason="Not needed!")
    def test_ssn_filter(self):
       
        '''Test filter function for case search tool'''
        driver = cfg.driver
        driver.get(cfg.OaO_url)
        print cfg.OaO_url
        ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        print (len(ssn_list)-1)
        sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], len(ssn_list))]
        #for item in sample(ssn_list[:10], 3)]
        time.sleep(2)
        ssn_filter = driver.execute_script("document.getElementById('ssnFilter')")
        #driver.find_element_by_id("ssnFilter")
        
        for item in sample_ssn_list:
            ssn_filter.send_keys(item[:4])
            time.sleep(2)
            ssn_filter.clear()
        time.sleep(5)

    def tearDown(self):
        '''Tear Down test'''
        #self.driver.close()
    

def suite():
    suite = unittest.TestSuite()
    suite.addTest(TestSSNSearch('test_ssn_find'))
    suite.addTest(TestSSNSearch('test_ssn_sort'))
    suite.addTest(TestSSNSearch('test_ssn_filter'))
    
    return suite


if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
