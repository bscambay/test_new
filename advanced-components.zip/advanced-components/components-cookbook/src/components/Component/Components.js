import React from 'react'

// ES6 class-style
class App extends React.Component {
  render() {} // required
}

export default App
