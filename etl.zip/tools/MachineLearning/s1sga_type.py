'''
    this is the utility to check the classifier that is built from S1VERDICTTYPEFEATURESREV2.txt
'''

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)

ml = ML_util("S1VERDICTTYPEFEATURESREV2.txt", "OneVsRestClassifier", 3, logging_dir)

ml.run()
