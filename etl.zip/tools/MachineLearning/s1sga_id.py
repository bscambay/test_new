'''
    this is the utility to check the classifier that is built from S1VERDICTIDFEATURESREV2.txt
'''

from ml_util import ML_util

# logging location; you can specify any log file you want
logging_dir = '{}.log'.format(__file__)

ml = ML_util("S1VERDICTIDFEATURESREV2.txt", 'LogisticRegression', 3, logging_dir)
ml.run()

exit()

testing_str = ['2. The claimant has not engaged in substantial gainful activity since December 12, 2013, the alleged onset date (20 CFR 404.1571 et seq.).']
print ml.predict(testing_str)
