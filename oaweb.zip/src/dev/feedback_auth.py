import urllib

import psycopg2
from bottle import route, run, request, response, post
import config as cfg


@route('/test')
def test():
    # user = request.environ.get("AUTH_USER")
    user = request.headers.get("X-Remote-User")

    return " Get Request is Alive!" + str(user)


@post('/oaofb')
def oaofb():
    print "alive....."
    body = request.body.read()
    print "body = " + body
    body = body.replace("+", " ").replace("payload=", "")
    parsedBody = urllib.unquote(body).decode('utf8')
    nlp = parsedBody.split('&')
    print nlp
    ridid = request.forms.get("rid")

    print "rid = " + ridid
    for i in nlp:
        type = i.split("=")
        insert_feedback(ridid, type[0], type[1])
    response.status = 200
    print "Reponse Processed", response
    response["responseText"] = "mike"
    return 'Ajax Call Processed!'


def insert_feedback(rid, vname, vvalue):
    args = (rid, vname, vvalue)

    print args
    connection = psycopg2.connect("host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password))
    cursor = connection.cursor()

    sql = "INSERT INTO feedback (rid,vname, vvalue) VALUES (%s, %s, %s)"
    # print sql

    nbr = cursor.execute(sql, args)
    connection.commit()

    cursor.close()
    connection.close()


run(host='localhost', port=8097, server='cherrypy', debug=True, reloader=True)
