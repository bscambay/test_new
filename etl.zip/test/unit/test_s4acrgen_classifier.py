# unit test coverage for s4actgen_classifier

from types import ListType, TupleType
import pytest
import setup_config
import s4actgen_classifier as s4c

@pytest.fixture
def step4_prw_data():
    return 'The claimant is capable of performing past relevant work as a palletizer. This work does not require the performance of work-related activities precluded by the claimantts residual functional capacity (20 CFR 404.1565 and 416.965). The vocational expert reviewed the claimantis vocational background documented in the record prior to the hearing. The vocational expert was present to hear the claimantis testimony. Based on the claimantis documented vocational background and the claimantis testimony, the vocational expert indicated the claimant worked within the last 15 years in the following occupations: 1. Palletizer, DOT1 929.687-054, is a light, unskilled (SVP2 2) occupation as generally performed pursuant to the DOT; 2. Van driver, DOT 913.663-018, is a medium, semiskilled (SVP 3) occupation as generally performed pursuant to the DOT, but actually performed as medium work as described by the claimant; and 3. Filler machine operator, DOT 920.685-078, is a medium, unskilled (SVP 2) occupation as generally performed pursuant to the DOT, but actually performed as light work as described by the claimant. Based on the evidence of record, the undersigned finds the above-described work is past relevant work because the claimant performed it within 15 years of the date of this decision, for a sufficient length of time to learn and provide average performance, and at the level of substantial gainful activity. Having been asked to assume a person with the same age, education, and work experience as the claimant, and a residual functional capacity determined herein, the vocational expert testified that such an individual would be able to perform the past relevant work of palletizer as actually performed by the claimant and as generally performed in the regional and national economy. The testimony of the vocational expert is consistent with the DOT, and the undersigned accepts it. In comparing the claimantis residual functional capacity with the physical and mental demands of the claimantis past relevant work, the undersigned has determined the claimant is able to perform this past relevant work as actually performed by the claimant and as generally performed in the regional and national economy. Although the claimant is capable of performing past relevant work, there are other jobs existing in the national economy that he is also able to perform. Therefore, the Administrative Law Judge makes the following alternative findings for step five of the sequential evaluation process. The claimant was born on September 28, 1959 and was 52 years old, which is defined as an individual closely approaching advanced age, on the alleged disability onset date (20 CFR 1 Dictionary of Occupational Titles (U.S. Department of Labor, 1991) 2 Specific Vocational Preparation, as defined in Appendix C of the Dictionary of Occupational Titles See Next Page Herber A. Flores (619-18-0634) Page 11 of 12 404.1563 and 416.963). The claimant has at least a high school education and is able to communicate in English (20 CFR 404.1564 and 416.964). Transferability ofjob skills is not material to the determination of disability because using the Medical-Vocational Rules as a framework supports a finding that the claimant is "not disabled," whether or not the claimant has transferable job skills (See SSR 82-41 and 20 CFR Part 404, Subpart P, Appendix 2).'

@pytest.mark.parametrize("input, expected", [('The claimant HAS been able to perform gained activity', 'the claimant has been able to perform gained activity')])
def test_find_actually_generally_snippets(input, expected):
    returned = s4c.find_actually_generally_snippets(input)
    assert isinstance(returned, ListType) and returned[0] == expected

def test_regex_result_shortest_distance():
    returned = s4c.regex_result_shortest_distance("The claimant HAS been able to perform gained activity, in comparing the ", r' ?been|was|is', r'able to')
    assert isinstance(returned, int)

def test_text_features(step4_prw_data):
    returned = s4c.text_features(step4_prw_data)
    assert isinstance(returned, TupleType) and isinstance(returned[1], int)

def test_S4ActgenClassifier(step4_prw_data):
    clf = s4c.S4ActgenClassifier()
    assert clf.classify('') == "P"
    assert clf.classify(step4_prw_data).upper() in ['1', '2', '3', '4', '5', '6', '7', '8', 'U', 'P', 'E']
