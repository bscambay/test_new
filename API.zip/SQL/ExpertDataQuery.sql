﻿SELECT HOFC_WRK_UNIT_UID, hofc_wrk_unit_AC, wg_ernr_ssn_AC, CLMT_SSN, CRNT_RQSTD_DT, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2,
        T16_GLBL_BSS_UID_1, T16_GLBL_BSS_UID_2, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT,
        HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT,
        T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD,
        EFLDR_NUM, HEDULVL_CD, U.EXPERT_UID, '' AS DEV_GRP, cast(NULL as DATE) AS ACKT_RCVDT, '' AS DEV_SRC_CD, SCHD_SW,
        ATTNDD_SW, MED_SPCLY_CD, INSRT_TS, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, PTNTLY_HOMCDL_SW, SUICIDL_SW, 
        TERI_SW, EXPERT_TYP, TITLE, FNM, MNM, LNM, SFX        
FROM
(
    --HRGEXP
    SELECT  N.HOFC_WRK_UNIT_UID, hofc_wrk_unit_AC, wg_ernr_ssn_AC, CLMT_SSN, CRNT_RQSTD_DT, N.T2_GLBL_BSS_UID_1, N.T2_GLBL_BSS_UID_2, 
        N.T16_GLBL_BSS_UID_1, N.T16_GLBL_BSS_UID_2, N.T2_APP_DT, N.T16_APP_DT, N.T2_PFLG_DT, N.T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT, 
        HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, N.REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT,
        N.T2_DSPN_CD, N.T16_DSPN_CD, N.T2_PRTL_FFVRBL_CD, N.T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD,
        N.EFLDR_NUM, N.HEDULVL_CD, O.EXPERT_UID, '' AS DEV_GRP, cast(NULL as DATE) AS ACKT_RCVDT, '' AS DEV_SRC_CD, O.SCHD_SW, 
        O.ATTNDD_SW, O.MED_SPCLY_CD, O.INSRT_TS, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
    FROM
    (
        SELECT *
        FROM
        (
            SELECT Y.*, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2, T16_GLBL_BSS_UID_1, T16_GLBL_BSS_UID_2
            FROM
            (
                SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                FROM
                (
                                                                                                                           
                    SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                        wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                    FROM
                    (
                        SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                        FROM
                        (                                
                            SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                            FROM MHALCOPY.WRKUNH 
                            WHERE EFLDR_NUM IN  
                            (
                                SELECT B.EFLDR_NUM
                                FROM 
                                (
                                    SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                    FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                    AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
									ORDER BY HOFC_WRK_UNIT_UID
                                    FETCH FIRST 250 ROWS ONLY
                                ) AS A                                                                                    
                                INNER JOIN MHAODS.WRKUNH AS B
                                ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                WHERE B.EFLDR_NUM IS NOT NULL
                            )   
                        )  AS E
                        INNER JOIN MHAODS.ARCHWKUT AS F
                        ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                    ) AS S             
                    INNER JOIN 
                    (
                        SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                        FROM 
                        (
                            SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                            FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                            AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
							ORDER BY HOFC_WRK_UNIT_UID
                            FETCH FIRST 250 ROWS ONLY
                        ) AS A                                                                                    
                        INNER JOIN MHAODS.WRKUNH AS B
                        ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                        WHERE B.EFLDR_NUM IS NOT NULL                        
                    ) AS T
                    ON T.EFLDR_NUM = S.EFLDR_NUM
                    AND T.HRG_TYP = S.HRG_TYP
                    AND T.CLM_TYP = S.CLM_TYP
                                                                                                            
                ) AS Q
                INNER JOIN MHAODS.CLMINFO AS H
                ON Q.CLM_UID = H.CLM_UID
            ) as Y
            INNER JOIN MHAODS.DISPNH AS K
            ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
        ) as R
        LEFT JOIN 
        (
            SELECT FLDR_NUM, HEDULVL_CD FROM MEDIB.CASE
            WHERE FLDR_NUM IN 
            (
                SELECT Y.EFLDR_NUM
                FROM
                (
                    SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                    FROM
                    (
                        SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                        FROM
                        (
                            SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                            FROM
                            (                                
                                SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                FROM MHALCOPY.WRKUNH 
                                WHERE EFLDR_NUM IN  
                                (
                                    SELECT B.EFLDR_NUM
                                    FROM 
                                    (
                                        SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                        FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                        AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
										ORDER BY HOFC_WRK_UNIT_UID
										FETCH FIRST 250 ROWS ONLY
                                    ) AS A                                                                                    
                                    INNER JOIN MHAODS.WRKUNH AS B
                                    ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                    WHERE B.EFLDR_NUM IS NOT NULL
                                )   
                            )  AS E
                            INNER JOIN MHAODS.ARCHWKUT AS F
                            ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                        ) AS S             
                        INNER JOIN 
                        (
                            SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                            FROM 
                            (
                                SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
								ORDER BY HOFC_WRK_UNIT_UID
								FETCH FIRST 250 ROWS ONLY
                            ) AS A                                                                                    
                            INNER JOIN MHAODS.WRKUNH AS B
                            ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                            WHERE B.EFLDR_NUM IS NOT NULL
                        ) AS T
                        ON T.EFLDR_NUM = S.EFLDR_NUM
                        AND T.HRG_TYP = S.HRG_TYP
                        AND T.CLM_TYP = S.CLM_TYP
                                                                                                                                                                
                    ) AS Q
                    INNER JOIN MHAODS.CLMINFO AS H
                    ON Q.CLM_UID = H.CLM_UID
                ) as Y
                INNER JOIN MHAODS.DISPNH AS K
                ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
            )
            AND HEDULVL_CD IS NOT NULL        
        ) as hev
        ON R.EFLDR_NUM = hev.FLDR_NUM
    ) AS N
    INNER JOIN MHAODS.HRGEXP AS O
    ON N.HOFC_WRK_UNIT_UID = O.HOFC_WRK_UNIT_UID
    UNION ALL
    SELECT N.HOFC_WRK_UNIT_UID, hofc_wrk_unit_AC, wg_ernr_ssn_AC, CLMT_SSN, CRNT_RQSTD_DT,N.T2_GLBL_BSS_UID_1, N.T2_GLBL_BSS_UID_2, 
        N.T16_GLBL_BSS_UID_1, N.T16_GLBL_BSS_UID_2, N.T2_APP_DT, N.T16_APP_DT, N.T2_PFLG_DT, N.T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT, 
        HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, N.REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT,
        N.T2_DSPN_CD, N.T16_DSPN_CD, N.T2_PRTL_FFVRBL_CD, N.T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD, 
        N.EFLDR_NUM, N.HEDULVL_CD, O.EXPERT_UID, O.DEV_GRP, O.ACKT_RCVDT, O.DEV_SRC_CD, '' AS SCHD_SW, '' AS ATTNDD_SW, '' AS MED_SPCLY_CD, 
        O.INSRT_TS, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW
    FROM
    (
        --DEVLPH
        --Base
        SELECT *
        FROM
        (
            SELECT Y.*, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2, T16_GLBL_BSS_UID_1, T16_GLBL_BSS_UID_2
            FROM
            (
                SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                FROM
                (                                                        
                    SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                        wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                    FROM
                    (
                        SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, 
                                T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                        FROM
                        (                  
                            SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                            FROM MHALCOPY.WRKUNH 
                            WHERE EFLDR_NUM IN  
                            (
                                SELECT B.EFLDR_NUM
                                FROM 
                                (
                                    SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                    FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                    AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
									ORDER BY HOFC_WRK_UNIT_UID
									FETCH FIRST 250 ROWS ONLY
                                ) AS A                                                                                    
                                INNER JOIN MHAODS.WRKUNH AS B
                                ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                WHERE B.EFLDR_NUM IS NOT NULL
                            )   
                        )  AS E
                        INNER JOIN MHAODS.ARCHWKUT AS F
                        ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                    ) AS S             
                    INNER JOIN 
                    (
                        SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                        FROM 
                        (
                            SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                            FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                            AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
							ORDER BY HOFC_WRK_UNIT_UID
                            FETCH FIRST 250 ROWS ONLY
                        ) AS A                                                                                      
                        INNER JOIN MHAODS.WRKUNH AS B
                        ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                        WHERE B.EFLDR_NUM IS NOT NULL
                    ) AS T
                    ON T.EFLDR_NUM = S.EFLDR_NUM
                    AND T.HRG_TYP = S.HRG_TYP
                    AND T.CLM_TYP = S.CLM_TYP                                     
                ) AS Q
                INNER JOIN MHAODS.CLMINFO AS H
                ON Q.CLM_UID = H.CLM_UID
            ) as Y
            INNER JOIN MHAODS.DISPNH AS K
            ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
        ) as R
        LEFT JOIN 
        (
            SELECT FLDR_NUM, HEDULVL_CD FROM MEDIB.CASE
            WHERE FLDR_NUM IN 
            (
                SELECT Y.EFLDR_NUM
                FROM
                (
                    SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                    FROM
                    (                                                                                        
                        SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                        FROM
                        (
                            SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                            FROM
                            (                         
                                SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                FROM MHALCOPY.WRKUNH 
                                WHERE EFLDR_NUM IN  
                                (
                                    SELECT B.EFLDR_NUM
                                    FROM 
                                    (
                                        SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                        FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                        AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
										ORDER BY HOFC_WRK_UNIT_UID
										FETCH FIRST 250 ROWS ONLY
                                    ) AS A                                                                                           
                                    INNER JOIN MHAODS.WRKUNH AS B
                                    ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                    WHERE B.EFLDR_NUM IS NOT NULL
                                )   
                            )  AS E
                            INNER JOIN MHAODS.ARCHWKUT AS F
                            ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                        ) AS S             
                        INNER JOIN 
                        (
                            SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, 
                                CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, 
                                CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                            FROM 
                            (
                                SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
								ORDER BY HOFC_WRK_UNIT_UID
								FETCH FIRST 250 ROWS ONLY
                            ) AS A                                                                                             
                            INNER JOIN MHAODS.WRKUNH AS B
                            ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                            WHERE B.EFLDR_NUM IS NOT NULL
                        ) AS T
                        ON T.EFLDR_NUM = S.EFLDR_NUM
                        AND T.HRG_TYP = S.HRG_TYP
                        AND T.CLM_TYP = S.CLM_TYP                                             
                    ) AS Q
                    INNER JOIN MHAODS.CLMINFO AS H
                    ON Q.CLM_UID = H.CLM_UID
                ) as Y
                INNER JOIN MHAODS.DISPNH AS K
                ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
            )
            AND HEDULVL_CD IS NOT NULL        
        ) as hev
        ON R.EFLDR_NUM = hev.FLDR_NUM                     
    ) AS N
    INNER JOIN MHAODS.DEVLPH AS O
    ON N.HOFC_WRK_UNIT_UID = O.HOFC_WRK_UNIT_UID
) AS U
LEFT JOIN 
(     
    SELECT EXPERT_UID, EXPERT_TYP, TITLE, FNM, MNM, LNM, SFX
    FROM MHAODS.OPTLEXP 
    WHERE EXPERT_UID IN
    (
        SELECT unionexp.EXPERT_UID
        FROM 
        (
            SELECT N.HOFC_WRK_UNIT_UID, hofc_wrk_unit_AC, wg_ernr_ssn_AC, CLMT_SSN, CRNT_RQSTD_DT, N.T2_GLBL_BSS_UID_1, N.T2_GLBL_BSS_UID_2, 
                   N.T16_GLBL_BSS_UID_1, N.T16_GLBL_BSS_UID_2, N.T2_APP_DT, N.T16_APP_DT, N.T2_PFLG_DT, N.T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT, 
                   HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, N.REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT,
                   N.T2_DSPN_CD, N.T16_DSPN_CD, N.T2_PRTL_FFVRBL_CD, N.T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD,
                   N.EFLDR_NUM, N.HEDULVL_CD, O.EXPERT_UID, '' AS DEV_GRP, cast(NULL as DATE) AS ACKT_RCVDT, '' AS DEV_SRC_CD, O.SCHD_SW, 
                   O.ATTNDD_SW, O.MED_SPCLY_CD, O.INSRT_TS, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                   PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
            FROM
            (
                SELECT *
                FROM
                (
                    SELECT Y.*, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2, T16_GLBL_BSS_UID_1, T16_GLBL_BSS_UID_2
                    FROM
                    (
                        SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                        FROM
                        (                                                                                                                        
                            SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                            FROM
                            (
                                SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                        TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                        HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                                FROM
                                (                    
                                    SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                    FROM MHALCOPY.WRKUNH 
                                    WHERE EFLDR_NUM IN  
                                    (
                                        SELECT B.EFLDR_NUM
                                        FROM 
                                        (
                                            SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                            FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                            AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
											ORDER BY HOFC_WRK_UNIT_UID
											FETCH FIRST 250 ROWS ONLY
                                        ) AS A                                                                                    
                                        INNER JOIN MHAODS.WRKUNH AS B
                                        ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                        WHERE B.EFLDR_NUM IS NOT NULL
                                    )   
                                )  AS E
                                INNER JOIN MHAODS.ARCHWKUT AS F
                                ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                            ) AS S             
                            INNER JOIN 
                            (
                                SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                                FROM 
                                (
                                    SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                    FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                    AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
									ORDER BY HOFC_WRK_UNIT_UID
									FETCH FIRST 250 ROWS ONLY
                                ) AS A                                                                                        
                                INNER JOIN MHAODS.WRKUNH AS B
                                ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                WHERE B.EFLDR_NUM IS NOT NULL
                            ) AS T
                            ON T.EFLDR_NUM = S.EFLDR_NUM
                            AND T.HRG_TYP = S.HRG_TYP
                            AND T.CLM_TYP = S.CLM_TYP                                                                        
                        ) AS Q
                        INNER JOIN MHAODS.CLMINFO AS H
                        ON Q.CLM_UID = H.CLM_UID
                    ) as Y
                    INNER JOIN MHAODS.DISPNH AS K
                    ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
                ) as R
                LEFT JOIN 
                (
                    SELECT FLDR_NUM, HEDULVL_CD FROM MEDIB.CASE
                    WHERE FLDR_NUM IN 
                    (
                        SELECT Y.EFLDR_NUM
                        FROM
                        (
                            SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                            FROM
                            (                                                                                                                       
                                SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                        wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                FROM
                                (
                                    SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                        TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                        HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                                    FROM
                                    (                  
                                        SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                        FROM MHALCOPY.WRKUNH 
                                        WHERE EFLDR_NUM IN  
                                        (
                                            SELECT B.EFLDR_NUM
                                            FROM 
                                            (
                                                SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                                FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                                AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
												ORDER BY HOFC_WRK_UNIT_UID
												FETCH FIRST 250 ROWS ONLY
                                            ) AS A                                                                                  
                                            INNER JOIN MHAODS.WRKUNH AS B
                                            ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                            WHERE B.EFLDR_NUM IS NOT NULL
                                        )   
                                    )  AS E
                                    INNER JOIN MHAODS.ARCHWKUT AS F
                                    ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                                ) AS S             
                                INNER JOIN 
                                (
                                    SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                                    FROM 
                                    (
                                        SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                        FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                        AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
										ORDER BY HOFC_WRK_UNIT_UID
										FETCH FIRST 250 ROWS ONLY
                                    ) AS A                                                                                      
                                    INNER JOIN MHAODS.WRKUNH AS B
                                    ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                    WHERE B.EFLDR_NUM IS NOT NULL
                                ) AS T
                                ON T.EFLDR_NUM = S.EFLDR_NUM
                                AND T.HRG_TYP = S.HRG_TYP
                                AND T.CLM_TYP = S.CLM_TYP                                                                                         
                            ) AS Q
                            INNER JOIN MHAODS.CLMINFO AS H
                            ON Q.CLM_UID = H.CLM_UID
                        ) as Y
                        INNER JOIN MHAODS.DISPNH AS K
                        ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
                    )
                    AND HEDULVL_CD IS NOT NULL        
                ) as hev
                ON R.EFLDR_NUM = hev.FLDR_NUM
            ) AS N
            INNER JOIN MHAODS.HRGEXP AS O
            ON N.HOFC_WRK_UNIT_UID = O.HOFC_WRK_UNIT_UID
            UNION ALL
            SELECT N.HOFC_WRK_UNIT_UID, hofc_wrk_unit_AC, wg_ernr_ssn_AC, CLMT_SSN, CRNT_RQSTD_DT,N.T2_GLBL_BSS_UID_1, N.T2_GLBL_BSS_UID_2, 
                N.T16_GLBL_BSS_UID_1, N.T16_GLBL_BSS_UID_2, N.T2_APP_DT, N.T16_APP_DT, N.T2_PFLG_DT, N.T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT, 
                HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, N.REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT,
                N.T2_DSPN_CD, N.T16_DSPN_CD, N.T2_PRTL_FFVRBL_CD, N.T16_PRTL_FFVRBL_CD,
                BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD, N.EFLDR_NUM, N.HEDULVL_CD, O.EXPERT_UID, O.DEV_GRP, O.ACKT_RCVDT, 
                O.DEV_SRC_CD, '' AS SCHD_SW, '' AS ATTNDD_SW, '' AS MED_SPCLY_CD, O.INSRT_TS, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW
            FROM
            (
                --DEVLPH
                --Base
                SELECT *
                FROM
                (
                    SELECT Y.*, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2, T16_GLBL_BSS_UID_1, T16_GLBL_BSS_UID_2
                    FROM
                    (
                        SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                        FROM
                        (                                                                                        
                            SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                            FROM
                            (
                                SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                    TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                    HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                                FROM
                                (                         
                                    SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                    FROM MHALCOPY.WRKUNH 
                                    WHERE EFLDR_NUM IN  
                                    (
                                        SELECT B.EFLDR_NUM
                                        FROM 
                                        (
                                            SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                            FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                            AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
											ORDER BY HOFC_WRK_UNIT_UID
											FETCH FIRST 250 ROWS ONLY
                                        ) AS A                                                                                           
                                        INNER JOIN MHAODS.WRKUNH AS B
                                        ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                        WHERE B.EFLDR_NUM IS NOT NULL
                                    )   
                                )  AS E
                                INNER JOIN MHAODS.ARCHWKUT AS F
                                ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                            ) AS S             
                            INNER JOIN 
                            (
                                SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                                FROM 
                                (
                                    SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                    FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                    AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
									ORDER BY HOFC_WRK_UNIT_UID
									FETCH FIRST 250 ROWS ONLY
                                ) AS A                                                                                             
                                INNER JOIN MHAODS.WRKUNH AS B
                                ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                WHERE B.EFLDR_NUM IS NOT NULL
                            ) AS T
                            ON T.EFLDR_NUM = S.EFLDR_NUM
                            AND T.HRG_TYP = S.HRG_TYP
                            AND T.CLM_TYP = S.CLM_TYP                                             
                        ) AS Q
                        INNER JOIN MHAODS.CLMINFO AS H
                        ON Q.CLM_UID = H.CLM_UID
                    ) as Y
                    INNER JOIN MHAODS.DISPNH AS K
                    ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
                ) as R
                LEFT JOIN 
                (
                    SELECT FLDR_NUM, HEDULVL_CD FROM MEDIB.CASE
                    WHERE FLDR_NUM IN 
                    (
                        SELECT Y.EFLDR_NUM
                        FROM
                        (
                            SELECT Q.*, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT
                            FROM
                            (                                                                                                        
                                SELECT S.*,hofc_wrk_unit_AC, CLMT_SSN, CRNT_RQSTD_DT, WKLD_TYP, 
                                        wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                FROM
                                (
                                    SELECT E.*, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, REP_UID, 
                                        TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, 
                                        HRG_ISU_CD, EDIB_CD, OHA_DAA_CD  
                                    FROM
                                    (                                
                                        SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM
                                        FROM MHALCOPY.WRKUNH 
                                        WHERE EFLDR_NUM IN  
                                        (
                                            SELECT B.EFLDR_NUM
                                            FROM 
                                            (
                                                SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                        CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                                FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                                AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
												ORDER BY HOFC_WRK_UNIT_UID
												FETCH FIRST 250 ROWS ONLY
                                            ) AS A                                                                                  
                                            INNER JOIN MHAODS.WRKUNH AS B
                                            ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                            WHERE B.EFLDR_NUM IS NOT NULL
                                        )   
                                    )  AS E
                                    INNER JOIN MHAODS.ARCHWKUT AS F
                                    ON E.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                                ) AS S             
                                INNER JOIN 
                                (
                                    SELECT B.HOFC_WRK_UNIT_UID as hofc_wrk_unit_AC, B.EFLDR_NUM, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, A.WKLD_TYP, 
                                        CLM_TYP, WG_ERNR_SSN as wg_ernr_ssn_AC, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                        PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW 
                                    FROM 
                                    (
                                        SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, 
                                                CLM_TYP, WG_ERNR_SSN, CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, 
                                                PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW  
                                        FROM MHAODS.PACAR WHERE RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')
                                        AND HOFC_WRK_UNIT_UID IS NOT NULL                                      
										ORDER BY HOFC_WRK_UNIT_UID
										FETCH FIRST 250 ROWS ONLY
                                    ) AS A                                                                                    
                                    INNER JOIN MHAODS.WRKUNH AS B
                                    ON A.HOFC_WRK_UNIT_UID = B.HOFC_WRK_UNIT_UID
                                    WHERE B.EFLDR_NUM IS NOT NULL
                                ) AS T
                                ON T.EFLDR_NUM = S.EFLDR_NUM
                                AND T.HRG_TYP = S.HRG_TYP
                                AND T.CLM_TYP = S.CLM_TYP                                                     
                            ) AS Q
                            INNER JOIN MHAODS.CLMINFO AS H
                            ON Q.CLM_UID = H.CLM_UID
                        ) as Y
                        INNER JOIN MHAODS.DISPNH AS K
                        ON Y.HOFC_WRK_UNIT_UID = K.HOFC_WRK_UNIT_UID
                    )
                    AND HEDULVL_CD IS NOT NULL        
                ) as hev
                ON R.EFLDR_NUM = hev.FLDR_NUM                            
            ) AS N
            INNER JOIN MHAODS.DEVLPH AS O
            ON N.HOFC_WRK_UNIT_UID = O.HOFC_WRK_UNIT_UID
        ) AS unionexp
        WHERE unionexp.EXPERT_UID IS NOT NULL
    ) 
) AS expcomb
ON U.EXPERT_UID = expcomb.EXPERT_UID 
ORDER BY U.hofc_wrk_unit_AC WITH UR
