We use the files in this folder to load code examples for the aside "ES6: Modules."

You can run any individual file using `babel-node`, like this:

```
./node_modules/.bin/babel-node 1/app-1.js
```
