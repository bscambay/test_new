''' healthcheck for oao web application import routes:
    1. OAO Case Entity Page Generation
    2. OAO Store Feedback
    3. OAO Age Calculator Widget
    4. OAO Age Calculator Widget - DID Retrieval
    5. OAO Age Calculator Widget - Claimant DOB Retrieval
    6. OAO Child BMI Calculator Widget
    7. OAO SSO Code Lookup Widget
    8. OAO Analysis Template Generator Widget
    9. OAO Serve favicon - static files
'''

import re
import bs4
import requests
from bottle_health_check import HealthCheck
from bottle import request

# help function for http get
def http_check(url, method, data=None, header=None):
    try:
        res = None
        if method == 'post':
            res = requests.post(url, headers=header, data=data)
        else:
            res = requests.get(url)
        res.raise_for_status()
        return res.status_code  # just return normal status code if successful
    except Exception as ex:
        if res is None:
            return str(ex)  # true error message
        else:
            return str(res.status_code)

def oao_case_find(url):
    try:
        res = None
        res = requests.get(url)
        res.raise_for_status()
        content = res.content.lower()
        if content.find('processing error:') > -1:
            content_soup = bs4.BeautifulSoup(content, 'lxml')
            error_content = content_soup.select('h2.heading')
            if len(error_content):
                return str(res.status_code) + ' | ' + error_content[0].get_text()
            else:
                return str(res.status_code)
        else:
            return res.status_code

    except Exception as ex:
        if res is None:
            return str(ex)  # true error message
        else:
            return str(res.status_code)

class HcHelper(object):
    def __init__(self, app=None, route_path=None):
        self.health = HealthCheck(app, route_path)
        self.health.add_check(self.check_oao)
        # self.health.add_check(self.check_google)
        self.health.add_check(self.check_sso_lookup)

    # 1. OAO Case Entity Page Generation; see above for possible needed check
    def check_oao(self, reqid=None):
        # grab reqid from request.url
        rid = re.search(r'healthcheck\/[0-9]+', request.url)
        if rid:
            url = request.url.replace('/healthcheck/', "/oaoapp/")
            status = oao_case_find(url)
        else:
            url = request.url.replace('/healthcheck', "/oaoapp/4")
            status = http_check(url, 'get')

        return self.check_status(status, "OAO Case Entity Page Generation ok", "Case Entity Page Generation HAS issue")

    def check_google(self):
        url = 'https://google.com'
        status = http_check(url, 'get')
        return self.check_status(status, "google has no issue", 'google has issue')

    def check_sso_lookup(self):
        url = request.url.replace('/healthcheck', '/_ssolookup')
        data = "reqid=&inputzip=21201"
        status = http_check(url, method='post', data=data)
        return self.check_status(status, "OAO SSO Lookup Page Generation ok", "OAO SSO Lookup Page Generation HAS issue")

    def check_status(self, status, ok_msg="", not_ok_msg=""):
        if status == 200:
            return True, ok_msg
        else:
            return False, not_ok_msg + ' | ' +  status
