﻿namespace INSIGHT_Request.Models
{
    public class ArpsRouteParameters
    {
        public string hofc_wrk_unit_uid { get; set; } = "";
        public string ocd { get; set; } = "";
        public string searchssn { get; set; } = "";
    }
}