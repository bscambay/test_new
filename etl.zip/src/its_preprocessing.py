# INSIGHT INABILITY TO SUSTAIN LOGISTIC REGRESSION CLASSIFIER PREPROCESSING
#
# AUTHOR: 
# Kurt Glaze / Eric Kim
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED:
# 08.24.2016
# 
# SUMMARY:
# A suite of scripts that support a logistic regression classifier algorithm 
# designed to take 'raw' disability hearing decision RFC text (INSIGHT 
# 'rfctxt' value) as input and output a classification as to whether each 
# subsection of it does or does not contain 'inability to sustain' language.
# 
# WARNING: The following is alpha-level/prototype software whose output
# quality has not yet been formally validated and whose documentation is not
# yet fully formed.
#==============================================================================

# Import modules:
import re
import os.path
import logging
import nlp_helper as nh
import text_cleaner as tc
import regex_strings as rs

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Preprocess files and load lines into arrays:
# OPENQ: No 'return'.  What calls this?  Looks like 
# a data loading assistance function but why is it here?
def preprocess_and_eval_files(file_path, file_lines_list, *other_lists):
	try:
		file_lines = open(file_path, 'r').readlines()
		file_lines = [line.rstrip() for line in file_lines]
		file_lines = [eval(line) for line in file_lines if not line.startswith('#')]
		for line in file_lines:
			file_lines_list.append(line)
			for list in other_lists:
				list.append(line)
	except Exception:
		logger.exception('EXCEPTION')
		raise
				
# Generate RFC text snippets:
# TODO: This MAY benefit from revision based on latest RFCPARSER
# splitting/cleaning techniques.
def generate_snippets(text):
	try:
		# Split by full sentences:
		rfc_split = nh.sentence_splitter(text)
		
		# Split a sent by a given punctuation, re-add the splitting ones, and append to a list
		# TODO: Consider updating in conformity with the advances made in RFCPARSER.
		def split_and_readd_punct(split_list, sent, punct):
			sent_split = sent.split(punct + ' ')
			if len(sent_split) > 1:
				for i in range(len(sent_split) - 1):
					sent_plus_delimiter = str(sent_split[i]) + str(punct + ' ')
					split_list.append(sent_plus_delimiter)
				
				# Check that the last item isn't an empty string (or just whitespace).
				# Such a case occurs if the sentence ended with the punctuation.
				if sent_split[-1].split():
					split_list.append(sent_split[-1])
			else:
				split_list.append(sent_split[0])
		
		# Split by 'never-part-of-list' conjunction terms (TIP: These conjunctions were selected after study):
		# Keep setting temp_split to [] and copying the results back into rfc_split
		temp_split = []
		for sent in rfc_split:
			sent_split = re.split(rs.nonlist_conj_words_regex, sent)
			for item in sent_split:
				item = tc.normalize_spacing(item)
				temp_split.append(item)
		rfc_split = list(temp_split)
		
		# In the case of a list using a colon and multiple semicolons,
		# attach each list item to the phrase before the colon.
		temp_split = []
		for sent in rfc_split:
			# OPENQ: What if multiple colons?
			if ': ' in sent and '; ' in sent and sent.index(': ') < sent.index('; '):
				sent_split = sent.split(': ')
				pre_colon_split = sent_split[:-1]
				pre_colon_split = ''.join(pre_colon_split)
				post_colon_split = sent_split[-1]
				semicolon_split = post_colon_split.split('; ')
				for i in range(len(semicolon_split)):
					colon_list_fragment = pre_colon_split + ': ' + semicolon_split[i]
					if i < len(semicolon_split) - 1:
						colon_list_fragment += '; '
					temp_split.append(colon_list_fragment)
			else:
				# Split by colons (while re-adding the splitting colons):
				# OPENQ: What if semicolon BEFORE colon in this instance?
				split_and_readd_punct(temp_split, sent, ':')
		rfc_split = list(temp_split)
		
		# Split by semicolons (while re-adding the splitting semicolons):
		temp_split = []
		for sent in rfc_split:
			split_and_readd_punct(temp_split, sent, ';')
		rfc_split = list(temp_split)
		
		return rfc_split
	except Exception:
		logger.exception('EXCEPTION')
		raise

	# Define ITS data assembly function:
def rfcitsdataassemblyparser(rfcdecidlistitem):
	try:
		decid = rfcdecidlistitem[0]
		rfc_lol_fa = rfcdecidlistitem[1]

		rfc_split = generate_snippets(rfc_lol_fa)
		
		# Begin assembling dataset:
		tuplist = []
		for sent in rfc_split:
			sent = ' ' + sent + ' '
			tuplist.append((decid, sent, '', '', '', '', ''))
		tuplist.append(('','', '', '', '', '', ''))
		
		return tuplist
	except Exception:
		logger.exception('EXCEPTION')
		raise

# Testing:
if __name__ == '__main__':
	
	import datetime
	import multiprocessing
	import pandas
	from multiprocessing import Pool, Manager
	import glob
	import numpy as np
	import nltk
	from nltk import word_tokenize
	from nltk.tokenize.punkt import PunktSentenceTokenizer, PunktParameters
	

	# Open the INSIGHT FY 2014 dataset:
	print 'Loading INSIGHT data...'
	# OPEN Q: I can't find this file...
	# df = pandas.read_csv('D:\\ITS\\newrfctxtvalues_its_study.csv', dtype=str, na_filter=False)
	df = pandas.read_csv('newrfctxtvalues_its_study.csv', dtype=str, na_filter=False)

	# Build a decid:RFC dictionary from 'rfctxt' values:
	print len(df)
	df = df[~df['rfctxt'].isin(['U', 'E'])]
	print len(df)
	decidrfcdict = dict(zip(df['DOCU_CTL_ID'], df['rfctxt']))
	decidrfcdict_lol = []
	for k,v in decidrfcdict.iteritems():
		decidrfcdict_lol.append((k,v))
	print 'decidrfcdict_lol len: ' + str(len(decidrfcdict_lol))

	## THIS IS PREP WORK TO CONVERT A LARGER INSIGHT EXTRACT DATAFRAME TO ONLY A RELEVANT SUBSECTION OF CASES AND VALUES ##
	## NO LONGER RELEVANT ##
	# Build a decid:rfctxtfnum dictionary:
	# ffavdf_rfctxtfnum = ffavdf[ffavdf['rfctxt'].isin(['U', 'P'])]
	# ffavdf_rfctxtfnum = ffavdf_rfctxtfnum[~ffavdf_rfctxtfnum['rfctxtfnum'].isin(['U', 'P'])]
	# ffavdf_rfctxtfnum.sample(frac=0.99)
	# decidrfcdict2 = dict(zip(ffavdf_rfctxt['DOCU_CTL_ID'], ffavdf_rfctxt['rfctxtfnum']))
	# decidrfcdict2_lol = []
	# for k,v in decidrfcdict2:
		# decidrfcdict2_lol.append([k,v])
	# print 'decidrfcdict2_lol len: ' + str(len(decidrfcdict2_lol))

	# # Clean INSIGHT RFC values by removing 'rfctxtfnum' values where the term 'past relevant work' appears:
	# decidrfcdict2_lol_REV1 = []
	# for item in decidrfcdict2_lol:
		# if not re.search(r'[^a-zA-Z]past\s{0,}relevant\s{0,}work', item[1], re.I):
			# decidrfcdict2_lol_REV1.append(item)
	# print 'decidrfcdict2_lol_REV1 len (post 'PRW err' removal): ' + str(len(decidrfcdict2_lol_REV1))

	# Begin multiprocessing:
	#decidrfcdict_lol = decidrfcdict_lol[:40000]
	
	cpu_count = multiprocessing.cpu_count()
	processes_ct = int(round(cpu_count*float(0.7)))
	pool = multiprocessing.Pool(processes=processes_ct)
	results = pool.map_async(rfcitsdataassemblyparser, decidrfcdict_lol)
	pool.close()
	pool.join()
	resultsretrieved = results.get()
	resultsretrieved_rev = []
	for item in resultsretrieved:
		if isinstance(item, tuple):
			resultsretrieved_rev.append(item)
		else:
			for subitem in item:
				resultsretrieved_rev.append(subitem)
	
	
	
	# Save results:
	rfcitsdf = pandas.DataFrame(resultsretrieved_rev)
	timestamp = datetime.datetime.now().strftime('%m-%d-%y_%H%M%S%p')
	df_fullpath_new = 'rfcits_assignmentdata_' + timestamp + '.csv'
	rfcitsdf.to_csv(df_fullpath_new, dtype=str,
					index=None, header=['DOCU_CTL_ID', 'SNIPPET', 'NONSTRICT_COMPLIANT_PRESENT?',
										'NONSTRICT_NONCOMPLIANT_PRESENT?', 'STRICT_PRESENT?', 'NOTES', 'UNSURE'])
	print 'Complete!'