import os
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from lxml import html
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains

# Set directories:
#setup_config
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)


#pytest -v test_case_search.py::TestSSNSearch::test_ssn_sort
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_find
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_filter


class TestCaseSearch(unittest.TestCase):

    '''Setup test'''
    def setUp(self):
        print
        #Instantiate webdriver IE browser
        self.driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        #self.driver = webdriver.Chrome("C:\\IEDriver\\chromedriver.exe")
        #Navigate to Insight Web app
        self.url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results"
        #self.user_id = "897960"
        #Wait for a certain amount time before throwing an exception if page is not found.
        self.wait = WebDriverWait(self.driver, 2)
    
    
         
    

    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_filter(self):       
        '''Test filter function for case search tool'''
        driver = self.driver
        url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results"
        driver.get(url)
        #driver.execute_script("document.getElementsByClassName('ssn_results_column')")
        time.sleep(5)
        Table =  driver.find_element_by_xpath("//div/table[@class ='show tablesorter']") 
        #driver.find_element_by_id("decision_table")
        print Table.text
        ssn_list = driver.find_element_by_xpath("//table/tbody/tr/td[@class ='ssn_results_column']").getAttribute("innerHTML") 
        #driver.execute_script("document.getElementsByClassName('ssn_results_column')")
        
        #driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        print ssn_list
        #sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], 3)]
        time.sleep(2)
        ssn_filter = driver.execute_script("document.getElementById('ssnFilter')")
        print ssn_filter
        '''
        for item in sample_ssn_list:
            ssn_filter.send_keys(item[:4])
            time.sleep(2)
            ssn_filter.clear()
        time.sleep(5)
        '''
    def test_url(self):
        url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results/ssn"
        #"http://s1ff515:9008/search_results/"
        assert url

    def tearDown(self):
        '''Tear Down test'''
        self.driver.close()


def suite():
    suite = unittest.TestSuite()
    suite.addTest(TestSSNSearch('test_ssn_sort'))
    suite.addTest(TestSSNSearch('test_ssn_filter'))
    suite.addTest(TestSSNSearch('test_ssn_find'))
    return suite


if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
