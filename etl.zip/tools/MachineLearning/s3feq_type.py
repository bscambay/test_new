# step 3 finding, not sure what feq_type means

from ml_util import ML_util

# logging location
logging_dir = '{}.log'.format(__file__)
ml = ML_util("S3FEVERDICTTYPEFEATURESREV3.txt", 'OneVsRestClassifier', 3, logging_dir)
ml.run()
