# Script to Reset Environment Variables 
# Step #1: delete any existing insight environment variables.  All insight variables will begin with "INSIGHT_"
# Step #2: after clearing existing insight variable, read the associated env file and add new variables.

# Environment Variable Levels: Process, User, Machine
# Machine level requires Administrative Access

#$EnvironmenVariableLevel = [System.EnvironmentVariableTarget]::User;
$EnvironmenVariableLevel = [System.EnvironmentVariableTarget]::Machine;
#$EnvironmenVariableLevel = [System.EnvironmentVariableTarget]::Process;

$AddVariableFilePath = "C:\nlp\vc\prod\src\.env"; # this looks for the .env file in the root of the repository.  
if([System.IO.File]::Exists($AddVariableFilePath))
{
    $CurrentEnvVariables = [System.Environment]::GetEnvironmentVariables($EnvironmenVariableLevel);
    foreach($envVariable in $CurrentEnvVariables.Keys)
    {   
        if(!$envVariable.StartsWith("INSIGHT_")){continue;}

        [System.Environment]::SetEnvironmentVariable($envVariable, $null, $EnvironmenVariableLevel);
        [System.Console]::WriteLine("Variable Deleted: " + $envVariable);
    }

    $AddEnvVariableData = Get-Content -Path $AddVariableFilePath;
    foreach($row in $AddEnvVariableData)
    {
        if($row -NOTLIKE "*=*"){continue;}

        # file data is in the format, VARIABLE_NAME = VARIABLE_VALUE
        # Get the index of the first occurrence of the equal sign to split the string
        $EqualIndex = $row.IndexOf("=");
        $EnvVariableName = $row.Substring(0, $EqualIndex).Trim();
        $EnvVariableValue = $row.Substring($EqualIndex + 1).Trim();
        $EnvVariableValue = $EnvVariableValue.Replace("'","");
        $EnvVariableValue = $EnvVariableValue.Replace('"',"");

        # Create new Environment Variable
        [System.Environment]::SetEnvironmentVariable($EnvVariableName, $EnvVariableValue, $EnvironmenVariableLevel);
        [System.Console]::WriteLine("Variable Set: " + $EnvVariableName + ", Value: " + $EnvVariableValue);
    }
}