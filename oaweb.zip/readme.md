# Insight Analysis for OAO

## Starting

Start out by cloning this repository:
```
cd c:\ws\repos
git clone ssh://git@stash.ba.ssa.gov/ins/insight_analysis_oao.git
cd insight_analysis_oao
```
Install dependancies
```
robocopy \\s1ff600\resources c:\ProgramData\Pip pip.ini /NFL /NDL /s
pip install -r requires.txt
```

## Configuration/Credential management
Configuration and Credentials are managed via environment variables found in the .env file.
There is a sample.env file in the 'src' directory that contains all the credentials. Do not enter personal credentials in this file.
This sample.env gets copied into a .env file automatically if this is the first time the code is running.
For local development update the .env file with personal user/password information.

## Testing
Note:
    Tox will take a while to run upon first invocation.  Tox run a second time runs much faster because it keeps track of virtualenv details and will not recreate or re-install dependencies.
```
pip install tox
```
unit test
```
tox -e test-scripts
```
code coverage
```
tox -e cov-report
```
lint
```
tox -e lint
```
run all
```
tox or tox -v
```
