# INSIGHT FULL SUITE MASTER CONFIGURATION FILE
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.11.2017
#
# SUMMARY: 
# Contains configuration data.  For security reasons, this will NOT be 
# distributed externally to INSIGHT version control.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import datetime
import os.path
import multiprocessing


# IFS OAO Bottle settings:
#
# # Set AJAX route:
# ajax_rt_dict = {'dev':'http://localhost:8080', 'prod':'http://insight.ba.ssa.gov:8189'}
# ajax_rt = ajax_rt_dict['dev']
#
# # Set parameter values for ifs_bottle_oao.py Bottle 'run()' call:
# bottle_run_hn = 'localhost'
# bottle_run_port_dict = {'dev':8080, 'prod':8190}
# bottle_run_port = bottle_run_port_dict['dev']


# IFS Database Table Names:
ifs_database_tblnm_list_s2_struct = ['struct_hodisp', 'struct_oao', 'struct_exp']
ifs_database_tblnm_list_s2_nonstruct_parent = 'dspn_doc'
ifs_database_tblnm_list_s2_nonstruct_child = ['claimdisp', 'quality', 's1sga', 's2', 'mdi', 's3mteq', 's3feq', 'rfc', 's4', 's4dot', 's5', 's5dot', 'mvr', 'srcnm']


# IFS OAO ETL/Batch Process Settings:
# TIP: Use ONLY forward slashes for paths.
batch_tgt_uid_nm = r'DOCU_CTL_ID'
batch_loop_interval = r'60'
batch_output_fn_fromroot = r'ifs_batch_%s.csv' % datetime.datetime.now().strftime('%m%d%Y_%I%M%S%p')
batch_exp_output_fp_fromroot = r'ifs_batch_exp_%s.csv' % datetime.datetime.now().strftime('%m%d%Y_%I%M%S%p')
# TIP: Max size of (PACAR rows) to process during an individual ETL run:
batch_size = 200
# TIP: Whether to randomize before slicing to the 'batch_size' number:
batch_random = True
# TIP: batch_mp_process_ct be either an integer or 'U'; if 'U', then
# ifs_batch.py will use half of the processing computer's
# total CPUs:
batch_mp_ver = False
batch_mp_process_ct = 'U'
# TIP: Filter out existing DOCU_CTL_ID observations in ifs_batch.py: 
batch_filter_existing_ver = True
batch_savetofile_ver = False
batch_savetodatabase_ver = True

# Store row with no doc_ctrl_id
batch_store_no_doc_ctrl_id = True

# Store records where ocr conversion failed
batch_store_tiff_txt_fail = True

# Store records where documents were not downloaded
batch_store_no_doc_download = True

# Store non_convered cases
batch_store_non_convered = True

# Filter failed struct oao
batch_filter_failed_struct_oao = True

# ETL Folders
batch_temp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../input/temp"))
batch_decisionfiles_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../input/decisionfiles"))
outputdir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../output"))

# Create folders if necessary
if not os.path.exists(batch_temp_dir):
    os.makedirs(batch_temp_dir)

if not os.path.exists(batch_decisionfiles_dir):
    os.makedirs(batch_decisionfiles_dir)

if not os.path.exists(outputdir):
    os.makedirs(outputdir)

# TODO: Create MEDIB/MIDIB DEV/PROD config variable.


