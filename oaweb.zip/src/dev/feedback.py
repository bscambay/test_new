import urllib

import psycopg2
from bottle import route, run, request, response
import config as cfg


def insert_feedback(rid, vname, vvalue, insert_src):
    args = (rid, vname, vvalue, insert_src)

    # print  args
    conn = psycopg2.connect("host='%s' port='%s' dbname='%s' user='%s' password='%s'" % (cfg.postgres_hostname, cfg.postgres_port, cfg.postgres_dbname, cfg.postgres_username, cfg.postgres_password))
    cursor = conn.cursor()

    sql = "INSERT INTO feedback (rid, vname, vvalue, insert_src) VALUES (%s, %s, %s, %s)"
    # print sql

    nbr = cursor.execute(sql, args)
    conn.commit()

    cursor.close()
    conn.close()


@route('/oaofb1')
def oaofb1():
    return " Get Request is Alive!"


@route('/oaofb/<rid:re:[0-9]+>', method=['POST'])
def oaofb(rid):
    user = request.headers.get("X-Remote-User")
    print "alive....."
    body = request.body.read()
    print "body = " + body
    body = body.replace("+", " ").replace("payload=", "")
    parsedBody = urllib.unquote(body).decode('utf8')
    nlp = parsedBody.split('&')

    ridid = str(rid)
    # ridid = str(request.forms.get("rid"))

    print "rid = " + ridid
    for i in nlp:
        type = i.split("=")
        insert_feedback(ridid, type[0], type[1], user)
    response.status = 200
    print "Reponse Processed", response
    response["responseText"] = "mike"
    return 'Ajax Call Processed!' + str(user)


run(host='localhost', port=8098, server='cherrypy', debug=True, reloader=True)
