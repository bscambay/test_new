import os
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select

# Set directories:
#setup_config
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)


#pytest -v test_case_search.py::TestSSNSearch::test_ssn_sort
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_find
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_filter


class TestCaseSearch_new(object):

    '''Setup test'''
    def setUp(self):
        print
        #Instantiate webdriver IE browser
        self.driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        #Navigate to Insight Web app
        self.url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results/ssn"
        #"http://localhost:8080/search_results/"
        self.user_id = "897960"
        #Wait for a certain amount time before throwing an exception if page is not found.
        self.wait = WebDriverWait(self.driver, 10)

    def test_url(self):
        #assert url
         
    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_sort(self):
        '''Test sort function for case search tool'''

        driver = self.driver
        driver.get(self.url)
        index = 1
        rowElements = driver.find_elements_by_xpath("//th[contains(@class, 'header')]")
        index = 1
        for ele in rowElements: 
            if index == 1: 
                print index, ele.text
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
                assert sorted(data) == data
            elif index > 1:
                print index, ele.text  
                ele.click()   
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
            
                date_pattern = re.match("(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$", data[0].split()[0].strip())
                if date_pattern != None:
                    data = [item.split()[0] for item in data]
                    assert sorted(data, key=lambda x: datetime.datetime.strptime(x, '%m/%d/%Y')) \
                        ==  [item.split()[0] for item in data]
                else:
                    assert sorted(data) == data
            index = index + 1
            data = []
            time.sleep(1)
        

    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_filter(self):
        '''Test filter function for case search tool'''
        #Set up data structure dictionary for contrived test data utilized during the test
        self.ssn_data = {
            'ssn_data1' : {'ssn':267-15-2504},
            'ssn_data2' : {'ssn':007-30-0907 }
            }
        self.ssn_nbrs = {k:v for k,v in self.ssn_data.iteritems() if 'ssn_data' in k}
        driver = self.driver
        driver.get(self.url)
        #ssn_data
        ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], 3)]
        ssn_filter = driver.find_element_by_id("ssnFilter")
        for item in sample_ssn_list:
            ssn_filter.send_keys(item[:4])
            time.sleep(2)
            ssn_filter.clear()
        time.sleep(5)

    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_find(self):
        '''Test find function for case search tool'''
        driver = self.driver
        driver.get(self.url)
        ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        print len(ssn_list)
        sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], 3)]
        
        for ssn in sample_ssn_list:
            driver.find_element_by_name('ssn_search').send_keys(ssn)
            wait = WebDriverWait(driver, 10)
            confirm = wait.until(EC.element_to_be_clickable((By.ID, "ssn_find")))
            confirm.click()
            #driver.find_element_by_id('ssn_find').click()
            time.sleep(1)
            driver.find_element_by_name('ssn_search').clear()
            #driver.find_element_by_id('ssn_find').click()
            wait = WebDriverWait(driver, 10)
            confirm = wait.until(EC.element_to_be_clickable((By.NAME, "ssn_search")))
            confirm.click()
          
        time.sleep(3)

    def tearDown(self):
        '''Tear Down test'''
        self.driver.close()


def suite():
    suite = unittest.TestSuite()
    suite.addTest(TestSSNSearch('test_ssn_sort'))
    suite.addTest(TestSSNSearch('test_ssn_filter'))
    suite.addTest(TestSSNSearch('test_ssn_find'))
    return suite


if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
