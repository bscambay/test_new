# INSIGHT HEARING DECISION QUALITY ANALYSIS ALGORITHM (INSIGHT Quality) -
# INDIVIDUAL DECISION HTML REPORT GENERATOR TEMPLATE JQUERY & HTML SNIPPETS
#
# AUTHOR:
# Kurt Glaze & Eric Kim
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# SUMMARY:
# Contains JQuery and JHTML template snippets utilized by 'iqrgenerator'
# to generate a custom INSIGHT Quality feedback HTML report file based on
# INSIGHT data values for a given decision text entity.
#
# DATE LAST UPDATED:
# 09.10.2016
#
# WARNING:
# The following is alpha-level/prototype software whose output quality has
# not yet been formally validated and whose documentation is not yet fully
# formed.
# ==============================================================================

# TIP: Not loading logging module here as this is a storage script.

# Define HTML Templates:

# Impairment Explorer HTML Template:


# HTML template to replace an SEP step 'problem' flag container variable
# where NO problem flags are present for that SEP step:
noprobdiv = """
<div class="indivflag">
	<div class='noprobdiv' title="No issues meriting attention relating to this area were detected.">No issues detected</div>
</div>"""

# HTML template to replace an SEP step other flag container variable where
# no flag entities are present for that SEP step:
nootherdiv = """
<div class="indivflag">
	<div class='noprobdiv' title="MEANING: No other flags are present for this SEP step category.">No other flags present</div>
</div>"""

# HTML template to replace an individual flag/feedback form where an outer
# loop exception occurs in the 'create_flagandff' function:
ff_outerloopexceptiontemplate = """
<div class="probothercontainer">
<div class="indivflag">
	<div class="flagtxtdiv">VARIABLE_flagtext_brief_desc<span class="errflagspan">VARIABLE_flagtext</span></div>
</div>
</div>"""

# HTML template for each individual flag's feedback form toggle button,
# text, and feedback form:
ff_fullHTMLtemplate = """
<div class="indivflag">
	<div class="ffbutton"><button class="feedbacktogglebutton" data-is-accordian=1 id="VARIABLE_fftogglebutton" data-toggle-id=
	"VARIABLE_ffdiv" aria-label="VARIABLE_flagtext_brief_desc VARIABLE_flagtext" aria-expanded=false>&#x02c5;</button></div>
	<div class="flagtxtdiv">VARIABLE_flagtext_brief_desc<span class="VARIABLE_flagcolor">VARIABLE_flagtext</span></div>
</div>
<!--OPTIONALTABLEVARIABLE-->
<div id="VARIABLE_ffdiv">
	<form class="ff" id="VARIABLE_ff" action="/IQ/save_VARIABLE_ff" data-post-url="/_oaofb" method="post" target="dummyframe">
		<div style="display:table;">
			<div style="display:table-row">
				<div class="fftablecellstatic"><h4 class="ffheader">About This Flag:</h4></div><div class="fftablecellcustom">VARIABLE_ffabout</div>
			</div>
			<div style="display:table-row">
				<div class="fftablecellstatic"><h4 class="ffheader">Related Regulations:</h4></div><div class="fftablecellcustom">VARIABLE_ffreg</div>
			</div>
			<div style="display:table-row">
				<div class="fftablecellstatic"><h4 class="ffheader">Issue With This Flag?</h4></div><div class="fftablecellcustom">Please check the option(s) that best describes the issue. If none describe it, enter a brief description of the issue below 'Other'.</div>
			</div>
		</div>
		VARIABLE_CHECKBOXES
        OTHER_TEXTAREA
		<br>
		<!--submit button given class textarea_button, and reset button class changed to textarea_button-->
		<input class="textarea_button" type="submit" id="VARIABLE_ff_submit" value="Send">
		<button class="textarea_button" type="reset" id="VARIABLE_ff_reset" form="VARIABLE_ff">Clear</button>
	</form>
</div>
"""

ff_otherTextArea = """
<label class="ffother" for="textarea_id" style="display:block;">Other Issue:</label>
<textarea aria-label="Other Issue With This Flag: VARIABLE_flagtext_brief_desc" class="fftextarea" id="textarea_id" name="VARIABLE_ff_othertextbox" form="VARIABLE_ff" cols="40" rows="2" ... ></textarea>
<br>
"""

# AC VERSION HTML template for each individual flag's feedback form toggle
# button, text, and feedback form:
ff_fullHTMLtemplate_ACvsn = """
<div class="indivflag">
	<div class="ffbutton"><button class="feedbacktogglebutton" data-is-accordian=1 id="VARIABLE_fftogglebutton" data-toggle-id=
	"VARIABLE_ffdiv" aria-label="VARIABLE_flagtext VARIABLE_flagtext" aria-expanded=false>&#x02c5;</button></div>
	<div class="flagtxtdiv">VARIABLE_flagtext_brief_desc<span class="VARIABLE_flagcolor">VARIABLE_flagtext</span></div>
	<!--OPTIONALTABLEVARIABLE-->
</div>
<div id="VARIABLE_ffdiv">
	<form class="ff" id="VARIABLE_ff" data-post-url="_oaofb" action="/IQ/save_VARIABLE_ff" method="post" target="dummyframe">
		<div style="display:table;">
			<div style="display:table-row">
				<div class="fftablecellstatic"><h4 class="ffheader">About This Flag:</h4></div><div class="fftablecellcustom">VARIABLE_ffabout</div>
			</div>
			<div style="display:table-row">
				<div class="fftablecellstatic"><h4 class="ffheader">Related Regulations:</h4></div><div class="fftablecellcustom">VARIABLE_ffreg</div>
			</div>
		</div>
	</form>
</div>
"""

# HTML sub-template for each individual flag's feedback form checkboxes:
ff_checkboxtemplate = """
<input  title="Issue With This Flag" class="ffinput" id="hash_txt" name="VARIABLE_ffcheckboxCT" type="checkbox"/>
</input>
<label for="hash_txt">TEXT</label>
<br>
"""

# HTML template for each individual flag's feedback form toggle button, text
# and form *when a GENERAL error has occurred*:
ff_fullHTMLtemplate_generror = """
<div class="indivflag">
	<div class="ffbutton"><button class="feedbacktogglebutton" data-is-accordian=1 id="VARIABLE_fftogglebutton" data-toggle-id=
	"VARIABLE_ffdiv" aria-label="VARIABLE_flagtext VARIABLE_flagtext" aria-expanded=false>&#x02c5;</button></div>
	<div class="flagtxtdiv"><span class="VARIABLE_flagcolor">VARIABLE_flagtext</span></div>
</div>
<div id="VARIABLE_ffdiv">
	<form class="ff" data-post-url="_oaofb">
		<div class="errflagdiv">Error generating dropdown. If this error persists, please report to DITI personnel.</div>
	</form>
</div>
"""

# HTML template for each flag's feedback form toggle button and form *when a
# LOOKUP error has occurred (i.e. when structured data isn't linked and thus
# the data value was never output by IQ - really this is tailored to the Step
# 1 SEQY flag)*:
# CANDIDATE FOR DEPRECATION (YOU SET THIS SORT OF FLAG TEXT BELOW - QUESTION
# IS WHETHER TO ENABLE FULL FEEDBACK FORM OR OUTPUT SOMETHING SIMILAR TO THE
# VERY SIMPLE 'NO PROBLEM' TEMPLATE!)
ff_fullHTMLtemplate_lookuperror = """
<div class="indivflag">
	<div class="ffbutton"><button class="feedbacktogglebutton" data-is-accordian=1 id="VARIABLE_fftogglebutton" data-toggle-id=
	"VARIABLE_ffdiv" aria-label="VARIABLE_flagtext VARIABLE_flagtext" aria-expanded=false>&#x02c5;</button></div>
	<div class="flagtxtdiv"><span class="VARIABLE_flagcolor">VARIABLE_flagtext</span></div>
</div>
<div id="VARIABLE_ffdiv">
	<form class="ff" data-post-url="_oaofb">
		<div class="errflagdiv">Error generating dropdown. If this error persists, please report to DITI personnel.</div>
	</form>
</div>
"""

# HTML template for errors:
errflagspanstart = """<span class='errflagspan'>"""
spanend = """</span>"""

# HTML template for DOT/RFC conflict table:
dotrfc_table = """
<div class="ffrfcdot" style="display:table;">
<div style="display:table-row">
<div class="fftablecellstatic"><h4 class="ffheader">DOT #</h4></div><div class="fftablecellstatic"><h4 class="ffheader">RFC Consistency</h4></div>
</div>
<!--DOTRFCROWSGOHERE-->
</div>
"""

# HTML template for DOT/RFC conflict individual rows:
dotrfc_tablerow = """
<div style="display:table-row">
<div class="fftablecellstatic"><span class="fftablecellcustom">VARIABLE_dotcode</span></div><div class="fftablecellcustom">VARIABLE_rfcconflictstrs</div>
</div>
 """

# (DEPRECATED 10272016) HTML template for the Impairment Explorer more info form:

# HTML template for each impairment item of the
# Impairment Explorer:
impexp_fullHTMLtemplate = """
<div class="indivflag">
	<div class="ffbutton"><button class="feedbacktogglebutton" data-is-accordian=1 id="VARIABLE_fftogglebutton" data-toggle-id=
	"VARIABLE_ffdiv" aria-label="VARIABLE_flagtext_brief_desc VARIABLE_flagtext" aria-expanded=false>&#x02c5;</button></div>
	<div class="flagtxtdiv">VARIABLE_flagtext_brief_desc<span class="noflagspan">VARIABLE_flagtext</span></div>
</div>
<div id="VARIABLE_ffdiv">
	<div class="ff">
		<div class="fftablecellstatic"><h4 class="ffheader">Def:</h4></div><div class="fftablecellcustom">VARIABLE_termdef</div>
		<table role="presentation">
			<tr>
				<th class="impexptableheader"><h4 class="ffheader">Affected Body Parts or Systems:</h4></th>
				<th class="impexptableheader"><h4 class="ffheader">Signs or Symptoms:</h4></th>
				<th class="impexptableheader"><h4 class="ffheader">Relevant Listings:</h4></th>
			</tr>
			<tr>
				<td class="impexptabledata">VARIABLE_apdata</td>
				<td class="impexptabledata">VARIABLE_ssdata</td>
				<td class="impexptabledata">VARIABLE_listingdata</td>
			</tr>
		</table>
	</div>
</div>
"""

# HTML template for no fields that returned no results in the
# Impairment Explorer WITHOUT search link (default)
noresultsfound = """<span class="noresultsfound">No results found.</span>"""

# HTML template for no fields that returned no results in the
# Impairment Explorer WITH search link:
noresultsfound_withsearch = """<span class="noresultsfound">No results found. <a href="https://www.google.com/#q=SEARCHTERM" target="_blank" aria-label="Google it SEARCHTERM_HUMAN">Google it.</a></span>"""

# HTML template for search link:
searchlink = """<span class="noresultsfound"> <a href="https://www.google.com/#q=SEARCHTERM" target="_blank" aria-label="Google it SEARCHTERM_HUMAN">Google it.</a></span>"""

# HTML template for no fields that returned no results in the
# Impairment Explorer WITH listings link
noresultsfound_withlistinglink = """<span class="noresultsfound">No results found.<br><a href="URLVAR" target="_blank" aria-label="View listings">View listings.</a></span>"""

# Custom Tools Page - HTML template for custom age calculation result row:
age_calc_row = """
<tr>
	<td valign="middle">
		<p class="result">AGE_DESC</p>
	</td>
	<td valign="middle">
		<p class="result">AGE_VAL</p>
	</td>
</tr>
"""

# Step 3 functionally equals template:
s3feq_PH_tpl = """<h2 class="subsection">Step 3 Functionally Equals: <span class="headingcustomcontent">s3feqver_HTML</span></h2>"""

# RFC template:
rfc_PH_tpl = """
<h2 class="subsection">RFC: <span class="headingcustomcontent">rfcfitexlvl_HTML</span></h2>
<div class="sepcontainer">
	<div class="probothercontainer">
		rfcflagprob_HTML
	</div>
	<div>
		<button aria-expanded=false aria-label="Show/Hide Other RFC Flag Results" class="fullresultstogglebutton" id="fullresultsbtn5" data-toggle-id='otherflagsdiv5'>Full Results</button>
		<div class="probothercontainer" id="otherflagsdiv5">
			rfcflagother_HTML
		</div>
	</div>
</div>
"""

# Step 4 template:
s4_PH_tpl = """
<h2 class="subsection">Step 4: <span class="headingcustomcontent">s4ver_HTML</span></h2>
<div class="sepcontainer">
	<div class="probothercontainer">
		s4flagprob_HTML
	</div>
	<div>
		<button aria-expanded=false aria-label="Show/Hide Other Step 4 Flag Results" class="fullresultstogglebutton" id="fullresultsbtn6" data-toggle-id='otherflagsdiv6'>Full Results</button>
		<div class="probothercontainer" id="otherflagsdiv6">
			s4flagother_HTML
		</div>
	</div>
</div>
"""

# Step 5 template:
s5_PH_tpl = """
<h2 class="subsection">Step 5: <span class="headingcustomcontent">s5ver_HTML</span></h2><!-- Step 5: Quality Bullets -->
<div class="sepcontainer">
	<div class="probothercontainer">
		s5flagprob_HTML
	</div>
	<!-- Step 5: Full Results -->
	<div>
		<button aria-expanded=false aria-label="Show/Hide Other Step 5 Flag Results" class="fullresultstogglebutton" id="fullresultsbtn7" data-toggle-id='otherflagsdiv7'>Full Results</button>
		<div class="probothercontainer" id="otherflagsdiv7">
			s5flagother_HTML
		</div>
	</div>
</div>
"""

# Case Summary Container DIV:
cs_div_tpl = """
			<div class="sectiondiv">

				<table role="presentation">
					<tr>
						<td>
							<div class="ffbutton">
                                    <button class="reportsectionbtn" id="reportsectionbtn_casesummary" data-is-accordian=1 data-toggle-id='casesummary' aria-label='Case Summary' aria-expanded='false'>&#x02c5;</button>
							</div>
						</td>
						<td>
							<h1 class="reportsection" id="navsummary">Case Summary</h1>
						</td>
						<td>
							<div class="ffbutton">
								<button class="moreinfotogglebuttonsec" data-toggle-id="casesummary_moreinfodiv" id="casesummarymoreinfobtn" aria-expanded=false aria-label="More Info about Case Summary">More Info</button>
							</div>
						</td>
					</tr>
				</table>

				<!-- Case Summary Section: More Info -->
				<div class="containerdiv" id="casesummary_moreinfodiv">
					<div class="indivflag">
						<form class="ff" id="casesummary_ff", name="casesummary_ff" data-post-url="_oaofb">
							<div style="display:table;">
								<div style="display:table-row">
									<div class="fftablecellstatic">
										<h4 class="ffheader">Summary</h4>
									</div>
									<div class="fftablecellcustom">
										The Case Summary section contains a collection of useful information about the case, from basic background information such as claim types to calculated information such as the
										RR filing deadline, links to pertinent policies, relevant claimant ages, and more.
										<br>
										<br>
									</div>
								</div>
								<div style="display:table-row">
									<div class="fftablecellstatic">
										<h4 class="ffheader">Sources of Info</h4>
									</div>
									<div class="fftablecellcustom">
										The source of all information provided in the Case Summary section is either (1) the case's hearing decision, or (2) existing structured data about the case contained in
										SSA systems (e.g. information such as the claim types at issue presented in tools like ARPS).
										<br>
										<br>
										We strive to use the most accurate source for each item of information provided based on study or an evaluation of case processing workflows. If the 'preferred' source does not have the information we seek to provide you, we sometimes use the other source as a backup measure.  If a non-preferred source is used, we'll add a 'Source' parenthetical beside that information letting you know.  If you don't see any such 'Source' parenthetical, we used the primary source.
										<br>
										<br>
										For your reference, the following is a list of the primary or 'preferred' source followed by the secondary or 'backup' source for each item of information provided in
										the Case Summary section.  If there is a primary source but no backup source, that means the information will always derive from the primary source:
										<ul>
											<li><span class="impexps2txtuline">Claim Type(s)</span>: Primary: Structured Data | Backup: None (Rationale: Structured data is typically very reliable for claim types; conversely, claim types are not reliably described in decision text).</li>
											<li><span class="impexps2txtuline">Disposition Type(s)</span>: Primary: Structured Data | Backup: None (Rationale: Structured data is typically very reliable for disposition types; conversely, disposition types are not reliably described in decision text).</li>
											<li><span class="impexps2txtuline">Claimant Date of Birth</span>: Primary: Structured Data | Backup: None (Rationale: Structured data is typically very reliable for date of birth; conversely, date of birth is not reliably present in decision text).</li>
											<li><span class="impexps2txtuline">Alleged Onset Date</span>: Primary: Decision | Backup: Structured Data (Rationale: Decision contains latest, 'controlling' AOD date, including amended AOD date; conversely, AOD dates in structured data may not be reliably updated, particularly if amended).</li>
											<li><span class="impexps2txtuline">Date(s) Filed</span>: Primary: Structured Data | Backup: None (Rationale: Structured data is typically very reliable for dates filed/protective filing dates; conversely, dates filed are not reliably described/present in decision text).</li>
											<li><span class="impexps2txtuline">Date Last Insured</span>: Primary: Decision | Backup: Structured Data (Rationale: Decision contains latest, 'controlling' DLI date; conversely, DLI values in structured data may not be reliably updated; note that once we can access DISCO, we also will output the 'latest' DLI as well for your reference).</li>
											<li><span class="impexps2txtuline">Disposition Date</span>: Primary: Decision | Backup: Structured Data (Rationale: Decision contains the 'controlling' disposition date; conversely, disposition dates in structured data often do not accurately reflect the date cited in the decision; note that INSIGHT has trouble detecting disposition date in decision text if a 'stamp' is used; in these cases the structured data value will be output).</li>
											<li><span class="impexps2txtuline">Request for Review Info</span>: Disposition date used to calculate RR timely filing deadline follows disposition date source order noted above; the RR receipt date is sourced from structured data, as we cannot presently 'examine' the text of RR forms received).</li>
											<li><span class="impexps2txtuline">SSO for Claimant Zip Code in Decision</span>: The decision is the only source used here for the claimant zip code used to calculate the SSO code.</li>
											<li><span class="impexps2txtuline">Claimant Ages at Start and End of PAI</span>: All information used to calculate the start and end of the PAI as well as claimant ages (from claimant date of birth to the AOD, DLI, etc.) follows the source orders for those items noted above.</li>
											<li><span class="impexps2txtuline">Claimant Weight Analysis</span>: Structured data is the only source used to calculate the claimant's weight.  You can find this information (the claimant's self-reported height and weight) in the Disability Report - Adult or Disability Report - Child (as appropriate).</li>
											<li><span class="impexps2txtuline">Circuit and Relevant Circuit ARs</span>: Primary: Decision | Backup: Structured Data (Rationale: Claimant address in decision is the 'controlling' address for applicable federal circuit calculation; conversely, claimant address information in structured data may not reliably reflect the address used in the decision).</li>
										</ul>
									</div>
								</div>
								<div style="display:table-row">
									<div class="fftablecellstatic">
										<h4 class="ffheader">WARNING</h4>
									</div>
									<div class="fftablecellcustom">
										Please note the following regarding the request for review (RR) timely filing deadline and timeliness alerts:
										<ul>
											<li>Timeliness alerts cannot account for the presence of 'postmark' dates that might merit a change to the date we consider the RR 'filed' for timeliness evaluation. See HALLEX I-3-1-1(D) for more information on postmarks.</li>
											<li>The deadline generated cannot account for extensions of the deadline due to "other non-work day for Federal employees" as noted in HALLEX I-3-1-1(D).</li>
											<li>The deadline generated automatically includes 5 additional days (for a total of 65 days) per HALLEX I-3-1-1(A).</li>
											<li>If a decision date cannot be extracted from the decision text itself, the deadline generated is calculated based on structured data, specifically the CPMS 'final disposition date' value.  Sometimes this value does not accurately correspond to the decision date cited in the decision document, which is controlling for the purpose of calculating the RR deadline.  Nevertheless, we still opt to calculate an RR deadline using this date to help ensure a deadline is provided to you. </li>
										</ul>
										Because of these issues, we again encourage you to treat this information as a 'jumping off point' and verify timeliness if it appears to be at issue.  A useful tool for this is the <a href="https://www.timeanddate.com/date/dateadd.html" target="_blank" aria-label="Add or Subtract From a Date Calculator at timeanddate.com">Add or Subtract From a Date Calculator at timeanddate.com</a>.
									</div>
								</div>

							</div>
						</form>
					</div>
				</div>

				<div id="casesummary">
					cs_claimtype_HTML
					cs_disptype_HTML
					cs_clmtdob_HTML
					cs_aod_HTML
					cs_dof_HTML
					cs_dli_HTML
					cs_did_HTML
					cs_rrtimely_HTML
					cs_sso_decisionzip_HTML
					cs_structagerelpaistart_HTML
					cs_structagerelpaiend_HTML
					cs_selfwt_HTML
					cs_circuitar_HTML
				</div>

			</div>"""
