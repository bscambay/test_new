
#Original author: Michael Iwunze
import os
import time
import sys
import re
import unittest
import logging
import requests
import pdb as pdb
import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select

# Set directories:
""" unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data") """
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")
date_helper = os.path.abspath("C:/WS/Repos/insight_analysis_oao/src/")
dh = os.path.abspath("C:/WS/Repos/insight_analysis_oao/src/")

# Import IFS module:
sys.path.insert(0, insightdir)

#import ifs_bmi_revised as bmi

#Import data helper
#import ifs_date_helper as dh

#Derive a Test class from the unittest.TestCase class
class TestInsight(unittest.TestCase):
    #Setup method for setting fixtures, data, variables atc...
    def setUp(self):
        print

        #Instantiate webdriver IE browser
        #self.driver = webdriver.Ie("C:\\IEDriver\\IEDriverServer.exe")
        self.driver =webdriver.Chrome("C:\\IEDriver\\chromedriver.exe")
        #Navigate to Insight Web app
        self.url = "http://localhost:8190/oaoapp/302"

        #Wait for a certain amount time before throwing an exception if page is not found.
        self.wait = WebDriverWait(self.driver, 10)

        #Define a list of headers to locate on the page
        self.headers = ['Case Summary', 'Quality Report', 'Tools']

        #self.driver.title = 'INSIGHT'

        #Set up data structure dictionary for contrived test data utilized during the test
        self.bmi_data = {
            'adult_bmi_data1' : {'Feet' : 4, 'Inches' : 'OOPS!', 'Weight' : 110, 'bmi' : 2.812},
            'adult_bmi_data2' : {'Feet' : 5, 'Inches' : 8, 'Weight' : 190, 'bmi' : 3.951},
            'adult_bmi_data3' : {'Feet' : 6, 'Inches' : 1, 'Weight' : 220, 'bmi' : 1.06},
            'child_bmi_data1' : {'Feet' : 3, 'Inches' : 7, 'Weight' : 85, 'Years': 5, 'Months':2, 'Sex': 'Female'},
            'child_bmi_data2' : {'Feet' : 4, 'Inches' : 11, 'Weight' : 100, 'Years': 10, 'Months':5,'Sex': 'Female'},
            'child_bmi_data3' : {'Feet' : 3, 'Inches' : 3, 'Weight' : 90, 'Years': 7, 'Months':9, 'Sex': 'Male'},
            'age_calc_data1'  : {'dob':'11/01/2012', 'eod':'08/06/2014', 'result':'1-y-9-m'},
            'age_calc_data2'  : {'dob':'01/01/1984', 'eod':'08/13/2016', 'result':'32-y-7-m'},
            'age_calc_data3'  : {'dob':'02/01/2000', 'eod':'08/15/2017', 'result':'17-y-6-m'}
            }
        #Data accessors
        self.adult_bmi = {k:v for k,v in self.bmi_data.iteritems() if 'adult_bmi' in k}
        self.child_bmi = {k:v for k,v in self.bmi_data.iteritems() if 'child_bmi' in k}
        self.age_calc = {k:v for k,v in self.bmi_data.iteritems() if 'age_calc' in k}

    #@unittest.skip("Skipping test_component_labels")
    def test_component_labels(self):

            driver = self.driver
            driver.get(self.url)

            #Call assert method to test for Title/Label on the Page
            self.assertIn('INSIGHT', self.driver.title)

            #Locate h1 headers
            elements = driver.find_elements_by_tag_name('h1')

            #Test that headers are present on the page...i.e, Case Summary, Quality Report..etc
            for ele in elements:
                self.assertIn(str(ele.text), self.headers)
            #Dont close browser immediately!!
            time.sleep(3)

    #Test age section
    @unittest.skip("Skipping test_age_calc")
    def test_age_calc(self):

            driver = self.driver

            # navigate to the application home page
            driver.get(self.url)
            submit_btn = driver.find_elements_by_id("calculate")
            #Use some JS Scroll dowm to age calculator section
            driver.execute_script("arguments[0].scrollIntoView();", submit_btn[2])

            #Go to Age calculation section
            #element = driver.find_element_by_id('agecalc_cldob')
            #driver.execute_script("arguments[0].click();", element)

            #Locate DOB text field:
            dob = driver.find_element_by_id('agecalcdob')

            #Locate EOD text field
            eod = driver.find_element_by_id('enddate')

            for idx, data in enumerate(self.age_calc.values()):

                #Data dictionary to aquire the necessary inputs to DOB and EOB and expected result fields
                dob_str, eod_str, result_str = data['dob'], data['eod'], data['result']

                #self.assertEqual(dh.parse_date_tostr('January 24, 1984'), '01/24/1984')
                #dob_str = dh.parse_date_tostr(dob_str)
                #print dob_str
                #Test calc age function

                #Run age calculator and use assert method to test result
                agecalc = dh.calc_age(dob_str, eod_str)
                self.assertEqual(agecalc, result_str)

                #driver.execute_script("arguments[0].scrollToView;", submit_btn[2])

                #Clear pre populated text fields and input eod and dob text in fields.
                driver.find_element_by_id('agecalcdob').clear()
                driver.find_element_by_id('enddate').clear()
                dob.send_keys(dob_str)
                eod.send_keys(eod_str)
                time.sleep(1) #I need you to wait
                time.sleep(1)
                #Click the Submit button
                submit_btn[2].click()
                #Wait for result element to appear.
                ele = self.wait.until(EC.visibility_of_element_located((By.ID, 'agecalc_result')))
                print ele.text
                #Use assert to ensure result label is correct
                self.assertEqual(result_str, str(ele.text).split()[0])
                time.sleep(3)
                print

    #@unittest.skip("Skipping test_adult_bmi")
    def test_adult_bmi(self):
            print 'Testing '
            driver = self.driver
            # navigate to the application home page
            driver.get(self.url)

            #elements = driver.find_elements_by_tag_name('h2')

            #for ele in elements:
            #    if "Adult (18+) BMI Calculator" in ele.text:
            #            driver.execute_script("arguments[0].scrollIntoView();", ele)

            element = driver.find_element_by_id('sso_showhide_btn')
            driver.execute_script("arguments[0].scrollIntoView();", element)


            #Locate height, inches and weight text fields
            bmi_ft = driver.find_elements_by_id('htft')
            bmi_in = driver.find_elements_by_id('htin')
            bmi_wt = driver.find_elements_by_id('wt')


            for idx, data in enumerate(self.adult_bmi.values()):

                #Aquire Data from data dictionary for input fields

                weight, feet, inches, bmi_data = data['Weight'], data['Feet'], data['Inches'], data['bmi']

                driver.find_element_by_id('wt').clear()
                driver.find_element_by_id('htft').clear()
                driver.find_element_by_id('htin').clear()

                #Populate input fields with aquired data
                bmi_wt[0].send_keys(weight)
                bmi_ft[0].send_keys(feet)
                bmi_in[0].send_keys(inches)

                #This handles bad input data and corrects.
                if isinstance(inches, str):
                    time.sleep(2.0)
                    driver.find_element_by_id('htin').clear()
                    bmi_in[0].send_keys('10')
                #Wait for to view result
                time.sleep(3)

                print
                print '{}: {} {} {}'.format(idx, weight, feet, inches)
                print
                ele = driver.find_element_by_id("bmiresult")
                #Make text exists
                self.assertIsNotNone(ele.text)
                print '  {}'.format(ele.text)
                time.sleep(2)
                print
            time.sleep(3)


    #@unittest.skip("Skipping test_child_bmi")
    def test_child_bmi(self):

        driver = self.driver
        # navigate to the application home page
        driver.get(self.url)

        #Scroll to adult bmi result area for full view child bmi section below.
        bmi_result = driver.find_element_by_class_name("result")
        driver.execute_script("arguments[0].scrollIntoView();", bmi_result)

        bmi_ft = driver.find_elements_by_id('htft')
        bmi_in = driver.find_elements_by_id('htin')
        bmi_wt = driver.find_elements_by_id('wt')
        bmi_yr = driver.find_elements_by_id('ageyr')
        bmi_mo = driver.find_elements_by_id('agemr')


        for idx, data in enumerate(self.child_bmi.values()):

            feet, inches, weight, years, months, sex \
            =  data['Feet'], data['Inches'], data['Weight'], data['Years'], data['Months'], data['Sex']

            bmi_ft[1].clear()
            bmi_in[1].clear()
            bmi_wt[1].clear()
            bmi_yr[0].clear()
            bmi_mo[0].clear()

            bmi_ft[1].send_keys(feet)
            bmi_in[1].send_keys(inches)
            bmi_wt[1].send_keys(weight)
            bmi_yr[0].send_keys(years)
            bmi_mo[0].send_keys(months)
            time.sleep(1)
            el = driver.find_element_by_name('sex')
            all_options = el.find_elements_by_tag_name('option')
            for option in all_options:
                if option.text == sex:
                    option.click()
                    break

            element = driver.find_elements_by_id("calculate")
            element[1].click()
            ele = driver.find_element_by_id("childbmi_result")
            print ele.text


            #agecalc = dh.calc_age("01/01/1990", "06/01/2000")
            #self.assertEqual(agecalc, "10-y-5-m")

            time.sleep(2)
            print


    def tearDown(self):
        self.driver.close()


def suite():
    suite = unittest.TestSuite()
    #suite.addTest(TestInsight('test_child_bmi'))
    #suite.addTest(TestInsight('test_adult_bmi'))
    suite.addTest(TestInsight('test_age_calc'))
    return suite


if __name__== "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite())