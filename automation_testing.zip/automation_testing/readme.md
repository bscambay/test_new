# Insight Automated Validation

## Starting

Start out by cloning this repository:
```
cd c:\ws\repos
git clone ssh://git@stash.ba.ssa.gov/ins/automation_testing.git
cd automation_testing
```
Install dependancies
```
robocopy \\s1ff600\resources c:\ProgramData\Pip pip.ini /NFL /NDL /s
pip install -r requires.txt
```
## Testing
```
tox
```
