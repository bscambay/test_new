$(document).ready(function () {
    var allBoxes = $("div.boxes").children("div");
    transitionBox(null, allBoxes.first());
});

function transitionBox(from, to) {
    function next() {
        var nextTo;
        if (to.is(":last-child")) {
            nextTo = to.closest(".boxes").children("div").first();
        } else {
            nextTo = to.next();
        }
        to.fadeIn(500, function () {
            setTimeout(function () {
                transitionBox(to, nextTo);
            }, 7000);
        });
    }
    
    if (from) {
        from.fadeOut(500, next);
    } else {
        next();
    }
}


/// HTML TO USE:
/// <div class="boxes">
///     <div class="box1">
/// 	<p>This is a paragraph in box 1.</p>
/// 	<p>This is a paragraph in box 1.</p>
/// 	<p>This is a paragraph in box 1.</p>
/// 	</div>
///     <div class="box2">
/// 	<p>This is a paragraph in box 2.</p>
/// 	<p>This is a paragraph in box 2.</p>
/// 	<p>This is a paragraph in box 2.</p>
/// 	</div>
///     <div class="box3">
/// 	<p>This is a paragraph in box 3.</p>
/// 	<p>This is a paragraph in box 3.</p>
/// 	<p>This is a paragraph in box 3.</p>
/// 	</div>
/// </div>
///
/// <script type="text/javascript" src="static/about.js"></script>

/// CSS TO USE:
/* Define About section box styles */
/// .boxes div {
///     display: none;
/// }