﻿using INSIGHT_Request.Models;
using INSIGHT_Request.Properties;
using INSIGHT_Request.Util;
using log4net;
using System;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Caching;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;

namespace INSIGHT_Request
{
    public static class WWData
    {
        private static ILog logger = log4net.LogManager.GetLogger(typeof(WWData));


        private static OdbcConnection pc = new OdbcConnection("DSN=" + Settings.Default.DbDSN + ";uid=" + getPsqlUID() + ";pwd=" + getPsqlPWD() + ";");
        private static OdbcConnection oc = new OdbcConnection("");

        private static string getPsqlUID()
        {
            MemoryCache cache = MemoryCache.Default;
            string psqlUID = (string)cache["psqlUID"];
            return psqlUID;
        }

        private static string getPsqlPWD()
        {
            MemoryCache cache = MemoryCache.Default;
            string psqlPWD = (string)cache["psqlPWD"];
            return psqlPWD;
        }

        private static string getDb2DSN()
        {
            MemoryCache cache = MemoryCache.Default;
            string db2DSN = (string)cache["db2DSN"];
            return db2DSN;
        }
        private static string getDb2UID()
        {
            MemoryCache cache = MemoryCache.Default;
            string db2UID = (string)cache["db2UID"];
            return db2UID;
        }
        private static string getDb2PWD()
        {
            MemoryCache cache = MemoryCache.Default;
            string db2PWD = (string)cache["db2PWD"];
            return db2PWD;
        }
        private static string getDb2SCHEMA()
        {
            MemoryCache cache = MemoryCache.Default;
            string db2SCHEMA = (string)cache["db2SCHEMA"];
            return db2SCHEMA;
        }
        private static string getDb2Connection()
        {
            return "DSN=" + getDb2DSN() + ";uid=" + getDb2UID() + ";pwd=" + getDb2PWD() + ";";
        }

        private static string getInsightConnection()
        {
            MemoryCache cache = MemoryCache.Default;
            string insightConnection = (string)cache["insight-connection-string"];
            return insightConnection;
        }
        private static string getInsightConnectionOAO()
        {
            MemoryCache cache = MemoryCache.Default;
            string insightConnectionOAO = (string)cache["insight-connection-string-oao"];
            return insightConnectionOAO;
        }

        private static string getMHAConnection()
        {
            return "DSN=" + getMHADSN() + ";uid=" + getMHAUID() + ";pwd=" + getMHAPWD() + ";";
        }

        private static string getMHADSN()
        {
            MemoryCache cache = MemoryCache.Default;
            string mhaDSN = (string)cache["mhaDSN"];
            return mhaDSN;
        }
        private static string getMHAPWD()
        {
            MemoryCache cache = MemoryCache.Default;
            string mhaPWD = (string)cache["mhaPWD"];
            return mhaPWD;
        }

        private static string getMHAUID()
        {
            MemoryCache cache = MemoryCache.Default;
            string mhaUID = (string)cache["mhaUID"];
            return mhaUID;
        }

        private static string getMHASchema()
        {
            MemoryCache cache = MemoryCache.Default;
            string mhaSCHEMA = (string)cache["mhaSCHEMA"];
            return mhaSCHEMA;
        }
        private static string getMeDibSchema()
        {
            MemoryCache cache = MemoryCache.Default;
            string medibSCHEMA = (string)cache["medibSCHEMA"];
            return medibSCHEMA;
        }

        private static string getOAOReportServer()
        {
            MemoryCache cache = MemoryCache.Default;
            string reportServer = (string)cache["insight-oao-report-server"];
            reportServer = Regex.Replace(reportServer, "Server=", string.Empty, RegexOptions.IgnoreCase);
            return reportServer;
        }

        /// <summary>
        /// Note: When switching from SQLServer to Postgres this method most be used
        /// to get the last RID. This sucks because even if we wrap this in a transaction there is potential 
        /// to retrieve the wrong value especially since there are multiple clients
        /// However it is minimized by the fact that the service itself should only have one db and two
        /// clients HLP and EFI
        /// </summary>
        /// <returns></returns>
        private static string LastId()
        {
            string rid = "";

            OdbcCommand cmd = new OdbcCommand("", pc);
            //query the sequence object itself better than select MAX(rid)
            string sql = "select last_value from public.rqst_rid_seq;";
            cmd.CommandText = sql;
            pc.Open();
            rid = cmd.ExecuteScalar().ToString();
            pc.Close();
            return rid;
        }
        public static DataTable getDocTypes()
        {
            OdbcCommand cmd = new OdbcCommand("", pc);
            string sql = @"SELECT ID,DOCTYPE,STRTDT,ENDDT,INSRT_TS,INSRT_SRC FROM public.REF_DOCTYPES WHERE ENDDT IS NULL";
            cmd.CommandText = sql;
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "REF_DOCTYPES");
            return ds.Tables["REF_DOCTYPES"];
        }
        public static DataSet getSettingDS()
        {
            OdbcCommand cmd;
            cmd = new OdbcCommand("", pc);

            OdbcSql sl = new OdbcSql();
            sl.Sql = @"SELECT * FROM public.ref_setting WHERE env = @ENV
                            AND(HOST = 'ALL' OR HOST = @HOST)";

            sl.OdbcSqlParameters.AddParameter("@ENV", Settings.Default.ENV, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@HOST", Environment.MachineName, OdbcSql.sqlDataTypes.OString);

            cmd.CommandText = sl.Prepare();
            DataSet ds = new DataSet();

            using (OdbcDataAdapter da = new OdbcDataAdapter(cmd))
            {
                try
                {
                    da.Fill(ds, "REF_SETTING");
                    if (ds.Tables["REF_SETTING"].Rows.Count < 1)
                    {
                        logger.Error("No settings retrieved");
                    }
                }
                catch (Exception x)
                {
                    logger.Error("Error:->" + Utils.GetCurrentMethod());
                    logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
                }
            }

            return ds;
        }

        public static DataTable getRequest()
        {
            OdbcCommand cmd = new OdbcCommand("", pc);
            OdbcSql sl = new OdbcSql();

            sl.Sql = @"
                    SELECT  
                    FROM public.REF_DOCTYPES 
                    WHERE ENDDT IS NULL
            ";

            cmd.CommandText = sl.Prepare();
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "REF_DOCTYPES");
            return ds.Tables["REF_DOCTYPES"];
        }


        public static DataSet Allegations(string folderNumber, string caseNumber, DataSet ds = null)
        {
            oc.ConnectionString = getDb2Connection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                Select ALLGN_DESC from @SCHEMA.ALLGNTXT 
                WHERE FLDR_NUM = @FLDR_NUM
                AND CASE_NUM = @CASE_NUM
                FETCH FIRST 100 ROWS ONLY WITH UR;
            ";
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folderNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@CASE_NUM", caseNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getDb2SCHEMA(), OdbcSql.sqlDataTypes.OConst);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "ALLGNTXT");
            return ds;
        }
        public static DataSet Allegation(string folderNumber, string caseNumber, DataSet ds = null)
        {
            oc.ConnectionString = getDb2Connection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                Select AOD,STOP_WRK_DT from @SCHEMA.ALLGN
                WHERE FLDR_NUM = @FLDR_NUM
                AND CASE_NUM = @CASE_NUM
                FETCH FIRST 100 ROWS ONLY WITH UR;
            ";
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folderNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@CASE_NUM", caseNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getDb2SCHEMA(), OdbcSql.sqlDataTypes.OConst);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "ALLGN");
            return ds;
        }
        public static DataSet CaseDocuments(string folderNumber, string caseNumber, string docId, DataSet ds = null)
        {
            oc.ConnectionString = getDb2Connection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                SELECT   DOCU_CD
		                ,MDF_CD
		                ,OCD
                        ,RQST_ID
		                ,TRTMNT_SRC_NM
		                ,DMA_RCPT_TS
		                ,B.CDESC as BTCH_SRC_CD
		                ,SRC_DOCU_DSPN
		                ,SSASGN_SITE
		                ,SSASGN_VNDR_NM
                from @SCHEMA.CASEDOC A
                LEFT OUTER JOIN @SCHEMA.BTCHSRC B
                ON A.BTCH_SRC_CD = B.CD
                WHERE FLDR_NUM = @FLDR_NUM      
                --AND CASE_NUM = @CASE_NUM
                AND DOCU_CTL_ID = @DOCU_CTL_ID
                FETCH FIRST 10 ROWS ONLY WITH UR;
            ";

            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getDb2SCHEMA(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folderNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@CASE_NUM", caseNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@DOCU_CTL_ID", docId, OdbcSql.sqlDataTypes.OString);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "CASEDOC");
            return ds;
        }

        public static DataSet Address(string folderNumber, string caseNumber, DataSet ds = null)
        {
            oc.ConnectionString = getDb2Connection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --CLNT ADDRESS
                Select 
                       RTRIM(COALESCE(A.ADDRLN_1,',')) as ADDR1
                      ,RTRIM(COALESCE(A.ADDRLN_2,'')) as ADDR2
                      ,RTRIM(COALESCE(A.ADDRLN_3,'')) as ADDR3
                      ,RTRIM(COALESCE(A.ADDRLN_4,'')) as ADDR4
                      ,RTRIM(COALESCE(A.CITY,'')) as CITY
                      ,RTRIM(COALESCE(A.ST,'')) as ST
                      ,RTRIM(COALESCE(A.ZIP5,'')) as ZIP5
                      ,RTRIM(COALESCE(A.ZIP4,'')) as ZIP4 
      
                from @SCHEMA.CLNTADDR A 
                WHERE FLDR_NUM = @FLDR_NUM
                AND CASE_NUM = @CASE_NUM
                AND ADDR_SUBTYP = 'M' 
                FETCH FIRST 10 ROWS ONLY WITH UR;
            

            ";

            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getDb2SCHEMA(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folderNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@CASE_NUM", caseNumber, OdbcSql.sqlDataTypes.ONumeric);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "CLNTADDR");
            return ds;
        }
        public static DataSet Claimant(string folderNumber, string caseNumber, DataSet ds = null)
        {
            oc.ConnectionString = getDb2Connection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                Select B.COSSN 
                      ,RTRIM(FNM_UCASE) as FNM_UCASE
                      ,RTRIM(UPPER(MNM)) as MNM_UCASE
                      ,RTRIM(LNM_UCASE) as LNM_UCASE
                      ,CASE_ESTB_DT
                      ,MOST_RCNT_FLG_DT
                      ,DOB
                      ,SEX
                      ,HT_INCH
                      ,WT_OUNCES
                      ,JURIS_OCD
                      ,A.ADJULVL_CD

                from @SCHEMA.CASE A
                INNER JOIN @SCHEMA.FLDR B
                ON A.FLDR_NUM = B.FLDR_NUM
                INNER JOIN @SCHEMA.CASECLM C
                ON A.FLDR_NUM = C.FLDR_NUM
                AND A.CASE_NUM = C.CASE_NUM
                WHERE A.FLDR_NUM = @FLDR_NUM
                AND A.CASE_NUM = @CASE_NUM
                FETCH FIRST 1 ROWS ONLY WITH UR;
            ";
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getDb2SCHEMA(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folderNumber, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@CASE_NUM", caseNumber, OdbcSql.sqlDataTypes.ONumeric);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "CASE");
            return ds;
        }

        public static HearingWork AddInsightRequest(DataSet ds, string cossn, string decisionText, HearingWork hw, string pin = "BA\\999999")
        {
            logger.Debug("In AddInsightRequest as User : " + pin);
            string inc = getInsightConnection();
            SqlConnection cn = new SqlConnection(inc);
            SqlCommand cmd = new SqlCommand("", cn);
            OdbcSql sl = new OdbcSql();
            //**************************************************************
            //WHEN DEBUGGING INSERT INTO ANALYSIS_REQUEST, DONT FORGET THERE
            //IS A TRIGGER ON THIS TABLE
            //************************************************************** 
            sl.Sql = @"
                    INSERT INTO dbo.ANALYSIS_REQUEST(COSSN,USER_PIN,DECISION_TEXT)
                    values(@COSSN,@PIN,@DECISION_TEXT)";
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@COSSN", SqlDbType = SqlDbType.VarChar, SqlValue = cossn });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@PIN", SqlDbType = SqlDbType.VarChar, SqlValue = pin });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@DECISION_TEXT", SqlDbType = SqlDbType.VarChar, SqlValue = decisionText });

            logger.Debug("Insight Insert ANALYSIS_REQUEST SQL: " + sl.Sql);
            cmd.CommandText = sl.Sql;
            Int64 rid = -1;
            try
            {
                cn.Open();
                rid = Int64.Parse(cmd.ExecuteScalar().ToString());
                hw.rid = rid.ToString();
                cn.Close();
            }
            catch (Exception ex)
            {

                logger.ErrorFormat("WWData.AddInsightRequest()" + ex.Message + ex.StackTrace);
            }

            sl.OdbcSqlParameters.Clear();
            try
            {
                foreach (DataTable dt in ds.Tables)
                {

                    foreach (DataRow dr in dt.Rows)
                    {
                        //set rid
                        sl.Sql = "insert into dbo." + dt.TableName + "(";
                        if (dt.Columns.Contains("RID"))
                        {
                            dr["RID"] = hw.rid;
                        }
                        //columns
                        foreach (DataColumn c in dt.Columns)
                        {
                            //sql
                            sl.Sql += c.ColumnName + ",";
                        }
                        sl.Sql = sl.Sql.Substring(0, sl.Sql.Length - 1) + ") VALUES(";
                        //values
                        foreach (DataColumn c in dt.Columns)
                        {
                            //sql
                            sl.Sql += "'" + dr[c.ColumnName] + "',";
                        }
                        sl.Sql = sl.Sql.Substring(0, sl.Sql.Length - 1) + ");";
                        //insert
                        logger.Debug("Insight Insert SQL: " + sl.Sql);
                        cmd.CommandText = sl.Sql;
                        cn.Open();
                        cmd.ExecuteNonQuery();
                        cn.Close();
                    }

                }
            }
            catch (Exception ex)
            {

                logger.ErrorFormat("WWData.AddInsightRequest()" + ex.Message + ex.StackTrace);
            }

            return hw;
        }

        public static OAOWork AddOAOInsightRequest(DataSet ds, string cossn, string decisionText, OAOWork hw)
        {

            string inc = getInsightConnectionOAO();
            SqlConnection cn = new SqlConnection(inc);
            SqlCommand cmd = new SqlCommand("", cn);
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                    INSERT INTO dbo.ANALYSIS_REQUEST(COSSN,DECISION_TEXT)
                    values(@COSSN,@DECISION_TEXT)
            ";
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@COSSN", SqlDbType = SqlDbType.VarChar, SqlValue = cossn });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@DECISION_TEXT", SqlDbType = SqlDbType.VarChar, SqlValue = decisionText });
            cmd.CommandText = sl.Sql;
            cn.Open();
            Int64 rid = Int64.Parse(cmd.ExecuteScalar().ToString());
            hw.rid = rid.ToString();
            cn.Close();
            sl.OdbcSqlParameters.Clear();

            foreach (DataTable dt in ds.Tables)
            {

                foreach (DataRow dr in dt.Rows)
                {
                    //set rid
                    sl.Sql = "insert into dbo." + dt.TableName + "(";
                    if (dt.Columns.Contains("RID"))
                    {
                        dr["RID"] = hw.rid;
                    }
                    //columns
                    foreach (DataColumn c in dt.Columns)
                    {
                        //sql
                        sl.Sql += c.ColumnName + ",";
                    }
                    sl.Sql = sl.Sql.Substring(0, sl.Sql.Length - 1) + ") VALUES(";
                    //values
                    foreach (DataColumn c in dt.Columns)
                    {
                        //sql
                        sl.Sql += "'" + dr[c.ColumnName] + "',";
                    }
                    sl.Sql = sl.Sql.Substring(0, sl.Sql.Length - 1) + ");";
                    //insert
                    Debug.WriteLine(sl.Sql);
                    cmd.CommandText = sl.Sql;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    cn.Close();
                }

            }
            return hw;
        }

        public static DataSet getOAOStatus(DataSet ds, OAOStatusRequest osr)
        {
            if (ds == null)
            {
                ds = new DataSet();
            }
            string inc = getInsightConnectionOAO();
            SqlConnection cn = new SqlConnection(inc);
            SqlCommand cmd = new SqlCommand("", cn);
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                   SELECT a.hofc_wrk_unit_AC, b.*
                      FROM [dbo].[struct_oao] a
                      INNER JOIN [dbo].dspn_doc b
                      on a.reqid = b.reqid
                      --12491915
                      --10624277
                      where hofc_wrk_unit_AC = @hofc_wrk_unit_AC
            ";
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@hofc_wrk_unit_AC", SqlDbType = SqlDbType.BigInt, SqlValue = osr.wrkunitofcuid });            
            cmd.CommandText = sl.Sql;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "OAO");            
            sl.OdbcSqlParameters.Clear();
            return ds;
        }

        public static DataSet HearingClaimant(string cossn, DataSet ds = null)
        {
            logger.DebugFormat("Getting HearingClaimant information for {0}", cossn);
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                SELECT
                '' AS RID 
                ,A.CLMT_SSN
                ,A.HOFC_WRK_UNIT_UID
                ,A.CLM_TYP
                ,A.HRG_TYP
                ,A.CLM_UID
                ,A.CASE_GRP_CD
                ,A.CLMT_NM25
                ,A.CLMT_ST
                ,A.CLMT_DOB
                ,A.REP_UID
                ,A.CRITL_CASE_CTGY_SW
                ,A.CLMT_DECD_SW
                ,A.DIRE_NEED_SW
                ,A.PTNTLY_HOMCDL_SW
                ,A.SUICIDL_SW
                ,A.TRML_ILLNESS_SW
                ,A.WG_ERNR_SSN
                ,A.BIC
                ,A.HRG_ISU_CD
                ,A.EDIB_CD
                ,A.OHA_DAA_CD
                ,C.EFLDR_NUM

                ,B.ALLGD_DISB_ONST_DT
                ,B.T2_APP_DT
                ,B.T16_APP_DT
                ,B.T2_PFLG_DT
                ,B.T16_PFLG_DT
                ,B.DLI
                --,D.EXPERT_UID
                --,D.SCHD_SW
                --,D.ATTNDD_SW
                --,D.MED_SPCLY_CD
                --,D.INSRT_TS
                --,E.EXPERT_UID
                --,E.DEV_SRC_CD
                --,E.DEV_GRP
                --,E.INSRT_TS
                --,E.ACKT_RCVDT
                --,F.EXPERT_TYP
                --,F.TITLE
                --,F.FNM
                --,F.MNM
                --,F.LNM
                --,F.SFX
                ,G.HEDULVL_CD
                ,G.SEX
                ,G.HT_INCH
                ,G.WT_OUNCES
                --,E.*


                FROM @SCHEMA.PARCWKUT A 
                INNER JOIN @SCHEMA.CLMINFO B
                ON A.CLM_UID = B.CLM_UID
                INNER JOIN @SCHEMA.WRKUNH C
                ON A.HOFC_WRK_UNIT_UID = C.HOFC_WRK_UNIT_UID
                INNER JOIN @MEDIB.CASE G 
                ON C.EFLDR_NUM = G.FLDR_NUM
                WHERE A.CLMT_SSN = @COSSN
                AND G.HEDULVL_CD IS NOT NULL
                WITH UR;
            ";
            try
            {
                sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);
                sl.OdbcSqlParameters.AddParameter("@MEDIB", getMeDibSchema(), OdbcSql.sqlDataTypes.OConst);
                sl.OdbcSqlParameters.AddParameter("@COSSN", cossn, OdbcSql.sqlDataTypes.OString);
                OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
                OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                da.Fill(ds, "STRUCT_HODISP");
            }
            catch (Exception ex)
            {

                logger.ErrorFormat("Error thrown in WWData.HearingClaimant() {0}", ex.Message + ex.StackTrace);
            }

            return ds;
        }

        //SELECT   
        //G.HEDULVL_CD
        //,G.SEX
        //,G.HT_INCH
        //,G.WT_OUNCES
        //FROM MEDIB.CASE G
        //WHERE G.FLDR_NUM = 203188882
        public static DataSet HearingSDR(string folderNum, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                SELECT
                G.FLDR_NUM   
                ,G.HEDULVL_CD
                ,G.SEX
                ,G.HT_INCH
                ,G.WT_OUNCES
                FROM MEDIB.CASE G
                WHERE G.FLDR_NUM = @FOLDERNUM
                WITH UR;
            ";
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@MEDIB", getMeDibSchema(), OdbcSql.sqlDataTypes.OConst);
            //sl.OdbcSqlParameters.AddParameter("@COSSN", cossn, OdbcSql.sqlDataTypes.OString);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_HODISP");
            return ds;
        }


        public static DataSet OAOClaimant(string cossn, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                SELECT
                     '' AS RID 
                    ,A.CLMT_SSN
                    ,A.HOFC_WRK_UNIT_UID
                    ,W.HOFC_WRK_UNIT_UID as HOFC_WRK_UNIT_UID_HRG
                    ,A.CLM_TYP
                    ,A.HRG_TYP
                    ,A.CLM_UID
                    ,A.CASE_GRP_CD
                    ,A.CLMT_NM25
                    ,F.CLMT_ST
                    ,A.CLMT_DOB
                    ,A.REP_UID
                    ,A.CRITL_CASE_CTGY_SW
                    ,A.CLMT_DECD_SW
                    ,A.DIRE_NEED_SW
                    ,A.PTNTLY_HOMCDL_SW
                    ,A.SUICIDL_SW
                    ,A.TERI_SW as TRML_ILLNESS_SW
                    ,A.WG_ERNR_SSN
                    ,A.BIC
                    ,A.HRG_ISU_CD
                    ,A.EDIB_CD
                    ,F.OHA_DAA_CD
                    ,C.EFLDR_NUM

                    ,B.ALLGD_DISB_ONST_DT
                    ,B.T2_APP_DT
                    ,B.T16_APP_DT
                    ,B.T2_PFLG_DT
                    ,B.T16_PFLG_DT
                    ,B.DLI
                    ,G.SEX
                    ,G.HT_INCH
                    ,G.WT_OUNCES                                                                                                                                                                                                                                                                ,G.HEDULVL_CD


                FROM MHAODS.PACAR A 
                INNER JOIN @SCHEMA.CLMINFO B
                ON A.CLM_UID = B.CLM_UID
                INNER JOIN @SCHEMA.WRKUNH C
                ON A.HOFC_WRK_UNIT_UID = C.HOFC_WRK_UNIT_UID
                LEFT OUTER JOIN MHALCOPY.WRKUNH W
                ON C.EFLDR_NUM = W.EFLDR_NUM
                AND W.HOFC_WRK_UNIT_UID < C.HOFC_WRK_UNIT_UID
                INNER JOIN @SCHEMA.ARCHWKUT F
                ON W.HOFC_WRK_UNIT_UID = F.HOFC_WRK_UNIT_UID
                INNER JOIN @MEDIB.CASE G 
                ON C.EFLDR_NUM = G.FLDR_NUM
                WHERE A.CLMT_SSN = @COSSN
                AND A.RQST_STUS_CD = 'ANWK'
                AND G.HEDULVL_CD IS NOT NULL
                WITH UR;
            ";
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@MEDIB", getMeDibSchema(), OdbcSql.sqlDataTypes.OConst);
            sl.OdbcSqlParameters.AddParameter("@COSSN", cossn, OdbcSql.sqlDataTypes.OString);
            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_OAODISP");
            return ds;
        }

        #region INSIGHT SEARCH
        //Perform User authentication by PIN and OCD
        //Check USRIDH table for the user PIN and get the list of office codes and corresponding hide switch(assumption: One user can have multiple offices) 
        //Permission needs to be provided by virtue of OFFICE or PIN
        //If one office from the user office list exists in SQL permission table with deleted flag 0, the user should be given access
        //If the user PIN exists in SQL permission table with deleted flag set to false, the user should be given access
        public static bool UserAuthByOCD(string UserOffice, string UserRole = null)
        {
            //Get PIN and ROLES from Postgres 
            //Permissions and Roles table
            //Authenticate user if the office is
            //in the permissions table
            bool userAuth = false;
            SqlCommand sCmd = new SqlCommand("", new SqlConnection(getInsightConnectionOAO()));
            DataTable permdT = new DataTable();
            permdT.TableName = "PERMISSIONS";
            OdbcSql permsl = new OdbcSql();
            permsl.Sql = @"SELECT PIN, OCD, ROLE_ID, upper(ROLE) AS USERROLE FROM [dbo].[permissions] p INNER JOIN [dbo].[roles] r
                                ON p.role_id = r.id
                                WHERE DELETED = 0 GROUP BY PIN, OCD, ROLE_ID, ROLE ORDER BY PIN";
            sCmd.CommandText = permsl.Prepare();

            
            try
            {               
                using (SqlDataAdapter da = new SqlDataAdapter(sCmd))
                {
                    da.Fill(permdT);
                }
                               
                if (permdT.Rows.Count < 1)
                {
                    throw new Exception("Error: No rows returned from permissions/roles table");
                }

                if (!string.IsNullOrEmpty(UserRole))
                {
                    var OfficeWithRole = (from row in permdT.AsEnumerable()
                                          where row.Field<string>("OCD") == UserOffice
                                          && row.Field<string>("USERROLE") == UserRole
                                          select new { Office = row.Field<string>("OCD"), Role = row.Field<string>("USERROLE") }).FirstOrDefault();
                    if (!string.IsNullOrEmpty(OfficeWithRole.Office))
                    {
                        userAuth = true;
                    }
                }
                else
                {
                    var OfficeWORole = (from row in permdT.AsEnumerable()
                                        where row.Field<string>("OCD") == UserOffice
                                        select new { Office = row.Field<string>("OCD"), Role = row.Field<string>("USERROLE") }).FirstOrDefault();
                    if (!string.IsNullOrEmpty(OfficeWORole.Office))
                    {
                        userAuth = true;
                    }
                }

            }
            catch (SqlException ox)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + ox.ToString() + "//" + ox.StackTrace);
                throw new Exception(ox.ToString());
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
                throw new Exception(x.ToString());
            }
            
            return userAuth;
        }

        public static bool UserAuthByPIN_OCD(string userPIN, OdbcConnection OdConn, bool adminRole = false)
        {

            DataTable dT = new DataTable();
            bool userAuth = false;
            OdbcCommand cmd = null;
            SqlCommand sCmd = null;
            dT.TableName = "USER_PRMYOCD_BY_PIN";
            logger.Info("DatabaseConnection :" + Regex.Match(OdConn.ConnectionString, "[U|u][I|i][D|d]=\\d+").Value);
            try
            {

                //Get PIN, OFFICE and ROLE from
                //SQL Server Permissions and Roles table                
                sCmd = new SqlCommand("", new SqlConnection(getInsightConnectionOAO()));
                DataTable permdT = new DataTable();
                permdT.TableName = "PERMISSIONS";
                OdbcSql permsl = new OdbcSql();
                permsl.Sql = @"SELECT PIN, OCD, ROLE_ID, upper(ROLE) AS USERROLE FROM 
                                [dbo].[Permissions] p INNER JOIN 
                                [dbo].[Roles] r
                                ON p.role_id = r.id
                                WHERE DELETED = 0 GROUP BY PIN, OCD, ROLE_ID, ROLE ORDER BY PIN";
                sCmd.CommandText = permsl.Prepare();
                logger.Info("DatabaseConnection User Id: " + Regex.Match(sCmd.Connection.ConnectionString, "[U|u][I|i][D|d]=[A-Za-z0-9]+").Value);
                try
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(sCmd))
                    {
                        da.Fill(permdT);
                    }
                }
                catch (OdbcException ox)
                {
                    logger.Error("Error:->" + Utils.GetCurrentMethod());
                    logger.Error("Error Details:->" + ox.ToString() + "//" + ox.StackTrace);
                    throw new Exception(ox.ToString());
                }
                catch(SqlException sx)
                {
                    logger.Error("Error:->" + Utils.GetCurrentMethod());
                    logger.Error("Error Details:->" + sx.ToString() + "//" + sx.StackTrace);
                    throw new Exception(sx.ToString());
                }
                catch (Exception x)
                {
                    logger.Error("Error:->" + Utils.GetCurrentMethod());
                    logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
                    throw new Exception(x.ToString());
                }

                //Verify Admin roles in Postgres only
                //USRIDH verification not required
                if (adminRole)
                {
                    //Check if admin's PIN exists in Permissions table
                    var R1 = (from row in permdT.AsEnumerable()
                              where row.Field<string>("PIN") == userPIN
                              && row.Field<string>("USERROLE").ToUpper() == "ADMINISTRATOR"
                              select row.Field<string>("PIN")).FirstOrDefault();

                    if (R1 != null)
                    {
                        userAuth = true;
                        return userAuth;
                    }
                    else
                    {
                        return userAuth;
                    }
                }

                OdbcSql sl = new OdbcSql();
                sl.Sql = @"
                SELECT
                    PRMY_OCD                                       
                FROM MHAODS.USRIDH 
                WHERE HIDE_SW ='N' 
                AND USER_PIN = @PIN  
                GROUP BY PRMY_OCD
                ORDER BY PRMY_OCD";
                sl.OdbcSqlParameters.AddParameter("@PIN", userPIN, OdbcSql.sqlDataTypes.OString);
                using (cmd = new OdbcCommand(sl.Prepare(), OdConn))
                {
                    try
                    {
                        OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                        da.Fill(dT);
                    }
                    catch (OdbcException ox)
                    {
                        logger.Error("Error:->" + Utils.GetCurrentMethod());
                        logger.Error("Error Details:->" + ox.ToString() + "//" + ox.StackTrace);
                        throw new Exception(ox.ToString());
                    }
                    catch (Exception x)
                    {
                        logger.Error("Error:->" + Utils.GetCurrentMethod());
                        logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
                        throw new Exception(x.ToString());
                    }
                }

                if (dT.Rows.Count > 0)
                {                    

                    try
                    {
                        if (permdT.Rows.Count < 1)
                        {
                            throw new Exception("Error: No rows returned from Permissions/Roles table");
                        }
                        else
                        {                            
                            if (dT.Rows.Count == 1) //UserPIN exists in USRIDH
                            {
                                //Check if user PIN exists in Permissions table as well
                                var Permissions_Val = (from row in permdT.AsEnumerable()
                                                        where row.Field<string>("PIN") == userPIN
                                                        select row.Field<string>("PIN")).FirstOrDefault();

                                if (Permissions_Val != null)
                                {
                                    userAuth = true;
                                    return userAuth;
                                }

                                //If user PIN does not exist in Permissions table
                                //Check if the office exists
                                string UserOffice = (from row in dT.AsEnumerable() select row.Field<string>("PRMY_OCD")).FirstOrDefault();
                                if (UserOffice != null)
                                {
                                    userAuth = UserAuthByOCD(UserOffice);
                                }
                            }
                            else if (dT.Rows.Count > 1) //One user can have multiple offices - loop through each office
                            {
                                foreach (DataRow item in dT.Rows)
                                {
                                    var T2 = (from row in permdT.AsEnumerable()
                                                where (row.Field<string>("OCD") == item["PRMY_OCD"].ToString() ||
                                                row.Field<string>("PIN") == userPIN)
                                                select row.Field<string>("OCD")).FirstOrDefault();

                                    if (T2 != null)
                                    {
                                        userAuth = true;
                                        break;
                                    }
                                }                                    
                            }                            
                        }
                    }
                    catch (NullReferenceException nx)
                    {
                        logger.Error("Error:->" + Utils.GetCurrentMethod());
                        logger.Error("Error Details:->" + nx.ToString() + "//" + nx.StackTrace);
                        throw new Exception(nx.ToString() + "//" + nx.StackTrace);
                    }
                    catch (Exception x)
                    {
                        logger.Error("Error:->" + Utils.GetCurrentMethod());
                        logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
                        throw new Exception( x.ToString() + "//" + x.StackTrace);
                    }
                }
                else
                {
                    return userAuth;
                }
            }
            catch (NullReferenceException nx)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + (nx.ToString() + "//" + nx.StackTrace));
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + (x.ToString()) + "//" + x.StackTrace);
            }

            return userAuth;
        }


        public static string AdminCasesByPin(string userpin, string adminpin, int checkaccess)
        {
            string status = string.Empty;
            oc.ConnectionString = getMHAConnection();

            if (checkaccess == 1)
            {
                if (UserAuthByPIN_OCD(adminpin, oc, true))
                {
                    return (status = "Administrator");
                }
                else
                {
                    return (status = "Not Administrator");
                }                
            }

            if(!UserAuthByPIN_OCD(adminpin, oc, true))
            {
                status = "{\"Message\":\"Administrator authentication failed\"}";
            }
            else
            {
                status = PACARCaseByPIN(userpin);
            }

            return status;
        }

        //Once user is authenticated 
        //get all OAO cases associated with the user's PIN

        public static string PACARCaseByPIN(string userPIN)
        {
            string status = string.Empty;
            oc.ConnectionString = getMHAConnection();

            if (UserAuthByPIN_OCD(userPIN, oc))
            {

                DataTable dT = new DataTable();

                dT.TableName = "PACAR_RESULT_BY_PIN";

                try
                {
                    OdbcSql sl = new OdbcSql();
                    sl.Sql = @"
                SELECT
                    HOFC_WRK_UNIT_UID,
                    CLMT_SSN, 
                    CLMT_NM25,
                    CLM_TYP, 
                    HRG_TYP,
                    WKLD_TYP,
                    RQST_RCVDT, 
                    HOFC_DSPN_DT
                FROM MHAODS.PACAR 
                WHERE FNL_DSPN_DT is NULL 
                AND RQST_STUS_CD <>'CLSD' 
                AND (ADJUR_A_PIN = @PIN 
                OR ADJUR_B_PIN = @PIN 
                OR ADJUR_C_PIN = @PIN) 
                UNION 
                SELECT 
                HOFC_WRK_UNIT_UID,
                    CLMT_SSN, 
                    CLMT_NM25,
                    CLM_TYP, 
                    HRG_TYP,
                    WKLD_TYP,
                    RQST_RCVDT, 
                    HOFC_DSPN_DT
                FROM 
                MHAODS.PACAR WHERE FNL_DSPN_DT IS NULL AND 
                RQST_STUS_CD IN ('ANWK','ANCR') AND 
                CRNT_ANLT_PIN = @PIN 
                ORDER BY HOFC_DSPN_DT DESC";
                    sl.OdbcSqlParameters.AddParameter("@PIN", userPIN, OdbcSql.sqlDataTypes.OString);
                    using (OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc))
                    {
                        OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                        da.Fill(dT);
                    }

                    if (dT == null)
                    {
                        throw new Exception("Invalid PACAR Table");
                    }

                    if (dT.Rows.Count > 0)
                    {
                        status = getOAOCaseByPACARPin(dT);
                    }
                    else
                    {
                        status = "{\"Message\":\"No claims associated with this user\"}";
                    }

                }
                catch (Exception x)
                {
                    logger.Error("Error:->" + Utils.GetCurrentMethod());
                    logger.Error("Error Details:->" + x.ToString());
                }
            }
            else
            {
                status = "{\"Error\":\"User or Office not Authorized\"}";
            }

            return status;

        }

        //Once user is authenticated 
        //get searched SSN details
        public static string PACARCaseBySSN(string userPIN, string searchSSN)
        {
            string status = string.Empty;
            oc.ConnectionString = getMHAConnection();

            if (UserAuthByPIN_OCD(userPIN, oc))
            {
                if (string.IsNullOrEmpty(userPIN) || string.IsNullOrEmpty(searchSSN))
                {
                    status = "{\"Message\":\"Valid value required for PIN and SSN\"}";
                }
                else
                {
                    if (searchSSN.Contains("-"))
                    {
                        searchSSN = searchSSN.Replace("-", "");
                    }                    

                    DataTable dT = new DataTable();

                    dT.TableName = "PACAR_RESULT_BY_SSN";

                    try
                    {
                        OdbcSql sl = new OdbcSql();
                        sl.Sql = @"
                SELECT
                    HOFC_WRK_UNIT_UID,
                    CLMT_SSN, 
                    CLMT_NM25,
                    CLM_TYP, 
                    HRG_TYP,
                    WKLD_TYP,
                    RQST_RCVDT, 
                    HOFC_DSPN_DT
                FROM MHAODS.PACAR 
                WHERE FNL_DSPN_DT IS NULL 
                AND RQST_STUS_CD <>'CLSD' 
                AND CLMT_SSN = @SSN                 
                UNION 
                SELECT 
                    HOFC_WRK_UNIT_UID,
                    CLMT_SSN, 
                    CLMT_NM25,
                    CLM_TYP, 
                    HRG_TYP,
                    WKLD_TYP,
                    RQST_RCVDT, 
                    HOFC_DSPN_DT
                FROM 
                MHAODS.PACAR WHERE FNL_DSPN_DT IS NULL AND 
                RQST_STUS_CD IN ('ANWK','ANCR') AND 
                CLMT_SSN = @SSN 
                ORDER BY HOFC_DSPN_DT DESC";
                        sl.OdbcSqlParameters.AddParameter("@SSN", searchSSN, OdbcSql.sqlDataTypes.OString);
                        using (OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc))
                        {
                            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                            da.Fill(dT);
                        }

                        if (dT == null)
                        {
                            throw new Exception("Invalid PACAR Table");
                        }

                        if (dT.Rows.Count > 0)
                        {
                            status = getOAOCaseByPACARPin(dT);
                        }
                        else
                        {
                            status = "{\"Message\":\"No claims associated with this user\"}";
                        }

                    }
                    catch (Exception x)
                    {
                        logger.Error("Error:->" + Utils.GetCurrentMethod());
                        logger.Error("Error Details:->" + x.ToString());
                    }
                }
            }
            else
            {
                status = "{\"Error\":\"User or Office not Authorized\"}";
            }

            return status;
        }

        //Get all rows from SQL Server "dbo.struct_oao" table and join to  
        //Cases retrieved from DB2 by user PIN. Join on hofc_wrk_unit_AC
        //to get REQID. Then build URL to be used by Python code
        public static string getOAOCaseByPACARPin(DataTable pacarResultDT)
        {

            string jSONResult = string.Empty;

            try
            {                
                DataTable dT = new DataTable();
                dT.TableName = "STRUCT_OAO";
                dT = getStructOAORecords();                

                Uri requestUri = HttpContext.Current.Request.Url;

                var mergeResult = (from T1 in pacarResultDT.AsEnumerable()
                                   join T2 in dT.AsEnumerable() on T1["HOFC_WRK_UNIT_UID"] equals Convert.ToInt32(T2["hofc_wrk_unit_AC"])
                                   into LeftJoinResult
                                   from T3 in LeftJoinResult.DefaultIfEmpty()
                                   orderby (T3 != null) descending, T1["HOFC_DSPN_DT"] descending
                                   select new PACAR_result()
                                   {
                                       HOFC_WRK_UNIT_UID = (int)T1["HOFC_WRK_UNIT_UID"],
                                       CLMT_SSN = (string)T1["CLMT_SSN"],
                                       CLMT_NM25 = (string)T1["CLMT_NM25"],
                                       CLM_TYP = (string)T1["CLM_TYP"],
                                       HRG_TYP = (string)T1["HRG_TYP"],
                                       WKLD_TYP = (string)T1["WKLD_TYP"],
                                       RQST_RCVDT = Regex.Match(T1["RQST_RCVDT"].ToString(),"\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                       HOFC_DSPN_DT = Regex.Match(T1["HOFC_DSPN_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                       link = (T3 == null) ? "" : string.Format("{0}://{1}{2}", requestUri.Scheme, getOAOReportServer(), T3["REQID"].ToString())
                                   });

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                System.Collections.Generic.List<PACAR_result> s = mergeResult.ToList();
                return (serializer.Serialize(mergeResult.ToList()));
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + x.ToString());
            }

            return jSONResult;
        }

        #endregion

        #region INSIGHT OAO INLINE SQL

        //Get the last stored HOFC_WRK_UNIT_AC value
        //from Postgres database - batches table
        private static void setLastBatch(string Work_Unit_UId_AC, string environment)
        {
            SqlCommand sCmd = null;

            try
            {
                OdbcSql sql = new OdbcSql();               
                sql.Sql = @"UPDATE [dbo].[batches]
                        SET nextrow = @WORK_UNIT_ID
                        WHERE tablename = @ENV";
                sql.OdbcSqlParameters.AddParameter("@ENV", environment, OdbcSql.sqlDataTypes.OString);
                sql.OdbcSqlParameters.AddParameter("@WORK_UNIT_ID", Work_Unit_UId_AC, OdbcSql.sqlDataTypes.ONumeric);
                
                using (sCmd = new SqlCommand(sql.Prepare(), new SqlConnection(getInsightConnectionOAO())))
                {
                    sCmd.CommandTimeout = 80000;
                   
                    sCmd.Connection.Open();

                    int returnValue = sCmd.ExecuteNonQuery();

                    if (returnValue <= 0)
                    {
                        throw new Exception("Update batches table failed");
                    }

                    if (sCmd.Connection.State == ConnectionState.Open)
                    {
                        sCmd.Connection.Close();
                    }
                }
            }
            catch (Exception x)
            {
                if (sCmd.Connection.State == ConnectionState.Open)
                {
                    sCmd.Connection.Close();
                }

                logger.ErrorFormat("Error thrown in WWData.setLastBatch() {0}", x.ToString() + "//" + x.StackTrace);
            }            
        }

        private static string getLastBatch(string environment)
        {
            OdbcSql sql = new OdbcSql();
            sql.Sql = @"SELECT nextrow 
                        FROM [dbo].[batches]
                        WHERE tablename = @ENV";
            sql.OdbcSqlParameters.AddParameter("@ENV", environment, OdbcSql.sqlDataTypes.OString);

            DataTable dT = new DataTable();

            using (SqlCommand sCmd = new SqlCommand(sql.Prepare(), new SqlConnection(getInsightConnectionOAO())))
            {
                sCmd.CommandTimeout = 80000;
                SqlDataAdapter da = new SqlDataAdapter(sCmd);
                da.Fill(dT);
            }

            if (!(dT.Rows[0]["nextrow"] == DBNull.Value))
            {
                return (dT.Rows[0]["nextrow"].ToString());
            }

            return null;
        }

        private static DataTable getStructOAORecords()
        {
            OdbcSql sql = new OdbcSql();
            sql.Sql = @"SELECT hofc_wrk_unit_AC, REQID 
                        FROM [dbo].[struct_oao]";

            DataTable structoaodT = new DataTable();

            try
            {
                using (SqlCommand sCmd = new SqlCommand(sql.Prepare(), new SqlConnection(getInsightConnectionOAO())))
                {
                    sCmd.CommandTimeout = 80000;
                    SqlDataAdapter da = new SqlDataAdapter(sCmd);
                    da.Fill(structoaodT);
                }
            }
            catch(SqlException sx)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + sx.ToString() + "//" + sx.StackTrace);
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
            }

            return structoaodT;
        }

        public static string CaseDetailsFromFolder()
        {
            string status = string.Empty;
            string query = string.Empty;
            oc.ConnectionString = getMHAConnection();

            string lastWork_Unit_AC = getLastBatch("PACAR");

            DataTable dT = new DataTable();

            dT.TableName = "EXPERTDETAILS";

            try
            {

                OdbcSql sl = new OdbcSql();

                query = Utils.GetQueryFromResource("INSIGHT_Request.SQL.ExpertDataQuery.sql");

                if (lastWork_Unit_AC != null)
                {
                    query = Utils.GetQueryFromResource("INSIGHT_Request.SQL.ExpertDataParmQuery.sql");
                    query = query.Replace("parm", lastWork_Unit_AC);
                }

                sl.Sql = query;

                using (OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc))
                {
                    cmd.CommandTimeout = 80000;
                    OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                    da.Fill(dT);
                }

                if (dT == null)
                {
                    throw new Exception("Some error occurred trying to get expert details data");
                }

                if (dT.Rows.Count > 0)
                {

                    DataTable oaodT = new DataTable();
                    oaodT = getStructOAORecords();

                    //Remove rows from MI query results
                    //that are present in struct_oao
                    var results = from T1 in dT.AsEnumerable()
                                  join T2 in oaodT.AsEnumerable() on T1["hofc_wrk_unit_ac"] equals Convert.ToInt32(T2["hofc_wrk_unit_ac"])
                                  into T3

                                  from T4 in T3.DefaultIfEmpty()
                                  where T4 == null
                                  select new
                                  {
                                      HOFC_WRK_UNIT_UID = T1["HOFC_WRK_UNIT_UID"],
                                      T2_GLBL_BSS_UID_1 = T1["T2_GLBL_BSS_UID_1"],
                                      T2_GLBL_BSS_UID_2 = T1["T2_GLBL_BSS_UID_2"],
                                      T16_GLBL_BSS_UID_1 = T1["T16_GLBL_BSS_UID_1"],
                                      T16_GLBL_BSS_UID_2 = T1["T16_GLBL_BSS_UID_2"],
                                      EFLDR_NUM = T1["EFLDR_NUM"],
                                      T2_APP_DT = Regex.Match(T1["T2_APP_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T16_APP_DT = Regex.Match(T1["T16_APP_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T2_PFLG_DT = Regex.Match(T1["T2_PFLG_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T16_PFLG_DT = Regex.Match(T1["T16_PFLG_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      DLI = Regex.Match(T1["DLI"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      ALLGD_DISB_ONST_DT = Regex.Match(T1["ALLGD_DISB_ONST_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      HRG_TYP = T1["HRG_TYP"],
                                      CLM_TYP = T1["CLM_TYP"],
                                      CLM_UID = T1["CLM_UID"],
                                      CASE_GRP_CD = T1["CASE_GRP_CD"],
                                      CLMT_NM25 = T1["CLMT_NM25"],
                                      CLMT_ST = T1["CLMT_ST"],
                                      CLMT_DOB = Regex.Match(T1["CLMT_DOB"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      REP_UID = T1["REP_UID"],
                                      TRML_ILLNESS_SW = T1["TRML_ILLNESS_SW"],
                                      FNL_DSPN_DT = Regex.Match(T1["FNL_DSPN_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T2_DSPN_CD = T1["HOFC_WRK_UNIT_UID"],
                                      T16_DSPN_CD = T1["T2_DSPN_CD"],
                                      T2_PRTL_FFVRBL_CD = T1["T2_PRTL_FFVRBL_CD"],
                                      T16_PRTL_FFVRBL_CD = T1["T16_PRTL_FFVRBL_CD"],
                                      BIC = T1["BIC"],
                                      WG_ERNR_SSN = T1["WG_ERNR_SSN"],
                                      HRG_ISU_CD = T1["HRG_ISU_CD"],
                                      EDIB_CD = T1["EDIB_CD"],
                                      OHA_DAA_CD = T1["OHA_DAA_CD"],
                                      HEDULVL_CD = T1["HEDULVL_CD"],
                                      EXPERT_UID = T1["EXPERT_UID"],
                                      DEV_GRP = T1["DEV_GRP"],
                                      ACKT_RCVDT = Regex.Match(T1["ACKT_RCVDT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      DEV_SRC_CD = T1["DEV_SRC_CD"],
                                      SCHD_SW = T1["SCHD_SW"],
                                      ATTNDD_SW = T1["ATTNDD_SW"],
                                      MED_SPCLY_CD = T1["MED_SPCLY_CD"],
                                      INSRT_TS = Regex.Match(T1["INSRT_TS"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      EXPERT_TYP = T1["EXPERT_TYP"],
                                      TITLE = T1["TITLE"],
                                      FNM = T1["FNM"],
                                      MNM = T1["MNM"],
                                      LNM = T1["LNM"],
                                      SFX = T1["SFX"],
                                  };


                    var dtList = results.ToList();

                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    status = serializer.Serialize(dtList);

                    setLastBatch(dT.Rows[dT.Rows.Count - 1]["hofc_wrk_unit_AC"].ToString(), "PACAR");
                }
                else
                {
                    status = "{\"Message\":\"Expert details data not found\"}";
                }

            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
            }

            return status;

        }

        internal static string GetMergedCaseData()
        {
            string status = string.Empty;
            string query = string.Empty;
            oc.ConnectionString = getMHAConnection();
            string lastWork_Unit_AC = getLastBatch("CASES");

            DataTable dT = new DataTable();

            dT.TableName = "MERGED_CASE_DATA";

            try
            {
                OdbcSql sl = new OdbcSql();

                query = Utils.GetQueryFromResource("INSIGHT_Request.SQL.MergedCasesQuery.sql");

                if (lastWork_Unit_AC != null)
                {
                    query = Utils.GetQueryFromResource("INSIGHT_Request.SQL.MergedCasesParmQuery.sql");
                    query = query.Replace("parm", lastWork_Unit_AC);
                }

                sl.Sql = query;

                using (OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc))
                {
                    cmd.CommandTimeout = 80000;
                    OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                    da.Fill(dT);
                }

                if (dT == null)
                {
                    throw new Exception("Some error occurred trying to get merged case details data");
                }

                if (dT.Rows.Count > 0)
                {

                    DataTable oaodT = new DataTable();
                    oaodT = getStructOAORecords();

                    //Remove rows from MI query results
                    //that are present in struct_oao
                    var results = from T1 in dT.AsEnumerable()
                                  join T2 in oaodT.AsEnumerable() on T1["hofc_wrk_unit_ac"] equals Convert.ToInt32(T2["hofc_wrk_unit_ac"])
                                  into T3

                                  from T4 in T3.DefaultIfEmpty()
                                  where T4 == null
                                  select new
                                  {
                                      HOFC_WRK_UNIT_UID = T1["HOFC_WRK_UNIT_UID"],
                                      EFLDR_NUM = T1["EFLDR_NUM"],
                                      HRG_TYP = T1["HRG_TYP"],
                                      CLM_TYP = T1["CLM_TYP"],
                                      CLM_UID = T1["CLM_UID"],
                                      CASE_GRP_CD = T1["CASE_GRP_CD"],
                                      CLMT_NM25 = T1["CLMT_NM25"],
                                      CLMT_ST = T1["CLMT_ST"],
                                      CLMT_DOB = Regex.Match(T1["CLMT_DOB"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      REP_UID = T1["REP_UID"],
                                      TRML_ILLNESS_SW = T1["TRML_ILLNESS_SW"],
                                      FNL_DSPN_DT = Regex.Match(T1["FNL_DSPN_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T2_DSPN_CD = T1["T2_DSPN_CD"],
                                      T16_DSPN_CD = T1["T2_DSPN_CD"],
                                      T2_PRTL_FFVRBL_CD = T1["T2_PRTL_FFVRBL_CD"],
                                      T16_PRTL_FFVRBL_CD = T1["T16_PRTL_FFVRBL_CD"],
                                      BIC = T1["BIC"],
                                      WG_ERNR_SSN = T1["WG_ERNR_SSN"],
                                      HRG_ISU_CD = T1["HRG_ISU_CD"],
                                      EDIB_CD = T1["EDIB_CD"],
                                      OHA_DAA_CD = T1["OHA_DAA_CD"],
                                      HOFC_WRK_UNIT_AC = T1["HOFC_WRK_UNIT_AC"],
                                      CLMT_SSN = T1["CLMT_SSN"],
                                      CRNT_RQSTD_DT = Regex.Match(T1["CRNT_RQSTD_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      WKLD_TYP = T1["WKLD_TYP"],
                                      WG_ERNR_SSN_AC = T1["WG_ERNR_SSN_AC"],
                                      CRITL_CASE_CTGY_SW = T1["CRITL_CASE_CTGY_SW"],
                                      CLMT_DECD_SW = T1["CLMT_DECD_SW"],
                                      DIRE_NEED_SW = T1["DIRE_NEED_SW"],
                                      PTNTLY_HOMCDL_SW = T1["PTNTLY_HOMCDL_SW"],
                                      SUICIDL_SW = T1["SUICIDL_SW"],
                                      TERI_SW = T1["TERI_SW"],
                                      T2_APP_DT = Regex.Match(T1["T2_APP_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T16_APP_DT = Regex.Match(T1["T16_APP_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T2_PFLG_DT = Regex.Match(T1["T2_PFLG_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T16_PFLG_DT = Regex.Match(T1["T16_PFLG_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      DLI = Regex.Match(T1["DLI"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      ALLGD_DISB_ONST_DT = Regex.Match(T1["ALLGD_DISB_ONST_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      T2_GLBL_BSS_UID_1 = T1["T2_GLBL_BSS_UID_1"],
                                      T2_GLBL_BSS_UID_2 = T1["T2_GLBL_BSS_UID_2"],
                                      T16_GLBL_BSS_UID_1 = T1["T16_GLBL_BSS_UID_1"],
                                      T16_GLBL_BSS_UID_2 = T1["T16_GLBL_BSS_UID_2"],
                                      FLDR_NUM = T1["FLDR_NUM"],
                                      HEDULVL_CD = T1["HEDULVL_CD"],
                                      HT_INCH = T1["HT_INCH"],
                                      WT_OUNCES = T1["WT_OUNCES"],
                                      SEX = T1["SEX"],
                                      DOCU_CTL_ID = T1["DOCU_CTL_ID"],
                                      DMA_RCPT_TS = Regex.Match(T1["DMA_RCPT_TS"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value,
                                      DCN_DT = Regex.Match(T1["DCN_DT"].ToString(), "\\d{1,2}/\\d{1,2}/\\d{4}").Value
                                  };


                    var dtList = results.ToList();

                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    serializer.MaxJsonLength = Int32.MaxValue;
                    status = serializer.Serialize(dtList);

                    setLastBatch(dT.Rows[dT.Rows.Count - 1]["HOFC_WRK_UNIT_AC"].ToString(), "CASES");

                }
                else
                {
                    status = "{\"Message\":\"Expert details data not found\"}";
                }

            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:->" + x.ToString() + "//" + x.StackTrace);
            }

            return status;

        }

        #endregion

        public static DataSet HearingExpert(string wrkUnitId, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --HRGEXP
                SELECT
                '' as RID
                ,D.HOFC_WRK_UNIT_UID
                ,D.EXPERT_UID
                ,D.SCHD_SW
                ,D.ATTNDD_SW
                ,D.MED_SPCLY_CD
                ,D.INSRT_TS
                ,F.EXPERT_TYP
                ,F.TITLE
                ,F.FNM
                ,F.MNM
                ,F.LNM
                ,F.SFX
                FROM @SCHEMA.HRGEXP D
                LEFT OUTER JOIN @SCHEMA.DEVLPH E 
                ON D.HOFC_WRK_UNIT_UID = E.HOFC_WRK_UNIT_UID
                LEFT JOIN @SCHEMA.OPTLEXP F 
                ON E.EXPERT_UID = F.EXPERT_UID
                WHERE D.HOFC_WRK_UNIT_UID = @HOFC_WRK_UNIT_UID
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_EXP");
            return ds;
        }

        public static DataSet OAOExpert(string wrkUnitId, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --HRGEXP
                SELECT
                '' as RID
                ,D.HOFC_WRK_UNIT_UID
                ,D.EXPERT_UID
                ,D.SCHD_SW
                ,D.ATTNDD_SW
                ,D.MED_SPCLY_CD
                ,D.INSRT_TS
                ,F.EXPERT_TYP
                ,F.TITLE
                ,F.FNM
                ,F.MNM
                ,F.LNM
                ,F.SFX
                FROM @SCHEMA.HRGEXP D
                LEFT OUTER JOIN @SCHEMA.DEVLPH E 
                ON D.HOFC_WRK_UNIT_UID = E.HOFC_WRK_UNIT_UID
                LEFT JOIN @SCHEMA.OPTLEXP F 
                ON E.EXPERT_UID = F.EXPERT_UID
                WHERE D.HOFC_WRK_UNIT_UID = @HOFC_WRK_UNIT_UID
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_EXP");
            return ds;
        }


        public static DataSet HearingDevelopment(string wrkUnitId, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --DEVLPH
                SELECT
                '' as RID 
                ,E.HOFC_WRK_UNIT_UID
                ,E.EXPERT_UID
                ,E.DEV_SRC_CD
                ,E.DEV_GRP
                ,E.INSRT_TS
                ,E.ACKT_RCVDT
                ,F.EXPERT_TYP
                ,F.TITLE
                ,F.FNM
                ,F.MNM
                ,F.LNM
                ,F.SFX
                FROM @SCHEMA.DEVLPH E
                LEFT JOIN @SCHEMA.OPTLEXP F 
                ON E.EXPERT_UID = F.EXPERT_UID
                WHERE E.HOFC_WRK_UNIT_UID = @HOFC_WRK_UNIT_UID
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_EXP");
            return ds;
        }
        public static DataSet OAODevelopment(string wrkUnitId, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --DEVLPH
                SELECT
                '' as RID 
                ,E.HOFC_WRK_UNIT_UID
                ,E.EXPERT_UID
                ,E.DEV_SRC_CD
                ,E.DEV_GRP
                ,E.INSRT_TS
                ,E.ACKT_RCVDT
                ,F.EXPERT_TYP
                ,F.TITLE
                ,F.FNM
                ,F.MNM
                ,F.LNM
                ,F.SFX
                FROM @SCHEMA.DEVLPH E
                LEFT JOIN @SCHEMA.OPTLEXP F 
                ON E.EXPERT_UID = F.EXPERT_UID
                WHERE E.HOFC_WRK_UNIT_UID = @HOFC_WRK_UNIT_UID
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMHASchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_EXP_DEVLPO");
            return ds;
        }
        public static DataSet HearingDocuments(string folder, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --CASEDOCS
                SELECT
                *
                FROM @SCHEMA.CASEDOC E
                WHERE E.FLDR_NUM = @FLDR_NUM
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folder, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMeDibSchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_FOLDER_DOCUMENTS");
            return ds;
        }

        public static DataSet OAODocuments(string folder, DataSet ds = null)
        {
            oc.ConnectionString = getMHAConnection();
            if (ds == null)
            {
                ds = new DataSet();
            }
            OdbcSql sl = new OdbcSql();
            sl.Sql = @"
                --CASEDOCS
                SELECT
                *
                FROM @SCHEMA.CASEDOC E
                WHERE E.FLDR_NUM = @FLDR_NUM
                WITH UR;
            ";

            //sl.OdbcSqlParameters.AddArrayParameter("@HOFC_WRK_UNIT_UID", wrkUnitId, OdbcSql.sqlDataTypes.OString);
            sl.OdbcSqlParameters.AddParameter("@FLDR_NUM", folder, OdbcSql.sqlDataTypes.ONumeric);
            sl.OdbcSqlParameters.AddParameter("@SCHEMA", getMeDibSchema(), OdbcSql.sqlDataTypes.OConst);


            OdbcCommand cmd = new OdbcCommand(sl.Prepare(), oc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            da.Fill(ds, "STRUCT_FOLDER_DOCUMENTS");
            return ds;
        }



        public static dynamic GetSetting(string setting, string returnType, string host, string env = "D")
        {
            OdbcSql sql = new OdbcSql();
            sql.Sql = @"
                            SELECT * 
                            FROM public.ref_setting 
                            WHERE env = @ENV 
                            AND (HOST = 'ALL' OR HOST = @HOST)
                            AND HOST_VALUE = @HOST_VALUE  
                       ";
            sql.OdbcSqlParameters.AddParameter("@ENV", env, OdbcSql.sqlDataTypes.OString);
            sql.OdbcSqlParameters.AddParameter("@HOST", host, OdbcSql.sqlDataTypes.OString);
            sql.OdbcSqlParameters.AddParameter("@HOST_VALUE", setting, OdbcSql.sqlDataTypes.OString);

            OdbcCommand cmd = new OdbcCommand(sql.Prepare(), pc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds, "REF_SETTING");
                foreach (DataRow r in ds.Tables["REF_SETTING"].Rows)
                {
                    switch (returnType.ToUpper())
                    {
                        case "STRING":
                            try
                            {
                                return r["HOST_SETTING"].ToString().Trim();
                            }
                            catch (Exception ex)
                            {
                                logger.Error("Error:->" + Utils.GetCurrentMethod());
                                logger.Error("Error Details:->" + ex.ToString());

                            }
                            break;
                        case "INT":
                            try
                            {
                                return int.Parse(r["HOST_SETTING"].ToString().Trim());
                            }
                            catch (Exception ex)
                            {
                                logger.Error("Error:->" + Utils.GetCurrentMethod());
                                logger.Error("Error Details:->" + ex.ToString());

                            }
                            break;
                        default:
                            logger.Error("Error:->" + Utils.GetCurrentMethod());
                            logger.Error("Error Details:->" + returnType + " doesnt exist");
                            break;
                    }
                }
            }
            catch (Exception x)
            {
                logger.Error("Error:->" + Utils.GetCurrentMethod());
                logger.Error("Error Details:" + x.StackTrace);
            }

            logger.Error("Error:->" + Utils.GetCurrentMethod());
            logger.Error("Error Details:->No Records exist for the given parameters:" + setting + ":" + host + ":" + env);
            return "";
        }
        public static string GetRequestByDocId(string docid)
        {
            string rsp = "";
            OdbcCommand cmd = new OdbcCommand("SELECT REQUESTOBJ FROM public.RQST WHERE docid = '" + docid + "' ORDER BY insrt_ts desc LIMIT 1 ", pc);
            OdbcDataAdapter da = new OdbcDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "RQST");
            foreach (DataRow r in ds.Tables["RQST"].Rows)
            {
                try
                {
                    rsp = r["REQUESTOBJ"].ToString().Trim();
                }
                catch (Exception ex)
                {

                    return "";
                }
            }
            return rsp;
        }
    }
}
