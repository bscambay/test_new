# step 3 RFC finding

from ml_util import ML_util

# logging location
logging_file = '{}.log'.format(__file__)

ml = ML_util("RFCLABELEDFEATURESREV5_06172016.txt", 'LogisticRegression', 3, logging_file)
ml.run()
