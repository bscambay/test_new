# INSIGHT FULL SUITE - BATCH PROCESSOR - DECISION TEXT RETRIEVAL FUNCTIONS
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.10.2017
#
# SUMMARY: 
# Attempt to locate a single relevant DOCU_CTL_ID value for a given input
# FLDR_NUM value.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

import datetime
import logging
# Import modules:
import os.path
import config as cfg
import shutil
import zipfile
from zipfile import BadZipfile

import requests

import batch_extracttext
# Import config_sec:
# secdir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../sec"))
# sys.path.insert(0, secdir)
import config_sec as cfg_sec

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")
batch_temp_dir = cfg.batch_temp_dir
batch_decisionfiles_dir = cfg.batch_decisionfiles_dir

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)

# Retrieve global/parsing values:
batch_decisionfiles_dir_fn_list = [os.path.splitext(d)[0] for d in os.listdir(batch_decisionfiles_dir) if
                                   d.endswith('txt')]


# Retrieve decision text file from DMA TIF using DOCU_CTL_ID value:
def retrieve_from_tif_noocr_batch(docu_ctl_id_input_list):
    try:

        # Transform the DOCU_CTL_ID input list into sublists of length 50 (plus chunk containing remainder):
        def chunk(l, n):
            for i in xrange(0, len(l), n):
                yield l[i:i + n]

        docu_ctl_id_input_list_chunks = list(chunk(docu_ctl_id_input_list, 50))

        # Open connection:
        s = requests.Session()
        surl_login = cfg_sec.dma_logon % cfg_sec.dma_pin
        s.get(surl_login)
        cookiejar = s.cookies['dmaSESSIONID']
        cookies = dict(cookies_are=cookiejar)

        # Iterate through chunks of 50 to download/store TIFs within zip files:
        for i, sublist in enumerate(docu_ctl_id_input_list_chunks):
            surl_pop = cfg_sec.dma_document_retrieval % (cfg_sec.dma_pin, ','.join(sublist))
            response = s.get(surl_pop, cookies=cookies)
            filenm = "%s.zip" % datetime.datetime.now().strftime('%m-%d-%Y-%H-%M-%S')
            filenmfp = os.path.join(batch_temp_dir, filenm)
            with open(filenmfp, "wb") as x:
                x.write(response.content)

        # Close connection:
        surl_logoff = cfg_sec.dma_logoff % cfg_sec.dma_pin
        s.get(surl_logoff)

        # Unzip resulting zip files:
        zipfilenames = [os.path.join(batch_temp_dir, f) for f in os.listdir(batch_temp_dir) if f.endswith(".zip")]
        for zipfp in zipfilenames:
            try:
                print zipfp
                zf = zipfile.ZipFile(zipfp)
                for nm in zf.namelist():
                    zf.extract(nm, batch_temp_dir, "w")
                zf.close()
            except BadZipfile:
                pass

        # Delete zip files:
        for zipfp in zipfilenames:
            os.remove(zipfp)

        return '1'

    except Exception:
        logger.exception('EXCEPTION')
        return 'E'


# Process OCR HTML into text files:
def retrieve_from_tif_postocr(docu_ctl_id_input):
    try:
        if bool(docu_ctl_id_input.startswith('A')) is False:
            return '0'
        else:
            hocrhtml_fn = docu_ctl_id_input + ".html"
            # hocrhtml_fn = docu_ctl_id_input + ".hocr"
            hocrhtml_fp = os.path.join(batch_temp_dir, hocrhtml_fn)
            batch_extracttext.textextractor(hocrhtml_fp)
            txt_fp = hocrhtml_fp[:-5] + ".txt"
            txt_fp_basename = os.path.basename(txt_fp)
            shutil.copyfile(txt_fp, os.path.join(batch_decisionfiles_dir, txt_fp_basename))
            if os.path.isfile(os.path.join(batch_decisionfiles_dir, txt_fp_basename)):
                return '1'
            else:
                return '0'
    except Exception as ex:
        logger.exception('EXCEPTION: '+str(ex))
        return '0'
