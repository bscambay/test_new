# INSIGHT HEARING DECISION DATA EXTRACTION ALGORITHM (INSIGHT Extract) - 
# DATA LOADER
# 
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
# 
# DATE LAST UPDATED: 
# 09.09.2016
# 
# SUMMARY:
# Loads datasets utilized by INSIGHT Extract.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has not
# yet been formally validated and whose documentation is not yet fully formed.
#==============================================================================

# Import modules:
import os
import os.path
import io
import string
import logging
import numpy as np
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression

# Set data directory:
insightdir = os.path.dirname(os.path.realpath(__file__))
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Function to convert individual lines of a dataset from a text file 
# into a list of strings:
def load_data_into_list(dataset_path):
	try:
		data_list = []
		with io.open(dataset_path, "rt", encoding="utf8", errors="ignore") as data:
			for line in data:
				line = line.strip()
				if bool(line.startswith('#')) is False and line != '':
					data_list.append(line.strip())
		return data_list
	except Exception:
		logger.exception('EXCEPTION')
		raise
		

# Load Disease/ICD-9 Dataset:
try:
	disease_list_lines = load_data_into_list(os.path.join(datadir, "IE_MDILIST.txt"))
	disease_dict = {line.split("===")[0]: line.split("===")[1] for line in disease_list_lines}
except Exception:
	logger.exception('EXCEPTION')
	raise


# NERSA Non-Name Capitalized Words List:
try:
	ie_nersa_blacklist = load_data_into_list(os.path.join(datadir, "IE_NERSA_BLACKLIST.txt"))
	ie_nersa_nonhumancapwords = load_data_into_list(os.path.join(datadir, "IE_NERSA_NONHUMANCAPWORDS.txt"))
	ie_nersa_nonhumancapwords_single_upper = []
	for item in ie_nersa_nonhumancapwords:
		itemsplit = item.split()
		for subitem in itemsplit:
			ie_nersa_nonhumancapwords_single_upper.append(subitem.upper())
except Exception:
	logger.exception('EXCEPTION')
	raise


# Function to generate IE ML training set data:
def generate_training_sets(dataset_path, ngram_range_end):
	try:
		verdict_features = []
		verdict_labels = []
		with io.open(dataset_path, "rt", encoding="utf8", errors="ignore") as ml_data:
			for line in ml_data:
				try:
					label = int(line[0])
					verdict_labels.append(label)
					feature = line[2:].strip()
					verdict_features.append(unicode(feature))
				except Exception:
					pass
		x_training_set = np.array(verdict_features)
		y_training_set = np.array(verdict_labels)
		verdict_vectorizer = TfidfVectorizer(analyzer='word', sublinear_tf=True, lowercase=False, ngram_range=(1, ngram_range_end))
		x_training_set = verdict_vectorizer.fit_transform(x_training_set)
		return (x_training_set, y_training_set), verdict_vectorizer
	except Exception:
		logger.exception('EXCEPTION')
		raise


# Load/train IE ML classifiers:
try:
	# TIP: Using * to unpack the tuple returned by the generator function as 2 arguments for the function.
	s1sga_id_training_data, s1sga_id_vectorizer = generate_training_sets(os.path.join(datadir, "S1VERDICTIDFEATURESREV2.txt"), 2)
	s1sga_id_clf = LogisticRegression().fit(*s1sga_id_training_data)
	
	s1sga_type_training_data, s1sga_type_vectorizer = generate_training_sets(os.path.join(datadir, "S1VERDICTTYPEFEATURESREV2.txt"), 3)
	s1sga_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s1sga_type_training_data)
	
	s2_id_training_data, s2_id_vectorizer = generate_training_sets(os.path.join(datadir, "S2VERDICTIDFEATURESREV2.txt"), 2)
	s2_id_clf = LogisticRegression().fit(*s2_id_training_data)
	
	s2_type_training_data, s2_type_vectorizer = generate_training_sets(os.path.join(datadir, "S2VERDICTTYPEFEATURESREV2.txt"), 5)
	s2_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s2_type_training_data)
	
	s3mteq_id_clf_training_data, s3mteq_id_vectorizer = generate_training_sets(os.path.join(datadir, "S3VERDICTIDFEATURESREV3.txt"), 2)
	s3mteq_id_clf = LogisticRegression().fit(*s3mteq_id_clf_training_data)
	
	s3mteq_type_training_data, s3mteq_type_vectorizer = generate_training_sets(os.path.join(datadir, "S3VERDICTTYPEFEATURESREV3.txt"), 3)
	s3mteq_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s3mteq_type_training_data)
	
	s3feq_id_training_data, s3feq_id_vectorizer = generate_training_sets(os.path.join(datadir, "S3FEVERDICTIDFEATURESREV3.txt"), 2)
	s3feq_id_clf = LogisticRegression().fit(*s3feq_id_training_data)
	
	s3feq_type_training_data, s3feq_type_vectorizer = generate_training_sets(os.path.join(datadir, "S3FEVERDICTTYPEFEATURESREV3.txt"), 3)
	s3feq_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s3feq_type_training_data)
	
	rfc_training_data, rfc_vectorizer = generate_training_sets(os.path.join(datadir, "RFCLABELEDFEATURESREV5_06172016.txt"), 3)
	rfc_clf = LogisticRegression().fit(*rfc_training_data)
	
	s4_id_training_data, s4_id_vectorizer = generate_training_sets(os.path.join(datadir, "S4VERDICTIDFEATURESREV2.txt"), 3)
	s4_id_clf = LogisticRegression().fit(*s4_id_training_data)
	
	s4_type_training_data, s4_type_vectorizer = generate_training_sets(os.path.join(datadir, "S4VERDICTTYPEFEATURESREV2.txt"), 3)
	s4_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s4_type_training_data)
	
	s5_id_training_data, s5_id_vectorizer = generate_training_sets(os.path.join(datadir, "S5VERDICTIDFEATURESREV2.txt"), 2)
	s5_id_clf = LogisticRegression().fit(*s5_id_training_data)
	
	s5_type_training_data, s5_type_vectorizer = generate_training_sets(os.path.join(datadir, "S5VERDICTTYPEFEATURESREV2.txt"), 3)
	s5_type_clf = OneVsRestClassifier(LogisticRegression()).fit(*s5_type_training_data)
except Exception:
	logger.exception('EXCEPTION')
	raise


# Load state-to-circuit bridge data:
# TIP: Relevant columns are 'circuit', 'state_nm', 'state_abbrev_gpo', and 'state_abbrev_standard'.
try:
	circuitdf = pandas.read_csv(os.path.join(datadir, "circuitdata.csv"), dtype=str)
	circuitdf['state_nm'] = circuitdf['state_nm'].str.upper()
	circuitdf['state_abbrev_gpo'] = circuitdf['state_abbrev_gpo'].str.upper()
	circuitdf['state_abbrev_standard'] = circuitdf['state_abbrev_standard'].str.upper()
except Exception:
	logger.exception('EXCEPTION')
	raise