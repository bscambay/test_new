# INSIGHT HEARING DECISION QUALITY ANALYSIS ALGORITHM (INSIGHT Quality)
# COMMON CALCULATIONS MODULE
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 10.13.2016
#
# SUMMARY: 
# Contains functions that perform miscellaneous/common calculation tasks
# required by INSIGHT Quality.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import re
import os.path
import ast
import logging
import pandas
import iq_data_loader as iqdl
import nlp_helper
import regex_strings as rs
import its_sklearn_classifier as its

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
logdir = os.path.join(insightdir, "Log")
datadir = os.path.join(insightdir, "Data")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Locate relevant finding observations (schema 2):
def locate_relevant_finding_obs(input_dict, origin_obs_nm, origin_obs_ordnum, target_obs_nm, direction_type):
	'''Relevant corresponding finding observation locator.
	
	When comparing the content of two different finding types,
	it is necessary to locate the relevant corresponding finding
	observations to perform the comparsion. This function does
	that via heuristics and text location.  'Relevancy' can mean
	'closest proximally' if multiple origin finding observations,
	can mean 'all in target direction' if only one origin finding
	observation, etc.
	
	TIP: This *is* capable of handling 'grouped' 2+ tgt, 2+ obs
	complexities (TGT -> TGT -> ORG -> ORG (or reverse)) by outputting
	[].
	
	Args:
		input_dict {dict}: An INSIGHT observation dict.
		origin_obs_nm {str}: The name of the origin
			finding we wish to compare to the target
			finding, equal to a key name in the INSIGHT
			obs dict, e.g. 's2' or 's4'.
		origin_obs_ordnum {int}: The specific origin
			finding's ORD_NUM value values (e.g. insight_dict['s2'][1]).
		target_obs_nm {str}: The name of the target finding,
			equal to a key name in the INSIGHT obs dict
			(e.g. 'rfc').
		direction_type {str}: Indicator of the direction
			or order the target finding will be found; 'before'
			means the target finding is located before the origin
			finding; 'after' means after the origin finding.
	Returns:
		tgt_obs_ordnum_list {list}: A list of target finding
			observation ORD_NUM numbers corresponding to those
			target finding observations deemed 'relevant'
			for this comparison.
	Raises:
		N/A (returns empty list if exception occurs).
	'''
	try:

		tgt_obs_ordnum_list = []
				
		origin_obs_dictlist = []
		origin_obs_val = input_dict[origin_obs_nm]
		for k,v in origin_obs_val.iteritems():
			if v['ORD_NUM'] == origin_obs_ordnum:
				origin_obs_dictlist.append(v)
		
		if len(origin_obs_dictlist) != 1:
			return tgt_obs_ordnum_list
		
		origin_obs_dict = origin_obs_dictlist[0]
		origin_obs_loc_tup_start = origin_obs_dict['loc_st']
		origin_obs_loc_tup_end = origin_obs_dict['loc_end']
		
		# If 0 origin obs, return []:
		if len(input_dict[origin_obs_nm]) == 0:
			return tgt_obs_ordnum_list
			
		# Elif only 1 origin obs, parsing is simple:
		elif len(input_dict[origin_obs_nm]) == 1:
			if len(input_dict[target_obs_nm]) == 0:
				return tgt_obs_ordnum_list
			else:
				for k,v in input_dict[target_obs_nm].iteritems():
					if direction_type == 'before':
						v_loc_tup_end = v['loc_end']
						if v_loc_tup_end < origin_obs_loc_tup_start:
							tgt_obs_ordnum_list.append(v['ORD_NUM'])
					elif direction_type == 'after':
						v_loc_tup_start = v['loc_st']
						if v_loc_tup_start > origin_obs_loc_tup_end:
							tgt_obs_ordnum_list.append(v['ORD_NUM'])
		
		# Elif 2+ origin obs, parsing is more complex to deal with
		# TGT -> TGT -> ORG -> ORG (or reverse) 'grouped' scenario
		# that we cannot currently parse absent finding-by-finding temporal
		# parsing:
		else:
			# If 0 tgt obs, return []:
			if len(input_dict[target_obs_nm]) == 0:
				return tgt_obs_ordnum_list
			
			# Elif only 1 tgt obs, parse same as if 1 origin obs:
			elif len(input_dict[target_obs_nm]) == 1:
				for k,v in input_dict[target_obs_nm].iteritems():
					if direction_type == 'before':
						v_loc_tup_end = v['loc_end']
						if v_loc_tup_end < origin_obs_loc_tup_start:
							tgt_obs_ordnum_list.append(v['ORD_NUM'])
					elif direction_type == 'after':
						v_loc_tup_start = v['loc_st']
						if v_loc_tup_start > origin_obs_loc_tup_end:
							tgt_obs_ordnum_list.append(v['ORD_NUM'])
			
			# Else 2+ tgt obs check for TGT -> TGT -> ORG -> ORG (or reverse) 'grouped' 
			# scenario - if present, output []; else, proceed:
			else:
				
				# Get all other origin obs loc values
				# located in same direction as target obs:
				other_origin_obs_loc = []
				if direction_type == 'before':
					for k,v in input_dict[origin_obs_nm].iteritems():
						if v['ORD_NUM'] != origin_obs_ordnum:
							if v['loc_end'] < origin_obs_loc_tup_start:
								other_origin_obs_loc.append(v['loc_end'])
				elif direction_type == 'after':
					for k,v in input_dict[origin_obs_nm].iteritems():
						if v['ORD_NUM'] != origin_obs_ordnum:
							if v['loc_st'] > origin_obs_loc_tup_end:
								other_origin_obs_loc.append(v['loc_st'])
								
				# Parse tgt obs:
				# If 0 origin obs in same direction as target obs, you cannot
				# parse this 'clumped' scenario; return []:
				if not other_origin_obs_loc:
					return tgt_obs_ordnum_list
				else:
					# Else, if 1+ origin obs in same direction as target obs,
					# add values only where sequence is correct/non-clumped:
					if direction_type == 'before':
						other_origin_obs_loc_max = max(other_origin_obs_loc)
						for k,v in input_dict[target_obs_nm].iteritems():
							if other_origin_obs_loc_max < v['loc_end'] < origin_obs_loc_tup_start:
								tgt_obs_ordnum_list.append(v['ORD_NUM'])
					elif direction_type == 'after':
						other_origin_obs_loc_min = min(other_origin_obs_loc)
						for k,v in input_dict[target_obs_nm].iteritems():
							if other_origin_obs_loc_min > v['loc_st'] > origin_obs_loc_tup_end:
								tgt_obs_ordnum_list.append(v['loc_st'])
		
		return tgt_obs_ordnum_list
			
	except Exception:
		logger.exception('EXCEPTION')
		return []


# DOT # Lookup Error Checker:
def dotlookupcheck(dotnumstr):
	'''Determines whether an input DOT #
	value exists in INSIGHT's DOT dataset.'''
	try:
		return bool(dotnumstr in iqdl.dotdffrozenset)
	except Exception:
		logger.exception('EXCEPTION')
		return 'E'

# DOT # vs. RFC Function:
def dotvsrfc(input_dict, dottgtlist):
	'''Compare individual DOT # job requirements
	to an individual RFC to return any conflicts
	between the two.
	
	Arguments:
		input_dict {dict}: A dictionary containing values from
		an INSIGHT observation dictionary 'rfc' observation, e.g.
		'insight_dict['rfc'][1]'.
		dottgtlist {list}: A list of target DOT #'s.
	
	Returns:
		resdict {dict}: A dictionary where k = an DOT #
		targeted and v = a list of DOT/RFC conflict descriptions
		formatted like 'rfcfitexlvl=S vs dotexlvl=L',
		'rfcclimbrampstairlol=O vs dotclimblol=F', etc.
		where the RFC name corresponds to an INSIGHT RFC
		individual function capacity level data point
		name OR '0' (no errors) OR 'P' (passed), 'LE' 
		(lookup error), or 'E' (error).
		Every target passsed will have a value.
		'''
	try:
		# Retrieve all RFC LoL/FA values:
		rfcexlvl_parsed = input_dict["rfcexlvl_parsed"]
		rfcsitlol = input_dict["rfcsitlol"]
		rfcstandlol = input_dict["rfcstandlol"]
		rfcwalklol = input_dict["rfcwalklol"]
		rfcliftlol = input_dict["rfcliftlol"]
		rfccarrylol = input_dict["rfccarrylol"]
		rfcpushlol = input_dict["rfcpushlol"]
		rfcpulllol = input_dict["rfcpulllol"]
		rfcclimbrampstairlol = input_dict["rfcclimbrampstairlol"]
		rfcclimblrslol = input_dict["rfcclimblrslol"]
		rfcbalancelol = input_dict["rfcbalancelol"]
		rfcbalancelol = input_dict["rfcbalancelol"]
		rfcstooplol = input_dict["rfcstooplol"]
		rfckneellol = input_dict["rfckneellol"]
		rfccrouchlol = input_dict["rfccrouchlol"]
		rfccrawllol = input_dict["rfccrawllol"]
		rfcreachlol = input_dict["rfcreachlol"]
		rfchandlelol = input_dict["rfchandlelol"]
		rfcfingerlol = input_dict["rfcfingerlol"]
		rfcfeellol = input_dict["rfcfeellol"]
		rfcnearacuitylol = input_dict["rfcnearacuitylol"]
		rfcfaracuitylol = input_dict["rfcfaracuitylol"]
		rfcdepthperceptionlol = input_dict["rfcdepthperceptionlol"]
		rfcaccomodationlol = input_dict["rfcaccomodationlol"]
		rfccolorvisionlol = input_dict["rfccolorvisionlol"]
		rfcfieldofvisionlol = input_dict["rfcfieldofvisionlol"]
		rfcexposuretoweatherlol = input_dict["rfcexposuretoweatherlol"]
		rfcextremeheatlol = input_dict["rfcextremeheatlol"]
		rfcextremecoldlol = input_dict["rfcextremecoldlol"]
		rfcwetnesslol = input_dict["rfcwetnesslol"]
		rfchumiditylol = input_dict["rfchumiditylol"]
		rfcvibrationlol = input_dict["rfcvibrationlol"]
		rfcatmosphericconditionslol = input_dict["rfcatmosphericconditionslol"]
		rfchazardslol = input_dict["rfchazardslol"]
		rfcmovingmechanicallol = input_dict["rfcmovingmechanicallol"]
		rfcexposedheightslol = input_dict["rfcexposedheightslol"]
		rfctoxiccausticchemicalslol = input_dict["rfctoxiccausticchemicalslol"]
		rfctalklol = input_dict["rfctalklol"]
		rfchearlol = input_dict["rfchearlol"]
		rfctastelol = input_dict["rfctastelol"]
		rfcsmelllol = input_dict["rfcsmelllol"]

		# Create function to convert INSIGHT string representation of list, 
		# string of semicolon-divided values, or a string of a single
		# value into a list object containing all values, then return list:
		# TIP: rfcparser presently DOES return string representations
		# of lists for dual assignment functions. Plan to change that.
		def listify(input):
			try:
				if isinstance(input, list):
					input_rev = [rev for rev in input if rev not in ['U', 'P', 'E', '']]
					return input_rev
				else: 
					if '[' not in input:
						input_rev = input.split('; ')
						if len(input_rev) > 1:
							input_rev = [rev for rev in input_rev if rev not in ['U', 'P', 'E', '']]
						return input_rev
					else:
						input_rev = ast.literal_eval(input)
						input_rev = [rev for rev in input_rev if rev not in ['U', 'P', 'E', '']]
						return input_rev
			except Exception:
				logger.exception('EXCEPTION')
				logger.critical(str(input))
				logger.critical(str(type(input)))
				return 'E'
		
		# Begin iterating through 'tgt_dict' to output to 'resdict' 
		# k = target data point name and v = :
		# 'P' (passed, e.g. no DOT # value present),
		# 'E' (error, an error occurred, e.g. a lookup error or program error)
		# '0' (no errors found), 
		# a list of 1+ conflict descriptor strings.
		resdict = {}
		for dotnum in dottgtlist:
			try:
				# Begin comparing RFC LoL/FA values to dotnum's values:
				rfcdotflaglist = []
				if dotnum in ['U', 'P', 'E', '']:
					resdict[dotnum] = 'P'
				else:
					# TIP: If 'dotnum' not in index, Pandas raises a KeyError.
					# You handle that below by assigning an 'LE' value to the
					# DOT # causing this.
					# TIP: This outputs a PANDAS Series, which you can query using the 
					# same syntax as dictionary querying.	
					# TIP: Series retrieval from a large DataFrame is much faster than a 
					# large dictionary (see Series Performance Notes).
					dotnumdata = iqdl.dotdf.loc[dotnum]
					
					# (A) Exertion levels:

					# Exertional Level:
					rfcexlvl_parsed_list = listify(rfcexlvl_parsed)
					rfcexlvl_parsed_list_filtered = [v for v in rfcexlvl_parsed_list if v not in ['U', 'P', 'E', 'F', '']]
					if rfcexlvl_parsed_list_filtered:
						dotexertion = dotnumdata['STRENGTH']
						
						if dotexertion == "L":
							if len([x for x in rfcexlvl_parsed_list_filtered if x in ['L', 'M', 'H']]) == 0:
								err = 'exlvl=' + '; '.join(rfcexlvl_parsed_list_filtered) + ' vs dotexlvl=' + str(dotexertion)
								rfcdotflaglist.append(err)
						elif dotexertion == "M":
							if len([x for x in rfcexlvl_parsed_list_filtered if x in ['M', 'H']]) == 0:
								err = 'exlvl=' + '; '.join(rfcexlvl_parsed_list_filtered) + ' vs dotexlvl=' + str(dotexertion)
								rfcdotflaglist.append(err)
						elif dotexertion == "H":
							if len([x for x in rfcexlvl_parsed_list_filtered if x == 'H']) == 0:
								err = 'exlvl=' + '; '.join(rfcexlvl_parsed_list_filtered) + ' vs dotexlvl=' + str(dotexertion)
								rfcdotflaglist.append(err)		
					
					# Sitting:
					if rfcsitlol.isdigit():
						dotexertion = dotnumdata["STRENGTH"]
						if rfcsitlol.isdigit():
							if int(rfcsitlol) < 6:
								err = "rfcsitlol=" + str(rfcsitlol) + " vs dotexlvl=" + str(dotexertion)
								rfcdotflaglist.append(err)

					# Standing:
					if rfcstandlol.isdigit():
						dotexertion = dotnumdata["STRENGTH"]
						if dotexertion == "S":
							if int(rfcstandlol) < 2:
								err = "rfcstandlol=" + str(rfcstandlol) + " vs dotexlvl=" + str(dotexertion)
								rfcdotflaglist.append(err)
						if dotexertion in ["L", "M", "H", "V"]:
							if int(rfcstandlol) < 6:
								err = "rfcstandlol=" + str(rfcstandlol) + " vs dotexlvl=" + str(dotexertion)
								rfcdotflaglist.append(err)

					# Walking:
					if rfcwalklol.isdigit():
						dotexertion = dotnumdata["STRENGTH"]
						if dotexertion == "S":
							if int(rfcwalklol) < 2:
								err = "rfcwalklol=" + str(rfcwalklol) + " vs dotexlvl=" + str(dotexertion)
								rfcdotflaglist.append(err)
						if dotexertion in ["L", "M", "H", "V"]:
							if int(rfcwalklol) < 6:
								err = "rfcwalklol=" + str(rfcwalklol) + " vs dotexlvl=" + str(dotexertion)
								rfcdotflaglist.append(err)			

					# Lifting:
					rfcliftlol = listify(rfcliftlol)
					dotexertion = dotnumdata["STRENGTH"]
					for lol in rfcliftlol:
						if lol.isdigit():
							if dotexertion == "L":
								if int(lol) < 10:
									err = "rfcliftlol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)
							if dotexertion == "M":
								if int(lol) < 25:
									err = "rfcliftlol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)
							if dotexertion in ["H", "V"]:
								if int(lol) < 50:
									err = "rfcliftlol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)							

					# Carrying:
					rfccarrylol = listify(rfccarrylol)
					dotexertion = dotnumdata["STRENGTH"]
					for lol in rfccarrylol:
						if lol.isdigit():
							if dotexertion == "L":
								if int(lol) < 10:
									err = "rfccarrylol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)
							if dotexertion == "M":
								if int(lol) < 25:
									err = "rfccarrylol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)
							if dotexertion in ["H", "V"]:
								if int(lol) < 50:
									err = "rfccarrylol=" + str(lol) + " vs dotexlvl=" + str(dotexertion)
									rfcdotflaglist.append(err)						

					# Pushing / Pulling:
					# TIP: The DOT data on hand does not specify precise pushing/pulling requirements of various jobs, and
					# SSA regulations don't specify EXACT amounts of pushing/pulling entailed at different exertional levels.
					# However, SSA regulations (POMS DI 25001.001 . SSR 83-10) do indicate that light work (and presumably any exertion
					# level more demanding than it) can entail "sitting most of the time while pushing or pulling arm or leg 
					# controls, or working at a production rate pace while constantly pushing or pulling materials even though 
					# the weight of the materials is negligible."  Thus, it is reasonable to raise a conflict if the claimant 
					# is completely precluded from pushing or pulling but is stated to be able to perform a job requiring
					# light or greater exertional strength:
					rfcpushlol = listify(rfcpushlol)
					dotexertion = dotnumdata["STRENGTH"]
					for lol in rfcpushlol:
						if lol == "N":
							if dotexertion in ["L", "M", "H", "V"]:
								err = "rfcpushlol=" + str(lol) + " vs dotexertion=" + str(dotexertion)
								rfcdotflaglist.append(err)					
					
					rfcpulllol = listify(rfcpulllol)
					dotexertion = dotnumdata["STRENGTH"]
					for lol in rfcpulllol:
						if lol == "N":
							if dotexertion in ["L", "M", "H", "V"]:
								err = "rfcpulllol=" + str(lol) + " vs dotexertion=" + str(dotexertion)
								rfcdotflaglist.append(err)											
								
					# (B) Posturals / Manipulatives / Visuals:

					# Climbing ramps/stairs:
					# TIP: DOT only has a 'climbing' value, not as specific.  So looking for EITHER
					# LRS or RS conflicts and outputting whatever raises a result.
					if rfcclimbrampstairlol in ['N', 'O', 'F']:

						dotclimblol = dotnumdata["PHYDMD02"]  # OPEN Q: Does the DOT definition of 'climbing' entail BOTH ramps/stairs AND LRS?

						if rfcclimbrampstairlol == "N":
							if dotclimblol == "O" or dotclimblol == "F" or dotclimblol == "C":
								err = "rfcclimbrampstairlol=" + str(rfcclimbrampstairlol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)
						if rfcclimbrampstairlol == "O":
							if dotclimblol == "F" or dotclimblol == "C":
								err = "rfcclimbrampstairlol=" + str(rfcclimbrampstairlol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)
						if rfcclimbrampstairlol == "F":
							if dotclimblol == "C":
								err = "rfcclimbrampstairlol=" + str(rfcclimbrampstairlol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)					 

					# Climbing L/R/S:
					if rfcclimblrslol in ['N', 'O', 'F']:
					
						dotclimblol = dotnumdata["PHYDMD02"]  # OPEN Q: Does the DOT definition of 'climbing' entail BOTH ramps/stairs AND LRS?

						if rfcclimblrslol == "N":
							if dotclimblol == "O" or dotclimblol == "F" or dotclimblol == "C":
								err = "rfcclimblrslol=" + str(rfcclimblrslol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)
						if rfcclimblrslol == "O":
							if dotclimblol == "F" or dotclimblol == "C":
								err = "rfcclimblrslol=" + str(rfcclimblrslol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)
						if rfcclimblrslol == "F":
							if dotclimblol == "C":
								err = "rfcclimblrslol=" + str(rfcclimblrslol) + " vs dotclimblol=" + str(dotclimblol)
								rfcdotflaglist.append(err)

					# Balancing:
					if rfcbalancelol in ['N', 'O', 'F']:

						dotbalancelol = dotnumdata["PHYDMD03"]

						if rfcbalancelol == "N":
							if dotbalancelol == "O" or dotbalancelol == "F" or dotbalancelol == "C":
								err = "rfcbalancelol=" + str(rfcbalancelol) + " vs dotbalancelol=" + str(dotbalancelol)
								rfcdotflaglist.append(err)
						if rfcbalancelol == "O":
							if dotbalancelol == "F" or dotbalancelol == "C":
								err = "rfcbalancelol=" + str(rfcbalancelol) + " vs dotbalancelol=" + str(dotbalancelol)
								rfcdotflaglist.append(err)
						if rfcbalancelol == "F":
							if dotbalancelol == "C":
								err = "rfcbalancelol=" + str(rfcbalancelol) + " vs dotbalancelol=" + str(dotbalancelol)
								rfcdotflaglist.append(err)

					# Stooping:
					if rfcstooplol in ['N', 'O', 'F']:

						dotstooplol = dotnumdata["PHYDMD04"]

						if rfcstooplol == "N":
							if dotstooplol == "O" or dotstooplol == "F" or dotstooplol == "C":
								err = "rfcstooplol=" + str(rfcstooplol) + " vs dotstooplol=" + str(dotstooplol)
								rfcdotflaglist.append(err)
						if rfcstooplol == "O":
							if dotstooplol == "F" or dotstooplol == "C":
								err = "rfcstooplol=" + str(rfcstooplol) + " vs dotstooplol=" + str(dotstooplol)
								rfcdotflaglist.append(err)
						if rfcstooplol == "F":
							if dotstooplol == "C":
								err = "rfcstooplol=" + str(rfcstooplol) + " vs dotstooplol=" + str(dotstooplol)
								rfcdotflaglist.append(err)

					# Kneeling:
					if rfckneellol in ['N', 'O', 'F']:

						dotkneellol = dotnumdata["PHYDMD05"]

						if rfckneellol == "N":
							if dotkneellol == "O" or dotkneellol == "F" or dotkneellol == "C":
								err = "rfckneellol=" + str(rfckneellol) + " vs dotkneellol=" + str(dotkneellol)
								rfcdotflaglist.append(err)
						if rfckneellol == "O":
							if dotkneellol == "F" or dotkneellol == "C":
								err = "rfckneellol=" + str(rfckneellol) + " vs dotkneellol=" + str(dotkneellol)
								rfcdotflaglist.append(err)
						if rfckneellol == "F":
							if dotkneellol == "C":
								err = "rfckneellol=" + str(rfckneellol) + " vs dotkneellol=" + str(dotkneellol)
								rfcdotflaglist.append(err)

					# Crouching:
					if rfccrouchlol in ['N', 'O', 'F']:

						dotcrouchlol = dotnumdata["PHYDMD06"]

						if rfccrouchlol == "N":
							if dotcrouchlol == "O" or dotcrouchlol == "F" or dotcrouchlol == "C":
								err = "rfccrouchlol=" + str(rfccrouchlol) + " vs dotcrouchlol=" + str(dotcrouchlol)
								rfcdotflaglist.append(err)
						if rfccrouchlol == "O":
							if dotcrouchlol == "F" or dotcrouchlol == "C":
								err = "rfccrouchlol=" + str(rfccrouchlol) + " vs dotcrouchlol=" + str(dotcrouchlol)
								rfcdotflaglist.append(err)
						if rfccrouchlol == "F":
							if dotcrouchlol == "C":
								err = "rfccrouchlol=" + str(rfccrouchlol) + " vs dotcrouchlol=" + str(dotcrouchlol)
								rfcdotflaglist.append(err)

					# Crawling:
					if rfccrawllol in ['N', 'O', 'F']:

						dotcrawllol = dotnumdata["PHYDMD07"]

						if rfccrawllol == "N":
							if dotcrawllol == "O" or dotcrawllol == "F" or dotcrawllol == "C":
								err = "rfccrawllol=" + str(rfccrawllol) + " vs dotcrawllol=" + str(dotcrawllol)
								rfcdotflaglist.append(err)
						if rfccrawllol == "O":
							if dotcrawllol == "F" or dotcrawllol == "C":
								err = "rfccrawllol=" + str(rfccrawllol) + " vs dotcrawllol=" + str(dotcrawllol)
								rfcdotflaglist.append(err)
						if rfccrawllol == "F":
							if dotcrawllol == "C":
								err = "rfccrawllol=" + str(rfccrawllol) + " vs dotcrawllol=" + str(dotcrawllol)
								rfcdotflaglist.append(err)

					# Reaching:
					rfcreachlol = listify(rfcreachlol)
					dotreachlol = dotnumdata["PHYDMD08"]
					for lol in rfcreachlol:
						if lol in ['N', 'O', 'F']:
							if lol == "N":
								if dotreachlol in ['O', 'F', 'C']:
									err = "rfcreachlol=" + str(lol) + " vs dotreachlol=" + str(dotreachlol)
									rfcdotflaglist.append(err)
							elif lol == "O":
								if dotreachlol in ['F', 'C']:
									err = "rfcreachlol=" + str(lol) + " vs dotreachlol=" + str(dotreachlol)
									rfcdotflaglist.append(err)
							elif lol == "F":
								if dotreachlol == "C":
									err = "rfcreachlol=" + str(lol) + " vs dotreachlol=" + str(dotreachlol)
									rfcdotflaglist.append(err)

					# Handling:
					rfchandlelol = listify(rfchandlelol)
					dothandlelol = dotnumdata["PHYDMD09"]
					for lol in rfchandlelol:
						if lol in ['N', 'O', 'F']:
							if lol == "N":
								if dothandlelol in ['O', 'F', 'C']:
									err = "rfchandlelol=" + str(lol) + " vs dothandlelol=" + str(dothandlelol)
									rfcdotflaglist.append(err)
							elif lol == "O":
								if dothandlelol in ['F', 'C']:
									err = "rfchandlelol=" + str(lol) + " vs dothandlelol=" + str(dothandlelol)
									rfcdotflaglist.append(err)
							elif lol == "F":
								if dothandlelol == "C":
									err = "rfchandlelol=" + str(lol) + " vs dothandlelol=" + str(dothandlelol)
									rfcdotflaglist.append(err)

					# Fingering:
					rfcfingerlol = listify(rfcfingerlol)
					dotfingerlol = dotnumdata["PHYDMD10"]
					for lol in rfcfingerlol:
						if lol in ['N', 'O', 'F']:
							if lol == "N":
								if dotfingerlol in ['O', 'F', 'C']:
									err = "rfcfingerlol=" + str(lol) + " vs dotfingerlol=" + str(dotfingerlol)
									rfcdotflaglist.append(err)
							elif lol == "O":
								if dotfingerlol in ['F', 'C']:
									err = "rfcfingerlol=" + str(lol) + " vs dotfingerlol=" + str(dotfingerlol)
									rfcdotflaglist.append(err)
							elif lol == "F":
								if dotfingerlol == "C":
									err = "rfcfingerlol=" + str(lol) + " vs dotfingerlol=" + str(dotfingerlol)
									rfcdotflaglist.append(err)

					# Feeling:
					rfcfeellol = listify(rfcfeellol)
					dotfeellol = dotnumdata["PHYDMD11"]
					for lol in rfcfeellol:
						if lol in ['N', 'O', 'F']:
							if lol == "N":
								if dotfeellol in ['O', 'F', 'C']:
									err = "rfcfeellol=" + str(lol) + " vs dotfeellol=" + str(dotfeellol)
									rfcdotflaglist.append(err)
							elif lol == "O":
								if dotfeellol in ['F', 'C']:
									err = "rfcfeellol=" + str(lol) + " vs dotfeellol=" + str(dotfeellol)
									rfcdotflaglist.append(err)
							elif lol == "F":
								if dotfeellol == "C":
									err = "rfcfeellol=" + str(lol) + " vs dotfeellol=" + str(dotfeellol)
									rfcdotflaglist.append(err)

					# Talk:
					if rfctalklol in ['N', 'O', 'F']:

						dottalklol = dotnumdata["PHYDMD12"]

						if rfctalklol == "N":
							if dottalklol == "O" or dottalklol == "F" or dottalklol == "C":
								err = "rfctalklol=" + str(rfctalklol) + " vs dottalklol=" + str(dottalklol)
								rfcdotflaglist.append(err)
						if rfctalklol == "O":
							if dottalklol == "F" or dottalklol == "C":
								err = "rfctalklol=" + str(rfctalklol) + " vs dottalklol=" + str(dottalklol)
								rfcdotflaglist.append(err)
						if rfctalklol == "F":
							if dottalklol == "C":
								err = "rfctalklol=" + str(rfctalklol) + " vs dottalklol=" + str(dottalklol)
								rfcdotflaglist.append(err)

					# Hear:
					if rfchearlol in ['N', 'O', 'F']:

						dothearlol = dotnumdata["PHYDMD13"]

						if rfchearlol == "N":
							if dothearlol == "O" or dothearlol == "F" or dothearlol == "C":
								err = "rfchearlol=" + str(rfchearlol) + " vs dothearlol=" + str(dothearlol)
								rfcdotflaglist.append(err)
						if rfchearlol == "O":
							if dothearlol == "F" or dothearlol == "C":
								err = "rfchearlol=" + str(rfchearlol) + " vs dothearlol=" + str(dothearlol)
								rfcdotflaglist.append(err)
						if rfchearlol == "F":
							if dothearlol == "C":
								err = "rfchearlol=" + str(rfchearlol) + " vs dothearlol=" + str(dothearlol)
								rfcdotflaglist.append(err)

					# Taste:
					if rfctastelol in ['N', 'O', 'F']:

						dottastelol = dotnumdata["PHYDMD14"]

						if rfctastelol == "N":
							if dottastelol == "O" or dottastelol == "F" or dottastelol == "C":
								err = "rfctastelol=" + str(rfctastelol) + " vs dottastelol=" + str(dottastelol)
								rfcdotflaglist.append(err)
						if rfctastelol == "O":
							if dottastelol == "F" or dottastelol == "C":
								err = "rfctastelol=" + str(rfctastelol) + " vs dottastelol=" + str(dottastelol)
								rfcdotflaglist.append(err)
						if rfctastelol == "F":
							if dottastelol == "C":
								err = "rfctastelol=" + str(rfctastelol) + " vs dottastelol=" + str(dottastelol)
								rfcdotflaglist.append(err)

					# Smell:
					if rfcsmelllol in ['N', 'O', 'F']:

						dotsmelllol = dotnumdata["PHYDMD14"]

						if rfcsmelllol == "N":
							if dotsmelllol == "O" or dotsmelllol == "F" or dotsmelllol == "C":
								err = "rfcsmelllol=" + str(rfcsmelllol) + " vs dotsmelllol=" + str(dotsmelllol)
								rfcdotflaglist.append(err)
						if rfcsmelllol == "O":
							if dotsmelllol == "F" or dotsmelllol == "C":
								err = "rfcsmelllol=" + str(rfcsmelllol) + " vs dotsmelllol=" + str(dotsmelllol)
								rfcdotflaglist.append(err)
						if rfcsmelllol == "F":
							if dotsmelllol == "C":
								err = "rfcsmelllol=" + str(rfcsmelllol) + " vs dotsmelllol=" + str(dotsmelllol)
								rfcdotflaglist.append(err)

					# Near acuity:
					if rfcnearacuitylol in ['N', 'O', 'F']:

						dotnearacuitylol = dotnumdata["PHYDMD15"]

						if rfcnearacuitylol == "N":
							if dotnearacuitylol == "O" or dotnearacuitylol == "F" or dotnearacuitylol == "C":
								err = "rfcnearacuitylol=" + str(rfcnearacuitylol) + " vs dotnearacuitylol=" + str(dotnearacuitylol)
								rfcdotflaglist.append(err)
						if rfcnearacuitylol == "O":
							if dotnearacuitylol == "F" or dotnearacuitylol == "C":
								err = "rfcnearacuitylol=" + str(rfcnearacuitylol) + " vs dotnearacuitylol=" + str(dotnearacuitylol)
								rfcdotflaglist.append(err)
						if rfcnearacuitylol == "F":
							if dotnearacuitylol == "C":
								err = "rfcnearacuitylol=" + str(rfcnearacuitylol) + " vs dotnearacuitylol=" + str(dotnearacuitylol)
								rfcdotflaglist.append(err)

					# Far acuity:
					if rfcfaracuitylol in ['N', 'O', 'F']:

						dotfaracuitylol = dotnumdata["PHYDMD16"]

						if rfcfaracuitylol == "N":
							if dotfaracuitylol == "O" or dotfaracuitylol == "F" or dotfaracuitylol == "C":
								err = "rfcfaracuitylol=" + str(rfcfaracuitylol) + " vs dotfaracuitylol=" + str(dotfaracuitylol)
								rfcdotflaglist.append(err)
						if rfcfaracuitylol == "O":
							if dotfaracuitylol == "F" or dotfaracuitylol == "C":
								err = "rfcfaracuitylol=" + str(rfcfaracuitylol) + " vs dotfaracuitylol=" + str(dotfaracuitylol)
								rfcdotflaglist.append(err)
						if rfcfaracuitylol == "F":
							if dotfaracuitylol == "C":
								err = "rfcfaracuitylol=" + str(rfcfaracuitylol) + " vs dotfaracuitylol=" + str(dotfaracuitylol)
								rfcdotflaglist.append(err)

					# Depth perception:
					if rfcdepthperceptionlol in ['N', 'O', 'F']:

						dotdepthperceptionlol = dotnumdata["PHYDMD17"]

						if rfcdepthperceptionlol == "N":
							if dotdepthperceptionlol == "O" or dotdepthperceptionlol == "F" or dotdepthperceptionlol == "C":
								err = "rfcdepthperceptionlol=" + str(rfcdepthperceptionlol) + " vs dotdepthperceptionlol=" + str(dotdepthperceptionlol)
								rfcdotflaglist.append(err)
						if rfcdepthperceptionlol == "O":
							if dotdepthperceptionlol == "F" or dotdepthperceptionlol == "C":
								err = "rfcdepthperceptionlol=" + str(rfcdepthperceptionlol) + " vs dotdepthperceptionlol=" + str(dotdepthperceptionlol)
								rfcdotflaglist.append(err)
						if rfcdepthperceptionlol == "F":
							if dotdepthperceptionlol == "C":
								err = "rfcdepthperceptionlol=" + str(rfcdepthperceptionlol) + " vs dotdepthperceptionlol=" + str(dotdepthperceptionlol)
								rfcdotflaglist.append(err)

					# Accomodation:
					if rfcaccomodationlol in ['N', 'O', 'F']:

						dotaccomodationlol = dotnumdata["PHYDMD18"]

						if rfcaccomodationlol == "N":
							if dotaccomodationlol == "O" or dotaccomodationlol == "F" or dotaccomodationlol == "C":
								err = "rfcaccomodationlol=" + str(rfcaccomodationlol) + " vs dotaccomodationlol=" + str(dotaccomodationlol)
								rfcdotflaglist.append(err)
						if rfcaccomodationlol == "O":
							if dotaccomodationlol == "F" or dotaccomodationlol == "C":
								err = "rfcaccomodationlol=" + str(rfcaccomodationlol) + " vs dotaccomodationlol=" + str(dotaccomodationlol)
								rfcdotflaglist.append(err)
						if rfcaccomodationlol == "F":
							if dotaccomodationlol == "C":
								err = "rfcaccomodationlol=" + str(rfcaccomodationlol) + " vs dotaccomodationlol=" + str(dotaccomodationlol)
								rfcdotflaglist.append(err)

					# Color vision:
					if rfccolorvisionlol in ['N', 'O', 'F']:

						dotcolorvisionlol = dotnumdata["PHYDMD19"]

						if rfccolorvisionlol == "N":
							if dotcolorvisionlol == "O" or dotcolorvisionlol == "F" or dotcolorvisionlol == "C":
								err = "rfccolorvisionlol=" + str(rfccolorvisionlol) + " vs dotcolorvisionlol=" + str(dotcolorvisionlol)
								rfcdotflaglist.append(err)
						if rfccolorvisionlol == "O":
							if dotcolorvisionlol == "F" or dotcolorvisionlol == "C":
								err = "rfccolorvisionlol=" + str(rfccolorvisionlol) + " vs dotcolorvisionlol=" + str(dotcolorvisionlol)
								rfcdotflaglist.append(err)
						if rfccolorvisionlol == "F":
							if dotcolorvisionlol == "C":
								err = "rfccolorvisionlol=" + str(rfccolorvisionlol) + " vs dotcolorvisionlol=" + str(dotcolorvisionlol)
								rfcdotflaglist.append(err)

					# Field of vision:
					if rfcfieldofvisionlol in ['N', 'O', 'F']:

						dotfieldofvisionlol = dotnumdata["PHYDMD20"]

						if rfcfieldofvisionlol == "N":
							if dotfieldofvisionlol == "O" or dotfieldofvisionlol == "F" or dotfieldofvisionlol == "C":
								err = "rfcfieldofvisionlol=" + str(rfcfieldofvisionlol) + " vs dotfieldofvisionlol=" + str(dotfieldofvisionlol)
								rfcdotflaglist.append(err)
						if rfcfieldofvisionlol == "O":
							if dotfieldofvisionlol == "F" or dotfieldofvisionlol == "C":
								err = "rfcfieldofvisionlol=" + str(rfcfieldofvisionlol) + " vs dotfieldofvisionlol=" + str(dotfieldofvisionlol)
								rfcdotflaglist.append(err)
						if rfcfieldofvisionlol == "F":
							if dotfieldofvisionlol == "C":
								err = "rfcfieldofvisionlol=" + str(rfcfieldofvisionlol) + " vs dotfieldofvisionlol=" + str(dotfieldofvisionlol)
								rfcdotflaglist.append(err)

					# (C) Environmentals:
					# RFC VALUE OPTIONS: 'N', 'O', 'F', 'C', 'OCCASIONALEQUIV', 'FREQUENTEQUIV'
					# DOT VALUE OPTIONS: N, O, F, C

					# Exposure to weather:
					if rfcexposuretoweatherlol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotexposuretoweatherlol = dotnumdata["ENVCON01"]

						if rfcexposuretoweatherlol == "N":
							if dotexposuretoweatherlol == "O" or dotexposuretoweatherlol == "F" or dotexposuretoweatherlol == "C":
								err = "rfcexposuretoweatherlol=" + str(rfcexposuretoweatherlol) + " vs dotexposuretoweatherlol=" + str(dotexposuretoweatherlol)
								rfcdotflaglist.append(err)
						if rfcexposuretoweatherlol in ['O', 'OCCASIONALEQUIV']:
							if dotexposuretoweatherlol == "F" or dotexposuretoweatherlol == "C":
								err = "rfcexposuretoweatherlol=" + str(rfcexposuretoweatherlol) + " vs dotexposuretoweatherlol=" + str(dotexposuretoweatherlol)
								rfcdotflaglist.append(err)
						if rfcexposuretoweatherlol in ['F', 'FREQUENTEQUIV']:
							if dotexposuretoweatherlol == "C":
								err = "rfcexposuretoweatherlol=" + str(rfcexposuretoweatherlol) + " vs dotexposuretoweatherlol=" + str(dotexposuretoweatherlol)
								rfcdotflaglist.append(err)

					# Extreme cold:
					if rfcextremecoldlol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotextremecoldlol = dotnumdata["ENVCON02"]

						if rfcextremecoldlol == "N":
							if dotextremecoldlol == "O" or dotextremecoldlol == "F" or dotextremecoldlol == "C":
								err = "rfcextremecoldlol=" + str(rfcextremecoldlol) + " vs dotextremecoldlol=" + str(dotextremecoldlol)
								rfcdotflaglist.append(err)
						if rfcextremecoldlol in ['O', 'OCCASIONALEQUIV']:
							if dotextremecoldlol == "F" or dotextremecoldlol == "C":
								err = "rfcextremecoldlol=" + str(rfcextremecoldlol) + " vs dotextremecoldlol=" + str(dotextremecoldlol)
								rfcdotflaglist.append(err)
						if rfcextremecoldlol in ['F', 'FREQUENTEQUIV']:
							if dotextremecoldlol == "C":
								err = "rfcextremecoldlol=" + str(rfcextremecoldlol) + " vs dotextremecoldlol=" + str(dotextremecoldlol)
								rfcdotflaglist.append(err)

					# Extreme heat:
					if rfcextremeheatlol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotextremeheatlol = dotnumdata["ENVCON03"]

						if rfcextremeheatlol == "N":
							if dotextremeheatlol == "O" or dotextremeheatlol == "F" or dotextremeheatlol == "C":
								err = "rfcextremeheatlol=" + str(rfcextremeheatlol) + " vs dotextremeheatlol=" + str(dotextremeheatlol)
								rfcdotflaglist.append(err)
						if rfcextremeheatlol in ['O', 'OCCASIONALEQUIV']:
							if dotextremeheatlol == "F" or dotextremeheatlol == "C":
								err = "rfcextremeheatlol=" + str(rfcextremeheatlol) + " vs dotextremeheatlol=" + str(dotextremeheatlol)
								rfcdotflaglist.append(err)
						if rfcextremeheatlol in ['F', 'FREQUENTEQUIV']:
							if dotextremeheatlol == "C":
								err = "rfcextremeheatlol=" + str(rfcextremeheatlol) + " vs dotextremeheatlol=" + str(dotextremeheatlol)
								rfcdotflaglist.append(err)

					# Wetness:
					if rfcwetnesslol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotwetnesslol = dotnumdata["ENVCON04"]

						if rfcwetnesslol == "N":
							if dotwetnesslol == "O" or dotwetnesslol == "F" or dotwetnesslol == "C":
								err = "rfcwetnesslol=" + str(rfcwetnesslol) + " vs dotwetnesslol=" + str(dotwetnesslol)
								rfcdotflaglist.append(err)
						if rfcwetnesslol in ['O', 'OCCASIONALEQUIV']:
							if dotwetnesslol == "F" or dotwetnesslol == "C":
								err = "rfcwetnesslol=" + str(rfcwetnesslol) + " vs dotwetnesslol=" + str(dotwetnesslol)
								rfcdotflaglist.append(err)
						if rfcwetnesslol in ['F', 'FREQUENTEQUIV']:
							if dotwetnesslol == "C":
								err = "rfcwetnesslol=" + str(rfcwetnesslol) + " vs dotwetnesslol=" + str(dotwetnesslol)
								rfcdotflaglist.append(err)

					# Humidity:
					if rfchumiditylol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dothumiditylol = dotnumdata["ENVCON04"]	 # OPEN Q: Is this correct? Same as 'wetness'...

						if rfchumiditylol == "N":
							if dothumiditylol == "O" or dothumiditylol == "F" or dothumiditylol == "C":
								err = "rfchumiditylol=" + str(rfchumiditylol) + " vs dothumiditylol=" + str(dothumiditylol)
								rfcdotflaglist.append(err)
						if rfchumiditylol in ['O', 'OCCASIONALEQUIV']:
							if dothumiditylol == "F" or dothumiditylol == "C":
								err = "rfchumiditylol=" + str(rfchumiditylol) + " vs dothumiditylol=" + str(dothumiditylol)
								rfcdotflaglist.append(err)
						if rfchumiditylol in ['F', 'FREQUENTEQUIV']:
							if dothumiditylol == "C":
								err = "rfchumiditylol=" + str(rfchumiditylol) + " vs dothumiditylol=" + str(dothumiditylol)
								rfcdotflaglist.append(err)

					# Vibration:
					if rfcvibrationlol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotvibrationlol = dotnumdata["ENVCON06"]

						if rfcvibrationlol == "N":
							if dotvibrationlol == "O" or dotvibrationlol == "F" or dotvibrationlol == "C":
								err = "rfcvibrationlol=" + str(rfcvibrationlol) + " vs dotvibrationlol=" + str(dotvibrationlol)
								rfcdotflaglist.append(err)
						if rfcvibrationlol in ['O', 'OCCASIONALEQUIV']:
							if dotvibrationlol == "F" or dotvibrationlol == "C":
								err = "rfcvibrationlol=" + str(rfcvibrationlol) + " vs dotvibrationlol=" + str(dotvibrationlol)
								rfcdotflaglist.append(err)
						if rfcvibrationlol in ['F', 'FREQUENTEQUIV']:
							if dotvibrationlol == "C":
								err = "rfcvibrationlol=" + str(rfcvibrationlol) + " vs dotvibrationlol=" + str(dotvibrationlol)
								rfcdotflaglist.append(err)

					# Atmospheric conditions:
					if rfcatmosphericconditionslol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotatmosphericconditionslol = dotnumdata["ENVCON07"]

						if rfcatmosphericconditionslol == "N":
							if dotatmosphericconditionslol == "O" or dotatmosphericconditionslol == "F" or dotatmosphericconditionslol == "C":
								err = "rfcatmosphericconditionslol=" + str(rfcatmosphericconditionslol) + " vs dotatmosphericconditionslol=" + str(dotatmosphericconditionslol)
								rfcdotflaglist.append(err)
						if rfcatmosphericconditionslol in ['O', 'OCCASIONALEQUIV']:
							if dotatmosphericconditionslol == "F" or dotatmosphericconditionslol == "C":
								err = "rfcatmosphericconditionslol=" + str(rfcatmosphericconditionslol) + " vs dotatmosphericconditionslol=" + str(dotatmosphericconditionslol)
								rfcdotflaglist.append(err)
						if rfcatmosphericconditionslol in ['F', 'FREQUENTEQUIV']:
							if dotatmosphericconditionslol == "C":
								err = "rfcatmosphericconditionslol=" + str(rfcatmosphericconditionslol) + " vs dotatmosphericconditionslol=" + str(dotatmosphericconditionslol)
								rfcdotflaglist.append(err)

					# Moving mechanical hazards:
					if rfcmovingmechanicallol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotmovingmechanicallol = dotnumdata["ENVCON08"]

						if rfcmovingmechanicallol == "N":
							if dotmovingmechanicallol == "O" or dotmovingmechanicallol == "F" or dotmovingmechanicallol == "C":
								err = "rfcmovingmechanicallol=" + str(rfcmovingmechanicallol) + " vs dotmovingmechanicallol=" + str(dotmovingmechanicallol)
								rfcdotflaglist.append(err)
						if rfcmovingmechanicallol in ['O', 'OCCASIONALEQUIV']:
							if dotmovingmechanicallol == "F" or dotmovingmechanicallol == "C":
								err = "rfcmovingmechanicallol=" + str(rfcmovingmechanicallol) + " vs dotmovingmechanicallol=" + str(dotmovingmechanicallol)
								rfcdotflaglist.append(err)
						if rfcmovingmechanicallol in ['F', 'FREQUENTEQUIV']:
							if dotmovingmechanicallol == "C":
								err = "rfcmovingmechanicallol=" + str(rfcmovingmechanicallol) + " vs dotmovingmechanicallol=" + str(dotmovingmechanicallol)
								rfcdotflaglist.append(err)

					# Heights hazards:
					if rfcexposedheightslol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dotexposedheightslol = dotnumdata["ENVCON10"]

						if rfcexposedheightslol == "N":
							if dotexposedheightslol == "O" or dotexposedheightslol == "F" or dotexposedheightslol == "C":
								err = "rfcexposedheightslol=" + str(rfcexposedheightslol) + " vs dotexposedheightslol=" + str(dotexposedheightslol)
								rfcdotflaglist.append(err)
						if rfcexposedheightslol in ['O', 'OCCASIONALEQUIV']:
							if dotexposedheightslol == "F" or dotexposedheightslol == "C":
								err = "rfcexposedheightslol=" + str(rfcexposedheightslol) + " vs dotexposedheightslol=" + str(dotexposedheightslol)
								rfcdotflaglist.append(err)
						if rfcexposedheightslol in ['F', 'FREQUENTEQUIV']:
							if dotexposedheightslol == "C":
								err = "rfcexposedheightslol=" + str(rfcexposedheightslol) + " vs dotexposedheightslol=" + str(dotexposedheightslol)
								rfcdotflaglist.append(err)

					# Toxic caustic chemicals:
					if rfctoxiccausticchemicalslol in ['N', 'O', 'F', 'OCCASIONALEQUIV', 'FREQUENTEQUIV']:

						dottoxiccausticchemicalslol = dotnumdata["ENVCON13"]

						if rfctoxiccausticchemicalslol == "N":
							if dottoxiccausticchemicalslol == "O" or dottoxiccausticchemicalslol == "F" or dottoxiccausticchemicalslol == "C":
								err = "rfctoxiccausticchemicalslol=" + str(rfctoxiccausticchemicalslol) + " vs dottoxiccausticchemicalslol=" + str(dottoxiccausticchemicalslol)
								rfcdotflaglist.append(err)
						if rfctoxiccausticchemicalslol in ['O', 'OCCASIONALEQUIV']:
							if dottoxiccausticchemicalslol == "F" or dottoxiccausticchemicalslol == "C":
								err = "rfctoxiccausticchemicalslol=" + str(rfctoxiccausticchemicalslol) + " vs dottoxiccausticchemicalslol=" + str(dottoxiccausticchemicalslol)
								rfcdotflaglist.append(err)
						if rfctoxiccausticchemicalslol in ['F', 'FREQUENTEQUIV']:
							if dottoxiccausticchemicalslol == "C":
								err = "rfctoxiccausticchemicalslol=" + str(rfctoxiccausticchemicalslol) + " vs dottoxiccausticchemicalslol=" + str(dottoxiccausticchemicalslol)
								rfcdotflaglist.append(err)
					
				# If 0 flags found, assign this DOT #'s quality value as 'U':
				if len(rfcdotflaglist) == 0:
					resdict[dotnum] = '0'
				# Else, assign this DOT #'s quality value as 'rfcdotflaglist' (which contains a string representation of the details of each conflict between this DOT # and the RFC LoL/FA values):
				else:
					resdict[dotnum] = rfcdotflaglist
			except KeyError:
				resdict[dotnum] = 'E'
			except Exception:
				logger.exception('EXCEPTION')
				resdict[dotnum] = 'E'
		
		return resdict
	except Exception:
		logger.exception('EXCEPTION')
		resdict = {}
		for tgt in dottgtlist:
			resdict[tgt] = 'E'
		return resdict


		
