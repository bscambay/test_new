﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSIGHT_Request.Models
{
    public class OAOFolderDocument
    {
        [JsonProperty("folderNumber")]
        public string FLDR_NUM { get; set; } = "";
        [JsonProperty("caseNumber")]
        public string CASE_NUM { get; set; } = "";
        [JsonProperty("documentId")]
        public string DOCU_CTL_ID { get; set; } = "";
        [JsonProperty("documentTypeCode(DOCTYPE)")]
        public string DOCU_CD { get; set; } = "";
        [JsonProperty("modularDocumentFolderCode(MDF)")]
        public string MDF_CD { get; set; } = "";
        [JsonProperty("officeCode(OCD)")]
        public string OCD { get; set; } = "";
        [JsonProperty("notes")]
        public string DMA_NOTES { get; set; } = "";
        [JsonProperty("treatmentSourceName")]
        public string TRTMNT_SRC_NM { get; set; } = "";
        [JsonProperty("dmaReceiptTimestamp")]
        public string DMA_RCPT_TS { get; set; } = "";

    }
}
