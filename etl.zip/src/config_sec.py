# INSIGHT FULL SUITE MASTER CONFIGURATION FILE
# CREDENTIALS / PINS MERITING HIGHER SECURITY
# ============================================

import argparse

parser = argparse.ArgumentParser(description='Arguments to load configurations')
config_parser = parser.add_mutually_exclusive_group(required=False)
config_parser.add_argument('--development', dest="development", action='store_true', help='Use development configurations.')
config_parser.add_argument('--integration', dest="integration", action='store_true', help='Use integration configurations.')
config_parser.add_argument('--validation', dest="validation", action='store_true', help='Use validation configurations.')
config_parser.add_argument('--production', dest="production", action='store_true', help='Use production configurations.')
parser.set_defaults(development=True)

args = parser.parse_known_args()[0]

if args.production:
    print(" Put prd configurations here. ")
elif args.validation:
    print(" Put val configurations here. ")
elif args.integration:
    print(" Put int configurations here. ")
elif args.development:
    # IFS database connection:
    ifs_server_nm = r'S1FF500\SQLNLP'
    ifs_server_nm_ho = r'S1FF500\SQLNLP'
    ifs_database_nm = r'INSIGHTDEV_OAO_V2'
    ifs_database_nm_ho = r'INSIGHTDEV_HO_V2'
    ifs_database_uid = r'<username>'
    ifs_database_pw = r'<password>'

    # DMA connection:
    dma_pin = '<pin>'

    # DMA Links
    dma_document_retrieval = 'http://dma-dev-vendor-cnt.ba.ssa.gov/DMAeClient/DMADirect?action=save&subaction=noannotation&directuname=%s&docid=%s&responseVer=1&logoff=false'
    dma_logon = 'http://dma-dev-vendor-cnt.ba.ssa.gov/DMAeClient/DMADirect?action=logon&directuname=%s&responseVer=1'
    dma_logoff = 'http://dma-dev-vendor-cnt.ba.ssa.gov/DMAeClient/DMADirect?action=logoff&directuname=%s&responseVer=1'

    # Database connection:
    doors_cnxn_str = 'Driver={SQL Server};Server=ODAR-SQL-HQ-08.ba.ad.ssa.gov;Database=doors;'
    reftables_cnxn_str = 'Driver={SQL Server};Server=ODAR-SQL-HQ-08.ba.ad.ssa.gov;Database=reftables;'

    # MIDIB database connection:
    db2_server = 'DSNDSGD0'
    db2_server_pedib = 'DSNDSGD0'
    midib_hn = 'DSNDSGD0.SSATST1.SSPF.SSA.GOV'
    pedib_hn = 'DSNDSGD0.SSATST1.SSPF.SSA.GOV'
    midib_port = '33500'
    pedib_port = '33500'
    midib_uid = '<pin>'
    midib_pw = '<pwd>'

    # DOORS database connection:
    pdors_hn = 'prdedw.ba.ssa.gov'
    pdors_port = '5432'
    pdors_dbname = 'pedw'
    pdors_user = '<pin>'
    pdors_password = '<pin>'

    # schema and Tables
    pacar = 'MHAODST1.PACAR'
    mhaods_wrkunh = 'MHALX.WRKUNH'
    malcopy_wrkunh = 'MHALX.WRKUNH'
    mhaods_archwkut = 'MHAODST1.ARCHWKUT'
    mhaods_parcwkut = 'MHAODST1.PARCWKUT'
    mhaods_clminfo = 'MHALX.CLMINFO'
    mhaods_dispnh = 'MHALX.DISPNH'
    mhaods_hrgexp = 'MHALX.HRGEXP'
    mhaods_devlph = 'MHALX.DEVLPH'
    mhaods_optlexp = 'MHALX.OPTLEXP'
    medib_case = 'PEDIBZ1.CASE'
    medib_casedoc = 'PEDIBZ1.CASEDOC'