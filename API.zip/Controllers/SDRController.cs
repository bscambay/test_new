﻿using INSIGHT_Request;
using INSIGHT_Request.Models;
using INSIGHT_Request.Util;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace INSIGHT_Request.Controllers
{
    public class SDRController : ApiController
    {
        [HttpPost]
        [ActionName("Claimant")]
        public HttpResponseMessage GetSDRClaimantInformation([FromBody] ClaimantRequest rqst)
        {

            ClaimantRequest c = rqst;
            DataSet ds = new DataSet();
            //TEST SET
            //FLDR_NUM = 211659033
            //CASE_NUM = 226661346
            //
            ds = WWData.Allegations(c.folderNumber, c.caseNumber,ds);
            ds = WWData.Address(c.folderNumber, c.caseNumber, ds);
            ds = WWData.Claimant(c.folderNumber, c.caseNumber, ds);
            ds = WWData.Allegation(c.folderNumber, c.caseNumber, ds);
            Claimant cc = new Claimant();
            foreach (DataRow r in ds.Tables["CASE"].Rows)
            {


                cc.FLDR_NUM = int.Parse(c.folderNumber);
                cc.CASE_NUM = int.Parse(c.caseNumber);
                cc.FNM_UCASE = r["FNM_UCASE"].ToString();
                cc.MNM_UCASE = r["MNM_UCASE"].ToString();
                cc.LNM_UCASE = r["LNM_UCASE"].ToString();
                cc.SEX = r["SEX"].ToString();
                cc.DOB = r["DOB"].ToString();
                cc.COSSN = r["COSSN"].ToString();
                cc.HT_INCH = r["HT_INCH"].ToString();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString();
                cc.JURIS_OCD = r["JURIS_OCD"].ToString();
                cc.ADJULVL_CD = r["ADJULVL_CD"].ToString();
                cc.MOST_RCNT_FLG_DT = r["MOST_RCNT_FLG_DT"].ToString();
                cc.CASE_ESTB_DT = r["CASE_ESTB_DT"].ToString();

            }
            cc.ADDR = ConvertAddress(ds.Tables["CLNTADDR"]);
            cc.ALLGN_DESC = ConvertAllegations(ds.Tables["ALLGNTXT"]);

            foreach (DataRow r in ds.Tables["ALLGN"].Rows)
            {
                cc.AOD = r["AOD"].ToString().ToValueOrEmpty();
                cc.STOP_WRK_DATE = r["STOP_WRK_DT"].ToString().ToValueOrEmpty();
            }



            HttpResponseMessage response = new HttpResponseMessage();
            response = Request.CreateResponse(HttpStatusCode.OK,cc);
            return response;

        }
        public Claimant GetSDRClaimant(ClaimantRequest rqst)
        {
            ClaimantRequest c = rqst;
            DataSet ds = new DataSet();
            //TEST SET
            //FLDR_NUM = 211659033
            //CASE_NUM = 226661346
            //
            ds = WWData.Allegations(c.folderNumber, c.caseNumber, ds);
            ds = WWData.Address(c.folderNumber, c.caseNumber, ds);
            ds = WWData.Claimant(c.folderNumber, c.caseNumber, ds);
            ds = WWData.Allegation(c.folderNumber, c.caseNumber, ds);

            Claimant cc = new Claimant();
            foreach (DataRow r in ds.Tables["CASE"].Rows)
            {

                cc.FLDR_NUM = int.Parse(c.folderNumber);
                cc.CASE_NUM = int.Parse(c.caseNumber);
                cc.FNM_UCASE = r["FNM_UCASE"].ToString().ToValueOrEmpty();
                cc.MNM_UCASE = r["MNM_UCASE"].ToString().ToValueOrEmpty();
                cc.LNM_UCASE = r["LNM_UCASE"].ToString().ToValueOrEmpty();
                cc.SEX = r["SEX"].ToString().ToValueOrEmpty();
                cc.DOB = r["DOB"].ToString().ToShortDate();
                cc.COSSN = r["COSSN"].ToString().ToValueOrEmpty();
                cc.HT_INCH = r["HT_INCH"].ToString().ToValueOrEmpty();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString().ToValueOrEmpty();
                cc.JURIS_OCD = r["JURIS_OCD"].ToString().ToValueOrEmpty();
                cc.ADJULVL_CD = r["ADJULVL_CD"].ToString().ToValueOrEmpty();
                cc.MOST_RCNT_FLG_DT = r["MOST_RCNT_FLG_DT"].ToString().ToValueOrEmpty();
                cc.CASE_ESTB_DT = r["CASE_ESTB_DT"].ToString().ToValueOrEmpty();

            }
            cc.ADDR = ConvertAddress(ds.Tables["CLNTADDR"]);
            cc.ALLGN_DESC = ConvertAllegations(ds.Tables["ALLGNTXT"]);
            foreach (DataRow r in ds.Tables["ALLGN"].Rows)
            {
                cc.AOD = r["AOD"].ToString().ToValueOrEmpty();
                cc.STOP_WRK_DATE = r["STOP_WRK_DT"].ToString().ToValueOrEmpty();
            }
            return cc;
        }
        private string ConvertAddress(DataTable dt)
        {
            //Expecting format [STREET ADDRESS][4 SPACES][CITY][SPACE][2 DIGIT STATE][SPACE][5 DIGIT ZIP]
            string addr = "";
            if(dt.Rows.Count < 1)
            {
                return addr;
            }
            foreach(DataRow r in dt.Rows)
            {
                if (r["ADDR1"].ToString() != "") { addr += r["ADDR1"].ToString().Trim(); };
                if (r["ADDR2"].ToString() != "") { addr += " " + r["ADDR2"].ToString().Trim(); };
                if (r["ADDR3"].ToString() != "") { addr += " " + r["ADDR3"].ToString().Trim(); };
                if (r["ADDR4"].ToString() != "") { addr += " " + r["ADDR4"].ToString().Trim(); };
                if (r["CITY"].ToString() != "") { addr += "    " + r["CITY"].ToString().Trim(); };
                if (r["ST"].ToString() != "") { addr += "  " + r["ST"].ToString().Trim(); };
                if (r["ZIP5"].ToString() != "") { addr += " " + r["ZIP5"].ToString().Trim(); };
                //if (r["ZIP4"].ToString() != "") { addr += "-" + r["ZIP4"].ToString(); };
            }
            return addr;
        }
        private string ConvertAllegations(DataTable dt)
        {
            string allgtxt = "";
            if (dt.Rows.Count < 1)
            {
                return allgtxt;
            }
            foreach (DataRow r in dt.Rows)
            {
                if (r["ALLGN_DESC"].ToString().Trim() != "") { allgtxt += r["ALLGN_DESC"].ToString() + ";"; };
            }
            if(allgtxt.Length > 1) { allgtxt = allgtxt.Substring(0, allgtxt.Length - 1); }

            return allgtxt;
        }
    }
}
