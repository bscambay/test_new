import os
import time
import sys
import re
import unittest
import pytest
import requests
import logging
import datetime
from random import *
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.proxy import *

# Set directories:
#setup_config
unittest_dir = os.path.dirname(os.path.realpath(__file__))
test_dir = os.path.abspath(os.path.join(unittest_dir, os.pardir))
insightdir = os.path.abspath(os.path.join(test_dir, os.pardir))
datadir = os.path.join(insightdir, "Data")

# Import IFS module:
sys.path.insert(0, insightdir)


#pytest -v test_case_search.py::TestSSNSearch::test_ssn_sort
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_find
#pytest -v test_case_search.py::TestSSNSearch::test_ssn_filter


class TestCaseSearch(object):

    '''Setup test'''
    @classmethod
    def setup_class(self):
        print
        Proxy = "http://access.lb.ssa.gov:80"

        #webdriver.DesiredCapabilities.CHROME['proxy']={
        #   "httpProxy":Proxy,
        #    "ftpProxy":Proxy,
        #    "sslProxy":Proxy,
        #    "noProxy":"*.ssa.gov",
        #    "proxyType":"MANUAL",
        #    "autodetect":False
        #}
        #self.driver = driver = webdriver.Chrome("C:\\IEDriver\\chromedriver.exe")
        self.driver = webdriver.Remote(
        desired_capabilities=webdriver.DesiredCapabilities.CHROME,
        #desired_capabilities =webdriver.DesiredCapabilities.HTMLUNIT.copy(),
        command_executor='http://selenium-hub.labs.addev.ssa.gov:4444/wd/hub'
           
)


        #Instantiate webdriver IE browser
        #self.driver = webdriver.Ie("bin/IEDriverServer.exe")
        #Navigate to Insight Web app
        self.url = "http://s1ff531.ba.ad.ssa.gov:8189/search_results/"
        self.Hearingurl = "http://s1ff532.ba.ad.ssa.gov:8189/draftanalysis/1"
        #self.user_id = "027763"
        #Wait for a certain amount time before throwing an exception if page is not found.
        self.wait = WebDriverWait(self.driver, 10)

    def test_url(self):
        url = self.Hearingurl
        #"http://s1ff531.ba.ad.ssa.gov:8189/search_results/ssn"
        assert url
         
    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_sort(self):
        '''Test sort function for case search tool'''
        driver = self.driver
        driver.get(self.url)
        index = 1
        rowElements = driver.find_elements_by_xpath("//th[contains(@class, 'header')]")
        index = 1
        for ele in rowElements: 
            if index == 1: 
                print index, ele.text
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
                assert sorted(data) == data
            elif index > 1:
                print index, ele.text  
                ele.click()   
                data = [str(item.text).strip() for item in \
                        driver.find_elements_by_xpath("//td["+str(index)+"]")[:10]]
            
                date_pattern = re.match("(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$", data[0].split()[0].strip())
                if date_pattern != None:
                    data = [item.split()[0] for item in data]
                    assert sorted(data, key=lambda x: datetime.datetime.strptime(x, '%m/%d/%Y')) \
                        ==  [item.split()[0] for item in data]
                else:
                    assert sorted(data) == data
            index = index + 1
            data = []
            time.sleep(1)

    #pytest.mark.skip(reason="Not needed!")
    def test_ssn_find(self):
        '''Test find function for case search tool'''
        driver = self.driver
        driver.get(self.url)
        ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        print "SSN List FIND" + str(len(ssn_list))
        #sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], 3)]
        sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], len(ssn_list))]
       
        for ssn in sample_ssn_list:
            driver.find_element_by_name('ssn_search').send_keys(ssn)
            wait = WebDriverWait(driver, 10)
            confirm = wait.until(EC.element_to_be_clickable((By.ID, "ssn_find")))
            confirm.click()
            #driver.find_element_by_id('ssn_find').click()
            time.sleep(1)
            driver.find_element_by_name('ssn_search').clear()
            #driver.find_element_by_id('ssn_find').click()
            wait = WebDriverWait(driver, 10)
            confirm = wait.until(EC.element_to_be_clickable((By.NAME, "ssn_search")))
            confirm.click()
          
        time.sleep(3)
    #@pytest.mark.skip(reason="Not needed!")
    def test_ssn_filter(self):
        '''Test filter function for case search tool'''
        driver = self.driver
        driver.get(self.url)
        print self.url
        time.sleep(4)       
        #ssn_list = driver.find_elements_by_xpath("//td[@class='ssn_results_column']")
        ssn_list = driver.find_elements_by_xpath("//table/tbody/tr/td[contains(@class, 'ssn_results_column')]")
        print "SSN List" + str(len(ssn_list))
        #sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], 3)]
        sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], len(ssn_list))]
        print sample_ssn_list
        time.sleep(4)
        ssn_filter = driver.execute_script("document.getElementById('ssnFilter')")
        #driver.find_element_by_id("ssnFilter")
        
        for item in sample_ssn_list:
            #sample_ssn_list = [str(item.text) for item in sample(ssn_list[:10], len(ssn_list))]
            #ssn_filter.send_keys(item[:4])
            print item
            #ssn_filter = driver.execute_script("document.getElementById('ssnFilter')")
            ele = driver.find_element_by_xpath(".//*[@id='ssnFilter']")
            ele.send_keys(item[:4])
            #driver.find_element_by_name('ssnFilter').send_keys(item)
            #driver.execute_script.send_keys(item[:4])
            time.sleep(1)
            ele.clear()
            #ssn_filter.clear() 

    def test_url(self):
        driver = self.driver
        driver.get(self.url)
        #url= self.OAO_url
        assert self.url 
        #self.OAO_url
        #time.sleep(2)
        #self.driver.close()
        #self.OAO_url
   
        #time.sleep(5)
    def tearDown(self):
        '''Tear Down test'''
        self.driver.close()

def suite():
    suite = unittest.TestSuite()
    suite.addTest(TestCaseSearch('test_ssn_sort'))    
    suite.addTest(TestCaseSearch('test_ssn_find'))
    suite.addTest(TestCaseSearch('test_ssn_filter'))
    return suite


if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite())
   
