# INSIGHT FULL SUITE - BATCH PROCESSOR - DOCU_CTL_ID PARSER
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 01.10.2017
#
# SUMMARY: 
# Attempt to locate a single relevant DOCU_CTL_ID value for a given input
# FLDR_NUM value.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
#=============================================================================

# Import modules:
import sys
import os.path
import operator
import datetime
import logging
import ibm_db
import pandas
import config as cfg
import date_helper as dh

# Import config_sec:
# secdir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../../sec"))
# sys.path.insert(0, secdir)
import config_sec as cfg_sec

# Disable Pandas chained assignment warning (raising too many false positives):
pandas.options.mode.chained_assignment = None

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Batch DOCU_CTL_ID retrieval function:
def retrieve_docu_ctl_id_via_efldr_num_batch(efldr_num_fnl_dspn_dt_tuplist):
    '''Attempt to identify the DOCU_CTL_ID of the hearing
    decision TIF file most likely associated with a targeted case via its
    EFLDR_NUM and FNL_DSPN_DT.

    Args:
        efldr_num_fnl_dspn_dt_tuplist {list}: A list of tuples, each containing
            two values:
        (1) efldr_num_input {str}: A single structured EFLDR_NUM value for a targeted
            case.
        (2) fnl_dspn_dt_input {str}: A final disposition date value, formatted as
            MM/DD/YYYY (##/##/####), as parsed from a structured
            FNL_DSPN_DT value for a targeted case.
    Returns:
        batchresdict {dictionary}: A dictionary where each key = an EFLDR_NUM
            value passed and each value = a tuple containing two values:
        (1) A single DOCU_CTL_ID string or 'E' (an exception occurred
            when parsing the DOCU_CTL_ID or a DOCU_CTL_ID could not be
            located).
        (2) A 'complex_docu_ctl_id_parsing_ver' value of '0' {str} for
            'not complex' or '1' {str} for 'complex'.  Used elsewhere to
            determine whether to perform additional verification that the
            text associated with the DOCU_CTL_ID value returned in fact
            is for the targeted case.
    Raises:
        N/A. If exception occurs, empty dictionary returned.'''
    try:
        batchresdict = {}

        # Retrieve target data from MIDIB.CASEDOC:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        efldr_num_list = [tup[0] for tup in efldr_num_fnl_dspn_dt_tuplist]
        temp_fldr_num_list = [efldr_num_list[i:i + 500] for i in xrange(0, len(efldr_num_list), 500)]
        efldr_reslist = []
        for hl in temp_fldr_num_list:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (cfg_sec.db2_server_pedib, cfg_sec.pedib_hn, cfg_sec.pedib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            sql = "SELECT FLDR_NUM, DOCU_CTL_ID, DMA_RCPT_TS, DCN_DT FROM %s WHERE FLDR_NUM IN (%s) AND " \
                  "DOCU_CD='3110' AND MDF_CD='A'" % (cfg_sec.medib_casedoc, ', '.join([str(int(h)) for h in hl]))
            stmt = ibm_db.exec_immediate(conn, sql)

            resultlist = []
            while stmt:
                # TIP: 'fetch_assoc' returns a dictionary:
                result = ibm_db.fetch_assoc(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)

            ibm_db.close(conn)
            del stmt

            # Output result into DataFrame:
            resdf = pandas.DataFrame(resultlist)
            efldr_reslist.append(resdf)

        efldrdf = pandas.concat(efldr_reslist)

        # Return if efldrdf is empty
        if len(efldrdf) == 0:
            return batchresdict

        efldrdf['DMA_RCPT_TS'] = efldrdf['DMA_RCPT_TS'].map(lambda x: x.date())

        # Iterate through EFLDR_NUM inputs to retrieve appropriate DOCU_CTL_ID:
        for t in efldr_num_fnl_dspn_dt_tuplist:

            efldrdfslice = efldrdf.loc[efldrdf['FLDR_NUM'] == t[0]]

            # If 0 results, return 'E':
            if len(efldrdfslice) == 0:
                batchresdict[t[0]] = ('E', 'E')

            # If only 1 result, take that DOCU_CTL_ID:
            elif len(efldrdfslice) == 1:
                resdecid = efldrdfslice.iloc[0]['DOCU_CTL_ID']
                batchresdict[t[0]] = (resdecid, '0')

            else:
                fnl_dspn_dt_input = t[1]
                if fnl_dspn_dt_input is not None and fnl_dspn_dt_input not in ['U', 'P', 'E', '']:

                    fnl_dspn_dt_input_dt = dh.parse_date_todatetime_struct(fnl_dspn_dt_input)
                    if isinstance(fnl_dspn_dt_input_dt, datetime.datetime):
                        fnl_dspn_dt_input_dt_date = fnl_dspn_dt_input_dt.date()

                        # ID obs with smallest delta between DMA upload date and disposition date:
                        dspn_dma_td_dict = {}
                        for i, row in efldrdfslice.iterrows():
                            dma_rcpt_ts = row['DMA_RCPT_TS']
                            td = abs((dma_rcpt_ts - fnl_dspn_dt_input_dt_date).total_seconds())
                            dspn_dma_td_dict[row['DOCU_CTL_ID']] = td
                        dspn_dma_td_smallest = min(dspn_dma_td_dict.iteritems(), key=operator.itemgetter(1))[0]

                        # ID obs with most recent DMA upload date:
                        rcpt_dt_dict = {}
                        for i, row in efldrdfslice.iterrows():
                            rcpt_dt_dict[row['DOCU_CTL_ID']] = row['DMA_RCPT_TS']
                        most_recent_docu_ctl_id = max(rcpt_dt_dict.iteritems(), key=operator.itemgetter(1))[0]

                        # If same obs, proceed to parse this target obs:
                        if most_recent_docu_ctl_id == dspn_dma_td_smallest:

                            # If no decision date value, take target obs anyway:
                            # TIP: Model for retrieval of specific item via .loc():
                            efldrdftgt_dcndt = efldrdf.loc[efldrdf['DOCU_CTL_ID'] == most_recent_docu_ctl_id]['DCN_DT'].item()
                            if efldrdftgt_dcndt is None:
                                batchresdict[t[0]] = (most_recent_docu_ctl_id, '1')

                            # If decision date value, take only if within 30 days of FNL_DSPN_DT:
                            # TIP: 30 day window is based on anecdotal SME observations.
                            else:
                                if isinstance(efldrdftgt_dcndt, datetime.datetime):
                                    efldrdftgt_dcndt = efldrdftgt_dcndt.date()
                                month_secs = datetime.timedelta(days=30).total_seconds()
                                dcn_dspn_td_secs = abs((efldrdftgt_dcndt - fnl_dspn_dt_input_dt_date).total_seconds())
                                if dcn_dspn_td_secs <= month_secs:
                                    batchresdict[t[0]] = (most_recent_docu_ctl_id, '0')
                                else:
                                    batchresdict[t[0]] = (most_recent_docu_ctl_id, '1')
                        else:
                            batchresdict[t[0]] = ('E', 'E')
                    else:
                        batchresdict[t[0]] = ('E', 'E')
                else:
                    batchresdict[t[0]] = ('E', 'E')

        # Return results:
        return batchresdict
    except Exception as ex:
        logger.exception('EXCEPTION: '+str(ex))
        return {}