# INSIGHT FULL SUITE -  OAO ETL/BATCH PROCESSING - STRUCTURED DATA
# RETRIEVAL
#
# AUTHOR: 
# Kurt Glaze
# U.S. Social Security Administration
# Office of Appellate Operations
# Division of Quality, Br. 9 / Gerald Ray Academy
#
# DATE LAST UPDATED:
# 10.25.2017
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has 
# not yet been formally validated and whose documentation is not yet fully 
# formed.
# =============================================================================

# Import modules:
import sys
import datetime
import os.path
import logging
import random
import ibm_db
import pandas
import numpy as np
import config as cfg
import date_helper as dh
import batch_decid_parser
import database_actions as ifsda
import database_actions_misc as dam
import database_actions_batch as ifsdab

# Import config_sec:
import config_sec as cfg_sec

# Disable Pandas chained assignment warning (raising too many false positives):
pandas.options.mode.chained_assignment = None

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")

# Set up child logger:
logger_name = 'ifs.%s' % __name__
logger = logging.getLogger(logger_name)


# Normalize database-derived dates contained in a
# Pandas DataFrame by column from Datetime or Timestamp
# objects into IFS-formatted date strings:
# TIP: Each date will either equal an IFS-formatted
# date string or 'E'.
def normalize_dates(input_df):
    for cn in input_df:
        cn_dtype = input_df[cn].dtype
        if cn_dtype == 'datetime64[ns]':
            input_df[cn] = [d.strftime('%m/%d/%Y') if not pandas.isnull(d) else 'E' for d in input_df[cn]]
    return input_df


# Retrieve select structured data in support of IFS OAO operations (schema 2):
def retrieve_oao_struct_case_ent_schema2():
    """Retrieve structured data value in support of the INSIGHT
	OAO ETL process (schema 2).
	
	WARNING: Pandas automatically converts integer columns containing NaN values
	to float64, as integer data types cannot represent NaN values.  This means
	that columns like 'REP_UID' that naturally contain NaN are converted to
	float values (e.g. '.0' added).  This means any attempt to convert these
	columns (e.g. 'testdf['REP_UID'] = testdf['REP_UID'].astype(np.int64)')
	will fail.  The result of this is that any integer structured data value
	with NaN values will be converted to and stored as a float value in INSIGHT
	databases.  Remember that when parsing INSIGHT data.
	
	Args:
		N/A
	Returns:
		A tuple where:
		- tup[0] = A Pandas dataframe containing OAO case entity structured data.
		- tup[1] = A Pandas dataframe containing 'expert' structured data associated
		with the 'HOFC_WRK_UNIT_UID' values in tup[0].
	Raises:
		N/A"""
    try:

        # Retrieve all PACAR observations in ANWK status:
        db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
        cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
        conn = ibm_db.connect(db_cnxn_str, "", "")
        col_names = ['HOFC_WRK_UNIT_UID', 'CLMT_SSN', 'CRNT_RQSTD_DT', 'HRG_TYP', 'WKLD_TYP', 'CLM_TYP', 'WG_ERNR_SSN',
                     'CRITL_CASE_CTGY_SW', 'CLMT_DECD_SW', 'DIRE_NEED_SW', 'PTNTLY_HOMCDL_SW', 'SUICIDL_SW', 'TERI_SW']

        sql = "SELECT HOFC_WRK_UNIT_UID, CLMT_SSN, CRNT_RQSTD_DT, HRG_TYP, WKLD_TYP, CLM_TYP, WG_ERNR_SSN, " \
              "CRITL_CASE_CTGY_SW, CLMT_DECD_SW, DIRE_NEED_SW, PTNTLY_HOMCDL_SW, SUICIDL_SW, TERI_SW FROM %s WHERE " \
              "RQST_STUS_CD IN ('SCRN', 'ANWK', 'ARRC')" % (cfg_sec.pacar)

        stmt = ibm_db.exec_immediate(conn, sql)
        resultlist = []
        while stmt:
            result = ibm_db.fetch_tuple(stmt)
            if result is False:
                break
            else:
                resultlist.append(result)
        ibm_db.close(conn)
        del stmt
        resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
        pacardf = pandas.DataFrame(resdictlist)

        # Filter to only those PACAR.HOFC_WRK_UNIT_UID not already in INSIGHT DB:
        hofclist = ifsda.retrieve_column_values('struct_oao', 'hofc_wrk_unit_AC')
        hofclist = [int(h) for h in hofclist]
        pacardf = pacardf.loc[~pacardf.HOFC_WRK_UNIT_UID.isin(hofclist)]
        logger.critical('pacardf after removal of existing values: ')
        logger.critical(str(len(pacardf)))

        # Filter to only those failed PACAR.HOFC_WRK_UNIT_UID:
        if cfg.batch_filter_failed_struct_oao:
            hofclistfailed = ifsda.retrieve_column_values('failed_struct_oao', 'hofc_wrk_unit_AC')
            hofclistfailed = [int(h) for h in hofclistfailed]
            pacardf = pacardf.loc[~pacardf.HOFC_WRK_UNIT_UID.isin(hofclistfailed)]
            logger.critical('pacardf after removal of failed values: ')
            logger.critical(str(len(pacardf)))

        # Convert CRNT_RQSTD_DT type:
        pacardf['CRNT_RQSTD_DT'] = pacardf['CRNT_RQSTD_DT'].apply(pandas.to_datetime)

        # Retrieve all 'EFLDR_NUM' values from DART.WRKUNH:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        pacardf_hofclist = pacardf['HOFC_WRK_UNIT_UID'].tolist()
        pacardf_hofc_lists = [pacardf_hofclist[i:i + 500] for i in xrange(0, len(pacardf_hofclist), 500)]
        wrkunhdf_reslist = []
        for hl in pacardf_hofc_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'EFLDR_NUM']
            sql = "SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM FROM %s WHERE HOFC_WRK_UNIT_UID IN (%s)" % \
                  (cfg_sec.mhaods_wrkunh, ", ".join([str(int(h)) for h in hl]))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            wrkunhdf_reslist.append(resdf)
        wrkunhdf = pandas.concat(wrkunhdf_reslist)

        # Merge, then remove any 'NaN' EFLDR_NUM observations (supporting
        # electronic cases only for now):
        mergedf = pandas.merge(pacardf, wrkunhdf, how='inner', on='HOFC_WRK_UNIT_UID')
        mergedf = mergedf.loc[mergedf['EFLDR_NUM'].notnull()]
        mergedf['EFLDR_NUM'] = mergedf['EFLDR_NUM'].astype(np.int64)
        logger.critical('mergedf after removal of NaN EFLDR_NUM values: ')
        logger.critical(str(len(mergedf)))

        # Copy/rename HOFC namespace to avoid collision with HO-level HOFC
        # namespace, then drop original:
        mergedf['hofc_wrk_unit_AC'] = mergedf['HOFC_WRK_UNIT_UID']
        mergedf.drop('HOFC_WRK_UNIT_UID', axis=1, inplace=True)
        mergedf['wg_ernr_ssn_AC'] = mergedf['WG_ERNR_SSN']
        mergedf.drop('WG_ERNR_SSN', axis=1, inplace=True)

        # Retrieve all HOFC_WRK_UNIT_UID values associated with the EFLDR_NUM values:
        db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
        cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
        conn = ibm_db.connect(db_cnxn_str, "", "")
        col_names = ['HOFC_WRK_UNIT_UID', 'EFLDR_NUM']
        sql = "SELECT HOFC_WRK_UNIT_UID, EFLDR_NUM FROM %s WHERE EFLDR_NUM IN (%s)" % \
              (cfg_sec.malcopy_wrkunh, ", ".join([str(int(h)) for h in mergedf['EFLDR_NUM'].tolist()]))
        stmt = ibm_db.exec_immediate(conn, sql)
        resultlist = []
        while stmt:
            result = ibm_db.fetch_tuple(stmt)
            if result is False:
                break
            else:
                resultlist.append(result)
        ibm_db.close(conn)
        del stmt
        resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
        wrkunhdf2 = pandas.DataFrame(resdictlist)

        # Retrieve all ARCHWKUT data associated with the HOFC_WRK_UNIT_UID values:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        wrkunhdf2_hofclist = wrkunhdf2['HOFC_WRK_UNIT_UID'].tolist()
        wrkunhdf2_hofc_lists = [wrkunhdf2_hofclist[i:i + 500] for i in xrange(0, len(wrkunhdf2_hofclist), 500)]
        archwkutdf_reslist = []
        for hl in wrkunhdf2_hofc_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'HRG_TYP', 'CLM_TYP', 'CLM_UID', 'CASE_GRP_CD', 'CLMT_NM25', 'CLMT_ST',
                         'CLMT_DOB', 'REP_UID', 'TRML_ILLNESS_SW', 'FNL_DSPN_DT', 'T2_DSPN_CD', 'T16_DSPN_CD',
                         'T2_PRTL_FFVRBL_CD', 'T16_PRTL_FFVRBL_CD', 'BIC', 'WG_ERNR_SSN', 'HRG_ISU_CD', 'EDIB_CD',
                         'OHA_DAA_CD']
            sql = "SELECT HOFC_WRK_UNIT_UID, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, " \
                  "REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, " \
                  "T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD FROM %s WHERE " \
                  "HOFC_WRK_UNIT_UID IN (%s)" % \
                  (cfg_sec.mhaods_archwkut, ", ".join([str(int(h)) for h in hl]))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            archwkutdf_reslist.append(resdf)

        archwkutdf = pandas.concat(archwkutdf_reslist)
        archwkutdf[['CLMT_DOB', 'FNL_DSPN_DT']] = archwkutdf[['CLMT_DOB', 'FNL_DSPN_DT']].apply(pandas.to_datetime)
        logger.critical('archwkutdf len: ')
        logger.critical(str(len(archwkutdf)))

        # For any HOFC_WRK_UNIT_UID not found in ARCHWKUT, try PARCWKUT:
        # TIP: Recently issued cases may not immediately post to ARCHWKUT, so we must
        # consult PARCWKUT.  This happens often in URR cases.
        hofc_nonmatch_list = list(set([str(int(h)) for h in wrkunhdf2['HOFC_WRK_UNIT_UID'].tolist()]) - set(
            [str(int(h)) for h in archwkutdf.HOFC_WRK_UNIT_UID.tolist()]) - set(
            [str(int(h)) for h in mergedf.hofc_wrk_unit_AC.tolist()]))
        logger.critical('HOFC_NONMATCH_LIST LEN:')
        logger.critical(len(hofc_nonmatch_list))

        # There should be an if statement here in the case hofc_nonmatch_list is empty
        if len(hofc_nonmatch_list) != 0:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'HRG_TYP', 'CLM_TYP', 'CLM_UID', 'CASE_GRP_CD', 'CLMT_NM25', 'CLMT_ST',
                         'CLMT_DOB', 'REP_UID', 'TRML_ILLNESS_SW', 'FNL_DSPN_DT', 'T2_DSPN_CD', 'T16_DSPN_CD',
                         'T2_PRTL_FFVRBL_CD', 'T16_PRTL_FFVRBL_CD', 'BIC', 'WG_ERNR_SSN', 'HRG_ISU_CD', 'EDIB_CD',
                         'OHA_DAA_CD']
            sql = "SELECT HOFC_WRK_UNIT_UID, HRG_TYP, CLM_TYP, CLM_UID, CASE_GRP_CD, CLMT_NM25, CLMT_ST, CLMT_DOB, " \
                  "REP_UID, TRML_ILLNESS_SW, FNL_DSPN_DT, T2_DSPN_CD, T16_DSPN_CD, T2_PRTL_FFVRBL_CD, " \
                  "T16_PRTL_FFVRBL_CD, BIC, WG_ERNR_SSN, HRG_ISU_CD, EDIB_CD, OHA_DAA_CD FROM %s WHERE " \
                  "HOFC_WRK_UNIT_UID IN (%s)" % (cfg_sec.mhaods_parcwkut, ", ".join(
                hofc_nonmatch_list))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            parcwkutdf = pandas.DataFrame(resdictlist)

        # Merge EFLDR_NUM values into archwkutdf/parcwkutdf
        archwkutdf = pandas.merge(archwkutdf, wrkunhdf2, how='inner', on='HOFC_WRK_UNIT_UID')
        # If parcwkut results, merge in WRKUNH data, then concatenate to ARCHWKUT data:
        wkutdf_concat = archwkutdf
        if len(hofc_nonmatch_list) != 0:
            if len(parcwkutdf) != 0:
                parcwkutdf = pandas.merge(parcwkutdf, wrkunhdf2, how='inner', on='HOFC_WRK_UNIT_UID')
                wkutdf_concat = pandas.concat([archwkutdf, parcwkutdf])

        # Merge in ARCHWKUT data:
        mergedf = pandas.merge(mergedf, wkutdf_concat, how='inner', on=['EFLDR_NUM', 'HRG_TYP', 'CLM_TYP'])
        logger.critical('mergedf after wkutdf_concat inner merge: ')
        logger.critical(str(len(mergedf)))

        # Remove T2-related post-merge duplicate data by filtering to only rows where wage earner SSN values are
        # equal (or where one of the wage earner SSN values are empty and thus no comparison can occur):
        # TIP: Example of this issue is CLMT_SSN ###-##-8502.
        mergedf = mergedf[
            (mergedf['wg_ernr_ssn_AC'] == mergedf['WG_ERNR_SSN']) | (mergedf['wg_ernr_ssn_AC'] == '         ') | (
            mergedf['WG_ERNR_SSN'] == '         ')]
        logger.critical('mergedf after wage earner filter: ')
        logger.critical(str(len(mergedf)))

        # Retrieve from CLMINFO using CLM_UID:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        mergedf_clmuidlist = mergedf['CLM_UID'].tolist()
        mergedf_clmuid_lists = [mergedf_clmuidlist[i:i + 500] for i in xrange(0, len(mergedf_clmuidlist), 500)]
        clminfodf_reslist = []
        for hl in mergedf_clmuid_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['CLM_UID', 'T2_APP_DT', 'T16_APP_DT', 'T2_PFLG_DT', 'T16_PFLG_DT', 'DLI', 'ALLGD_DISB_ONST_DT']
            sql = "SELECT CLM_UID, T2_APP_DT, T16_APP_DT, T2_PFLG_DT, T16_PFLG_DT, DLI, ALLGD_DISB_ONST_DT FROM " \
                  "%s WHERE CLM_UID IN (%s)" % (cfg_sec.mhaods_clminfo, ", ".join(list(set([str(int(h)) for h in hl]))))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            clminfodf_reslist.append(resdf)

        clminfodf = pandas.concat(clminfodf_reslist)
        clminfodf[['T2_APP_DT', 'T16_APP_DT', 'T2_PFLG_DT', 'T16_PFLG_DT', 'DLI', 'ALLGD_DISB_ONST_DT']] = clminfodf[
            ['T2_APP_DT', 'T16_APP_DT', 'T2_PFLG_DT', 'T16_PFLG_DT', 'DLI', 'ALLGD_DISB_ONST_DT']].apply(
            pandas.to_datetime)

        # Merge in CLMINFO data:
        mergedf = pandas.merge(mergedf, clminfodf, on='CLM_UID', how='inner')

        # Retrieve from DISPNH using HOFC_WRK_UNIT_UID:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        mergedf_hofclist = mergedf['HOFC_WRK_UNIT_UID'].tolist()
        mergedf_hofc_lists = [mergedf_hofclist[i:i + 500] for i in xrange(0, len(mergedf_hofclist), 500)]
        dispnhdf_reslist = []
        for hl in mergedf_hofc_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'T2_GLBL_BSS_UID_1', 'T2_GLBL_BSS_UID_2', 'T16_GLBL_BSS_UID_1',
                         'T16_GLBL_BSS_UID_2']
            sql = "SELECT HOFC_WRK_UNIT_UID, T2_GLBL_BSS_UID_1, T2_GLBL_BSS_UID_2, T16_GLBL_BSS_UID_1, " \
                  "T16_GLBL_BSS_UID_2 FROM %s WHERE HOFC_WRK_UNIT_UID IN (%s)" % (cfg_sec.mhaods_dispnh, ", ".join([str(v) for v in hl]))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            dispnhdf_reslist.append(resdf)
        dispnhdf = pandas.concat(dispnhdf_reslist)

        # Merge in DISPNH data:
        # TIP: Every OAO-derived entity should have these values.
        # An 'inner' merge is therefore appropriate.
        mergedf = pandas.merge(mergedf, dispnhdf, on='HOFC_WRK_UNIT_UID', how='inner')
        logger.critical('mergedf after DISPNH inner merge: ')
        logger.critical(str(len(mergedf)))

        # Retrieve HEDULVL_CD from MEDIB.CASE:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        mergedf_efldrlist = mergedf['EFLDR_NUM'].tolist()
        mergedf_efldr_lists = [mergedf_efldrlist[i:i + 500] for i in xrange(0, len(mergedf_efldrlist), 500)]
        casedf_reslist = []
        for hl in mergedf_efldr_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server_pedib, cfg_sec.pedib_hn, cfg_sec.pedib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['FLDR_NUM', 'HEDULVL_CD']
            sql = "SELECT FLDR_NUM, HEDULVL_CD FROM %s WHERE FLDR_NUM IN (%s)" % \
                  (cfg_sec.medib_case, ", ".join(list(set([str(int(h)) for h in hl]))))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            casedf_reslist.append(resdf)
        casedf = pandas.concat(casedf_reslist)

        # Filter out null HEDULVL_CD values:
        casedf = casedf.loc[casedf['HEDULVL_CD'].notnull()]

        # Merge in CASE data:
        # TIP: Not every entity will have an HEDULVL_CD value (e.g. young children).
        # A 'left' merge is therefore appropriate.
        mergedf = pandas.merge(mergedf, casedf, how='left', left_on='EFLDR_NUM', right_on='FLDR_NUM')
        mergedf.drop('FLDR_NUM', axis=1, inplace=True)

        # Retrieve all 'expert' data into a single dataframe:
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        mergedf_hofclist = mergedf['HOFC_WRK_UNIT_UID'].tolist()
        mergedf_hofc_lists = [mergedf_hofclist[i:i + 500] for i in xrange(0, len(mergedf_hofclist), 500)]
        hrgexpdf_reslist = []
        for hl in mergedf_hofc_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'EXPERT_UID', 'SCHD_SW', 'ATTNDD_SW', 'MED_SPCLY_CD', 'INSRT_TS']
            sql = "SELECT HOFC_WRK_UNIT_UID, EXPERT_UID, SCHD_SW, ATTNDD_SW, MED_SPCLY_CD, INSRT_TS FROM " \
                  "%s WHERE HOFC_WRK_UNIT_UID IN (%s)" % \
                  (cfg_sec.mhaods_hrgexp, ", ".join(list(set([str(int(h)) for h in hl]))))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            hrgexpdf_reslist.append(resdf)
        hrgexpdf = pandas.concat(hrgexpdf_reslist)

        # TIP: DEVLPH observations that are medical experts carry
        # a 'DEV_SRC_CD' value of 'M'.
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        mergedf_hofclist = mergedf['HOFC_WRK_UNIT_UID'].tolist()
        mergedf_hofc_lists = [mergedf_hofclist[i:i + 500] for i in xrange(0, len(mergedf_hofclist), 500)]
        devlphdf_reslist = []
        for hl in mergedf_hofc_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['HOFC_WRK_UNIT_UID', 'EXPERT_UID', 'INSRT_TS', 'ACKT_RCVDT', 'DEV_SRC_CD']
            sql = "SELECT HOFC_WRK_UNIT_UID, EXPERT_UID, INSRT_TS, ACKT_RCVDT, DEV_SRC_CD FROM %s " \
                  "WHERE HOFC_WRK_UNIT_UID IN (%s)" % (cfg_sec.mhaods_devlph, ", ".join( list(set([str(int(h)) for h in hl]))))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            devlphdf_reslist.append(resdf)
        devlphdf = pandas.concat(devlphdf_reslist)

        # Concatenate:
        expdf = pandas.concat([hrgexpdf, devlphdf], axis=0)
        expdf_nonnull = expdf.loc[expdf['EXPERT_UID'].notnull()]

        # Retrieve associated OPTLEX data:
        # TIP: OPLTEXP observations that are medical experts carry
        # a 'EXPERT_TYP' value of 'M'.
        # TIP: To avoid SQL 101 error, limiting individual retrieval to 500 parameters:
        expdf_nonnull_list = expdf_nonnull['EXPERT_UID'].tolist()
        expdf_nonnull_lists = [expdf_nonnull_list[i:i + 500] for i in xrange(0, len(expdf_nonnull_list), 500)]
        optlexpdf_reslist = []
        for hl in expdf_nonnull_lists:
            db_cnxn_str = "DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;" % (
            cfg_sec.db2_server, cfg_sec.midib_hn, cfg_sec.midib_port, cfg_sec.midib_uid, cfg_sec.midib_pw)
            conn = ibm_db.connect(db_cnxn_str, "", "")
            col_names = ['EXPERT_UID', 'EXPERT_TYP', 'TITLE', 'FNM', 'MNM', 'LNM', 'SFX']
            sql = "SELECT EXPERT_UID, EXPERT_TYP, TITLE, FNM, MNM, LNM, SFX FROM %s WHERE EXPERT_UID IN (%s)" % \
                  (cfg_sec.mhaods_optlexp, ", ".join(list(set([str(x) for x in hl if x]))))
            stmt = ibm_db.exec_immediate(conn, sql)
            resultlist = []
            while stmt:
                result = ibm_db.fetch_tuple(stmt)
                if result is False:
                    break
                else:
                    resultlist.append(result)
            ibm_db.close(conn)
            del stmt
            resdictlist = [dict(zip(col_names, indivres)) for indivres in resultlist]
            resdf = pandas.DataFrame(resdictlist)
            optlexpdf_reslist.append(resdf)
        optlexpdf = pandas.concat(optlexpdf_reslist)

        # Merge in OPTLEX values any time there's a match:
        expdfmerged = pandas.merge(expdf, optlexpdf, on='EXPERT_UID', how='left')

        # Retrieve & merge in height/weight/sex data from MIDIB.CASE:
        # TIP: Not every entity will have height/weight values.
        # A 'left' merge is therefore appropriate.
        input_efldr_num_list = list(set(mergedf['EFLDR_NUM'].tolist()))
        htwtsex_df = dam.retrieve_htwt_casedata(input_efldr_num_list)
        mergedf = pandas.merge(mergedf, htwtsex_df, on='EFLDR_NUM', how='left')
        logger.critical('mergedf FINALr: ')
        logger.critical(str(len(mergedf)))

        # Apply INSIGHT-centric filters to exclude non-covered case/decision types:
        # TIP (06092017): After comparison with mirroring code run by RK, we have determined
        # that our filtering outcomes are highly similar and thus reliable.
        def gen_noncovered_ver(row):
            """Returns verdict value of 1 for any case whose data indicates
			it is not presently covered by INSIGHT (dual-sequential evaluation
			decisions, dismissals, non-electronic, etc.)."""
            if row['T2_PRTL_FFVRBL_CD'].strip() not in ['F', '']:
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['T2_PRTL_FFVRBL_CD'].strip() not in ['F', '']:")
                # logger.critical(str(row['T2_PRTL_FFVRBL_CD']))
                return 1
            if row['T16_PRTL_FFVRBL_CD'].strip() not in ['F', '']:
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['T16_PRTL_FFVRBL_CD'].strip() not in ['F', '']:")
                # logger.critical(str(row['T16_PRTL_FFVRBL_CD']))
                return 2
            if row['CASE_GRP_CD'] == '01' and row['T16_DSPN_CD'].endswith('DI'):
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['CASE_GRP_CD'] == '01' and row['T16_DSPN_CD'].endswith('DI')")
                return 3
            if row['CASE_GRP_CD'] == '02' and row['T2_DSPN_CD'].endswith('DI'):
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['CASE_GRP_CD'] == '02' and row['T2_DSPN_CD'].endswith('DI')")
                return 4
            if row['CASE_GRP_CD'] == '03' and row['T16_DSPN_CD'].endswith('DI') and row['T2_DSPN_CD'].endswith('DI'):
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['CASE_GRP_CD'] == '03' and row['T16_DSPN_CD'].endswith('DI') and row['T2_DSPN_CD'].endswith('DI')")
                return 5
            if row['HRG_ISU_CD'] != 'D':
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['HRG_ISU_CD'] != 'D'")
                # logger.critical(row['HRG_ISU_CD'])
                return 6
            if row['EDIB_CD'] != 'F':
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['EDIB_CD'] != 'F'")
                # logger.critical(row['EDIB_CD'])
                return 7
            if row['T2_GLBL_BSS_UID_1'] in [125.0, 126.0, 127.0, 128.0, 368.0, 369.0, 463.0, 526.0, 129.0, 130.0, 131.0,
                                            370.0, 527.0, 580.0]:
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['T2_GLBL_BSS_UID_1'] in [125.0, 126.0, 127.0, 128.0, 368.0, 369.0, 463.0, 526.0, 129.0, 130.0, 131.0, 370.0, 527.0, 580.0]")
                # logger.critical(row['T2_GLBL_BSS_UID_1'])
                return 8
            if row['T2_GLBL_BSS_UID_2'] in [125.0, 126.0, 127.0, 128.0, 368.0, 369.0, 463.0, 526.0, 129.0, 130.0, 131.0,
                                            370.0, 527.0, 580.0]:
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['T2_GLBL_BSS_UID_2'] in [125.0, 126.0, 127.0, 128.0, 368.0, 369.0, 463.0, 526.0, 129.0, 130.0, 131.0, 370.0, 527.0, 580.0]")
                # logger.critical(row['T2_GLBL_BSS_UID_2'])
                return 9
            if row['T16_GLBL_BSS_UID_1'] in [167.0, 168.0, 169.0, 170.0, 171.0, 172.0, 173.0, 174.0, 195.0, 196.0,
                                             197.0, 198.0] and row['OHA_DAA_CD'] in ['A', 'B', 'D', 'J', 'K', 'L', 'N',
                                                                                     'W', 'X', 'Y', 'Z']:
                # logger.critical(row['HOFC_WRK_UNIT_UID'])
                # logger.critical("row['T16_GLBL_BSS_UID_1'] in [167.0, 168.0, 169.0, 170.0, 171.0, 172.0, 173.0, 174.0, 195.0, 196.0, 197.0, 198.0] and row['OHA_DAA_CD'] in ['A', 'B', 'D', 'J', 'K', 'L', 'N', 'W', 'X', 'Y', 'Z']")
                # logger.critical(row['T16_GLBL_BSS_UID_1'])
                # logger.critical(row['OHA_DAA_CD'])
                return 10
            return 0

        mergedf['noncovered_ver'] = mergedf.apply(lambda row: gen_noncovered_ver(row), axis=1)

        # Function to return an EFLDR_NUM to remove if every row
        # associated with it has a 'noncovered_ver' that != 0:
        def gen_noncovered_efldrnum(row):
            efldr_num = row['EFLDR_NUM']
            efn_df = mergedf.loc[mergedf['EFLDR_NUM'] == efldr_num]
            if len([nv for nv in efn_df['noncovered_ver'].tolist() if nv != 0]) == len(efn_df):
                return efldr_num
            else:
                return 0

        # Function to return an EFLDR_NUM to remove if every row
        # associated with it has a 'noncovered_ver' that != 0: Version 2
        def gen_noncovered_elfdrnum2(mergedf):
            # Get unique ELFDR_NUM
            resdf = mergedf
            nonconvered_efldr_num_sub_list = []
            unique_efldr_numdf = mergedf.drop_duplicates(subset='EFLDR_NUM')

            for efldr_num in unique_efldr_numdf['EFLDR_NUM']:
                inputdf = mergedf.loc[mergedf['EFLDR_NUM'] == efldr_num]
                if len([nv for nv in inputdf['noncovered_ver'].tolist() if nv != 0]) == len(inputdf):
                    nonconvered_efldr_num_sub_list.append(efldr_num)
                else:
                    nonconvered_efldr_num_sub_list.append(0)

                sub_list = [r for r in nonconvered_efldr_num_sub_list if r != 0]

                if cfg.batch_store_non_convered and len(sub_list) > 0:
                    # Store records associated with the case entity has a 'noncovered_ver' for filtering on next cycle
                    nonconvered_efldr_num_df = mergedf.loc[mergedf['EFLDR_NUM'].isin(sub_list)]
                    # Add empty DOCU_CTL_ID
                    nonconvered_efldr_num_df["DOCU_CTL_ID"] = "E"
                    ifsdab.insert_failed_schema2(nonconvered_efldr_num_df, "Non-covered case/decision type.")

                resdf = resdf.loc[~resdf['EFLDR_NUM'].isin(sub_list)]

            return resdf

        # Remove a case entity and all its rows only if every row associated with
        # the case entity has a 'noncovered_ver' that != 0 (via parsing in gen_noncovered_efldrnum()):
        logger.critical('mergedf pre-nonconvered_efldr_num_list/noncovered_ver len: ')
        logger.critical(str(len(mergedf)))
        mergedf = gen_noncovered_elfdrnum2(mergedf)
        logger.critical('mergedf post-nonconvered_efldr_num_list/noncovered_ver len: ')
        logger.critical(str(len(mergedf)))

        # Retrieve & merge in DOCU_CTL_ID, then remove any case entity that does
        # not have a DOCU_CTL_ID value associated with each of its rows:
        # TIP: Because merging DOCU_CTL_ID via EFLDR_NUM, removal action should
        # remove all rows associated with a given case entity, as each row for a
        # given case entity should carry the same EFLDR_NUM.
        # TODO: Update IFS suite to take advantage of the complexity verdict
        # returned in each tuple by 'retrieve_docu_ctl_id_via_efldr_num_batch()'.
        # TODO: Eventually update to take advantage of alternate decision sources
        # such as the Word document repository.
        efldr_num_fnl_dspn_dt_tuplist = zip(mergedf['EFLDR_NUM'].tolist(), mergedf['FNL_DSPN_DT'].tolist())
        decid_resdict = batch_decid_parser.retrieve_docu_ctl_id_via_efldr_num_batch(efldr_num_fnl_dspn_dt_tuplist)
        logger.critical("decid_resdict len:")
        logger.critical(len(decid_resdict))

        # If 'decid_resdict' is empty, return empty DFs:
        if not decid_resdict:
            mergedf = pandas.DataFrame()
            expdfmerged = pandas.DataFrame()
            return mergedf, expdfmerged
        decid_resdict_slice = {k: v[0] for k, v in decid_resdict.iteritems()}
        mergedf['DOCU_CTL_ID'] = mergedf['EFLDR_NUM'].map(decid_resdict_slice)

        if cfg.batch_store_no_doc_ctrl_id:
            # Store records with no document control ids in the database for filtering on next cycle
            nodecisiondocdf = mergedf.loc[mergedf['DOCU_CTL_ID'] == 'E']
            ifsdab.insert_failed_schema2(nodecisiondocdf, "No Document Control ID")

        # Filter records with no document control ids
        mergedf = mergedf.loc[mergedf['DOCU_CTL_ID'] != 'E']
        logger.critical('mergedf len post-docu_ctl_id E removal len: ')
        logger.critical(str(len(mergedf)))

        # Slice remaining cases down to cfg.batch_size:
        # TIP: Using DOCU_CTL_ID to filter b/c should be only
        # one unique decisional DOCU_CTL_ID value per case entity.
        if cfg.batch_size != 'U':
            decid_unique = list(set(mergedf['DOCU_CTL_ID'].tolist()))
            if cfg.batch_random is True:
                random.shuffle(decid_unique)
                mergedf = mergedf.loc[mergedf.DOCU_CTL_ID.isin(decid_unique[:cfg.batch_size])]
            else:
                mergedf = mergedf.loc[mergedf.DOCU_CTL_ID.isin(decid_unique[:cfg.batch_size])]
        logger.critical("mergedf len filtered via cfg.batch_size:")
        logger.critical(len(mergedf))

        # Filter expdfmerged to only those observations whose
        # HOFC_WRK_UNIT_UID values are still present in mergedf:
        expdfmerged = expdfmerged.loc[expdfmerged['HOFC_WRK_UNIT_UID'].isin(mergedf['HOFC_WRK_UNIT_UID'].tolist())]

        # Standardize date columns to INSIGHT-formatted date string:
        mergedf = normalize_dates(mergedf)
        expdfmerged = normalize_dates(expdfmerged)

        # Return data:
        return mergedf, expdfmerged

    except Exception as ex:
        logger.exception('EXCEPTION: '+str(ex))
        mergedf = pandas.DataFrame()
        expdfmerged = pandas.DataFrame()
        return mergedf, expdfmerged
