# TEST bmi-revised module under src.
#
# AUTHOR:
# Michael Iwunze
#
# ==============================================================================


import os
import sys
import logging
from collections import OrderedDict
import numpy as np
import pytest

# Set directories:
import setup_config

#Import ifs bmi module for testing bmi calc
import bmi_revised as bmi


#Test BMI calculator
@pytest.mark.parametrize("htin_input_str, wtlb_input_str, expected", [
    ('100.0', '40', '2.812'),
    (np.nan, '40', 'E'),
    ('120.0', '50', '2.441'),
    (np.nan, '50', 'E'),
])
def test_bmi_result(htin_input_str, wtlb_input_str, expected):
    bmi_result = bmi.calc_bmi(htin_input_str, wtlb_input_str)
    assert isinstance(bmi_result, str)
    assert bmi_result == expected


#Test Adult BMI Interpreter
@pytest.mark.parametrize("bmi_input_str, htin_input_str, wtlb_input_str, expected", [
    (np.nan, np.nan, np.nan, ('E', 'E')),
    ('24.410', np.nan, np.nan, ('NML', '<span style="color:green; "> Normal (BMI = 24.410 for height [nan in] & weight [nan lb])</span>')),
    (np.nan, np.nan, '48', ('E', 'E')),
    ('24.410', '80', '48', ('NML', '<span style="color:green; "> Normal (BMI = 24.410 for height [80 in] & weight [48 lb])</span>'))
])
def test_interp_bmi_adult(bmi_input_str, htin_input_str, wtlb_input_str, expected):
    bmi_tuple = bmi.interp_bmi_adult(bmi_input_str, htin_input_str, wtlb_input_str)
    assert isinstance(bmi_tuple, tuple)
    assert bmi_tuple == expected


#Test Child BMI Interpreter 0-2
@pytest.mark.parametrize("sex_input_str, htin_input_str, wtlb_input_str, expected", [
    (np.nan, np.nan, np.nan, ('E', 'E')),
    ('M', '29', '35', ('OB', '<span style="color:#ce0000; "> Obese (weight >= 95th percentile for weight [35 lb], height [29 in], and sex [M])</span>'))
])
def test_interp_bmi_child_0_2(sex_input_str, htin_input_str, wtlb_input_str, expected):
    bmi_tuple = bmi.interp_bmi_child_0_2(sex_input_str, htin_input_str, wtlb_input_str)
    assert isinstance(bmi_tuple, tuple)
    assert bmi_tuple == expected


#Test Child BMI 2-18
@pytest.mark.parametrize("age_input_str, sex_input_str, bmi_input_str, expected", [
    (np.nan, np.nan, np.nan, ('E', 'E')),
    ('15-y-3-m', 'F', '62', ('OB', '<span style="color:#ce0000; "> Obese (BMI of 62 >= 95th percentile for age [15-y-3-m] & sex [F])</span>')),
    ('3-y-3-m', 'M', '17.136', ('NML', '<span style="color:green; "> Normal (BMI of 17.136 >= 5th percentile but < 85th percentile for age [3-y-3-m] & sex [M])</span>')),
    ('3-y-3-m', 'F', '17.136', ('OW', '<span style="color:purple; "> Overweight (BMI of 17.136 >= 85th percentile but < 95th percentile for age [3-y-3-m] & sex [F])</span>'))
])
def test_interp_bmi_child_2_18(age_input_str, sex_input_str, bmi_input_str, expected):
    bmi_tuple = bmi.interp_bmi_child_2_18(age_input_str, sex_input_str, bmi_input_str)
    assert isinstance(bmi_tuple, tuple)
    assert bmi_tuple == expected

#Test Weight Parser
@pytest.mark.parametrize('sex, htin, wtlb, age, dob, enddt, expected', [
    ('nan', 'nan', 'nan', 'nan', 'nan', 'nan', {'enddt': 'nan', 'bmi': 'E', 'interp_str': 'E', 'interp_var': 'E', 'dob': 'nan', 'age': 'nan', 'wtlb': 'nan', 'htin': 'nan', 'sex': 'E'}),
    ('F', '48', '80', '6-y-6-mo', 'U', 'U', {'enddt': 'U', 'dob': 'U', 'age': '6-y-6-mo', 'bmi': '24.41', 'htin': '48', 'sex': 'F', 'interp_str': 'E', 'interp_var': 'E', 'wtlb': '80'})
])
def test_parse_weight(sex, htin, wtlb, age, dob, enddt, expected):
    result_dict = bmi.parse_weight(sex, htin, wtlb, age, dob, enddt)

    #Return type check!
    assert isinstance(result_dict, dict)

    #Using OrderedDict class to sort dictionary results before testing assertion
    ordered_result_dict = OrderedDict(sorted(result_dict.items(), key=lambda t: t[0]))
    ordered_expected = OrderedDict(sorted(expected.items(), key=lambda t: t[0]))
    assert ordered_result_dict == ordered_expected
