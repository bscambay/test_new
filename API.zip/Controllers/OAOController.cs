﻿using INSIGHT_Request;
using INSIGHT_Request;
using INSIGHT_Request.Models;
using INSIGHT_Request.Properties;
using INSIGHT_Request.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;


namespace INSIGHT_Request.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class OAOController : ApiController
    {
        [HttpPost]
        [ActionName("OC")]
        public HttpResponseMessage HC([FromBody] OAOClaimantRequest rqst)
        {
            byte[] b = System.Convert.FromBase64String(rqst.decisionText);
            rqst.decisionText = System.Text.Encoding.Default.GetString(b);
            OAOClaimantRequest c = rqst;

            DataSet ds = new DataSet();
            //TEST SET
           
            //
            ds = WWData.OAOClaimant(c.cossn, ds);

            OAOWork ccl = new OAOWork();
            foreach (DataRow r in ds.Tables["STRUCT_OAODISP"].Rows)
            {
                OAOClaimant_O cc = new OAOClaimant_O();
                cc.CASE_GRP_CD = r["CASE_GRP_CD"].ToString();
                cc.CLMT_DECD_SW = r["CLMT_DECD_SW"].ToString();
                cc.CLMT_DOB = Utils.ToShortDate(r["CLMT_DOB"].ToString().Trim());

                cc.SEX = r["SEX"].ToString();
                cc.HT_INCH = r["HT_INCH"].ToString();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString();

                cc.CLMT_NM25 = r["CLMT_NM25"].ToString();
                cc.CLMT_SSN = r["CLMT_SSN"].ToString();
                cc.CLMT_ST = r["CLMT_ST"].ToString();
                cc.CLM_TYP = r["CLM_TYP"].ToString();
                cc.CLM_UID = r["CLM_UID"].ToString();
                cc.CRITL_CASE_CTGY_SW = r["CRITL_CASE_CTGY_SW"].ToString();
                cc.DIRE_NEED_SW = r["DIRE_NEED_SW"].ToString();
                cc.DLI = Utils.ToShortDate(r["DLI"].ToString().Trim());
                cc.EDIB_CD = r["EDIB_CD"].ToString();

                cc.EFLDR_NUM = r["EFLDR_NUM"].ToString();
                cc.HEDULVL_CD = r["HEDULVL_CD"].ToString();
                cc.HOFC_WRK_UNIT_UID = r["HOFC_WRK_UNIT_UID"].ToString();
                cc.HOFC_WRK_UNIT_UID_HRG = r["HOFC_WRK_UNIT_UID_HRG"].ToString();
                cc.HRG_ISU_CD = r["HRG_ISU_CD"].ToString();
                cc.HRG_TYP = r["HRG_TYP"].ToString();

                cc.OHA_DAA_CD = r["OHA_DAA_CD"].ToString();
                cc.PTNTLY_HOMCDL_SW = r["PTNTLY_HOMCDL_SW"].ToString();
                cc.REP_UID = r["REP_UID"].ToString();
                cc.SUICIDL_SW = r["SUICIDL_SW"].ToString();
                cc.T16_APP_DT = Utils.ToShortDate(r["T16_APP_DT"].ToString().Trim());
                cc.T16_PFLG_DT = Utils.ToShortDate(r["T16_PFLG_DT"].ToString().Trim());
                cc.T2_APP_DT = Utils.ToShortDate(r["T2_APP_DT"].ToString().Trim());
                cc.T2_PFLG_DT = Utils.ToShortDate(r["T2_PFLG_DT"].ToString().Trim());

                cc.TRML_ILLNESS_SW = r["TRML_ILLNESS_SW"].ToString();
                cc.WG_ERNR_SSN = r["WG_ERNR_SSN"].ToString();
                //should put the expert and devl inside this class
                ds = WWData.OAOExpert(cc.HOFC_WRK_UNIT_UID_HRG, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP_OAOEXP"].Rows)
                {
                    OAOExpert he = new OAOExpert();
                    he.ATTNDD_SW = hr["ATTNDD_SW"].ToString();
                    he.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    he.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    he.FNM = hr["FNM"].ToString();
                    he.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    he.LNM = hr["LNM"].ToString();
                    he.MED_SPCLY_CD = hr["MED_SPCLY_CD"].ToString();
                    he.MNM = hr["MNM"].ToString();
                    he.SCHD_SW = hr["SCHD_SW"].ToString();
                    he.SFX = hr["SFX"].ToString();
                    he.TITLE = hr["TITLE"].ToString();
                    cc.OAOExpert.Add(he);
                }
                ds = WWData.OAODevelopment(cc.HOFC_WRK_UNIT_UID_HRG, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP_DEVLPO"].Rows)
                {
                    OAODevelopment hd = new OAODevelopment();
                    hd.ACKT_RCVDT = Utils.ToShortDate(hr["ACKT_RCVDT"].ToString());
                    hd.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    hd.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    hd.FNM = hr["FNM"].ToString();
                    hd.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    hd.LNM = hr["LNM"].ToString();
                    hd.DEV_GRP = hr["DEV_GRP"].ToString();
                    hd.MNM = hr["MNM"].ToString();
                    hd.DEV_SRC_CD = hr["DEV_SRC_CD"].ToString();
                    hd.SFX = hr["SFX"].ToString();
                    hd.TITLE = hr["TITLE"].ToString();
                    cc.OAODevelopment.Add(hd);
                }




                ccl.OAOWorkListing.Add(cc);


            }
            //moved prior to documents because inserts are done programtically based on the ds name
            OAOWork suc = WWData.AddOAOInsightRequest(ds, rqst.cossn, rqst.decisionText, ccl);
            //HearingDocuments 
            //if (suc.OAOWorkListing.Count > 0)
            //{
            //    ds = WWData.OAODocuments(suc.OAOWorkListing[0].EFLDR_NUM, ds);
            //    foreach (DataRow doc in ds.Tables["STRUCT_FOLDER_DOCUMENTS"].Rows)
            //    {
            //        OAOFolderDocument hfd = new OAOFolderDocument();
            //        hfd.CASE_NUM = doc["CASE_NUM"].ToString();
            //        hfd.DMA_NOTES = doc["DMA_NOTES"].ToString();
            //        hfd.DMA_RCPT_TS = Utils.ToShortDate(doc["DMA_RCPT_TS"].ToString());
            //        hfd.DOCU_CD = doc["DOCU_CD"].ToString();
            //        hfd.DOCU_CTL_ID = doc["DOCU_CTL_ID"].ToString();
            //        hfd.FLDR_NUM = doc["FLDR_NUM"].ToString();
            //        hfd.MDF_CD = doc["MDF_CD"].ToString();
            //        hfd.OCD = doc["OCD"].ToString();
            //        hfd.TRTMNT_SRC_NM = doc["TRTMNT_SRC_NM"].ToString();
            //        suc.OAOFolderDocuments.Add(hfd);
            //    }
            //}

            HttpResponseMessage response = new HttpResponseMessage();
            if (rqst.displayJson)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc.rid);
            }

            return response;


        }

        [HttpPost]
        [ActionName("OC-data")]
        public HttpResponseMessage OC_Data([FromBody] OAOClaimantRequest rqst)
        {
           
            OAOClaimantRequest c = rqst;

            DataSet ds = new DataSet();
            //TEST SET
         
            //
            ds = WWData.OAOClaimant(c.cossn, ds);

            OAOWork ccl = new OAOWork();
            foreach (DataRow r in ds.Tables["STRUCT_OAODISP"].Rows)
            {
                OAOClaimant_O cc = new OAOClaimant_O();
                cc.CASE_GRP_CD = r["CASE_GRP_CD"].ToString();
                cc.CLMT_DECD_SW = r["CLMT_DECD_SW"].ToString();
                cc.CLMT_DOB = Utils.ToShortDate(r["CLMT_DOB"].ToString().Trim());

                cc.SEX = r["SEX"].ToString();
                cc.HT_INCH = r["HT_INCH"].ToString();
                cc.WT_OUNCES = r["WT_OUNCES"].ToString();

                cc.CLMT_NM25 = r["CLMT_NM25"].ToString();
                cc.CLMT_SSN = r["CLMT_SSN"].ToString();
                cc.CLMT_ST = r["CLMT_ST"].ToString();
                cc.CLM_TYP = r["CLM_TYP"].ToString();
                cc.CLM_UID = r["CLM_UID"].ToString();
                cc.CRITL_CASE_CTGY_SW = r["CRITL_CASE_CTGY_SW"].ToString();
                cc.DIRE_NEED_SW = r["DIRE_NEED_SW"].ToString();
                cc.DLI = Utils.ToShortDate(r["DLI"].ToString().Trim());
                cc.EDIB_CD = r["EDIB_CD"].ToString();

                cc.EFLDR_NUM = r["EFLDR_NUM"].ToString();
                cc.HEDULVL_CD = r["HEDULVL_CD"].ToString();
                cc.HOFC_WRK_UNIT_UID = r["HOFC_WRK_UNIT_UID"].ToString();
                cc.HOFC_WRK_UNIT_UID_HRG = r["HOFC_WRK_UNIT_UID_HRG"].ToString();
                cc.HRG_ISU_CD = r["HRG_ISU_CD"].ToString();
                cc.HRG_TYP = r["HRG_TYP"].ToString();

                cc.OHA_DAA_CD = r["OHA_DAA_CD"].ToString();
                cc.PTNTLY_HOMCDL_SW = r["PTNTLY_HOMCDL_SW"].ToString();
                cc.REP_UID = r["REP_UID"].ToString();
                cc.SUICIDL_SW = r["SUICIDL_SW"].ToString();
                cc.T16_APP_DT = Utils.ToShortDate(r["T16_APP_DT"].ToString().Trim());
                cc.T16_PFLG_DT = Utils.ToShortDate(r["T16_PFLG_DT"].ToString().Trim());
                cc.T2_APP_DT = Utils.ToShortDate(r["T2_APP_DT"].ToString().Trim());
                cc.T2_PFLG_DT = Utils.ToShortDate(r["T2_PFLG_DT"].ToString().Trim());

                cc.TRML_ILLNESS_SW = r["TRML_ILLNESS_SW"].ToString();
                cc.WG_ERNR_SSN = r["WG_ERNR_SSN"].ToString();
                //should put the expert and devl inside this class
                ds = WWData.OAOExpert(cc.HOFC_WRK_UNIT_UID_HRG, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP_OAOEXP"].Rows)
                {
                    OAOExpert he = new OAOExpert();
                    he.ATTNDD_SW = hr["ATTNDD_SW"].ToString();
                    he.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    he.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    he.FNM = hr["FNM"].ToString();
                    he.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    he.LNM = hr["LNM"].ToString();
                    he.MED_SPCLY_CD = hr["MED_SPCLY_CD"].ToString();
                    he.MNM = hr["MNM"].ToString();
                    he.SCHD_SW = hr["SCHD_SW"].ToString();
                    he.SFX = hr["SFX"].ToString();
                    he.TITLE = hr["TITLE"].ToString();
                    cc.OAOExpert.Add(he);
                }
                ds = WWData.OAODevelopment(cc.HOFC_WRK_UNIT_UID_HRG, ds);
                foreach (DataRow hr in ds.Tables["STRUCT_EXP_DEVLPO"].Rows)
                {
                    OAODevelopment hd = new OAODevelopment();
                    hd.ACKT_RCVDT = Utils.ToShortDate(hr["ACKT_RCVDT"].ToString());
                    hd.EXPERT_TYP = hr["EXPERT_TYP"].ToString();
                    hd.EXPERT_UID = hr["EXPERT_UID"].ToString();
                    hd.FNM = hr["FNM"].ToString();
                    hd.INSRT_TS = Utils.ToShortDate(hr["INSRT_TS"].ToString());
                    hd.LNM = hr["LNM"].ToString();
                    hd.DEV_GRP = hr["DEV_GRP"].ToString();
                    hd.MNM = hr["MNM"].ToString();
                    hd.DEV_SRC_CD = hr["DEV_SRC_CD"].ToString();
                    hd.SFX = hr["SFX"].ToString();
                    hd.TITLE = hr["TITLE"].ToString();
                    cc.OAODevelopment.Add(hd);
                }




                ccl.OAOWorkListing.Add(cc);


            }
            //moved prior to documents because inserts are done programtically based on the ds name
            OAOWork suc = ccl;
            //HearingDocuments
            //if (suc.OAOWorkListing.Count > 0)
            //{
            //    ds = WWData.OAODocuments(suc.OAOWorkListing[0].EFLDR_NUM, ds);
            //    foreach (DataRow doc in ds.Tables["STRUCT_FOLDER_DOCUMENTS"].Rows)
            //    {
            //        OAOFolderDocument hfd = new OAOFolderDocument();
            //        hfd.CASE_NUM = doc["CASE_NUM"].ToString();
            //        hfd.DMA_NOTES = doc["DMA_NOTES"].ToString();
            //        hfd.DMA_RCPT_TS = Utils.ToShortDate(doc["DMA_RCPT_TS"].ToString());
            //        hfd.DOCU_CD = doc["DOCU_CD"].ToString();
            //        hfd.DOCU_CTL_ID = doc["DOCU_CTL_ID"].ToString();
            //        hfd.FLDR_NUM = doc["FLDR_NUM"].ToString();
            //        hfd.MDF_CD = doc["MDF_CD"].ToString();
            //        hfd.OCD = doc["OCD"].ToString();
            //        hfd.TRTMNT_SRC_NM = doc["TRTMNT_SRC_NM"].ToString();
            //        suc.OAOFolderDocuments.Add(hfd);
            //    }
            //}

            HttpResponseMessage response = new HttpResponseMessage();
            if (rqst.displayJson)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.OK, suc.rid);
            }

            return response;


        }

        [HttpPost]
        [ActionName("OC-issue")]
        public HttpResponseMessage OC_Issue([FromBody] OAOStatusRequest rqst)
        {

            OAOStatusRequest c = rqst;
            //‘_ver’ 
            //One add:  Update Tony’s code to output dynamic links to INSIGHT case pages – for each REQID, query ‘dspn_doc’, 
            //count the number of ‘1’ values in ‘_ver’ columns, and output that total into that REQID’s link text as displayed in the Query Tool, 
            //e.g. “Open INSIGHT Page(3)”.  Will help users make a quick call as to whether they even want to open the INSIGHT page / speeds up their interactions with the tool.
            DataSet ds = new DataSet();
            //TEST SET
           
            //http://insight.ba.ssa.gov:8189/oaoapp/12
            Random r = new Random();
            

            int issues = r.Next(0, 9);
            OAOStatus os = new OAOStatus();
            if(Settings.Default.ENV == "P" | Settings.Default.ENV == "V")
            {
                int errors = 0;
                string oaorqst = "";
                ds = WWData.getOAOStatus(ds, c);
                //2017-10-24 - KAG
                //1.Query INSIGHT DB (the ‘struct_oao’ table) to determine whether the ARPS ‘wrkofcunit_uid’ exists as a value in the ‘struct_oao.hofc_wrk_unit_AC’ column.
                //    a.If it does exist, retrieve the ‘struct_oao.REQID’ value associated with it and use that to generate the URL to the appropriate INSIGHT page for the ARPS link(e.g. ‘http://insight.ba.ssa.gov:8189/oaoapp/81847’) with the ARPS link text as ‘Open’.
                //    b.If it does NOT exist, send ‘No INSIGHT Case Page’ as the ARPS link text.If you have to include an ‘href’ value, make it the INSIGHT OAO Case Search page(‘http://insightsearch.ba.ssa.gov:8199/’).  But ideally, we’d just pass back ‘No INSIGHT Case Search’ to ARPS as text rather than as a link.

                //removing error count based on the above
                foreach (DataRow rw in ds.Tables["OAO"].Rows)
                {
                    //foreach(DataColumn dc in ds.Tables["OAO"].Columns)
                    //{
                    //    if (dc.ColumnName.ToLower().Contains("_ver"))
                    //    {
                    //        string s = rw[dc.ColumnName].ToString().Trim();
                    //        if(s != "U")
                    //        {
                    //            int tmpError = int.Parse(s);
                    //            if(tmpError > 0)
                    //            {
                    //                errors += tmpError;
                    //            }
                    //        }

                    //    }
                    //}
                    oaorqst = rw["reqid"].ToString().Trim();
                }
                if(ds.Tables["OAO"].Rows.Count < 1)
                {
                    os.label = "No INSIGHT";
                    //bring from database
                    os.uri = "#";
                }
                else
                {
                    os.label = "Open";
                    //bring from database
                    os.uri = "http://insight.ba.ssa.gov:8189/oaoapp/" + oaorqst;
                }
                //count no errors from above requirements
                //if(errors > 0)
                //{
                //    os.label = "Open";
                //    //bring from database
                //    os.uri = "http://insight.ba.ssa.gov:8189/oaoapp/" + oaorqst;
                //}
                

            }
            else
            {
                os.label = "Open";
                //bring from database
                //remove /INSIGHT BEFORE PUBLISH
                //http://localhost:61555/INSIGHT/
                //Production http://s1ff501:8199/INSIGHT/
                string cossn = rqst.cossn;
                os.uri = "http://insightsearch.ba.ssa.gov:8199/" + cossn.ToString();
            }
           
            //james test
            //os.label = "";
            //os.uri = "";
            HttpResponseMessage response = new HttpResponseMessage();
            response = Request.CreateResponse(HttpStatusCode.OK, os);

            return response;


        }

    }
}
