﻿using INSIGHT_Request.Models;
using INSIGHT_Request.Properties;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Caching;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace INSIGHT_Request
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            addCacheObjects();
            log4net.Config.XmlConfigurator.Configure();
            GlobalConfiguration.Configure(WebApiConfig.Register);
        }
        private void addCacheObjects()
        {
            ObjectCache cache = MemoryCache.Default;

            DataSet appSettingDS = (DataSet)cache["appSettingDS"];
            string psqlUID = (string)cache["psqlUID"];
            string psqlPWD = (string)cache["psqlPWD"];

            string db2DSN = (string)cache["db2DSN"];
            string db2UID = (string)cache["db2UID"];
            string db2PWD = (string)cache["db2PWD"];
            string db2SCHEMA = (string)cache["db2SCHEMA"];

            string mhaDSN = (string)cache["mhaDSN"];
            string mhaUID = (string)cache["mhaUID"];
            string mhaPWD = (string)cache["mhaPWD"];
            string mhaSCHEMA = (string)cache["mhaSCHEMA"];
            string medibSCHEMA = (string)cache["medibSCHEMA"];
            string insightConnection = (string)cache["insightConnection"];
            string insightConnectionOAO = (string)cache["insightConnectionOAO"];
            string insightReportUrlOAO = (string)cache["insightReportUrlOAO"];


            CacheItemPolicy policy = new CacheItemPolicy();



            var SecFile = System.IO.File.OpenText(AppDomain.CurrentDomain.BaseDirectory + ".sec.json");
            string SecObj = SecFile.ReadToEnd();
            SecFile.Close();
            Sec sec = JsonConvert.DeserializeObject<Sec>(SecObj);



            //TODO: Convert Settings to DataTable and retrieval function need to do major refactoring here

            psqlUID = sec.uid;
            cache.Set("psqlUID", psqlUID, policy);

            psqlPWD = sec.pwd;
            cache.Set("psqlPWD", psqlPWD, policy);

            appSettingDS = WWData.getSettingDS();
            cache.Set("appSettingDS", appSettingDS, policy);

            //db2DSN = WWData.GetSetting("db2-dsn", "STRING", Environment.MachineName, Settings.Default.ENV);
            //cache.Set("db2DSN", db2DSN, policy);

            //db2UID = WWData.GetSetting("db2-uid", "STRING", Environment.MachineName, Settings.Default.ENV);
            //cache.Set("db2UID", db2UID, policy);

            //db2PWD = WWData.GetSetting("db2-pwd", "STRING", Environment.MachineName, Settings.Default.ENV);
            //cache.Set("db2PWD", db2PWD, policy);

            //db2SCHEMA = WWData.GetSetting("db2-schema", "STRING", Environment.MachineName, Settings.Default.ENV);
            //cache.Set("db2SCHEMA", db2SCHEMA, policy);

            mhaDSN = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-dsn");

            //mhaDSN = WWData.GetSetting("mha-dsn", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaDSN", mhaDSN, policy);

            mhaUID = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-uid");

            //mhaUID = WWData.GetSetting("mha-uid", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaUID", mhaUID, policy);

            mhaPWD = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-pwd");

            //mhaPWD = WWData.GetSetting("mha-pwd", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaPWD", mhaPWD, policy);

            mhaSCHEMA = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "mha-schema");

            //mhaSCHEMA = WWData.GetSetting("mha-schema", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("mhaSCHEMA", mhaSCHEMA, policy);

            medibSCHEMA = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "medib-schema");

            //medibSCHEMA = WWData.GetSetting("medib-schema", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("medibSCHEMA", medibSCHEMA, policy);

            insightConnection = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-connection-string");

            //insightConnection = WWData.GetSetting("insight-connection-string", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-connection-string", insightConnection, policy);

            insightConnectionOAO = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-connection-string-oao");

            //insightConnectionOAO = WWData.GetSetting("insight-connection-string-oao", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-connection-string-oao", insightConnectionOAO, policy);

            insightReportUrlOAO = Util.Utils.ExtractValue(appSettingDS, "REF_SETTING", "insight-oao-report-server");
            //insightConnectionOAO = WWData.GetSetting("insight-connection-string-oao", "STRING", Environment.MachineName, Settings.Default.ENV);
            cache.Set("insight-oao-report-server", insightReportUrlOAO, policy);

        }
    }
}
