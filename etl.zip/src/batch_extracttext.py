# INSIGHT HTML TEXT EXTRACTION SCRIPT
# AUTHOR: Kurt Glaze, U.S. Social Security Administration, Office of Appellate Operations, Division of Quality, Br. 9 / Gerald Ray Academy 
# DATE LAST UPDATED: 06.30.2016
#
# PURPOSE: This script is designed to extract decisional text from Tesseract-generated HOCR HTML files while also correcting a number of common OCR-generated and/or general spelling errors.
#
# NOTICE: The INSIGHT config file must be located in the same directory as any INSIGHT Python script file utilizing its configuration data.
#
# WARNING: 
# The following is alpha-level/prototype software whose output quality has not yet been formally validated and whose documentation is not yet fully formed. 
# Caution is therefore urged in utilizing this software or its output for programmatic purposes.
# ============================================================================================================================================

### IMPORT MODULES ###
import os
import os.path
import re
from bs4 import BeautifulSoup
import sys
import string
import ntpath
import io
import timeit
import multiprocessing
import config as cfg

# Set INSIGHT directories:
insightdir = os.path.dirname(os.path.realpath(__file__))
templatesdir = os.path.join(insightdir, "Templates")
datadir = os.path.join(insightdir, "Data")
logdir = os.path.join(insightdir, "Log")
staticdir = os.path.join(insightdir, "static")
tempdir = os.path.join(insightdir, "temp")
viewsdir = os.path.join(insightdir, "views")


### DEFINE TEXT EXTRACTION/CLEANING FUNCTION ###
def textextractor(decisionfp):
    """Convert OCR HTML to cleaned text file.

	Args:
		decisionfp {str}
	Returns:
		N/A (saves text file using same file name
		to same directory as 'decisionfp').
	Raises:
		General excepion.
	"""
    try:

        decisionpath = os.path.dirname(decisionfp)
        decisionfn = os.path.basename(decisionfp)

        with io.open(decisionfp, "rt", encoding="utf-8", errors="ignore") as decision:

            decision = decision.read()

            # (1) EXCTRACT TEXT AND WRITE TO FILE USING CUSTOM BS METHOD (NOTE: The code below effectively cleans up BS text output while retaining paragraph information):
            prebsclean = re.sub(r"<p class=.*?>", "BEGINPAR",
                                decision)  # Replace XML with paragraph beginning/ending marker texts.
            prebsclean = re.sub(r"</p>", "ENDPAR", prebsclean)

            bsclean = BeautifulSoup(prebsclean, "lxml").get_text()  # Clear out all HTML.

            bsclean = re.sub("[\t\n\r\f\v]", " ",
                             bsclean)  # Clear out ALL newlines (you've already preserved paragraph info above)
            bsclean = re.sub("BEGINPAR", "\n", bsclean)  # Replace your paragraph placeholders with newlines.
            bsclean = re.sub("ENDPAR", "\n", bsclean)  # Replace your paragraph placeholders with newlines.
            bsclean = re.sub(r"^ +", "", bsclean, flags=re.M)  # Sub out erroneous whitespace.
            bsclean = re.sub(r"\n *", "\n", bsclean)  # Sub out erroneous whitespace.

            # (2) RUN MISSPELL CORRECTORS:
            # TODO (06.30.2016): Update misspell correctors in line with other INSIGHT scripts.

            # (2)(a) Correct 'TESTDECISIONS2'-based commonly misspelled words (from top-600 frequency list; words with clear corrections; non-Spanish/non-medical OCR errors):
            bsclean = re.sub(r"claimant\ws", "claimant's", bsclean, flags=re.I)
            bsclean = re.sub(r"consultant\ws", "consultant's", bsclean, flags=re.I)
            bsclean = re.sub(r"examiner\ws", "examiner's", bsclean, flags=re.I)
            bsclean = re.sub(r"child\ws", "child's", bsclean, flags=re.I)
            bsclean = re.sub(r"individual\ws", "individual's", bsclean, flags=re.I)
            bsclean = re.sub(r"expert\ws", "expert's", bsclean, flags=re.I)
            bsclean = re.sub(r"driver\ws", "driver's", bsclean, flags=re.I)
            bsclean = re.sub(r"doctor\ws", "doctor's", bsclean, flags=re.I)
            bsclean = re.sub(r"physician\ws", "physician's", bsclean, flags=re.I)
            bsclean = re.sub(r"widow\ws", "widow's", bsclean, flags=re.I)
            bsclean = re.sub(r"workers\w", "workers'", bsclean, flags=re.I)
            bsclean = re.sub(r"worker\ws", "worker's", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)gainfu(\w\w|\w)", "gainful", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)very(\w\w|\w)", "very", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)mild(\w\w|\w)", "mild", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)moderate(\w\w|\w)", "moderate", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)less than marked(\w\w|\w)", "less than marked", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)marked(\w\w|\w)", "marked", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)extreme(\w\w|\w)", "extreme", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)activity(\w\w|\w)", "activity", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)severe(\w\w|\w)", "severe", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)paragraph(\w\w|\w)", "paragraph", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)disabled(\w\w|\w)", "disabled", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)substantial(\w\w|\w)", "substantial", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)agencyis(\w\w|\w)", "agency's", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)substantial(\w\w|\w)", " substantial ", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)gainful(\w\w|\w)", " gainful ", bsclean, flags=re.I)
            bsclean = re.sub(r"(\w\w|\w)activity(\w\w|\w)", " activity ", bsclean, flags=re.I)
            bsclean = re.sub(r"thereaiter", " thereafter ", bsclean, flags=re.I)
            bsclean = re.sub(r"yearsi", " years ", bsclean, flags=re.I)
            bsclean = re.sub(r"attomey", " attorney ", bsclean, flags=re.I)
            bsclean = re.sub(r"socialsecurity", "social security", bsclean, flags=re.I)
            bsclean = re.sub(r"thejob", "the job", bsclean, flags=re.I)
            bsclean = re.sub(r"ofa", "of a", bsclean, flags=re.I)
            bsclean = re.sub(r"ofhearing", "of hearing", bsclean, flags=re.I)
            bsclean = re.sub(r"ofhow", "of how", bsclean, flags=re.I)
            bsclean = re.sub(r"ofthe", "of the", bsclean, flags=re.I)
            bsclean = re.sub(r"ofmental", "of mental", bsclean, flags=re.I)
            bsclean = re.sub(r"ifit", "if it", bsclean, flags=re.I)
            bsclean = re.sub(r"ifthe", "if the", bsclean, flags=re.I)
            bsclean = re.sub(r"ifan", "if an", bsclean, flags=re.I)
            bsclean = re.sub(r"ofthis", "of this", bsclean, flags=re.I)
            bsclean = re.sub(r"ofdisapproved", "of disapproved", bsclean, flags=re.I)
            bsclean = re.sub(r"of1", "of 1", bsclean, flags=re.I)
            bsclean = re.sub(r"of2", "of 2", bsclean, flags=re.I)
            bsclean = re.sub(r"of3", "of 3", bsclean, flags=re.I)
            bsclean = re.sub(r"of4", "of 4", bsclean, flags=re.I)
            bsclean = re.sub(r"of5", "of 5", bsclean, flags=re.I)
            bsclean = re.sub(r"of6", "of 6", bsclean, flags=re.I)
            bsclean = re.sub(r"of7", "of 7", bsclean, flags=re.I)
            bsclean = re.sub(r"of8", "of 8", bsclean, flags=re.I)
            bsclean = re.sub(r"of9", "of 9", bsclean, flags=re.I)

            # (2)(b) Correct 'START'-based commonly mispelled words:
            bsclean = re.sub(r' X-hour', ' 8-hour', bsclean, flags=re.I)
            bsclean = re.sub(r' X hour', ' 8 hour', bsclean, flags=re.I)
            bsclean = re.sub(r'meffitus', 'mellitus', bsclean, flags=re.I)
            bsclean = re.sub(r'conunimicate', 'communicate', bsclean, flags=re.I)
            bsclean = re.sub(r'fmgering', 'fingering', bsclean, flags=re.I)
            bsclean = re.sub(r'chrouic', 'chronic', bsclean, flags=re.I)
            bsclean = re.sub(r'siguificant', 'significant', bsclean, flags=re.I)
            bsclean = re.sub(r'learuing', 'learning', bsclean, flags=re.I)
            bsclean = re.sub(r'defmed', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r'otherjobs', 'other jobs', bsclean, flags=re.I)
            bsclean = re.sub(r'ifle', 'file', bsclean, flags=re.I)
            bsclean = re.sub(r'thoracie', 'thoracic', bsclean, flags=re.I)
            bsclean = re.sub(r'fme', 'fine', bsclean, flags=re.I)
            bsclean = re.sub(r'capabifity', 'capability', bsclean, flags=re.I)
            bsclean = re.sub(r'acconunodations', 'accomomodations', bsclean, flags=re.I)
            bsclean = re.sub(r'wifi', 'will', bsclean, flags=re.I)
            bsclean = re.sub(r'famifiar', 'familiar', bsclean, flags=re.I)
            bsclean = re.sub(r'inflanunatory', 'inflammatory', bsclean, flags=re.I)
            bsclean = re.sub(r'caimabis', 'cannabis', bsclean, flags=re.I)
            bsclean = re.sub(r'clamed', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r'stram', 'strain', bsclean, flags=re.I)
            bsclean = re.sub(r'\(MATA\)', '\(MVA\)', bsclean, flags=re.I)
            bsclean = re.sub(r'\(lamed', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r'httle', 'little', bsclean, flags=re.I)
            bsclean = re.sub(r'( {1,2})m( {1,2})', ' in ', bsclean, flags=re.I)
            bsclean = re.sub(r'dermed', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r'del-Bled', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r'darned', 'defined', bsclean, flags=re.I)
            bsclean = re.sub(r"0X", "08", bsclean, flags=re.I)
            bsclean = re.sub(r"1X", "18", bsclean, flags=re.I)
            bsclean = re.sub(r"2X", "28", bsclean, flags=re.I)
            bsclean = re.sub(r"3X", "38", bsclean, flags=re.I)
            bsclean = re.sub(r"4X", "48", bsclean, flags=re.I)
            bsclean = re.sub(r"5X", "58", bsclean, flags=re.I)
            bsclean = re.sub(r"6X", "68", bsclean, flags=re.I)
            bsclean = re.sub(r"7X", "78", bsclean, flags=re.I)
            bsclean = re.sub(r"8X", "88", bsclean, flags=re.I)
            bsclean = re.sub(r"9X", "98", bsclean, flags=re.I)
            bsclean = re.sub(r' X hours', ' 8 hours', bsclean, flags=re.I)
            lfinder = re.search(r"(\d|l)(\d|l)(\d|l)(-)(\d|l)(\d|l)(-)(\d|l)(\d|l)(\d|l)(\d|l)", bsclean, flags=re.I)
            if bool(lfinder) is True:
                initialgroup = lfinder.group()
                newgroup = ""
                for item in initialgroup:
                    if "l" in item:
                        newgroup = newgroup + "1"
                    else:
                        newgroup = newgroup + item
                bsclean = re.sub(initialgroup, newgroup, bsclean)

            # (2)(c) Correct any odd punctuation/spacing (which in part may have been generated by the above corrections):
            bsclean = re.sub(r"( {1,5}),", ",", bsclean)
            bsclean = re.sub(r"( {1,5})\.", ".", bsclean)
            bsclean = re.sub(r"( {1,5});", ";", bsclean)
            bsclean = re.sub(r"( {1,5}):", ":", bsclean)
            bsclean = re.sub(r"( {2,5})\)", ")", bsclean)
            bsclean = re.sub(r"( {2,5})\(", "(", bsclean)
            bsclean = re.sub(r"( {2,5})\]", "]", bsclean)
            bsclean = re.sub(r"( {2,5})\[", "[", bsclean)
            bsclean = re.sub(r"( {2,5})", " ", bsclean)

            # (3) WRITE CLEANED TEXT TO A TEXT FILE:
            bsclean = ''.join([char for char in bsclean if ord(char) < 128])
            outputfn = str(os.path.splitext(decisionfn)[0]) + ".txt"
            outputfp = os.path.join(decisionpath, outputfn)
            outputwriter = io.open(outputfp, "w", encoding="ascii", errors="strict")
            outputwriter.write(bsclean)
            outputwriter.close()

    except Exception, x:
        print decisionfp
        print str(x)
        raise


### DEFINE 'MAIN' SCRIPT ###
if __name__ == '__main__':
    # Assemble temp dir directory path:
    batch_temp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../input/temp"))

    # Assemble list of decision HTML full paths to be converted:
    hocr_html_fn_list = [fn[:-5] for fn in os.listdir(batch_temp_dir) if fn.endswith('html')]

    # Remove any decision HTML files already converted to a text file:
    hocr_txt_fn_list = [fn[:-4] for fn in os.listdir(batch_temp_dir) if fn.endswith('txt')]

    hocr_html_fn_list_filtered = list(set(hocr_html_fn_list) - set(hocr_txt_fn_list))
    hocr_html_fn_list_filtered = [fn + '.html' for fn in hocr_html_fn_list_filtered]
    hocr_html_fn_list_filtered = [os.path.join(batch_temp_dir, fn) for fn in hocr_html_fn_list_filtered]

    print len(hocr_html_fn_list_filtered)
    print hocr_html_fn_list_filtered[0]
    print os.path.exists(hocr_html_fn_list_filtered[0])
    raw_input('Continue?')

    # Start the multiprocess:
    start = timeit.default_timer()
    cpu_count = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=int(.7 * cpu_count))
    pool.map(textextractor, hocr_html_fn_list_filtered)
    pool.close()
    pool.join()
    stop = timeit.default_timer()
    print "INSIGHT EXTRACT TEXT - TIME TO COMPLETE: " + str(stop - start)
