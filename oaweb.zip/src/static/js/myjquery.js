/// Define JQuery Scripts for Individual 'Full Results' slideToggles
$(document).ready(function(){
	$("a.reportsection").click(function(e){
		e.preventDefault();
	});

	$('#otherflagsdiv1, #otherflagsdiv2, #otherflagsdiv3, #otherflagsdiv4, #otherflagsdiv5, #otherflagsdiv6, #otherflagsdiv7, #casesummary_moreinfodiv, #impexp_moreinfodiv, #impexp_allgn_impairmentsdiv, #impexp_allgn_findingsdiv, #sso_moreinfodiv, #alerts_moreinfodiv, #rfcdotmoreinfodiv, #bmi_moreinfodiv, #childbmi_moreinfodiv, #templategen_moreinfodiv, #agecalc_moreinfodiv, #impexp_moreinfodiv, #sso_moreinfodiv, #templategen_moreinfodiv, #bmi_moreinfodiv, #childbmi_moreinfodiv, #agecalc_moreinfodiv').hide();

	$("#impexp_tooldiv, #templategen_tooldiv, #bmi_tooldiv, #childbmi_tooldiv, #agecalc_tooldiv, #sso_tooldiv").show();

	// For INSIGHT OAO Draft Decision product, try hiding each main section by default
	// for a cleaner appearance.
	$("#casesummary").hide();
	$("#qualityreport").hide();
	$("#tools").hide();

	$(".feedbacktogglebutton, .feedbacktogglebuttontools").each(function(index){
		var el = $(this);
		if(typeof el.data('is-accordian') !== 'undefined'){
			$('#' + el.data('toggle-id')).hide();
			el.attr('aria-label', el.attr('aria-label').replace('\u2718', 'Failed').replace("\u2714", "Passed") );
		}
	});

	$("button[type=reset]").click(function(){
		var el = $(this),
			namePrefix = el.attr('id').replace("reset", ""),
			submitBtn = $('#' + namePrefix + 'submit');

		submitBtn.val('Send').attr("disabled", false).css({
			"font-style": "normal",
			"background-color": "white",
			"cursor": "pointer"
		});
	});

	$("#casesummarymoreinfobtn, #impexpmoreinfobtn, #ssomoreinfobtn, #rfcdotmoreinfobtn, #bmimoreinfobtn, #childbmimoreinfobtn, #alertsmoreinfobtn, #templategenmoreinfobtn, #agecalcmoreinfobtn, #reportsectionbtn_casesummary, #reportsectionbtn_qualityreport, #reportsectionbtn_tools, .fullresultstogglebutton, .feedbacktogglebutton, .feedbacktogglebuttontools").click(function(){
		var el = $(this),
			item2Toggle = $('#' + el.data('toggle-id') ),
			item2Hide = $('#' + el.data('hide-id') );

		item2Toggle.slideToggle(400, function(){
			el.attr('aria-expanded', item2Toggle.is(':visible') );
		});

		if(item2Toggle.is(':visible') && item2Hide.length > 0){
			item2Hide.slideUp();
		}

		if(typeof el.data('is-accordian') !== 'undefined'){
			el.text(el.text() === '\u02c5' ? '\u02c4' : '\u02c5');
		}
    });

	/// Define JQuery script to set the present URL as the value for all hidden form inputs of class "location" (this data is used to associate feedback with a particular IQ data entry).
	var myNodeList = document.getElementsByClassName("location");
	var i;
	for (i = 0; i < myNodeList.length; i++) {
		myNodeList[i].value = window.location.href;
	}

	/// Define navigation script:
	// Add smooth scrolling to all links
	$(".navlink").on('click', function(event) {

    	// Make sure this.hash has a value before overriding default behavior
		if (this.hash !== "") {
			// Prevent default anchor click behavior
			event.preventDefault();

			if (this.hash == "#top") {
				$('html, body').animate({ scrollTop: 0}, 800, function(){
				});
				$('#top').focus();
			}
			else {
				// Store hash
				var scrollEle = $(this.hash);

				// Using jQuery's animate() method to add smooth page scroll
				// The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
				$('html, body').animate({
						scrollTop: scrollEle.offset().top-75
					}, 800, function(){
				});

				scrollEle.focus();
				}
			} // End if
		return false;
	});
});
