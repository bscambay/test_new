Running Insight API locally

1. Open the code in visual studio
2. Build the code by clicking Build from the top menu
3. Click on Internet Explorer/Google Chrome to run the application(page will show forbidden....and that's fine)

To invoke the API and display results

	4. Using Postman test using the following URLs while the above is running

	4a. http://localhost:56294/insight-request/insightuser/casepinsearch(header parameters: userpin, searchssn)
	4b. http://localhost:56294/insight-request/insightuser/casessnsrch(header parameter: userpin, body parameter: searchssn)
	4c. http://localhost:56294/insight-request/insightuser/admincases/optional parameter:(1)...if you want to verify if the pin is an admin

ALTERNATIVELY

Use postman(from step 4 above) to invoke the following URLs from DEV(S1FF515) server
	http://s1ff515:9000/insight-request/insightuser/casepinsearch(header parameters: userpin, searchssn)
	http://s1ff515:9000/insight-request/insightuser/casessnsrch(header parameter: userpin, body parameter: searchssn)
	http://s1ff515:9000/insight-request/insightuser/admincases/optional parameter:(1)...if you want to verify if the pin is an admin


Steps to successfully build 

INSIGHT-Request Project

1. open command prompt and do a git clone dev branch to local folder 
2. open Package Manager console by doing the following
	- Click Tools in the Main Menu in Visual Studio -> NuGet Package Manager -> Package Manager Console
3. At the command prompt within the console type the following
	- Update-Package -Reinstall -IgnoreDependencies (this will install all the required packages for this project in packages folder)
4. Open INSIGHT-Request.csproj in notepad and change the following
	OLD
	<Error Condition="!Exists('..\packages\Microsoft.CodeDom.Providers.DotNetCompilerPlatform.1.0.0\build\Microsoft.CodeDom.Providers.DotNetCompilerPlatform.props')" ..........
    <Error Condition="!Exists('..\packages\Microsoft.Net.Compilers.1.0.0\build\Microsoft.Net.Compilers.props')" .........
	NEW
	<Error Condition="!Exists('packages\Microsoft.CodeDom.Providers.DotNetCompilerPlatform.1.0.0\build\Microsoft.CodeDom.Providers.DotNetCompilerPlatform.props')" ..........
    <Error Condition="!Exists('packages\Microsoft.Net.Compilers.1.0.0\build\Microsoft.Net.Compilers.props')" .........

	Visual Studio will show a File Modification Detected window - Click Reload Solution
	This should resolve the failing references

5. add a .sec.json file with your credentials that allows access to PostGres DEV507
{
	"uid":"your username",
	"pwd":"your password"
}
NOTE: do not add/commit this file to git for security reasons

INSIGHT-RequestTests Project

1. Install the following packages using NuGet Package Manager(if not already installed)
	Right click on the project and select Manage NuGet Packages
	- Microsoft.AspNet.WebApi(will also install Microsoft.AspNet.WebApi.Core, Client and WebHost)
	- Newtonsoft.Json
	- System.Net.Http(will also install System.Security.Cryptography.Algorithms, System.Security.Cryptography.Encoding,
		System.Security.Cryptography.Primitives, System.Security.Cryptography.X509Certificates)
2. Add References to the following Assemblies(if not already added)
	- INSIGHT-Request	 
	- System.RunTime.Caching	
	- System.Data
	- System.Web
	
Running unit tests from Visual Studio

-In Visual Studio, select TEST from the main menu. Then Select RUN -> All TESTS to run unit tests

Running unit tests from command line(Visual Studio 2017)

	-run tests from the command line
	1. Open a Visual Studio command prompt.

	To do this, choose Start, point to All Apps, point to Visual Studio 2017 folder and select developer command Prompt for VS2017.

	By default, the command prompt opens to the following folder:

	<drive letter>:\Program Files\Microsoft Visual Studio 11.0\VC
	
	2. Change directory to the folder that contains the assembly built from your test project.
	Either change directory to your solution folder or, when you run the MSTest.exe program in step 3, specify a full or relative path to the metadata file or to the test container.

	To do this, first change directory to your solution folder. For the Bank solution that was created in the prerequisite walkthrough, this folder is: <drive>:\Users\<username>\Documents\Visual Studio 2017\Projects\InsightAPI\INSIGHT-Request. Then change directory to the folder for your test project by typing the following command at the command prompt:

	cd INSIGHT-RequestTests\bin\Debug

	This folder contains the test project you created in the procedures for creating and running unit tests. The test project assembly, INSIGHT-RequestTests.dll, contains just a few unit tests.

	3. MSTest.exe is a command-line utility that lets you start and control the execution of tests. You can view the choices that MSTest.exe makes available through its options by typing the following at the command prompt:

	MSTest /?

	4. Use the command-line utility to test the application.

	Type the following at the command prompt:

	MSTest /testcontainer:INSIGHT-RequestTests.dll

	This command runs all the tests and returns results such as the following:

	Loading INSIGHT-RequestTests.dll...

	Starting Execution...

	Results               Top Level Tests
	-------               ---------------
	Passed                INSIGHT_RequestTests.WebApiTests.admincases
	Passed                INSIGHT_RequestTests.WebApiTests.casepinsearch
	Passed                INSIGHT_RequestTests.WebApiTests.casessnsearch
	3/3 test(s) Passed	