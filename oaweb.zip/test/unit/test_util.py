'''
    unit test for util.py
'''
import os
from types import ListType
import pytest

import setup_config
import util

def test_load_data_from_fake_file():
    fake_file = 'jdfidsjfid'
    with pytest.raises(IOError):
        util.load_data_into_list(fake_file)

def test_load_small_file():
    returned_list = util.load_data_into_list(os.path.join(setup_config.CONFIG.data_dir, 'umls_sx_types_terms_list_approach3_CUSTOM.txt'))
    assert isinstance(returned_list, ListType)

# disease_list_lines = util.load_data_into_list(os.path.join(datadir, "IE_MDILIST.txt"))
# print disease_list_lines
