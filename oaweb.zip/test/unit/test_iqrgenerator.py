from decimal import *
import os
import sys

src_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../src/iqrgenerator"))
sys.path.insert(0, src_dir)
from createflagtext import createflag
from env_loader import load_dotenv


# IQR generator dictionary test data for iqr generator

iqrepgen_dict = {u'flag_rfcparb_sf_ver': 'U', u'STRUCT_AGEREL_PAISTART': '41-y-0-m', u'dobsrc': '0',
         u'adjudicator': 'Gordan Momcilovic', u'mipsrc': 'U', u'flag_s5dot_lookuperr_ver': '0',
         u'repnmadd': 'Hector Reyes 1413 Montana Avenue El Paso, TX 79902', u'dlisrc': '0',
         'srcnm': [{u'srcnm': 'James Schutte PhD', u'REQID': 35826, u'ORD_NUM': 0},
                   {u'srcnm': 'Kim Rowlands MD', u'REQID': 35826, u'ORD_NUM': 1},
                   {u'srcnm': 'Matthew Turner PhD', u'REQID': 35826, u'ORD_NUM': 2},
                   {u'srcnm': 'Alba Nevarez MD', u'REQID': 35826, u'ORD_NUM': 3},
                   {u'srcnm': 'Scott Spoor MD', u'REQID': 35826, u'ORD_NUM': 4},
                   {u'srcnm': 'Eduardo Vazquez MD', u'REQID': 35826, u'ORD_NUM': 5},
                   {u'srcnm': 'Rosalinda Cruz Garcia MD', u'REQID': 35826, u'ORD_NUM': 6},
                   {u'srcnm': 'Manoucherher Refaeian MD', u'REQID': 35826, u'ORD_NUM': 7},
                   {u'srcnm': 'Jose Barahona MD', u'REQID': 35826, u'ORD_NUM': 8},
                   {u'srcnm': 'Caren Phelan PhD', u'REQID': 35826, u'ORD_NUM': 9}], u'flag_s4dot_lookuperr_ver': '0',
         u'clnmadd': 'Laura Cristina Betancourt 12243 Via Granada El Paso, TX 79936', u'flag_rfcmdi_cts_ver': 'U',
         u'clnmaddsrc': '0', u'DOCU_CTL_ID': 'A1001001A17E23B05641E50982', u'ssn': '451372022', u'CIRCUIT_STRUCT': '5',
         u'did': '05/26/2017', u'adjudicatorsrc': '0', 'rfc': [
            {u'rfcbalancelol': 'U', u'rfcreachpresent': '0', u'rfcclimbrampstairlol': 'U', u'rfcextremeheatlol': 'U',
             u'rfcwalklol': 'U', u'body_loc_end': 41879, u'rfcvibrationlol': 'U', u'rfccolorvisionlol': 'U',
             u'rfckneelpresent': '0', u'rfctalkpresent': '0', u'rfcdepthperceptionlol': 'U', u'rfcsitstandpresent': '0',
             u'rfcnearacuitypresent': '0', u'rfccolorvisionpresent': '0', u'rfcsitlol': 'U', u'rfcfeelpresent': '0',
             u'rfchandlelol': 'U', u'rfcfeellol': 'U', u'rfcwalkpresent': '0', u'rfcexposuretoweatherpresent': '0',
             u'rfchazardslol': 'U', u'REQID': 35826, u'rfchumiditylol': 'U', u'rfccarrypresent': '0',
             u'rfcwetnesslol': 'U', u'rfcstandlol': 'U', u'rfcliftpresent': '0', u'rfcstooplol': 'U',
             u'rfcliftlol': 'U', u'rfcmentalsfintpubpresent': '1', u'rfcexlvl_parsed': 'L',
             u'rfcfootcontrolspresent': '0', u'rfctastepresent': '0', u'rfcextremecoldlol': 'U', u'ORD_NUM': 0,
             u'rfctoxiccausticchemicalslol': 'U', u'rfcstooppresent': '0', u'rfctxtsrc': '3', u'rfchearpresent': '0',
             u'rfcfaracuitylol': 'U', u'rfcnoisepresent': '0',
             u'rfctxt': '5. After careful consideration of the entire record, the undersigned finds that the claimant has the residual functional capacity to perform light work as defined in 20 CFR 404.1567(b) except the claimant is limited to understand, remember, and carry out simple job instructions and work-related tasks. In addition, the claimant is limited to occasional interaction with supervisors, coworkers, and the public.  ',
             u'rfctoxiccausticchemicalspresent': '0', u'rfcfootcontrolslol': 'U', u'rfcpulllol': 'U',
             u'rfcclimbpresent': '0', u'rfcreachlol': 'U', u'rfcfingerpresent': '0', u'rfccrawllol': 'U',
             u'rfcmovingmechanicallol': 'U', u'rfcmentalcpppresent': '1', u'rfccrouchpresent': '0',
             u'rfcwetnesspresent': '0', u'rfcpushpullpresent': '0', u'rfchearlol': 'U', u'rfctalklol': 'U',
             u'rfcclimblrslol': 'U', u'rfcdepthperceptionpresent': '0', u'rfckneellol': 'U',
             u'rfcallmanipulativespresent': '0', u'loc_end': 15909, u'loc_st': 15497, u'rfcaccomodationlol': 'U',
             u'rfcnearacuitylol': 'U', u'rfctastelol': 'U', u'rfcfaracuitypresent': '0', u'rfchazardspresent': '0',
             u'rfchumiditypresent': '0', u'rfcexposuretoweatherlol': 'U', u'rfcvibrationpresent': '0',
             u'rfcfitexlvl': 'L', u'rfcsitpresent': '0', u'rfcatmosphericconditionslol': 'U',
             u'rfcfieldofvisionlol': 'U', u'rfcexposedheightslol': 'U', u'rfcatmosphericconditionspresent': '0',
             u'rfcextremetempspresent': '0', u'rfccrouchlol': 'U', u'rfccrawlpresent': '0', u'rfchandlepresent': '0',
             u'rfcstandpresent': '0', u'rfcmentalsfintanypresent': '1', u'rfcexposedheightspresent': '0',
             u'rfcfingerlol': 'U', u'rfcmovingmechanicalpresent': '0', u'rfcpushlol': 'U',
             u'rfcaccomodationpresent': '0', u'rfcsmelllol': 'U', u'rfcbalancepresent': '0', u'rfccarrylol': 'U',
             u'rfcsmellpresent': '0', u'rfcfieldofvisionpresent': '0', u'rfcclimbingobjectspresent': '0'}],
         u'repnmaddsrc': '0', u'REQID': 35826, 'struct_oao': [
            {u'CRITL_CASE_CTGY_SW': 'N', u'WKLD_TYP': 'RR ', u'SUICIDL_SW': 'N', u'DIRE_NEED_SW': 'N',
             u'PTNTLY_HOMCDL_SW': 'N', u'CLMT_DECD_SW': 'N', u'CRNT_RQSTD_DT': '06/28/2017', u'REQID': 35826,
             u'TERI_SW': 'N', u'hofc_wrk_unit_AC': Decimal('12584777')}], u'flag_rfcparb_cpp_ver': 'U',
         u'paistart': '02/18/2014', 'mdi': [{u'S2_ORD_NUM': 0, u'REQID': 35826, u'TXT': 'MAJOR DEPRESSIVE DISORDER',
                                             u'TYP': "['Mental or Behavioral Dysfunction']", u'CUI': "['C1269683']"},
                                            {u'S2_ORD_NUM': 0, u'REQID': 35826, u'TXT': 'CHRONIC PAIN SYNDROME',
                                             u'TYP': "['Disease or Syndrome']", u'CUI': "['C1298685']"},
                                            {u'S2_ORD_NUM': 0, u'REQID': 35826, u'TXT': 'MYOSITIS',
                                             u'TYP': "['Disease or Syndrome']", u'CUI': "['C0027121']"},
                                            {u'S2_ORD_NUM': 0, u'REQID': 35826, u'TXT': 'MYALGIA',
                                             u'TYP': "['Sign or Symptom']", u'CUI': "['C0231528']"}],
         u'flag_s3ver3nomeref_ver': 'U', u'flag_s5mvrlookuperr_ver': 'U', u'flag_rfcmdi_blind_ver': 'U',
         u'edversrc': '2', u'clzipsrc': '0', u'dli': '12/31/2019', u'flag_s5mvrnoprw_ver': 'U', 's3feq': [],
         u'STRUCT_AGEREL_PAISTART_SRC': '0', u'flag_s2txtuncertain_ver': 'U', u'repzipsrc': '0', u'repzip': '79902',
         u'clnm': 'Laura Cristina Betancourt', u'STRUCT_AGE_DID': '44-y-3-m', u'paiend': '05/26/2017',
         u'flag_rfc_logicconflict_ver': '0', u'clzip': '79936', u'clnmsrc': '0', u'flag_s4dotrfc_ver': 'U',
         'mvr': [{u's5mvr': '202.20', u's5mvrsrc': '0', u'REQID': 35826, u'S5_ORD_NUM': 0}],
         u'flag_rfc_vague_fa_ver': '0', u'STRUCT_AGEREL_PAIEND_SRC': '0', u'flag_s5dotrfc_ver': '0',
         u'flag_s4ver1s4actgenu_ver': 'U', u'flag_s5mvred_ver': '1', u'circuit': '5', u'flag_s5mvragepaiend_ver': '0',
         u'verefbg': '1', u'daamatsrc': 'U', u'merefbg': 'U', u'ssnsrc': '0', u'flag_rfc_vague_gen_ver': '0',
         u'venm': 'U', 'quality': [
            {u'ver': '1', u'nm': 'flag_s5mvred_val', u'val': '202.20', u'cn1': 's5', u'REQID': 35826, u'ORD_NUM1': '0',
             u'ORD_NUM2': 'U', u'cn2': 'U'}], u'flag_s2txtsxasmdi_ver': 'U',
         's4dot': [{u'REQID': 35826, u's4dotloc': 'B', u'S4_ORD_NUM': 0, u's4dotnum': '381687018'}], u'aodsrc': '0',
         u'daamat': 'U', u'flag_s5bordage_ver': 'U', u'didsrc': '0', 'claimdisp': [
            {u'disptype': '1', u'REQID': 35826, u'ORD_NUM': 0, u'dof': '12/02/2014', u'claimtype': 'T2 DIB'}],
         u'otrref': 'U', u'flag_s5mvragepai_ver': '0', u'txskillsver': '3', u'edver': 'I; H', u'repnm': 'Hector Reyes',
         u'merefbody': 'U', u'flag_s2txtonlysx_ver': 'U', 's3mteq': [
            {u'ORD_NUM': 0, u's3parbsf': 'U', u'body_loc_end': 15497, u's3parbcpp': 'U', u's3mteqtxtsrc': '0',
             u's3mteqver': '1', u'REQID': 35826, u's3parbdecomp': 'U', u's3mteqversrc': '0', u's3mteqlistnum': 'U',
             u's3parbadl': 'U', u'loc_st': 5197, u'loc_end': 5436,
             u's3mteqtxt': '4. The claimant does not have an impairment or combination of impairments that meets or medically equals the severity of one of the listed impairments in 20 CFR Part 404, Subpart P, Appendix 1 (20 CFR 404.1520(d), 404.1525 and 404.1526).'}],
         'struct_hodisp': [{u'T16_DSPN_CD': '    ', u'CLMT_SSN': '451372022', u'CLM_TYP': 'DIWC', u'CASE_GRP_CD': '02',
                            u'WG_ERNR_SSN': '451372022', u'T16_PFLG_DT': 'E', u'REQID': 35826, u'T2_DSPN_CD': 'UAFF',
                            u'T16_APP_DT': 'E', u'HT_INCH': '62', u'WT_LB': '165.0', u'T16_GLBL_BSS_UID_1': 'nan',
                            u'EFLDR_NUM': Decimal('205127938'), u'CLMT_ST': 'TX', u'BIC': 'A ', u'SEX': 'F',
                            u'CLMT_NM25': 'BETANCOURT, LAURA C      ', u'HRG_TYP': '10', u'T2_PFLG_DT': '12/02/2014',
                            u'HRG_ISU_CD': 'D', u'HOFC_WRK_UNIT_UID': Decimal('11066274'), u'T16_PRTL_FFVRBL_CD': ' ',
                            u'HEDULVL_CD': '13 ', u'T2_PRTL_FFVRBL_CD': ' ', u'REP_UID': '24427', u'DLI': '12/31/2019',
                            u'T2_APP_DT': '12/02/2014', u'ALLGD_DISB_ONST_DT': '02/18/2014',
                            u'T16_GLBL_BSS_UID_2': 'nan', u'OHA_DAA_CD': 'I', u'CLMT_DOB': '02/01/1973',
                            u'T2_GLBL_BSS_UID_1': '62', u'T2_GLBL_BSS_UID_2': 'nan', u'FNL_DSPN_DT': '05/23/2017',
                            u'TRML_ILLNESS_SW': 'N', u'EDIB_CD': 'F', u'CLM_UID': Decimal('11003697')}],
         u'flag_s2mdi_selfwt_ver': '0', 'CLAIMDISP_STRUCT': [
            {'PRTL_FFVRBL_CD': ' ', 'ALLGD_DISB_ONST_DT': '02/18/2014', 'DLI': '12/31/2019',
             'FNL_DSPN_DT': '05/23/2017', 'DSPN_CD': 'UAFF', 'PFLG_DT': '12/02/2014', 'CLM_TYP': 'T2 DIB',
             'APP_DT': '12/02/2014'}], u'repnmsrc': '0', u'flag_s5mvrtx_ver': 'U', u'flag_s5mvrrfcexlvl_ver': 'U',
         u'STRUCT_AGEREL_PAIEND': '44-y-3-m', u'verefbody': '1', 's5': [{u'ORD_NUM': 0, u's5versrc': '0',
                                                                         u's5txt': "10. Considering the claimant's age, education, work experience, and residual functional capacity, there are jobs that exist in significant numbers in the national economy that the claimant can perform",
                                                                         u's5txtsrc': '0', u'loc_end': 43432,
                                                                         u'REQID': 35826, u's5ver': '1',
                                                                         u'body_loc_end': 'U', u'loc_st': 43232,
                                                                         u's5fwkdir': '1; 2'}], 's4': [
            {u's4jobscanperf': 'U', u'ORD_NUM': 0, u'body_loc_end': 43232, u'REQID': 35826, u's4jobscanperfct': 'U',
             u'loc_end': 41959,
             u's4txt': '6. The claimant is unable to perform any past relevant work (20 CFR 404.1565).', u's4ver': '2',
             u's4versrc': '0', u's4txtsrc': '0', u'loc_st': 41879, u's4actgen': 'U'}], u'ssnxref': 'U',
         u'txskillsversrc': '0', u'mip': 'U', 'struct_exp': [
            {u'HOFC_WRK_UNIT_UID': '11066274', u'ACKT_RCVDT': 'MS. ', u'INSERT_TS': 'nan', u'SFX': 'U',
             u'TITLE': 'PAULINE        ', u'DEV_GRP': 'nan', u'MED_SPCLY_CD': '    ', u'LNM': '    ', u'REQID': 35826,
             u'MNM': 'RODRIGUEZ           ', u'FNM': '               ', u'SCHD_SW': 'Y', u'EXPERT_UID': '29597',
             u'ATTNDD_SW': 'Y'},
            {u'HOFC_WRK_UNIT_UID': '11066274', u'ACKT_RCVDT': '    ', u'INSERT_TS': 'nan', u'SFX': 'U',
             u'TITLE': 'HOWARD         ', u'DEV_GRP': 'nan', u'MED_SPCLY_CD': '    ', u'LNM': '    ', u'REQID': 35826,
             u'MNM': 'MARNAN              ', u'FNM': 'J.             ', u'SCHD_SW': 'Y', u'EXPERT_UID': '2116',
             u'ATTNDD_SW': 'Y'},
            {u'HOFC_WRK_UNIT_UID': '11066274', u'ACKT_RCVDT': '    ', u'INSERT_TS': 'nan', u'SFX': 'U',
             u'TITLE': 'REQUEST        ', u'DEV_GRP': 'nan', u'MED_SPCLY_CD': '    ', u'LNM': '    ', u'REQID': 35826,
             u'MNM': 'REQUEST INTERPRETER ', u'FNM': 'INTERPRETER    ', u'SCHD_SW': 'Y', u'EXPERT_UID': '51571',
             u'ATTNDD_SW': 'Y'}], u'aod': '02/18/2014', u'aodamendver': 'U',
         's5dot': [{u'REQID': 35826, u's5dotnum': '323687014', u'S5_ORD_NUM': 0},
                   {u'REQID': 35826, u's5dotnum': '706684022', u'S5_ORD_NUM': 0},
                   {u'REQID': 35826, u's5dotnum': '369687018', u'S5_ORD_NUM': 0}], u'dob': '02/01/1973',
         u'flag_rfcits_ver': '0', 's1sga': [{
                                                u's1sgatxt': '2. The claimant has not engaged in substantial gainful activity since February 18, 2014, the alleged onset date (20 CFR 404.1571 et seq.).',
                                                u's1sgaver': '1', u'ORD_NUM': 0, u'body_loc_end': 735, u'REQID': 35826,
                                                u'loc_end': 390, u's1sgatype': 'U', u's1sga_startdt': 'U',
                                                u's1sgatxtsrc': '0', u's1sgaversrc': '0', u'loc_st': 250,
                                                u's1sga_enddt': 'U'}], 's2': [{u'ORD_NUM': 0,
                                                                               u's2txt': '3. The claimant has the following severe impairments: (1) myalgia and myositis, not otherwise specified/chronic pain syndrome/unspecified somatic symptom disorder, (2) mild intellectual disorder, and (3) major depressive disorder (20 CFR 404.1520(c)',
                                                                               u'body_loc_end': 5197, u's2txtsrc': '0',
                                                                               u'loc_end': 984, u'REQID': 35826,
                                                                               u's2ver': '1', u'loc_st': 735,
                                                                               u's2versrc': '0'}], u'ssnxrefsrc': 'U',
         u's5mvrlookuperr': '[]'}


# Test create flag functionality in the iq generator module specifically S5 flag.
# IQR generator dictionary test data is used as input for testing.
class TestCreateflagtext(object):
    def test_createflagtext(self):
        cf = createflag(**iqrepgen_dict)
        result = cf.createflagtext_nonselfcontained(varnm = "flag_s5mvred", valpresent = "1")
        assert result == '&#x2718; Education level(s) found: Illiterate High School vs MVR(s): 202.20'

    def test_createflagtext_none(self):
        cf = createflag(**iqrepgen_dict)
        result = cf.createflagtext_nonselfcontained(varnm = "flag_s5mvred", valpresent = "1")
        assert result != '&#xFF18;  level(s) found: Illi rate vs MV(s): 202.20'


# Test if environment variables are present for the eview_url
def test_env_variables_are_loaded():
    """
    This test makes sure the env variables needed in iqrgenerator are available.

    load_dotenv() loads the .env file into the environment.
    This call is only for tests being run on local development.
    Has no effect in any other environment since the env variables are preloaded.
    """
    load_dotenv()
    eview_url = os.environ.get('INSIGHT_EVIEW_URL', '')
    decision_url = os.environ.get('INSIGHT_DECISION_URL', '')
    assert eview_url != ''
    assert decision_url != ''
